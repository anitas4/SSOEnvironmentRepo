TW.IDE.Widgets.messageformat = function () {
    "use strict";
	var thisWidget = this;
	this.MAX_INPUT_VALUES = 24;
	this.widgetIconUrl = function() {
        return  "../Common/extensions/MessageFormatWidget-extension/ui/messageformat/images/messageformat-widget.png";
    }
	this.widgetProperties = function () {
		 var properties = {
			'name': 'Message Format',
			'description': 'Formats message text. Use is similar to Java MessageFormat, and can be used with localizable token. For example: Input "Do you want to delete {0}" value0=test => "Do you want to delete test"',
			'category': ['Common'],
			'properties': {
                'Width': {
                    'description': 'Width of widget',
                    'defaultValue': 200
                },
                'Height': {
                    'description': "Height of widget",
                    'defaultValue': 28
                },
                'InputMessage': {
                    'isVisible': true, 
                    'baseType': 'STRING',
                    'defaultValue': '',
                    'description': "The message to be evaluated",
                    'isLocalizable': true,
					'isBindingTarget': true,
					'isEditable': true
                },
                'AutoEvaluate': {
                    'isVisible': true, 
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    'description': "The message is automatically evaluated when enabled"
                },
                'DataChangeType': {
                	'isVisible': false, 
                	'isBindingTarget': false,
                    'description' : TW.IDE.I18NController.translate('tw.expression-ide.properties.data-change-type.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'VALUE',
                    'selectOptions': [
                        { value: 'VALUE', text: TW.IDE.I18NController.translate('tw.expression-ide.properties.data-change-type.select-options.value') },
                        { value: 'ALWAYS', text: TW.IDE.I18NController.translate('tw.expression-ide.properties.data-change-type.select-options.always') },
                        { value: 'NEVER', text: TW.IDE.I18NController.translate('tw.expression-ide.properties.data-change-type.select-options.never') }
                    ]
                },
                'Output': {
                    'isVisible': true, 
                    'baseType': 'STRING',
                    'isBindingSource': true,
                    'description': "The message formated output"
                },
                'EscapeHTML': {
                    'description': 'Escape html tags like for example >',
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true
                },
                'NumberOfValues': {
                    'description': 'Number of input values',
                    'defaultValue': 1,
                    'baseType': 'NUMBER',
                    'isVisible': true
                }
            }
		}
		var inputValuesNumber;
		 
		
        for (inputValuesNumber = 0; inputValuesNumber < this.MAX_INPUT_VALUES; inputValuesNumber++) {
        	var isVisible = false;
        	if ( inputValuesNumber ==0){
        		isVisible = true;
        	}
            var inputValueProperty = {
                'description': 'Input value ' + inputValuesNumber,
                'isBindingTarget': true,
                'isEditable': true,
                'baseType': 'STRING',
                'warnIfNotBoundAsTarget': false,
                'isVisible': isVisible,
                'isLocalizable': false
            };
            properties.properties['InputValue' + inputValuesNumber] = inputValueProperty;
        }
        return properties;
	};
	
	this.setInputValuesProperties = function(value) {
        var allWidgetProps = this.allWidgetProperties();
        var inputValuesNumber;
		for (inputValuesNumber = value ; inputValuesNumber < this.MAX_INPUT_VALUES; inputValuesNumber++) {
            allWidgetProps['properties']['InputValue' + inputValuesNumber]['isVisible'] = false;
        }
		for (inputValuesNumber = 0; inputValuesNumber < value; inputValuesNumber++) {
            allWidgetProps['properties']['InputValue' + inputValuesNumber]['isVisible'] = true;
        }
        
    };
    
    this.afterLoad = function () {
        this.setInputValuesProperties(this.getProperty('NumberOfValues'));
    };
    
    
	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':
			case 'MessageFormat Property':
				thisWidget.jqElement.find('.messageformat-property').text(value);
			case 'Alignment':
				refreshHtml = true;
				break;
			case 'NumberOfValues':
				this.setInputValuesProperties(this.getProperty('NumberOfValues'));
		        this.updatedProperties();
		        refreshHtml = true;
		        break;   
			default:
				break;
		}
		
		return refreshHtml;
	};
	
	this.beforeSetProperty = function (name, value) {
        if (name === 'NumberOfValues') {
            value = parseInt(value, 10);
            if (value < 0 || value >= 24)
                return 'Number of values must be beetwen 0 and 24';
        }
    };
    

	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-messageformat">' +
					'<span class="messageformat-property">' + "MessageFormat: Invisible at Runtime" + '</span>' +
				'</div>';
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		valueElem = this.jqElement.find('.messageformat-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		valueElem.text(this.getProperty('MessageFormat Property'));
	};
	
	this.widgetEvents = function () {
	        return {
	            'Changed': {}
	        };
    };
    
    
    this.widgetServices = function () {
        return {
            'Evaluate': { 'warnIfNotBound': true }
        };
    };
    
};
