﻿TW.IDE.Widgets.genericradiobutton = function () {
  
  this.widgetIconUrl = function() {
    return  "../Common/extensions/RadioButton_ExtensionPackage/ui/radiobutton/radiobutton.ide.png";
  };
  
  this.widgetProperties = function () {

    return {
      'name': 'Generic Radio Button',
      'description': 'Enables user to select an option from a group of choices',
      'category': ['Common'],
      'dataSourceProperty': 'SelectedValue',
      'defaultBindingTargetProperty': 'SelectedValue',
      'properties': {
        'Orientation': {
          'baseType': 'STRING',
          'defaultValue': 'vert',
          'selectOptions': [
            { value: 'horz', text: 'Horizontal' },
            { value: 'vert', text: 'Vertical'}
          ],
          'isVisible': true,
          'description': 'Select how the buttons should be aligned'
        },
        'LabelOrientation': {
          'baseType': 'STRING',
          'defaultValue': 'right',
          'selectOptions': [
            { value: 'right', text: 'Right of Radio' },
            { value: 'left', text: 'Left of Radio'}
          ],
          'isVisible': true,
          'description': 'Select which side the label is on'
        },
        'SelectedValue': {
          'isBindingSource': true,
          'isBindingTarget': true,
          'baseType': 'STRING',
          'isVisible': true,
          'isEditable' : false,
          'description': 'Get or Set value which drives the State'
        },
        'SelectedText': {
          'isBindingSource': true,
          'isBindingTarget': true,
          'baseType': 'STRING',
          'isVisible': true,
          'isEditable': false,
          'description': 'Get or Set the name of the selected State'
        },
        'ReadOnly': {
          'description': 'If set to true, only displays the current state',
          'baseType': 'BOOLEAN',
          'isVisible': true,
          'defaultValue': false
        },
        'Width': {
          'description': 'Total width of the widget',
          'baseType': 'NUMBER',
          'isVisible': true,
          'defaultValue': 100
        },
        'Height': {
          'description': 'Total height of the widget',
          'baseType': 'NUMBER',
          'isVisible': true,
          'defaultValue': 200
        },
        'ButtonStates': {
          'description': 'Auto-populate radio buttons with names and values from a state definition.',
          'isVisible': true,
          'baseType': 'STATEDEFINITION'
        }
      }
    };
  };

  this.widgetEvents = function () {
    return { 'SelectionChanged': {} };
  };

  this.numberOfStates = 0;
  this.stateDefinitions = undefined;

  this.renderHtml = function () {

    var html = '<div class="widget-content" >'; 
    html +=     '<span class="select-button-states-text">';
    html +=       'Choose ButtonStates in Widget Properties'; 
    html +=     '</span>';
    html +=    '</div>';
    
    var i;
    var stateDefinitionName = this.getProperty('ButtonStates');
    var buttonStates;
    var stateInfo;
    var buttonText;
    var textSize, otherCssStyles, formatResult;
    
    if (stateDefinitionName !== undefined) {
    
      buttonStates = TW.getStateDefinition(stateDefinitionName);

      this.stateDefinitions = buttonStates.content.stateDefinitions;

      if (buttonStates.content.stateType === 'numeric') {
        this.numberOfStates = this.stateDefinitions.length;
      } else {
        this.numberOfStates = this.stateDefinitions.length - 1;
      }

      html = '<div class="widget-content" '; 
      html +=   'orientation="' + this.getProperty('Orientation') + '" '; 
      html +=   'labelOrientation ="'+ this.getProperty('LabelOrientation') +'" ';
      html +=   'style="width:' + this.getProperty('Width') + 'px ';
      html +=   'height:' + this.getProperty('Height') + 'px">';
      html += '<ul class="widget-radio-button">';

      labelOrientation = this.getProperty('LabelOrientation');

      for (i = 0; i < this.numberOfStates; i++) {
        
        stateInfo = this.stateDefinitions[i];
        buttonText = stateInfo.displayString;
        textSize = 'textsize-normal';
        otherCssStyles = '';
        formatResult = TW.getStyleFromStyleDefinition(stateInfo.defaultStyleDefinition);
        
        if (formatResult !== undefined) {
          textSize = TW.getTextSizeClassName(formatResult.textSize);
          otherCssStyles = TW.getStyleCssTextualFromStyle(formatResult);
        }

        if(labelOrientation === 'right') {
          html += '<li class="widget-radio-button-item">';
          html +=   '<input id="radio'+ i +'" type="radio" name="rb" value="' + buttonText + '"';
          html += ' />';
          html += '<label for="radio'+ i +'" style="'+ otherCssStyles +'" class="'+ textSize +'">' + Encoder.htmlEncode(buttonText) + '</label>';
          html += '</li>';
        } else {
          html += '<li class="widget-radio-button-item">';
          html += '<label for="radio'+ i +'" style="'+ otherCssStyles +'" class="'+ textSize +'">' + Encoder.htmlEncode(buttonText) + '</label>';
          html +=   '<input id="radio'+ i +'" type="radio" name="rb" value="' + buttonText + '"';
          html += ' />';
          html += '</li>';
        }

      }  
      
      html += '</ul>';
      html += '</div>';

    }

    return html;
  };

  this.afterSetProperty = function (name, value) {
    
    var thisWidget = this;
    var result = false;
    
    switch (name) {
      case 'Width':
      case 'Height' :
      case 'Orientation':
      case 'LabelOrientation':
      case 'ButtonStates':
        result = true;
        break;
      default:
        break;
    }
    
    return result;
  };

  this.afterRender = function () {
    
    var stateDefinitionName = this.getProperty('ButtonStates');
    var pctWidth = 100;
    var buttonStates;
    var widgetElement = this.jqElement;
    var widget = this;
    var styleBlock;

    if (stateDefinitionName !== undefined) {
      buttonStates = TW.getStateDefinition(stateDefinitionName);

      this.stateDefinitions = buttonStates.content.stateDefinitions;

      if (buttonStates.content.stateType === 'numeric') {
        this.numberOfStates = this.stateDefinitions.length;
      } else {
        this.numberOfStates = this.stateDefinitions.length - 1;
      }

    }
    
    styleBlock =  '<style>';
    styleBlock += '</style>';
      
    $(styleBlock).prependTo(widgetElement);

  };

  this.validate = function () {
    
    var result = [];
    
    if (!this.isPropertyBoundAsSource('SelectedValue') && !this.isPropertyBoundAsTarget('SelectedValue')) {
      result.push({ 
        severity: 'warning', 
        message: 'Either SelectedValue or SelectedText for {target-id} must be bound as a source or a target' 
      });
    }

    if (this.getProperty('ButtonStates') === undefined) {
      result.push({ 
        severity: 'warning', 
        message: 'ButtonStates for {target-id} must be configured' 
      });
    }

    return result;
  
  };
  
};
