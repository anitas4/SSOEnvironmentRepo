﻿TW.Runtime.Widgets.genericradiobutton = function () {
  
  var thisWidget = this;

  this.runtimeProperties = function () {
    return {
      'needsDataLoadingAndError': true
    };
  };
  
  this.numberOfStates = 0;
  this.stateDefinitions = undefined;
  this.isNumeric = false;
  this.isReadOnly = false;
  this.labelOrientation = undefined;

  this.renderHtml = function () {
    
    var html = '<div class="widget-content">Select Button States</div>';
    var i;
    var widget = this;
    var stateDefinitionName = widget.properties['ButtonStates'];
    var buttonStates;
    var isDisabled, isChecked;
    var stateInfo, buttonText, buttonValue;
    var textSize, otherCssStyles, formatResult;
    var buttonIndex = 0;

    if (widget.getProperty('ReadOnly') === true) {
      widget.isReadOnly = true;
    }

    if (stateDefinitionName !== undefined) {

      buttonStates = TW.getStateDefinition(stateDefinitionName);
      
      if (buttonStates !== undefined) {

        this.stateDefinitions = buttonStates.content.stateDefinitions;

        if (buttonStates.content.stateType === 'numeric') {
          this.numberOfStates = this.stateDefinitions.length;
          this.isNumeric = true;
        } else {
          this.numberOfStates = this.stateDefinitions.length - 1;
          this.isNumeric = false;
        }
        
        html = '<div class="widget-content" ';
        html +=   'orientation="' + this.getProperty('Orientation') + '" ';
        html +=   'labelOrientation ="'+ this.getProperty('LabelOrientation') +'" ';
        html +=   'style="width:' + this.getProperty('Width') + 'px ';
        html +=   'height:' + this.getProperty('Height') + 'px">';
        html += '<ul class="widget-radio-button">';

        labelOrientation = this.properties['LabelOrientation'];

        for (i = 0; i < this.numberOfStates; i++) {
            
            stateInfo = this.stateDefinitions[buttonIndex++];
            buttonText = stateInfo.displayString;
            if (stateInfo.defaultValue === undefined) {
              buttonValue = '';
            } else {
              buttonValue = stateInfo.defaultValue.toString();
            }
            isDisabled = widget.properties['ReadOnly'];
            isChecked = false;
            textSize = 'textsize-normal';
            otherCssStyles = '';
            formatResult = TW.getStyleFromStyleDefinition(stateInfo.defaultStyleDefinition);
            
            if (formatResult !== undefined) {
                textSize = TW.getTextSizeClassName(formatResult.textSize);
                otherCssStyles = TW.getStyleCssTextualFromStyle(formatResult);
            }

            if (labelOrientation === 'right') {
                html += '<li class="widget-radio-button-item" selected-value="' + buttonValue + '" state-name="' + buttonText + '">';
                html +=   '<input id="radio'+ i +'" type="radio" name ="' + this.jqElementId + '" value="' + buttonText + '"';
                html +=   isDisabled ? ' disabled ' : '';
                html +=   isChecked ? ' checked ' : '';
                html += ' />';
                html += '<label for="radio'+ i +'" style="'+ otherCssStyles +'" class="'+ textSize +'">' + Encoder.htmlEncode(buttonText) + '</label>';
                html += '</li>';
            } else {
                html += '<li class="widget-radio-button-item" selected-value="' + buttonValue + '" state-name="' + buttonText + '">';
                html += '<label for="radio'+ i +'" style="'+ otherCssStyles +'" class="'+ textSize +'">' + Encoder.htmlEncode(buttonText) + '</label>';
                html +=   '<input id="radio'+ i +'" type="radio" name ="' + this.jqElementId + '" value="' + buttonText + '"';
                html +=   isDisabled ? ' disabled ' : '';
                html +=   isChecked ? ' checked ' : '';
                html += ' />';
                html += '</li>';
            }

        }  
        
        html += '</ul>';
        html += '</div>';

      }
      return html;
    }
  };

  var liClicked = function (widget, liElem) {
    
    widget.jqElement.find('input:radio').removeAttr('checked');
        
    if (liElem === undefined) {
      
      if (widget.isNumeric) {
        
        liElem = widget.jqElement.find('li:last');
        liElem.find('input').prop('checked', true);
        widget.setProperty('SelectedText', liElem.find('label').text());
        
      } else {
        
        widget.setProperty('SelectedValue', undefined);
        widget.setProperty('SelectedText', undefined);
        
      }
      
    } else {
      
      liElem.find('input').prop('checked', true);
      widget.setProperty('SelectedValue', liElem.attr('selected-value'));
      widget.setProperty('SelectedText', liElem.find('label').text());
      
    }

    widget.jqElement.triggerHandler('SelectionChanged');

  };

  this.afterRender = function () {
    
    var stateDefinitionName = this.getProperty('ButtonStates');
    var pctWidth = 0;
    var buttonStates;
    var widgetElement = this.jqElement;
    var widget = this;
    var styleBlock;
    var rbElem;
    var firstRadio;

    if (stateDefinitionName !== undefined) {
      buttonStates = TW.getStateDefinition(stateDefinitionName);

      this.stateDefinitions = buttonStates.content.stateDefinitions;

      if (buttonStates.content.stateType === 'numeric') {
        this.numberOfStates = this.stateDefinitions.length;
      } else {
        this.numberOfStates = this.stateDefinitions.length - 1;
      }

    }
    
    styleBlock =  '<style>';
    styleBlock += '</style>';
      
    $(styleBlock).prependTo(widgetElement);

    if (!widget.isReadOnly) {
      widgetElement.find('li').bind('click', function (event) {  
        rbElem = TW.closestElementWithClass($(event.target), 'widget-radio-button-item');
        liClicked(widget, rbElem);
      });
    }

  };

  this.updateProperty = function (updatePropertyInfo) {
    
    var widget = this;
    var radio;
    var liElem = undefined;
    var val, fmt, limit;
    var isThisTheOne = false;
    var i=0;
    
    if (updatePropertyInfo.TargetProperty === "SelectedValue") {

      // if the value they set is undefined, we'll select the last button
      if (updatePropertyInfo.SinglePropertyValue !== undefined) {
        
        if (widget.isNumeric) {
        
          val = parseFloat(updatePropertyInfo.SinglePropertyValue);
          
          for (i; i < widget.stateDefinitions.length && liElem === undefined; i++) {
            
            fmt = widget.stateDefinitions[i];
            
            if (i === (widget.stateDefinitions.length - 1)) {
              liElem = widget.jqElement.find('li:last');
            } else {
              
              isThisTheOne = false;
              limit = parseFloat(fmt.defaultValue);
              
              if (fmt.comparator === '<=') {
                if (val <= limit) {
                  isThisTheOne = true;
                }
              } else if (fmt.comparator === '<') {
                if (val < limit) {
                  isThisTheOne = true;
                }
              } else if (fmt.comparator === '==') {
                if (val === limit) {
                  isThisTheOne = true;
                }
              }
              
              if (isThisTheOne) {
                liElem = widget.jqElement.find('li[selected-value="' + fmt.defaultValue.toString() + '"]');
              }
            }
          }
        } else {
          liElem = widget.jqElement.find('li[selected-value="' + updatePropertyInfo.SinglePropertyValue + '"]');
        }
      }

      liClicked(widget, liElem);
   
    } else if (updatePropertyInfo.TargetProperty === "SelectedText") {
     
      liElem = undefined;

      if (updatePropertyInfo.SinglePropertyValue !== undefined) {
        liElem = widget.jqElement.find('li[state-name="' + updatePropertyInfo.SinglePropertyValue + '"]');
      }

      liClicked(widget, liElem);
    }

  }
  
};
