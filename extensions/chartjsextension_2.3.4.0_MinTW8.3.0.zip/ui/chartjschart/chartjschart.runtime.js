TW.Runtime.Widgets.chartjschart= function () {
	var valueElem;
	var xValue;
	var yValue;
	var clickLabel;
	var dataSetIndex;
	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName). In
		// this example, we'll just return static HTML
		return 	'<div class="widget-content widget-chartjschart">' +
					'<canvas></canvas>' +
				'</div>';
	};
	
	var fireClickedEvent = function(){
		//console.log("in fireClickedEvent with xValue>>"+ xValue + " and y value >>" + yValue)
		thisWidget.setProperty('clickedDataSet', dataSetIndex);
		thisWidget.setProperty('clickedXLabel', xValue);
		thisWidget.setProperty('clickedYValue', yValue);
		thisWidget.setProperty('uniqueProperty', clickLabel);
		thisWidget.jqElement.triggerHandler('clicked');
	};

	this.properties.ResponsiveLayout = true;
	
	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		//valueElem = this.jqElement.find('.chartjschart-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		//valueElem.text(this.getProperty('chartjschart Property'));
		
		thisWidget = this;
		thisJqElement = thisWidget.jqElement;
		thisWidgetId = thisWidget.jqElementId;
		
		if(this.properties.ResponsiveLayout) {
			var width= this.jqElement.width();
		}
		
		thisWidget.jqElement.bind('click', function (e) {
			fireClickedEvent();
		});
		
	};

	this.resize = function(width,height) {
	     // invoked when widget is resized
	}
	
	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'data') {
			//a data = updatePropertyInfo.RawDataFromInvoke;
			$(thisJqElement)[0];
			$(thisJqElement).empty();
			$(thisJqElement)[0].innerHTML = '<canvas></canvas>';	
			for (var i = 0; i < updatePropertyInfo.ActualDataRows.length; i++) {
	            var row = updatePropertyInfo.ActualDataRows[i].jsonData;
	            var myJSON = JSON.stringify(row);
	            var obj = JSON.parse(myJSON);
	            //thisWidget.setProperty('uniqueProperty', obj.displayLabel);
	            var chartObj;
	            if(isNaN(obj.uniqueID)){
	            	chartObj = $(thisJqElement)[0].childNodes[0];
	            }else{
	            	chartObj = $("canvas")[obj.uniqueID];
	            	//var id = obj.uniqueID + 1;
	            	//chartObj = $('#cell_IOT_PTA_MU_RejectRatePerBatchObject-'+ id +'_chartjschart-14')[0].childNodes[0];
	            }
	            
	            var chart;
	            if(chartObj !== 'undefined'){
	            	chart = new Chart(chartObj,row);
	            	this.setProperty('dataJson', row);
	            }else{
	            	//console.log("in else undefined");
	            }
	        }
			
			chartObj.onclick = function (evt) {
    			var activePoints = chart.getElementsAtEventForMode(evt, 'point', chart.options);
				if(typeof activePoints[0] !== 'undefined'){
					//console.log("x = "+chart.data.datasets[activePoints[0]._datasetIndex].data[activePoints[0]._index]);
					//console.log("y = "+chart.data.labels[activePoints[0]._index]);
					//console.log("click label ="+ chart.config.displayLabel);
					//console.log("evt.srcElement.parentElement.id"+ evt.srcElement.parentElement.id);
					if(activePoints[0]._datasetIndex == 0){
						dataSetIndex = activePoints[0]._datasetIndex;
						clickLabel = chart.config.displayLabel;
						xValue = chart.data.datasets[activePoints[0]._datasetIndex].data[activePoints[0]._index];
						yValue = chart.data.labels[activePoints[0]._index];
						//var clickID = chart.config.uniqueID + 1;
						var str = evt.srcElement.parentElement.id;
						var clickID = str.substring(str.indexOf("-")+1,str.lastIndexOf("_"));
						//console.log("clickID = "+clickID);
						//$('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-26').find(':input')[0].value = xValue;
						//$('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-25').find(':input')[0].value = yValue;
						if ($('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-25').length) {
							$($($('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-25').find('input')[0])).val(yValue).trigger('change');
							$('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-27').find(':input')[0].value = clickLabel;
							$($($('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-26').find('input')[0])).val(xValue).trigger('change');
						}else if ($('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-61').length) {
							$($($('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-62').find('input')[0])).val(yValue).trigger('change');
							$($($('#cell_IOT_PTA_MU_RejectRatePerBatchObject-' + clickID +'_textbox-61').find('input')[0])).val(xValue).trigger('change');
							dataSetIndex = 0;	
						}
						else{
							console.log(" text box undefined ");
						}
					}else{
						dataSetIndex = "";
						clickLabel = "";
						xValue = "";
						yValue = "";
						//console.log("Other Dataset Indexed clicked>>" + dataSetIndex);
					}
				}else{
					dataSetIndex = "";
					clickLabel = "";
					xValue = "";
					yValue = "";
					console.log("type of click undefined")
				}	
			};
		}
	};
};