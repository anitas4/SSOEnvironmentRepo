TW.Runtime.Widgets.flexinfotable= function () {
    var thisWidget = this;
	var dataRows = undefined;
	var displayField = '';
	var selectedRow = -1;

	this.renderHtml = function () {
		var html = '<div class="widget-content fit-widget">'
		+ '</div>';
		return html;
	};

	var segmentOnClick = function(e) {
		selectedRow = $(this).index() - 1;
		thisWidget.updateSelection('Data', [selectedRow]);
		thisWidget.jqElement.triggerHandler('Clicked');
		e.stopPropagation();
		e.preventDefault();
	};

	// called whenever we need to redraw the widget
	var updateWidget = function() {
		$('#' + thisWidget.jqElementId + '> .flexinfotable-segment').remove();
		if (dataRows && dataRows.length > 0) {
			for (var i = 0; i < dataRows.length; ++i) {
				var row = dataRows[i];
				var html = '<div class="flexinfotable-segment">'
						+ row[displayField]
						+ '</div>';
				thisWidget.jqElement.append(html);
			}
		}

		$('#' + thisWidget.jqElementId + '> .flexinfotable-segment').bind('click', segmentOnClick);
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		if (updatePropertyInfo.TargetProperty === 'Data') {
			dataRows = updatePropertyInfo.ActualDataRows;
			updateWidget();
		}
	};

	this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
		selectedRow = selectedRowIndices[0];
    };	

	var getCSSFromStyle = function(styleName, style) {
		var color = style.foregroundColor;
		var backgroundColor = style.backgroundColor;
		var borderSize = style.lineThickness;
		if (borderSize === '') {
			borderSize = 0;
		}

		var borderColor = style.lineColor;
		if (borderColor === '') {
			borderColor = 'rgba(0, 0, 0, 0.0)';
		}

		return '#' + thisWidget.jqElementId + styleName + ' {'
					+ 'background-color: ' + backgroundColor + '; '
					+ 'color: ' + color + '; '
					+ 'border: ' + borderSize + 'px solid ' + borderColor + '; '
					+ TW.getTextSize(style.textSize)					
					+ '} '; 
	};	

	this.afterRender = function () {
		displayField = thisWidget.getProperty("DisplayField", "name");
		
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()
		var boxStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BoxStyle','DefaultRepeaterStyle'));
		var hoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BoxHoverStyle','DefaultRepeaterStyle'));
		var pressedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BoxPressedStyle','DefaultRepeaterStyle'));

		var margin = thisWidget.getProperty("BoxMargin");
		var padding = thisWidget.getProperty("BoxPadding");
		var height = thisWidget.getProperty("BoxHeight");

		var style = '<style>'
			+ getCSSFromStyle("> .flexinfotable-segment",boxStyle)
			+ getCSSFromStyle("> .flexinfotable-segment:hover",hoverStyle)
			+ getCSSFromStyle("> .flexinfotable-segment:active",pressedStyle)
			+ '#' + thisWidget.jqElementId + '> .flexinfotable-segment:hover { cursor:pointer; }'
			+ '#' + thisWidget.jqElementId + '> .flexinfotable-segment { vertical-align: middle; margin: ' + margin + '; padding: ' + padding + '; height: ' + height + '; line-height: ' + height + '}'
			+ '</style>';	
		$(style).prependTo(thisWidget.jqElement);
	};
};