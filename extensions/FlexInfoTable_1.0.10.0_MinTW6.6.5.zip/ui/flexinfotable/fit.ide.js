TW.IDE.Widgets.flexinfotable = function () {
	var thisWidget = this;

	this.widgetIconUrl = function () {
		return "'../Common/extensions/FlexInfoTable/ui/flexinfotable/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'FlexInfoTable',
			'description': '',
			'category': ['Common'],
			'supportsAutoResize': true,
			'properties': {
				'Data': {
					'description': '',
					'isBindingTarget': true,
					'isEditable': false,
					'baseType': 'INFOTABLE',
					'warnIfNotBoundAsTarget': true
				},
                'DisplayField': {
                    'description': '',
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data'
                },
				'BoxStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'BoxHoverStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'BoxPressedStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},				
				'BoxMargin': {
					'description':'',
					'baseType':'STRING',
					'defaultValue':'2px'
				},
				'BoxPadding': {
					'description':'',
					'baseType':'STRING',
					'defaultValue':'5px'
				},
				'BoxHeight': {
					'description':'',
					'baseType':'STRING',
					'defaultValue':'1.5em'
				},
			}
		}
	};

	this.widgetEvents = function () {
		return {
			'Clicked': { 'warnIfNotBound': false }
		};
	};


	this.afterSetProperty = function (name, value) {
		return true;
	};

	this.renderHtml = function () {
		var html = '<div class="widget-content fit-widget">'
			+ '<div class="flexinfotable-segment">Some Data</div>'
			+ '<div class="flexinfotable-segment">More Data?</div>'
		+ '</div>';

		return html;
	};

	var getCSSFromStyle = function(styleName, style) {

		var color = style.foregroundColor;
		var backgroundColor = style.backgroundColor;
		var borderSize = style.lineThickness;

		if (borderSize === '') {
			borderSize = 0;
		}

		var borderColor = style.lineColor;
		if (borderColor === '') {
			borderColor = 'rgba(0, 0, 0, 0.0)';
		}

		return '#' + thisWidget.jqElementId + styleName + ' {'
					+ 'background-color: ' + backgroundColor + '; '
					+ 'color: ' + color + '; '
					+ 'border: ' + borderSize + 'px solid ' + borderColor + '; '
					+ TW.getTextSize(style.textSize)
					+ '} ';

		
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()
		var boxStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BoxStyle','DefaultRepeaterStyle'));
		var hoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BoxHoverStyle','DefaultRepeaterStyle'));
		var pressedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BoxPressedStyle','DefaultRepeaterStyle'));

		var margin = thisWidget.getProperty("BoxMargin");
		var padding = thisWidget.getProperty("BoxPadding");
		var height = thisWidget.getProperty("BoxHeight");

		var style = '<style>'
			+ getCSSFromStyle("> .flexinfotable-segment",boxStyle)
			+ getCSSFromStyle("> .flexinfotable-segment:hover",hoverStyle)
			+ getCSSFromStyle("> .flexinfotable-segment:active",pressedStyle)
			+ '#' + thisWidget.jqElementId + '> .flexinfotable-segment:hover { cursor:pointer; }'
			+ '#' + thisWidget.jqElementId + '> .flexinfotable-segment { vertical-align: middle; margin: ' + margin + '; padding: ' + padding + '; height: ' + height + '; line-height: ' + height + '}'
			+ '</style>';	
		$(style).prependTo(thisWidget.jqElement);
	};
};