﻿TW.Runtime.Widgets.rocchart = function () {
    this.MAX_SERIES = 16;
    var widgetReference = this;

    this.dynamicSeries = undefined;
    
    this.selectedItems = [];
    
    this.needsManualResize = true;
    
    this.afterRender = function () {
        var widgetProperties = this.properties;

        this.chartDefinition = {
        	widgetReference : widgetReference,
            orientation : TW.ChartLibrary.ORIENTATION_VERTICAL,
            type : TW.ChartLibrary.CHART_TYPE_XY,
            axisMode : widgetProperties['YAxisMode'],
           	enableSelection : widgetProperties['AllowSelection'],
           	enableHover : widgetProperties['EnableHover'],
    		style : widgetProperties['ChartStyle'] ? widgetProperties['ChartStyle'] : 'DefaultChartStyle',
    		width : widgetProperties['Width'],
    		height : widgetProperties['Height'],
            indicatorstyle : widgetProperties['ChartIndicatorStyle'] ? widgetProperties['ChartIndicatorStyle'] : 'DefaultChartIndicatorStyle',
           	indicator : true,
            legend : {
            	visible : (widgetProperties['ShowLegend'] === true),
            	fixedwidth : widgetProperties['LegendWidth'],
                orientation : widgetProperties['LegendOrientation'] === undefined ? TW.ChartLibrary.ORIENTATION_VERTICAL : widgetProperties['LegendOrientation'],
                location : widgetProperties['LegendLocation'],
        		style : widgetProperties['ChartLegendStyle'] ? widgetProperties['ChartLegendStyle'] : 'DefaultChartLegendStyle'
            },
            xaxis : {
            	zoom : (widgetProperties['AllowXAxisZoom'] === true),
            	type : TW.ChartLibrary.AXIS_TYPE_NUMERIC,
            	labeltype : 'NUMBER',
            	format : widgetProperties['XAxisFormat'] !== undefined ? widgetProperties['XAxisFormat'] : '0000.0',
            	visible : widgetProperties['ShowXAxis'] !== undefined ? widgetProperties['ShowXAxis'] : true,
                smoothscaling : widgetProperties['XAxisSmoothScaling'] !== undefined ? widgetProperties['XAxisSmoothScaling'] : true,
                showlabels : widgetProperties['ShowXAxisLabels'] !== undefined ? widgetProperties['ShowXAxisLabels'] : true,
                showticks : widgetProperties['ShowXAxisTicks'] !== undefined ? widgetProperties['ShowXAxisTicks'] : true,
                grid : widgetProperties['ShowXAxisGrid'] !== undefined ? widgetProperties['ShowXAxisGrid'] : true,
                gridstyle : widgetProperties['GridStyle'] !== undefined ? widgetProperties['GridStyle'] : 'DefaultChartGridStyle',
            	intervals : widgetProperties['XAxisIntervals'] !== undefined ? widgetProperties['XAxisIntervals'] : 10,
            	labels : widgetProperties['XAxisLabels'] !== undefined ? widgetProperties['XAxisLabels'] : 2,
            	minorticks : widgetProperties['XAxisMinorTicks'] !== undefined ? widgetProperties['XAxisMinorTicks'] : 1,
            	autoscale : (widgetProperties['XAxisAutoscale'] === true),
            	zeroscale : (widgetProperties['XAxisZeroscale'] === true),
            	minimumvalue : widgetProperties['XAxisMinimum'],
            	maximumvalue : widgetProperties['XAxisMaximum'],
        		style : widgetProperties['XAxisStyle'] ? widgetProperties['XAxisStyle'] : 'DefaultChartAxisStyle',
                axistitle : widgetProperties['XAxisTitle'] ? widgetProperties['XAxisTitle'] : '',
        		renderer : TW.Renderer.DEFAULT
            },
            yaxis : {
            	zoom : (widgetProperties['AllowYAxisZoom'] === true),
            	type : TW.ChartLibrary.AXIS_TYPE_NUMERIC,
            	labeltype : 'NUMBER',
            	format : widgetProperties['YAxisFormat']!== undefined ? widgetProperties['YAxisFormat'] : '0000.0',
            	autoscale : (widgetProperties['YAxisAutoscale'] === true),
            	zeroscale : (widgetProperties['YAxisZeroscale'] === true),
            	minimumvalue : widgetProperties['YAxisMinimum'],
            	maximumvalue : widgetProperties['YAxisMaximum'],
            	visible : widgetProperties['ShowYAxis'] !== undefined ? widgetProperties['ShowYAxis'] : true,
            	showlabels : widgetProperties['ShowYAxisLabels'] !== undefined ? widgetProperties['ShowYAxisLabels'] : true,
                showticks : widgetProperties['ShowYAxisTicks'] !== undefined ? widgetProperties['ShowYAxisTicks'] : true,
                grid : widgetProperties['ShowYAxisGrid'] !== undefined ? widgetProperties['ShowYAxisGrid'] : true,
                gridstyle : widgetProperties['GridStyle'] !== undefined ? widgetProperties['GridStyle'] : 'DefaultChartGridStyle',
                intervals : widgetProperties['YAxisIntervals'] !== undefined ? widgetProperties['YAxisIntervals'] : 10,
                labels : widgetProperties['YAxisLabels'] !== undefined ? widgetProperties['YAxisLabels'] : 2,
                minorticks : widgetProperties['YAxisMinorTicks'] !== undefined ? widgetProperties['YAxisMinorTicks'] : 1,
        		style : widgetProperties['YAxisStyle'] ? widgetProperties['YAxisStyle'] : 'DefaultChartAxisStyle',
                axistitle : widgetProperties['YAxisTitle'] ? widgetProperties['YAxisTitle'] : '',
           		renderer : TW.Renderer.DEFAULT
            },
            yaxis2 : {
            	zoom : (widgetProperties['AllowYAxisZoom'] === true),
            	type : TW.ChartLibrary.AXIS_TYPE_NUMERIC,
            	labeltype : 'NUMBER',
            	format : widgetProperties['SecondaryYAxisFormat']!== undefined ? widgetProperties['SecondaryYAxisFormat'] : '0000.0',
            	autoscale : (widgetProperties['SecondaryYAxisAutoscale'] === true),
            	zeroscale : (widgetProperties['SecondaryYAxisZeroscale'] === true),
            	minimumvalue : widgetProperties['SecondaryYAxisMinimum'],
            	maximumvalue : widgetProperties['SecondaryYAxisMaximum'],
            	visible : widgetProperties['ShowYAxis'] !== undefined ? widgetProperties['ShowYAxis'] : true,
               	showlabels : widgetProperties['ShowYAxisLabels'] !== undefined ? widgetProperties['ShowYAxisLabels'] : true,
                showticks : widgetProperties['ShowYAxisTicks'] !== undefined ? widgetProperties['ShowYAxisTicks'] : true,
                grid : widgetProperties['ShowYAxisGrid'] !== undefined ? widgetProperties['ShowYAxisGrid'] : true,
                gridstyle : widgetProperties['GridStyle'] !== undefined ? widgetProperties['GridStyle'] : 'DefaultChartGridStyle',
                intervals : widgetProperties['YAxisIntervals'] !== undefined ? widgetProperties['YAxisIntervals'] : 10,
                labels : widgetProperties['YAxisLabels'] !== undefined ? widgetProperties['YAxisLabels'] : 2,
                minorticks : widgetProperties['YAxisMinorTicks'] !== undefined ? widgetProperties['YAxisMinorTicks'] : 1,
        		style : widgetProperties['YAxisStyle'] ? widgetProperties['YAxisStyle'] : 'DefaultChartAxisStyle',
           		renderer : TW.Renderer.DEFAULT
            },
            chartarea : {
                stacked : false,
        		style : widgetProperties['ChartAreaStyle'] ? widgetProperties['ChartAreaStyle'] : 'DefaultChartAreaStyle',
                selectedstyle : widgetProperties['SelectedItemStyle'] ? widgetProperties['SelectedItemStyle'] : 'DefaultChartSelectionStyle'
            },
            title : {
        		style : widgetProperties['ChartTitleStyle'] ? widgetProperties['ChartTitleStyle'] : 'DefaultChartTitleStyle',
            	text : this.getProperty('ChartTitle')
            }
        };

        this.chart = new TW.ChartLibrary.Chart(this.chartDefinition);
        
        // Add initial series objects to it

        var seriesNumber;

        this.enableSelection = false;
        
        var chartSeries = new Array();

        this.chart.chartarea.series = chartSeries;
        
        for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
            var dataField = widgetProperties['DataField' + seriesNumber];

            if (dataField !== undefined && dataField !== '') {
                var seriesType = widgetProperties['SeriesType' + seriesNumber];
                
                if (seriesType == 'chart' || seriesType === undefined || seriesType == null) {
                	seriesType = widgetProperties['ChartType'];
                }

               	this.enableSelection = widgetProperties['AllowSelection'];
                
                var seriesmarkerType = widgetProperties['SeriesMarkerType' + seriesNumber];
                if(seriesmarkerType === undefined || seriesmarkerType == 'chart')
                	seriesmarkerType = widgetProperties['MarkerType'];
                
            	var seriesDefinition = {
            		type : seriesType,
            		field : dataField,
            		label : this.getProperty('DataLabel' + seriesNumber),
            		//smoothing : widgetProperties['Smoothing'],
            		style : widgetProperties['SeriesStyle' + seriesNumber],
            		datastyle : widgetProperties['SeriesDataStyle' + seriesNumber],
            		markertype : seriesmarkerType,
            		markersize : widgetProperties['MarkerSize'],
            		useSecondaryAxis : (widgetProperties['UseSecondaryAxis' + seriesNumber] === true),
                	customAxisFormat : widgetProperties['AxisFormat' + seriesNumber]!== undefined ? widgetProperties['AxisFormat' + seriesNumber] : '0000.0',
                	customAxisAutoscale : (widgetProperties['AxisAutoscale' + seriesNumber] === true),
                	customAxisZeroscale : (widgetProperties['AxisZeroscale' + seriesNumber] === true),
                	customAxisMinimumvalue : widgetProperties['AxisMinimum' + seriesNumber],
                	customAxisMaximumvalue : widgetProperties['AxisMaximum' + seriesNumber]
            	};

            	// TODO: per series marker type
            	
            	var series = new TW.ChartLibrary.ChartSeries(this.chart,seriesDefinition,seriesNumber-1);

            	chartSeries.push(series);
            	
                this.selectedItems.push(new Array());
            }
        }

    };

    this.beforeDestroy = function () {
        if(this.chart !== undefined) {
            try {
            	this.chart.destroy();
            	this.chart = null;
            	delete this.chart;
            }
            catch (destroyErr) {
            }
        }

        if (this.chartDefinition !== undefined) {
            try {
                this.chartDefinition.widgetReference = null;
                this.chartDefinition = null;
                delete this.chartDefinition;
            }
            catch (destroyErr) {
            }
        }


        this.selectedItems = [];

        widgetReference = null;
    };

	this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
    	if(widgetReference.enableSelection) {
            TW.ChartLibrary.handleChartSelectionUpdate(this, this.chart, propertyName, selectedRowIndices);
    	}
	};

    this.updateProperty = function (updatePropertyInfo) {
        var widgetProperties = this.properties;

        if (updatePropertyInfo.TargetProperty === "ChartTitle") {
        	this.setProperty('ChartTitle', updatePropertyInfo.RawSinglePropertyValue);
        	this.chart.title.text = this.getProperty('ChartTitle');
        	this.chart.render();

            return;
        }

        if (updatePropertyInfo.TargetProperty === "XAxisMinimum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.xaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.xaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue;

            return;
        }

        if (updatePropertyInfo.TargetProperty === "XAxisMaximum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.xaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.xaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue;

            return;
        }

        if (updatePropertyInfo.TargetProperty === "YAxisMinimum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue;

            return;
        }

        if (updatePropertyInfo.TargetProperty === "YAxisMaximum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue;

            return;
        }

        if (updatePropertyInfo.TargetProperty === "SecondaryYAxisMinimum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis2.minimumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis2.minimumvalue = updatePropertyInfo.RawSinglePropertyValue;

            return;
        }

        if (updatePropertyInfo.TargetProperty === "SecondaryYAxisMaximum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis2.maximumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis2.maximumvalue = updatePropertyInfo.RawSinglePropertyValue;

            return;
        }

        if (updatePropertyInfo.TargetProperty.indexOf('DataField') === 0) {
        	for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
            	var fieldName = 'DataField' + seriesNumber.toString();
                var series = this.chart.chartarea.series[seriesNumber-1];
            	if (updatePropertyInfo.TargetProperty === fieldName) {
            		if (series !== undefined) {
            			this.setProperty(fieldName, updatePropertyInfo.RawSinglePropertyValue);
			            series.field = this.getProperty(fieldName);
            		} else {
            			this.setProperty(fieldName, updatePropertyInfo.RawSinglePropertyValue);
            		}
            		this.chart.render();

                    return;
            	}
        	}
        }

        // Check if starts with 'data'

        if (updatePropertyInfo.TargetProperty.indexOf('Data') === 0) {
            var dataRows = updatePropertyInfo.ActualDataRows;

            // Prepare series data

            var seriesNumber;
            
            if (updatePropertyInfo.TargetProperty === "Data") {

            	// Process shared x axis values
            	
            	var xAxisFieldName = widgetProperties['XAxisField'];

                this.chart.processDataset(dataRows,xAxisFieldName);
                
                for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
                    var series = this.chart.chartarea.series[seriesNumber - 1];
                    if(series !== undefined && series.field !== undefined && series.field != '') {

                        series.processDataset(dataRows,undefined);
                        
                        // Assign shared x axis values
                        
                        series.xvalues = this.chart.xvalues;
                    }
                }

            }
            else {
                for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
                    var sourceName = 'DataSource' + seriesNumber.toString();
                    var labelName = 'DataLabel' + seriesNumber.toString();

                    if (updatePropertyInfo.TargetProperty == sourceName) {
                    	var series = this.chart.chartarea.series[seriesNumber-1];
                    	
                        if(series !== undefined && series.field !== undefined && series.field != '') {
                            var xAxisFieldName = widgetProperties['XAxisField' + seriesNumber];
                            if(xAxisFieldName == undefined) {
                            	xAxisFieldName = widgetProperties['XAxisField'];
                            }

                            series.processDataset(dataRows,xAxisFieldName);
                        }
                    } else if (updatePropertyInfo.TargetProperty == labelName) {
	                    this.setProperty(labelName,updatePropertyInfo.SinglePropertyValue);
                    	var series = this.chart.chartarea.series[seriesNumber-1];
	                    series.label = this.getProperty(labelName);
                    }
                }
            }

            this.chart.render();
            
            if(widgetReference.enableSelection) {

        		var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;

                if (selectedRowIndices !== undefined) {
                    TW.ChartLibrary.handleChartSelectionUpdate(this, this.chart, updatePropertyInfo.TargetProperty, selectedRowIndices);
                }
                else {
                    TW.ChartLibrary.handleChartSelectionUpdate(this, this.chart, updatePropertyInfo.TargetProperty, new Array());
                }
        	}

        }
    };
    
	this.resize = function(width,height) {
		this.chart.resize(width, height);
	};
	
    var buildLocalizablePropertyAttributes = function (widget) {
    	var attributes = {'ChartTitle':{'isLocalizable':true}};
		var nSeries = widget.getProperty('NumberOfSeries');
		
		var seriesNumber;
		
		for (seriesNumber = 1; seriesNumber <= nSeries; seriesNumber++) {
			attributes['DataLabel' + seriesNumber] = {'isLocalizable': true};
		}
		
		return attributes;
    };
    
    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': true,
            'supportsAutoResize': true,
            'borderWidth': 1,
            'propertyAttributes': buildLocalizablePropertyAttributes(this)
        };
    };

    this.renderHtml = function () {
        var html = '<div class="widget-content widget-rocchart-container svg-chrome-fix"></div>';
        return html;
    };

};
