TW.IDE.Widgets.statepanel = function () {
    "use strict";
    var thisWidget = this;
    this.widgetIconUrl = function () {
        return "../Common/extensions/StatePanelWidget-extension/ui/" +
            "statepanel/statepanel.ide.png";
    };

    this.widgetProperties = function () {
        return {
            'name': "State Panel", // TW.IDE.I18NController.translate('tw.panel-ide.widget.name'),
            'description': "Panel that supports state-based formatting", // TW.IDE.I18NController.translate('tw.panel-ide.widget.description'),
            'category': ['Common', 'Containers'],
            'isContainer': true,
            'isDraggable': true,
            'supportsAutoResize': true,
            'properties': {
                'PanelFormat': {
                    'description': "Panel Format", //TW.IDE.I18NController.translate('tw.valuedisplay-ide.properties.value-format.description'),
                    'baseType': 'RENDERERWITHSTATE',
                    'baseTypeInfotableProperty': 'Data'    // which property's datashape to use and require being bound in order to configure the renderer, etc.
                },
                'Data': {
                    'description': "Data", //TW.IDE.I18NController.translate('tw.valuedisplay-ide.properties.data.description'),
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'ANYSCALAR',
                    'warnIfNotBoundAsTarget': true
                },
                'ShowBackgroundImage': {
                    'description': 'Show Background Image',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'Width': {
                    'defaultValue': 300,
                    'description': TW.IDE.I18NController.translate('tw.panel-ide.properties.width.description')
                },
                'Height': {
                    'defaultValue': 200,
                    'description': TW.IDE.I18NController.translate('tw.panel-ide.properties.height.description')
                },
                'ResponsiveLayout': {
                    'description': TW.IDE.I18NController.translate('tw.panel-ide.properties.responsive-layout.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    isVisible: false
                },
                'HorizontalAnchor': {
                    'baseType': 'STRING',
                    'description': TW.IDE.I18NController.translate('tw.panel-ide.properties.horizontal-anchor.description'),
                    'defaultValue': 'left',
                    'selectOptions': [
                        {
                            value: 'left',
                            text: TW.IDE.I18NController.translate('tw.panel-ide.properties.horizontal-anchor.select-options.left')
                        },
                        {
                            value: 'center',
                            text: TW.IDE.I18NController.translate('tw.panel-ide.properties.horizontal-anchor.select-options.center')
                        }
                        //{ value: 'right', text: 'Right' }
                    ],
                    isVisible: false
                },
                'VerticalAnchor': {
                    'baseType': 'STRING',
                    'description': TW.IDE.I18NController.translate('tw.panel-ide.properties.vertical-anchor.description'),
                    'defaultValue': 'top',
                    'selectOptions': [
                        {
                            value: 'top',
                            text: TW.IDE.I18NController.translate('tw.panel-ide.properties.vertical-anchor.select-options.top')
                        },
                        {
                            value: 'middle',
                            text: TW.IDE.I18NController.translate('tw.panel-ide.properties.vertical-anchor.select-options.middle')
                        }
                        //{ value: 'bottom', text: 'Bottom' }
                    ],
                    isVisible: false
                },
                'Style': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultPanelStyle',
                    'description': TW.IDE.I18NController.translate('tw.panel-ide.properties.style.description')
                },
                'HideScrollbars': {
                    'description': TW.IDE.I18NController.translate('tw.panel-ide.properties.hide-scroll-bars.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                }
            }
        };
    };

    this.beforeSetProperty = function (name, value) {
        switch (name) {
            case 'HorizontalAnchor':
            case 'VerticalAnchor':

                // This is for MASHUP-2202 ... if someone changes from middle to top or center to left, we don't want the widget to shift the opposite way.
                //  So, what we do in that case is to logically make it move to 25% instead of 50%
                if (this.properties.ResponsiveLayout !== true && value !== 'center' && value !== 'middle') {
                    var boundingBox = this.jqElement.closest('.widget-bounding-box');
                    var parentBoundingBox = boundingBox.parent().closest('.widget-bounding-box');

                    // figure out which is farther left and adjust it to that
                    var currentEffectiveLeft = (parentBoundingBox.outerWidth() / 2 - (this.getProperty('Width') / 2)) / 2;
                    var currentEffectiveTop = (parentBoundingBox.outerHeight() / 2 - (this.getProperty('Height') / 2)) / 2;

                    if (name === 'HorizontalAnchor') {
                        var propLeft = this.getProperty('Left');
                        if (currentEffectiveLeft < propLeft) {
                            this.setProperty('Left', currentEffectiveLeft);
                        }
                    } else {
                        var propTop = this.getProperty('Top');
                        if (currentEffectiveTop < propTop) {
                            this.setProperty('Top', currentEffectiveTop);
                        }
                    }

                }
                break;
        }
    };

    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Style':
            case 'Top':
            case 'Left':
            case 'Right':
            case 'Bottom':
            case 'Width':
            case 'Height':
            case 'HorizontalAnchor':
            case 'VerticalAnchor':
                result = true;
                break;
            default:
                break;
        }
        return result;

    };

    this.afterCreate = function () {
        this.showProperProperties();
    };

    this.afterLoad = function () {
        this.showProperProperties();
    };

    this.showProperProperties = function () {
        var thisWidget = this;

        var allWidgetProps = thisWidget.allWidgetProperties();

        if (thisWidget.properties.ResponsiveLayout === true) {
            allWidgetProps.properties['HorizontalAnchor']['isVisible'] = false;
            allWidgetProps.properties['VerticalAnchor']['isVisible'] = false;
        } else {
            allWidgetProps.properties['HorizontalAnchor']['isVisible'] = true;
            allWidgetProps.properties['VerticalAnchor']['isVisible'] = true;
        }
    };

    this.renderHtml = function () {
        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style'));

        var html = '';

        html +=
            '<div class="widget-content widget-statepanel widget-container" style="' + ((formatResult.image !== undefined && formatResult.image.length > 0) ? 'background-color: ' + formatResult.backgroundColor + '; background-image: url(' + formatResult.image + '); background-image: url(' + formatResult.image + '), -moz-linear-gradient(top,  ' + formatResult.backgroundColor + ',  ' + formatResult.secondaryBackgroundColor + '); background-image: url(' + formatResult.image + '), -webkit-gradient(linear, left top, left bottom, from(' + formatResult.backgroundColor + '), to(' + formatResult.secondaryBackgroundColor + ')); background-image: url(' + formatResult.image + '), -webkit-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + '); background-repeat: no-repeat; background-position: center center;' : '') + ' background-image: url(' + formatResult.image + '), -ms-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + ');">' +
            '</div>';
        return html;
    };

    this.afterRender = function () {

        var PanelStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style'));
        var PanelBG = TW.getStyleCssGradientFromStyle(PanelStyle);
        var PanelBorder = TW.getStyleCssBorderFromStyle(PanelStyle);

        var resource = TW.IDE.getMashupResource();
        var widgetStyles =
            '#' + thisWidget.jqElementId + '.widget-panel { ' + PanelBG + PanelBorder + ' } ';
        resource.styles.append(widgetStyles);

        if (thisWidget.getProperty('IsPrintLayout')) {
            thisWidget.jqElement.addClass('is-print-mashup');
        }

        var hAnchor = this.getProperty('HorizontalAnchor');
        if (hAnchor === undefined) {
            hAnchor = 'left';
        }
        var vAnchor = this.getProperty('VerticalAnchor');
        if (vAnchor === undefined) {
            vAnchor = 'top';
        }

        var boundingBox = this.jqElement.closest('.widget-bounding-box');

        switch (hAnchor) {
            case 'center':
                var width = this.getProperty('Width');
                boundingBox.css('margin-left', '-' + (width / 2) + 'px').css('left', '50%');
                break;
            default:
                if (this.properties.ResponsiveLayout !== true) {
                    boundingBox.css('margin-left', 'auto').css('left', this.getProperty('Left') + 'px');
                }
                break;

        }

        switch (vAnchor) {
            case 'middle':
                var height = this.getProperty('Height');
                boundingBox.css('margin-top', '-' + (height / 2) + 'px').css('top', '50%');
                break;
            case 'top':
                if (this.properties.ResponsiveLayout !== true) {
                    boundingBox.css('margin-top', 'auto').css('top', this.getProperty('Top') + 'px');
                }
        }

    };

};