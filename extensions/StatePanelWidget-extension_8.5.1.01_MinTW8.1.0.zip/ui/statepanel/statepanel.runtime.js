TW.Runtime.Widgets.statepanel = function () {
    "use strict";
    var hideScrollbars;
    var thisWidget = this;
    var isResponsive;
    var showBackgroundImage;

    this.runtimeProperties = function () {
        isResponsive = thisWidget.getProperty('ResponsiveLayout');
        showBackgroundImage = thisWidget.getProperty('ShowBackgroundImage');
        return {
            'borderWidth': 0,
            'isContainer': true,
            'supportsAutoResize': true,
            'isResponsive': isResponsive ? true : false
        };
    };

    this.renderHtml = function () {
        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'DefaultPanelStyle'));

        var html = '';
        html +=
            '<div class="widget-statepanel widget-container widget-content" style="' +
            TW.Runtime.Widgets.statepanel.getStyleFromFormat(showBackgroundImage, formatResult) + '">' +
            '</div>';
        return html;
    };

    this.updateProperty = function (updatePropertyInfo) {
        if (updatePropertyInfo.TargetProperty === "Data" || updatePropertyInfo.TargetProperty === "PanelFormat") {
            var valueData;
            var valueDataShape;
            var fieldDef;
            var dataRow;
            var sourceProperty;
            var valueFromRow;

            switch (updatePropertyInfo.TargetProperty) {
                case 'Data':
                    valueData = updatePropertyInfo.SinglePropertyValue;
                    valueDataShape = updatePropertyInfo.DataShape;
                    fieldDef = valueDataShape[updatePropertyInfo.SourceProperty];
                    dataRow = updatePropertyInfo.ActualDataRows[0];
                    sourceProperty = updatePropertyInfo.SourceProperty;
                    valueFromRow = updatePropertyInfo.RawSinglePropertyValue; //updatePropertyInfo.ActualDataRows[0][updatePropertyInfo.SourceProperty];
                    break;

                case 'PanelFormat':
                    if (this.hasDataEverBeenUpdated !== true) {
                        return;
                    }
                    valueData = this.lastValueData;
                    valueDataShape = this.lastDataShape;
                    fieldDef = this.lastFieldDef;
                    dataRow = this.lastDataRow;
                    sourceProperty = this.lastSourceProperty;
                    valueFromRow = this.lastValueFromRow;
                    break;
            }

            var formatResult = TW.getStyleFromStateFormatting({
                DataRow: dataRow,
                StateFormatting: this.getProperty("PanelFormat").formatInfo
            });
            thisWidget.jqElement.attr("style", TW.Runtime.Widgets.statepanel.getStyleFromFormat(showBackgroundImage, formatResult));

            if (updatePropertyInfo.TargetProperty === 'Data') {
                this.hasDataEverBeenUpdated = true;
                this.lastValueData = valueData;
                this.lastDataShape = valueDataShape;
                this.lastFieldDef = fieldDef;
                this.lastDataRow = dataRow;
                this.lastSourceProperty = sourceProperty;
                this.lastValueFromRow = valueFromRow;
            }
        }
    };

    this.afterRender = function () {

        var thisWidget = this;
        hideScrollbars = thisWidget.getProperty('HideScrollbars');

        var hAnchor = this.getProperty('HorizontalAnchor');
        if (hAnchor === undefined) {
            hAnchor = 'left';
        }
        var vAnchor = this.getProperty('VerticalAnchor');
        if (vAnchor === undefined) {
            vAnchor = 'top';
        }

        if ($('#runtime-workspace').hasClass('print')) {
            this.jqElement.closest('.widget-container-widget').addClass('panelinside');
        }

        var boundingBox = this.jqElement.closest('.widget-bounding-box');

        switch (hAnchor) {
            case 'center':
                var width = this.getProperty('Width');
                boundingBox.css('margin-left', '-' + (width / 2) + 'px').css('left', '50%');
                break;
        }

        switch (vAnchor) {
            case 'middle':
                var height = this.getProperty('Height');
                boundingBox.css('margin-top', '-' + (height / 2) + 'px').css('top', '50%');
                break;
        }

        setTimeout(function () {
            if (thisWidget.jqElement !== undefined) {
                thisWidget.jqElement.css("overflow", (hideScrollbars === true ? 'hidden' : 'auto'));
            }
        }, 1);

    };
};

TW.Runtime.Widgets.statepanel.getStyleFromFormat = function (showBackgroundImage, formatResult) {
    var style = "";
     var importantStyle =  '' ;
    if (formatResult.backgroundColor) {
        if (formatResult.secondaryBackgroundColor) {
            // gradient
			style += 'background: ' + formatResult.backgroundColor + ';' + 'background: -moz-linear-gradient(top, ' +
			formatResult.backgroundColor + ' 0%, ' + formatResult.secondaryBackgroundColor + ' 100%) ' +
			importantStyle + '; background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,' +
			formatResult.backgroundColor + '), color-stop(100%,' + formatResult.secondaryBackgroundColor + ')) ' +
			importantStyle + ';' + 'background: -webkit-linear-gradient(top, ' + formatResult.backgroundColor + ' 0%,' +
			formatResult.secondaryBackgroundColor + ' 100%) ' + importantStyle + ';' +
			'background: -o-linear-gradient(top, ' + formatResult.backgroundColor + ' 0%,' +
			formatResult.secondaryBackgroundColor + ' 100%) ' + importantStyle + ';' +
			'background: -ms-linear-gradient(top, ' + formatResult.backgroundColor + ' 0%,' +
			formatResult.secondaryBackgroundColor + ' 100%) ' + importantStyle + ';' +
			'background: linear-gradient(top, ' + formatResult.backgroundColor + ' 0%,' +
			formatResult.secondaryBackgroundColor + ' 100%) ' + importantStyle + ';' +
			'filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\'' +
			formatResult.backgroundColor + '\', endColorstr=\'' +
			formatResult.secondaryBackgroundColor + '\',GradientType=0 )' + importantStyle + ';';
        } else {
            // plain background
            style = style + 'background: ' + formatResult.backgroundColor + '; ';
        }
    }

    if (showBackgroundImage && formatResult.image) {
        style = style + 'background-image: url(' + formatResult.image + '); ' +
            'background-repeat: no-repeat; background-position: center center; ';
    }
    return style;
};

