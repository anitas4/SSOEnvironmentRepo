﻿TW.IDE.Widgets.pfizerfileupload = function () {
	
	var defaultHeight = 95;
	var noOptionHeight = 40;
	
	this.widgetIconUrl = function() {
		return  "'../Common/extensions/PfizerFileUpload/ui/pfizerfileupload/pfizerfileupload.png'";
	};

    this.widgetProperties = function () {

        return {
            'name': "pfizerfileupload",
            'description': TW.IDE.I18NController.translate('tw.fileupload-ide.widget.description'),
            'category': ['Data'],
            'borderWidth': 1,
            'properties': {
                'Width': {
                    'defaultValue': 302,
                    'isEditable': false,
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.width.description')
                },
                'Height': {
                    'defaultValue': defaultHeight,
                    'isEditable': false,
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.height.description')
                },
                'TabSequence': {
                    'description': 'Tab sequence index',
                    'baseType': 'NUMBER',
                    'defaultValue': 0,
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.tab-sequence.description')
                },
                'RepositoryName': {
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.repository-name.description'),
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': 'SystemRepository',
                    'baseType': 'THINGNAME',
                    'mustImplement':
                    { 
                        'EntityType': 'ThingTemplates',
                        'EntityName': 'FileRepository'
                    }
                },
                'DisplayRepositorySelector': {
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.display-repository-selector.description')
                },
                'Path': {
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.path.description'),
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': '/',
                    'baseType': 'STRING'
                },
                'DisplayPathTextBox': {
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.display-path-text-box.description')
                },
                'FileName': {
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.file-name.description'),
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING'
                },
                'FullPath': {
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.full-path.description'),
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING'
                },
                'Style':{
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultFileUploadStyle',
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.style.description')
                },
                'FocusStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultButtonFocusStyle',
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.focus-style.description')
                },
                'RepositoryStyle':{
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRepositoryStyle',
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.repository-style.description')
                },
                'AllowedFileTypes': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.allowed-file-types.description'),
                    'defaultValue': '',
                    'baseType': 'STRING'
                },
            	'MaximumFileSize': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.fileupload-ide.properties.maximum-file-size.description'),
                    'defaultValue': undefined,
                    'baseType': 'NUMBER'
                }
            },
			'isResizeable': false
        };
    };

    this.widgetEvents = function () {
        return {
            'UploadComplete': { 'warnIfNotBound': false },
            'UploadFailed': { 'warnIfNotBound': false },
            'FileChosen' : { 'warnIfNotBound': false }
        };
    };
	
    this.widgetServices = function () {
        return {
            'Upload': {},
            'ChooseFile':{}
        };
    };
    this.renderHtml = function () {
		
		
		var formatFileUploadResult = TW.getStyleFromStyleDefinition(this.getProperty('Style'));
		var formatRepositoryResult = TW.getStyleFromStyleDefinition(this.getProperty('RepositoryStyle'));

		var cssFileUploadBackground = TW.getStyleCssGradientFromStyle(formatFileUploadResult);
		var cssFileRepositoryText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRepositoryResult);
		var cssFileUploadBorder = TW.getStyleCssBorderFromStyle(formatFileUploadResult);
		var cssRepositoryBackground = TW.getStyleCssGradientFromStyle(formatRepositoryResult);
		
		
		if(this.getProperty('DisplayRepositorySelector') === undefined){
			this.setProperty('DisplayRepositorySelector', true);
		}
		if(this.getProperty('DisplayPathTextBox') === undefined){
			this.setProperty('DisplayPathTextBox', true);
		}
		
        var displayRepositorySelector = this.getProperty('DisplayRepositorySelector');
        var displayPathTextBox = this.getProperty('DisplayPathTextBox');

		

        var html = '';
        html += '<div class="widget-content widget-fileupload widget-fileupload-container" style="'+ cssFileUploadBackground + cssFileUploadBorder +'">' + 
					'<div class="repository-info clearfix" style="'+ cssRepositoryBackground +'">';
					
        	if (displayRepositorySelector == true) {
	            html += '<div class="fileupload-repository" >' + 
							'<label style="'+ cssFileRepositoryText +'">'+ TW.IDE.I18NController.translate('tw.fileupload-ide.file-repository') +':</label>' + 
							'<div class="repository-name"><span>'+ TW.IDE.I18NController.translate('tw.fileupload-ide.system-repository') +'</span></div>' +
						'</div>';
	        }
	        if (displayPathTextBox == true) {
	            html += '<div class="fileupload-path">' +
	            			'<label style="'+ cssFileRepositoryText +'">'+ TW.IDE.I18NController.translate('tw.fileupload-ide.path-on-repository') +':</label>' + 
							'<div class="upload-input"></div>' + 
						'</div>';
	        }
			html+= '</div>' ;
	        	html += '<div class="file-browser">' + 
							'<div class="fileupload-browse"><span>'+ TW.IDE.I18NController.translate('tw.fileupload-ide.choose-file') +'</span></div>' +
							'<div class="fileupload-file-input"><span>'+ TW.IDE.I18NController.translate('tw.fileupload-ide.no-file-chosen') +'</span></div>' +
							'<div class="fileupload-submit-button"><span>'+ TW.IDE.I18NController.translate('tw.fileupload-ide.upload') +'</span></div>' + 
						'</div>';
				
			html += '</div>';

        return html;
    };
	
	this.afterRender = function () {
		if(this.getProperty('DisplayRepositorySelector') === false && this.getProperty('DisplayPathTextBox') === false) {
			this.jqElement.find('.repository-info').attr('style','padding:0px; border-bottom: none;');
		}
		
		if(this.getProperty('DisplayRepositorySelector') === false){
			this.jqElement.find('.fileupload-path').addClass('noRepository');
		}
		if(this.getProperty('DisplayPathTextBox') === false){
			this.jqElement.find('.fileupload-repository').addClass('noPath');
		}

			

    };

    this.beforeSetProperty = function (name, value) {
        if (name.toLowerCase() === 'maximumfilesize') {
            if (parseFloat(value) < 0.0) {
                return TW.IDE.I18NController.translate('tw.ide-widget.messages.property-must-be-positive-value', {name: name});
            }
        }
    }

    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Style':
			case 'RepositoryStyle':
            case 'DisplayRepositorySelector':
            case 'DisplayPathTextBox':
				if(this.getProperty('DisplayRepositorySelector') === false && this.getProperty('DisplayPathTextBox') === false) {
					this.setProperty('Height', noOptionHeight);

				} else if(this.getProperty('DisplayRepositorySelector') === true || this.getProperty('DisplayPathTextBox') === true) {
					this.setProperty('Height', defaultHeight);
				}
                result = true;
                break;
            default:
                break;
        }
        return result;

    };
};	