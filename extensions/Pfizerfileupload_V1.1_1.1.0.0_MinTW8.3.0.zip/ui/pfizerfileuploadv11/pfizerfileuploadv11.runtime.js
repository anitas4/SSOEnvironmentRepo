﻿TW.Runtime.Widgets.pfizerfileupload = function () {

    var _uuid;
    var displayRepositorySelector;
    var displayPathTextBox;
    var widgetReference = this;

	
	var formatFileUploadResult;
	var formatRepositoryResult;
	var formatFocusResult;

	var cssFocusStyle;
		
	var cssFileUploadBackground ;
	var cssFileRepositoryText;
	var cssFileUploadBorder;
	var cssRepositoryBackground;

    var fileuploadText = {
        FileSize: TW.Runtime.convertLocalizableString('[[fileSizeError]]'),
        FileType: TW.Runtime.convertLocalizableString('[[fileTypeError]]')
    };

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': true,
            'borderWidth': 1
        };
    };

    this.renderHtml = function () {
        var html = '';

        formatFileUploadResult = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'DefaultFileUploadStyle'));
        formatRepositoryResult = TW.getStyleFromStyleDefinition(this.getProperty('RepositoryStyle', 'DefaultRepositoryStyle'));
        formatFocusResult = TW.getStyleFromStyleDefinition(this.getProperty('FocusStyle','DefaultButtonFocusStyle'));

        cssFocusStyle = TW.getStyleCssBorderFromStyle(formatFocusResult);
        cssFocusStyle += 'margin: -'+cssFocusStyle.match(/border-width:([0-9]+px;)/);

        cssFileUploadBackground = TW.getStyleCssGradientFromStyle(formatFileUploadResult);
        cssFileRepositoryText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRepositoryResult);
        cssFileUploadBorder = TW.getStyleCssBorderFromStyle(formatFileUploadResult);
        cssRepositoryBackground = TW.getStyleCssGradientFromStyle(formatRepositoryResult);

        html += '<div class="widget-content widget-pfizerfileupload" style="'+ cssFileUploadBackground + cssFileUploadBorder +'">';
        html += '</div>';

        return html;
    };

    this.afterRender = function () {
        var widgetElement = this.jqElement;

        displayRepositorySelector = widgetReference.getProperty('DisplayRepositorySelector');
        displayPathTextBox = widgetReference.getProperty('DisplayPathTextBox');

        //The form and input type of file need a name and id, therefore, generate it here (the names need to be unique in case there are multiple widgets)
        _uuid = TW.createUUID();

        widgetElement.append(getFormHTML());
        var formElement = widgetElement.find('#' + getFormName());
        formElement.append(getFormContentsHTML());

        $(getStyles()).prependTo(formElement);

        $(widgetElement).on('focusin', function () {
            $(widgetElement).addClass('focus');
        });

        $(widgetElement).on('focusout', function (e) {
            $(widgetElement).removeClass('focus');
        });

        formElement.ajaxForm({
            headers: { "X-XSRF-TOKEN": "TWX-XSRF-TOKEN-VALUE" },
            success: function (response, status, xhr, x) {
                widgetReference.jqElement.triggerHandler('UploadComplete');
            },
            error:function(jqXHR, textStatus, errorThrown) {
                TW.log.error('FileUpload Failed: "' + textStatus + '"');
                widgetReference.jqElement.triggerHandler('UploadFailed');
            }
        });

	    var selectorElement = widgetElement.find('#' + getFileRepositoryName());
	    var pathElement = widgetElement.find('#' + getPathName());
	    var inputFilesNameElement = widgetElement.find('#' + getInputFilesName());

	    if(selectorElement !== undefined) {
	    	var fileRepoName = widgetReference.getProperty("RepositoryName");
	    	if(fileRepoName != undefined && fileRepoName != '')
	    		selectorElement.val(fileRepoName);
	    }
	    
	    selectorElement.change(function(e) {
            widgetReference.setProperty('RepositoryName', selectorElement.val());
	    });
	    pathElement.change(function(e) {
            widgetReference.setProperty('Path', pathElement.val());
            
            var path = widgetReference.getProperty('Path');
            var filename = widgetReference.getProperty('FileName');
            
            nIndexSlash = path.lastIndexOf('/');
		    
		    var fullpath;
		    
		    if( nIndexSlash >= 0 && nIndexSlash == path.length) {
			    fullpath = path + filename;
		    }
		    else {
			    fullpath = path + "/" + filename;
		    }
		    
            widgetReference.setProperty('FullPath', fullpath);
	    });
	    inputFilesNameElement.change(function(e) {
		    var filename = Encoder.htmlEncode(inputFilesNameElement.val());
		    nIndexSlash = filename.lastIndexOf('\\');
		    if( nIndexSlash >= 0 ) {
			    filename = filename.substring(nIndexSlash+1);
		    }
            widgetReference.setProperty('FileName', Encoder.htmlEncode(filename));
          
            
            
            var path = widgetReference.getProperty('Path');
            var filename = Encoder.htmlDecode(widgetReference.getProperty('FileName'));
            
           
            nIndexSlash = path.lastIndexOf('/');
		    
		    var fullpath;
		    
		    if( nIndexSlash >= 0 && nIndexSlash == path.length) {
			    fullpath = path + filename;
		    }
		    else {
			    fullpath = path + "/" + filename;
		    }
		    
            widgetReference.setProperty('FullPath', fullpath);

            var files = inputFilesNameElement[0].files;
            var maximumFileSize = widgetReference.getProperty('MaximumFileSize');
            if(maximumFileSize !== undefined && files.length > 0 && (files[0].size/1048576) > maximumFileSize) {
                widgetReference.jqElement.find('.fileupload-file-input')[0].value = '';
                TW.Runtime.showStatusText('error', filename + ' ' + fileuploadText.FileSize + ' ' + maximumFileSize + 'MB');
            }

            var allowedFileTypes = widgetReference.getProperty('AllowedFileTypes');
            if(allowedFileTypes !== '') {
                allowedFileTypes = allowedFileTypes.replace(/ /g, '').split(',');
                if(allowedFileTypes.length > 0 && files.length > 0 && (allowedFileTypes.indexOf('.' + files[0].name.split('.').pop()) === -1)) {
                    widgetReference.jqElement.find('.fileupload-file-input')[0].value = '';
                    TW.Runtime.showStatusText('error', filename + ' ' + fileuploadText.FileType + ' ' + allowedFileTypes);
                }
            }
            var fileLabel1 = widgetReference.jqElement.find('.fileupload-file-label1'),
                fileLabel2 = widgetReference.jqElement.find('.fileupload-file-label2'),
                fname = filename;
            if(fname != ""){
                fileLabel2.text(shortenFilename(fname));
                fileLabel2.attr('title', filename);
                fileLabel1.attr('title', filename);
                widgetElement.triggerHandler('FileChosen');
            }
            else{
                fileLabel2.text('No file chosen');
                fileLabel2.attr('title', 'No file chosen');
                fileLabel1.attr('title', 'No file chosen');
            }
        });

		if(displayRepositorySelector === false && displayPathTextBox === false) {
			this.jqElement.find('.repository-info').attr('style','padding:0px; border-bottom: none;');
		}

		if(displayRepositorySelector === false){
			this.jqElement.find('.fileupload-path').addClass('noRepository');
		}
		if(displayPathTextBox === false){
			this.jqElement.find('.fileupload-repository').addClass('noPath');
		}
    };

	this.serviceInvoked = function(serviceName) {
		var widgetReference = this;
		if (serviceName === 'Upload') {
			//alert(getSubmitButtonID());
			//alert(document.getElementById(getSubmitButtonID()));
			document.getElementById(getSubmitButtonID()).click();
		}
		if (serviceName === 'ChooseFile') {
			
			document.getElementById(getInputButtonID()).click();
		}
    };	
    	
    this.updateProperty = function (updatePropertyInfo) {
        //var domElementId = this.jqElementId;
        var widgetElement = this.jqElement;
        //var widgetProperties = this.properties;

        switch (updatePropertyInfo.TargetProperty) {
            case 'RepositoryName':
                if (displayRepositorySelector == true) {
                    var selectElement = widgetElement.find('div.fileupload-repository select');
                    selectElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                } else {
                    var repoNameElement = widgetElement.find('div.fileupload-hidden-repository input');
                    repoNameElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                }
                break;
            case 'Path':
                if (displayPathTextBox == true) {
                    var pathElement = widgetElement.find('div.fileupload-path input');
                    pathElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                } else {
                    var pathElement = widgetElement.find('div.fileupload-hidden-path input');
                    pathElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                }
                break;
            default:
                break;
        }

        widgetElement = null;
    };

    this.afterSetProperty = function (name, value) {
        var refreshHtml = false;
        switch (name) {
            case 'Style':
                refreshHtml = true;
                break;
            default:
                break;
        }
        return refreshHtml;
    };

    this.beforeDestroy = function () {
        widgetReference = null;
    };

    //
    //  Returns the list of file repository things
    //
    var getFileRepositoryList = function () {
        var repositoryList;

        //Get the current user
        var invoker = new ThingworxInvoker({
            entityType: 'Resources',
            entityName: 'SearchFunctions',
            characteristic: 'Services',
            target: 'SearchThingsByTemplate',
            apiMethod: 'post',
            parameters: {
                'thingTemplate': 'FileRepository'
            }
        });

        var successHandler = function (result) {
            repositoryList = result.rows;
        };

        var failHandler = function (response) {
            TW.log.error('Failed to get file repository list');
        };

        invoker.invokeService(
            function (invoker) {
                successHandler(invoker.result);
            },
            function (invoker, xhr) {
                failHandler(xhr.responseText);
            },
            false
        );

        return repositoryList;
    };

    var getFormName = function () {
        return 'upload-form-' + _uuid;
    };

    var getInputFilesName = function () {
        return 'upload-files-' + _uuid;
    };

    var getSubmitButtonName = function () {
        return 'upload-submit-' + _uuid;
    };

    var getFileRepositoryName = function () {
        return 'upload-repository-' + _uuid;
    };

    var getPathName = function () {
        return 'upload-path-' + _uuid;
    };

    var getStyles = function(){
    	var styleBlock = '<style>' +
    		'#' + widgetReference.jqElementId + '.focus form { ' + cssFocusStyle + ' } ' +
		'</style>';
    	return styleBlock;
    };

    var getFormHTML = function () {
        var html = '';
        html += '<form name="' + getFormName() + '" id="' + getFormName() + '" class="fileupload-form" enctype="multipart/form-data" method="POST" action="/Thingworx/FileRepositoryUploader">' +
        		'</form>';
        return html;
    };

    var getFormContentsHTML = function () {
        var html = '';

        html += '<div class="repository-info clearfix" style="'+ cssRepositoryBackground +'">' + getFileRepositoryHTML() + getPathHTML() + '</div>';
        html += '<div class="file-browser">' + 
					getInputFilesHTML() +
					getSubmitButtonHTML() +
				'</div>';
				

			
        return html;
    };

    var getFileRepositoryHTML = function () {
        var html = '';
        if (displayRepositorySelector == true) {
            var repositoryList = getFileRepositoryList();
            html += '<div class="fileupload-repository ">' + 
						'<label style="'+ cssFileRepositoryText +'">' + TW.Runtime.convertLocalizableString('[[fileRepository]]') + ':</label>';
			html += '<select class="repository-name" tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getFileRepositoryName() + '" id="' + getFileRepositoryName() + '" >'; 
           	for (var count = 0; count < repositoryList.length; count++) {
               var repositoryName = repositoryList[count].name;
               html += '<option value="' + repositoryName + '">' + repositoryName + '</option>';
           	}
            html += '</select></div>';
        } else {
            html += '<div class="fileupload-hidden-repository" style="display:none;">' + 
						'<input tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getFileRepositoryName() + '" id="' + getFileRepositoryName() + '" value="' + widgetReference.getProperty("RepositoryName") + '">' +
					'</div>';
        }

        return html;
    };

    var getPathHTML = function () {
        var html = '';
        if (displayPathTextBox == true) {
            html += '<div class="fileupload-path">' + 
							'<label style="'+ cssFileRepositoryText +'">' + TW.Runtime.convertLocalizableString('[[pathOnRepository]]') + ':</label>' +
							'<input class="upload-input" tabindex="' + widgetReference.getProperty('TabSequence') + '" type="text" name="' + getPathName() + '" id="' + getPathName() + '" value="' + widgetReference.getProperty("Path")  + '"></input>' +
            		'</div>';
        } else {
            html += '<div class="fileupload-hidden-path" style="display:none;">' + 
						'<input type="hidden" name="' + getPathName() + '" id="' + getPathName() + '" value="' + widgetReference.getProperty("Path")  + '"></input>' + 
            		'</div>';
        }
        return html;
    };

    var getInputFilesHTML = function () {
        var html = '';

        html += '<label for="' + getInputFilesName() + '" class="fileupload-file-label1" title="' +
                 'No file chosen' + '">' + 'Choose File' +
                '</label>' +
                '<label for="' + getInputFilesName() + '" class="fileupload-file-label2" title="' +
                 'No file chosen' + '">' + 'No file chosen' +
                '</label>' +
                '<input tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getInputFilesName() + '" accept="' +
                 widgetReference.getProperty('AllowedFileTypes') + '" id="' + getInputFilesName() +
                '" type="file" font-size="2" class="fileupload-file-input" size="18">' +
                '</input>';
        return html;
    };
       var getInputButtonID = function () {
        var key = '';
        key += getInputFilesName();
        return key;
    };
    var getSubmitButtonHTML = function () {
        var html = '';
        html += '<input tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getSubmitButtonName() + '" id="' + getSubmitButtonName() + '" type="submit" class="fileupload-submit-button" value="' + TW.Runtime.convertLocalizableString('[[upload]]') + '"></input>';
        return html;
    };
	
    var getSubmitButtonID = function () {
        var id = '';
        id += getSubmitButtonName();
        return id;
    };

    var shortenFilename = function(labelText) {
        var spn = $('<span style="visibility:hidden font-size: 11px;"></span>').text(labelText).appendTo('body');
        if (spn.width() > 100) {
            var tempString = labelText;
            var lengthlabelText = labelText.length;
            while (spn.width() > 100) {
                tempString = tempString.slice(0, tempString.length / 2 - 1) + tempString.slice(tempString.length / 2 + 1);
                spn.text(tempString);
            }
            var len = tempString.length;
            labelText = labelText.substr(0, (len / 2) - 1) + "..." + labelText.substr(lengthlabelText - (len / 2) + 2, lengthlabelText);
        }
        spn.remove();
        return labelText;
    };

};