﻿TW.Runtime.Widgets.labelchart = function () {
    this.MAX_SERIES = 24;
    var widgetReference = this;

    this.dynamicSeries = undefined;

    this.selectedItems = [];

    this.needsManualResize = true;

    this.afterRender = function () {
        var widgetProperties = this.properties;

        this.chartDefinition = {
        	widgetReference : widgetReference,
            orientation : widgetProperties['ChartOrientation'] ? widgetProperties['ChartOrientation'] : TW.ChartLibrary.ORIENTATION_VERTICAL,
            type : TW.ChartLibrary.CHART_TYPE_LABEL,
            axisMode : widgetProperties['StackSeries'] ? 'single' : widgetProperties['YAxisMode'],
           	enableSelection : widgetProperties['AllowSelection'],
           	enableHover : widgetProperties['EnableHover'],
    		style : widgetProperties['ChartStyle'] ? widgetProperties['ChartStyle'] : 'DefaultChartStyle',
    		width : widgetProperties['Width'],
    		height : widgetProperties['Height'],
            indicatorstyle : widgetProperties['ChartIndicatorStyle'] ? widgetProperties['ChartIndicatorStyle'] : 'DefaultChartIndicatorStyle',
           	indicator : true,
            legend : {
            	visible : (widgetProperties['ShowLegend'] === true),
            	fixedwidth : widgetProperties['LegendWidth'],
                orientation : widgetProperties['LegendOrientation'] === undefined ? TW.ChartLibrary.ORIENTATION_VERTICAL : widgetProperties['LegendOrientation'],
                location : widgetProperties['LegendLocation'],
        		style : widgetProperties['ChartLegendStyle'] ? widgetProperties['ChartLegendStyle'] : 'DefaultChartLegendStyle'
            },
            xaxis : {
            	zoom : false,
            	type : TW.ChartLibrary.AXIS_TYPE_LABEL,
            	format : widgetProperties['XAxisFormat']!== undefined ? widgetProperties['XAxisFormat'] : 'XXXXXXXXXX',
                labeltype : widgetProperties['XAxisLabelType']!== undefined ? widgetProperties['XAxisLabelType'] : 'STRING',
            	visible : widgetProperties['ShowXAxis'] !== undefined ? widgetProperties['ShowXAxis'] : true,
            	showlabels : widgetProperties['ShowXAxisLabels'] !== undefined ? widgetProperties['ShowXAxisLabels'] : true,
                showticks : widgetProperties['ShowXAxisTicks'] !== undefined ? widgetProperties['ShowXAxisTicks'] : true,
                grid : widgetProperties['ShowXAxisGrid'] !== undefined ? widgetProperties['ShowXAxisGrid'] : true,
                gridstyle : widgetProperties['GridStyle'] !== undefined ? widgetProperties['GridStyle'] : 'DefaultChartGridStyle',
            	labelrotation: widgetProperties['XAxisLabelRotation'],
            	intervals : 0,
            	labels : 0,
            	minorticks : 0,
            	autoscale : false,
            	zeroscale : false,
            	minimumvalue : 0,
            	maximumvalue : 0,
        		style : widgetProperties['XAxisStyle'] ? widgetProperties['XAxisStyle'] : 'DefaultChartAxisStyle',
                axistitle : widgetProperties['XAxisTitle'] ? this.getProperty('XAxisTitle') : '',
        		renderer : TW.Renderer.DEFAULT
            },
            yaxis : {
            	zoom : (widgetProperties['AllowYAxisZoom'] === true),
            	type : TW.ChartLibrary.AXIS_TYPE_NUMERIC,
            	labeltype : 'NUMBER',
            	format : widgetProperties['YAxisFormat']!== undefined ? widgetProperties['YAxisFormat'] : '0000.0',
            	autoscale : (widgetProperties['YAxisAutoscale'] === true),
            	zeroscale : (widgetProperties['YAxisZeroscale'] === true),
            	minimumvalue : widgetProperties['YAxisMinimum'],
            	maximumvalue : widgetProperties['YAxisMaximum'],
            	visible : widgetProperties['ShowYAxis'] !== undefined ? widgetProperties['ShowYAxis'] : true,
               	showlabels : widgetProperties['ShowYAxisLabels'] !== undefined ? widgetProperties['ShowYAxisLabels'] : true,
                showticks : widgetProperties['ShowYAxisTicks'] !== undefined ? widgetProperties['ShowYAxisTicks'] : true,
                showSmartLabels : widgetProperties['ShowYAxisSmartLabels'] !== undefined ? widgetProperties['ShowYAxisSmartLabels'] : false,
                grid : widgetProperties['ShowYAxisGrid'] !== undefined ? widgetProperties['ShowYAxisGrid'] : true,
                gridstyle : widgetProperties['GridStyle'] !== undefined ? widgetProperties['GridStyle'] : 'DefaultChartGridStyle',
                intervals : widgetProperties['YAxisIntervals'] !== undefined ? widgetProperties['YAxisIntervals'] : 10,
                labels : widgetProperties['YAxisLabels'] !== undefined ? widgetProperties['YAxisLabels'] : 2,
                minorticks : widgetProperties['YAxisMinorTicks'] !== undefined ? widgetProperties['YAxisMinorTicks'] : 1,
        		style : widgetProperties['YAxisStyle'] ? widgetProperties['YAxisStyle'] : 'DefaultChartAxisStyle',
                axistitle : widgetProperties['YAxisTitle'] ? this.getProperty('YAxisTitle') : '',
           		renderer : TW.Renderer.DEFAULT
            },
            yaxis2 : {
            	zoom : (widgetProperties['AllowYAxisZoom'] === true),
            	type : TW.ChartLibrary.AXIS_TYPE_NUMERIC,
            	labeltype : 'NUMBER',
            	format : widgetProperties['SecondaryYAxisFormat']!== undefined ? widgetProperties['SecondaryYAxisFormat'] : '0000.0',
            	autoscale : (widgetProperties['SecondaryYAxisAutoscale'] === true),
            	zeroscale : (widgetProperties['SecondaryYAxisZeroscale'] === true),
            	minimumvalue : widgetProperties['SecondaryYAxisMinimum'],
            	maximumvalue : widgetProperties['SecondaryYAxisMaximum'],
            	visible : widgetProperties['ShowYAxis'] !== undefined ? widgetProperties['ShowYAxis'] : true,
               	showlabels : widgetProperties['ShowYAxisLabels'] !== undefined ? widgetProperties['ShowYAxisLabels'] : true,
                showticks : widgetProperties['ShowYAxisTicks'] !== undefined ? widgetProperties['ShowYAxisTicks'] : true,
                grid : widgetProperties['ShowYAxisGrid'] !== undefined ? widgetProperties['ShowYAxisGrid'] : true,
                gridstyle : widgetProperties['GridStyle'] !== undefined ? widgetProperties['GridStyle'] : 'DefaultChartGridStyle',
                intervals : widgetProperties['YAxisIntervals'] !== undefined ? widgetProperties['YAxisIntervals'] : 10,
                labels : widgetProperties['YAxisLabels'] !== undefined ? widgetProperties['YAxisLabels'] : 2,
                minorticks : widgetProperties['YAxisMinorTicks'] !== undefined ? widgetProperties['YAxisMinorTicks'] : 1,
        		style : widgetProperties['YAxisStyle'] ? widgetProperties['YAxisStyle'] : 'DefaultChartAxisStyle',
                axistitle : widgetProperties['SecondaryYAxisTitle'] ? widgetProperties['SecondaryYAxisTitle'] : '',
           		renderer : TW.Renderer.DEFAULT
            },
            chartarea : {
                stacked : widgetProperties['StackSeries'] ? widgetProperties['StackSeries'] : false,
        		style : widgetProperties['ChartAreaStyle'] ? widgetProperties['ChartAreaStyle'] : 'DefaultChartAreaStyle',
                selectedstyle : widgetProperties['SelectedItemStyle'] ? widgetProperties['SelectedItemStyle'] : 'DefaultChartSelectionStyle'
            },
            title : {
        		style : widgetProperties['ChartTitleStyle'] ? widgetProperties['ChartTitleStyle'] : 'DefaultChartTitleStyle',
            	text : this.getProperty('ChartTitle')
            }
        };

        this.chart = new TW.ChartLibrary.Chart(this.chartDefinition);

        // Add initial series objects to it

        var seriesNumber;

        this.enableSelection = false;

        var chartSeries = new Array();

        this.chart.chartarea.series = chartSeries;

        for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
            var dataField = widgetProperties['DataField' + seriesNumber];

            if (dataField !== undefined && dataField !== '') {
                var seriesType = widgetProperties['SeriesType' + seriesNumber];

                if (seriesType == 'chart' || seriesType === undefined || seriesType == null) {
                	seriesType = widgetProperties['ChartType'];
                }

               	this.enableSelection = widgetProperties['AllowSelection'];

                var seriesmarkerType = widgetProperties['SeriesMarkerType' + seriesNumber];
                if(seriesmarkerType === undefined || seriesmarkerType == 'chart')
                	seriesmarkerType = widgetProperties['MarkerType'];

            	var seriesDefinition = {
            		type : seriesType,
            		field : dataField,
            		label : this.getProperty('DataLabel' + seriesNumber),
            		smoothing : widgetProperties['Smoothing'],
            		style : widgetProperties['SeriesStyle' + seriesNumber],
            		datastyle : widgetProperties['SeriesDataStyle' + seriesNumber],
            		markertype : seriesmarkerType,
            		markersize : widgetProperties['MarkerSize'],
            		useSecondaryAxis : (widgetProperties['UseSecondaryAxis' + seriesNumber] === true),
                	customAxisFormat : widgetProperties['AxisFormat' + seriesNumber]!== undefined ? widgetProperties['AxisFormat' + seriesNumber] : '0000.0',
                	customAxisAutoscale : (widgetProperties['AxisAutoscale' + seriesNumber] === true),
                	customAxisZeroscale : (widgetProperties['AxisZeroscale' + seriesNumber] === true),
                	customAxisMinimumvalue : widgetProperties['AxisMinimum' + seriesNumber],
                	customAxisMaximumvalue : widgetProperties['AxisMaximum' + seriesNumber]
            	};

            	var series = new TW.ChartLibrary.ChartSeries(this.chart,seriesDefinition,seriesNumber-1);

            	chartSeries.push(series);

                this.selectedItems.push(new Array());
            }
        }

        this.chart.render();

        widgetProperties = null;
    };

    this.beforeDestroy = function () {
        if(this.chart !== undefined) {
            try {
            	this.chart.destroy();
            	this.chart = null;
            	delete this.chart;
            }
            catch (destroyErr) {
            }
        }

        if (this.chartDefinition !== undefined) {
            try {
                this.chartDefinition.widgetReference = null;
                this.chartDefinition = null;
                delete this.chartDefinition;
            }
            catch (destroyErr) {
            }
        }

        this.selectedItems = [];
        delete this.selectedItems;

        widgetReference = null;
    };

	this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {

    	if(widgetReference.enableSelection) {
            TW.ChartLibrary.handleChartSelectionUpdate(this, this.chart, propertyName, selectedRowIndices);
    	}
	};

    this.updateProperty = function (updatePropertyInfo) {
        var widgetProperties = this.properties;

        if (updatePropertyInfo.TargetProperty === "ChartTitle") {
        	this.setProperty('ChartTitle', updatePropertyInfo.RawSinglePropertyValue);
        	this.chart.title.text = this.getProperty('ChartTitle');
        }

        if (updatePropertyInfo.TargetProperty === "XAxisTitle") {
        	this.setProperty('XAxisTitle', updatePropertyInfo.RawSinglePropertyValue);
        	this.chart.xaxis.axistitle = this.getProperty('XAxisTitle');
        }

        if (updatePropertyInfo.TargetProperty === "YAxisTitle") {
        	this.setProperty('YAxisTitle', updatePropertyInfo.RawSinglePropertyValue);
        	this.chart.yaxis.axistitle = this.getProperty('YAxisTitle');
        }

        if (updatePropertyInfo.TargetProperty === "XAxisMinimum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.xaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.xaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue;
        }

        if (updatePropertyInfo.TargetProperty === "XAxisMaximum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.xaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.xaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue;
        }

        if (updatePropertyInfo.TargetProperty === "YAxisMinimum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis.minimumvalue = updatePropertyInfo.RawSinglePropertyValue;
        }

        if (updatePropertyInfo.TargetProperty === "YAxisMaximum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis.maximumvalue = updatePropertyInfo.RawSinglePropertyValue;
        }

        if (updatePropertyInfo.TargetProperty === "SecondaryYAxisMinimum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis2.minimumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis2.minimumvalue = updatePropertyInfo.RawSinglePropertyValue;
        }

        if (updatePropertyInfo.TargetProperty === "SecondaryYAxisMaximum") {
            if (updatePropertyInfo.RawSinglePropertyValue instanceof Date)
                this.chart.yaxis2.maximumvalue = updatePropertyInfo.RawSinglePropertyValue.getTime();
            else
                this.chart.yaxis2.maximumvalue = updatePropertyInfo.RawSinglePropertyValue;
        }

        var updatePropertyInfoForselectedRows = null;
        if (updatePropertyInfo.TargetProperty.indexOf('DataField') === 0) {
        	for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
            	var fieldName = 'DataField' + seriesNumber.toString();
                var series = this.chart.chartarea.series[seriesNumber-1];
            	if (updatePropertyInfo.TargetProperty === fieldName) {
            		if (series !== undefined) {
            			this.setProperty(fieldName, updatePropertyInfo.RawSinglePropertyValue);
			            series.field = this.getProperty(fieldName);
            		} else {
            			this.setProperty(fieldName, updatePropertyInfo.RawSinglePropertyValue);
            		}
            	}
        	}
        } else if (updatePropertyInfo.TargetProperty.indexOf('Data') === 0) {
            var dataRows = updatePropertyInfo.ActualDataRows;

            // Prepare series data

            var seriesNumber;

            if (updatePropertyInfo.TargetProperty === "Data") {

            	// Process shared x axis values

            	var xAxisFieldName = widgetProperties['XAxisField'];

                this.chart.processDataset(dataRows,xAxisFieldName);

                for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
                    var series = this.chart.chartarea.series[seriesNumber - 1];
                    if(series !== undefined && series.field !== undefined && series.field != '') {

                        series.processDataset(dataRows,undefined);

                        // Assign shared x axis values

                        series.xvalues = this.chart.xvalues;
                    }
                }

            }
            else {
                for (seriesNumber = 1; seriesNumber <= widgetProperties['NumberOfSeries']; seriesNumber++) {
                	var series = this.chart.chartarea.series[seriesNumber-1];

                	if (series !== undefined && series !== null) {
                    	var sourceName = 'DataSource' + seriesNumber.toString();

	                    if (updatePropertyInfo.TargetProperty == sourceName) {


	                        if(series !== undefined && series.field !== undefined && series.field != '') {
	                            var xAxisFieldName = widgetProperties['XAxisField' + seriesNumber];
	                            if(xAxisFieldName == undefined) {
	                            	xAxisFieldName = widgetProperties['XAxisField'];
	                            }

	                            series.processDataset(dataRows,xAxisFieldName);
	                        }
	                    } else {
	                    	var labelName = 'DataLabel' + seriesNumber.toString();
	                    	if (updatePropertyInfo.TargetProperty == labelName) {
	                    		this.setProperty(labelName, updatePropertyInfo.RawSinglePropertyValue);
	                    		series.label = this.getProperty(labelName);
	                    	}
	                    }
                	}
                }
            }

            updatePropertyInfoForselectedRows = updatePropertyInfo; // to keep old logic
        } //Data update

        this.delayedRender(updatePropertyInfoForselectedRows); // any change requires render
    };

    /* this function is called by updateProperty() after new data was implanted into the chart
    * this function runs render(). But does it with 100ms delay
    * so if more updates available during this slot of time - render wll be called only once (at the end)
    * @param updatePropertyInfo is required only for the case we have selected rows
    */
    this.delayedRender = function(updatePropertyInfo) {
        var thisWidget = this;

        // remove previously set render (if exists)
        if (this.renderTimeout) {
            clearTimeout(this.renderTimeout);
            this.renderTimeout = null;
        }

        // there is currently running render process. Will try to repeat the same call again in 100ms
        if (this.isRendering) {
            this.renderTimeout = setTimeout(function () {
                thisWidget.delayedRender(updatePropertyInfo);
            }, 100);

            return;
        }

        this.renderTimeout = setTimeout(function () {
            thisWidget.isRendering = true; // set flag - we are in rendering
            thisWidget.renderTimeout = null;
            try {
                thisWidget.chart.render();

                // this code was moved here from the updatProperties() since it should be called after the render...
                if(updatePropertyInfo && widgetReference.enableSelection) {
                    var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;

                    if (selectedRowIndices !== undefined) {
                        TW.ChartLibrary.handleChartSelectionUpdate(thisWidget, thisWidget.chart, updatePropertyInfo.TargetProperty, selectedRowIndices);
                    }
                    else {
                        TW.ChartLibrary.handleChartSelectionUpdate(thisWidget, thisWidget.chart, updatePropertyInfo.TargetProperty, new Array());
                    }
                }
            }catch (err) {
                TW.log.error('Runtime exception during chart rendering', err);
            }
            thisWidget.isRendering = false; // remove flag - we are in rendering
        }, 100);
    };

	this.resize = function(width,height) {
		this.chart.resize(width, height);
	};

    var buildLocalizablePropertyAttributes = function (widget) {
        var seriesNumber;

    	var attributes = {'ChartTitle':{'isLocalizable':true}};
		var nSeries = widget.getProperty('NumberOfSeries');
		for (seriesNumber = 1; seriesNumber <= nSeries; seriesNumber++) {
			attributes['DataLabel' + seriesNumber] = {'isLocalizable': true};
        }
        attributes['XAxisTitle'] = {'isLocalizable': true};
        attributes['YAxisTitle'] = {'isLocalizable': true};        
		return attributes;
    };

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': true,
            'supportsAutoResize': true,
            'borderWidth': 0,
            'propertyAttributes': buildLocalizablePropertyAttributes(this)
        };
    };

    this.renderHtml = function () {
        var html = '<div class="widget-content widget-labelchart-container svg-chrome-fix"></div>';
        return html;
    };

};
