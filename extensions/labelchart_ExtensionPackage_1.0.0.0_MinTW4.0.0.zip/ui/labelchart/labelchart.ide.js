﻿TW.IDE.Widgets.labelchart = function () {

    this.MAX_SERIES = 24;

    this.widgetProperties = function () {
        var properties = {
            'name': TW.IDE.I18NController.translate('tw.labelchart-ide.widget.name'),
            'description': TW.IDE.I18NController.translate('tw.labelchart-ide.widget.description'),
            'category': ['Data', 'Charts'],
            'supportsLabel': false,
            'borderWidth': 0,
            'supportsAutoResize': true,
            'defaultBindingTargetProperty': 'Data',
            'properties': {
                'SingleDataSource': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.single-data-source.description'),
                    'defaultValue': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true
                },
                'NumberOfSeries': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.number-of-series.description'),
                    'defaultValue': 8,
                    'baseType': 'NUMBER',
                    'isVisible': true
                },
                'Data': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.data.description'),
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'ChartType': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-type.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'bar',
                    'selectOptions': [
                        { value: 'line', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-type.select-options.line') },
                        { value: 'marker', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-type.select-options.marker') },
                        { value: 'linemarker', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-type.select-options.line-marker') },
                        { value: 'bar', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-type.select-options.bar') },
                        { value: 'area', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-type.select-options.area') },
                        { value: 'areamarker', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-type.select-options.area-marker') }
                    ]
                },
                'StackSeries': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.stack-series.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'ChartOrientation': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-orientation.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'vertical',
                    'isVisible' : true,
                    'selectOptions': [
                        { value: 'vertical', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-orientation.select-options.vertical') },
                        { value: 'horizontal', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-orientation.select-options.horizontal') }
                    ]
                },
                'ChartStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartStyle'
                },
                'ChartAreaStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-area-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartAreaStyle'
                },
                'ChartLegendStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-legend-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartLegendStyle'
                },
                'ChartTitleStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-title-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartTitleStyle'
                },
                'ChartIndicatorStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-indicator-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartIndicatorStyle'
                },
                'SelectedItemStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.selected-item-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartSelectionStyle'
                },
                'ChartTitle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.chart-title.description'),
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'isLocalizable': true
                },
                'ShowLegend': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-legend.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'LegendWidth': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-width.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'LegendLocation': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-location.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'right',
                    'selectOptions': [
                        { value: 'right', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-location.select-options.right') },
                        { value: 'top', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-location.select-options.top') },
                        { value: 'bottom', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-location.select-options.bottom') },
                        { value: 'left', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-location.select-options.left') }
                    ]
                },
                'LegendOrientation': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-orientation.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'vertical',
                    'selectOptions': [
                        { value: 'vertical', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-orientation.select-options.vertical') },
                        { value: 'horizontal', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.legend-orientation.select-options.horizontal') }
                    ]
                },
                'MarkerSize': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.marker-size.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 3
                },
                'MarkerType': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.marker-type.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'circle',
                    'selectOptions': [
                        { value: 'circle', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.marker-type.select-options.circle') },
                        { value: 'square', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.marker-type.select-options.square') },
                        { value: 'triangle', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.marker-type.select-options.triangle') },
                        { value: 'diamond', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.marker-type.select-options.diamond') },
                        { value: 'image', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.marker-type.select-options.image') }
                    ]
                },
                'Smoothing': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.smoothing.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'XAxisField': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-field.description'),
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data',
                    'isBindingTarget': false,
                    'isVisible': true
                },
                'ShowXAxis': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-x-axis.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'XAxisStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartAxisStyle'
                },
                'XAxisFormat': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-format.description'),
                    'baseType': 'STRING',
                    'defaultValue' : '0000.0'
                },
                'XAxisLabelType': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-label-type.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'STRING',
                    'selectOptions': [
                        { value: 'STRING', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-label-type.select-options.string') },
                        { value: 'NUMERIC', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-label-type.select-options.numeric') },
                        { value: 'DATETIME', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-label-type.select-options.date-time') }
                    ]
                },
                'XAxisLabelRotation': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-label-rotation.description'),
                    'baseType': 'NUMBER',
                    'defaultValue' : 0
                },
                'ShowXAxisLabels': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-x-axis-labels.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowXAxisTicks': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-x-axis-ticks.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'XAxisTitle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.x-axis-title.description'),
                    'baseType': 'STRING',
                    'defaultValue': '',
                    'isBindingTarget': true,
                    'isLocalizable': true
                },
                'YAxisTitle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-title.description'),
                    'baseType': 'STRING',
                    'defaultValue': '',
                    'isBindingTarget': true,
                    'isLocalizable': true
                },
                'SecondaryYAxisTitle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.secondary-y-axis-title.description'),
                    'baseType': 'STRING',
                    'defaultValue': ''
                },
                'ShowYAxis': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-y-axis.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'YAxisMode': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-mode.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'single',
                    'isVisible' : true,
                    'selectOptions': [
                        { value: 'single', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-mode.select-options.single') },
                        { value: 'dual', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-mode.select-options.dual') },
                        { value: 'multi', text: TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-mode.select-options.multi') }
                    ]
                },
                'ShowYAxisLabels': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-y-axis-labels.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowYAxisTicks': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-y-axis-ticks.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowYAxisSmartLabels': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-y-axis-smart-labels.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'YAxisStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartAxisStyle'
                },
                'YAxisFormat': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-format.description'),
                    'baseType': 'STRING',
                    'defaultValue' : '0000.0'
                },
                'YAxisIntervals': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-intervals.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 10
                },
                'YAxisMinorTicks': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-minor-ticks.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 1
                },
                'YAxisLabels': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-labels.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 2
                },
                'AllowYAxisZoom': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.allow-y-axis-zoom.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'YAxisMinimum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-minimum.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0.0
                },
                'YAxisMaximum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-maximum.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 100.0
                },
                'YAxisAutoscale': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-auto-scale.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'YAxisZeroscale': {
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.y-axis-zero-scale.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'SecondaryYAxisFormat': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.secondary-y-axis-format.description'),
                    'baseType': 'STRING',
                    'defaultValue' : '0000.0'
                },
                'SecondaryYAxisMinimum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.secondary-y-axis-minimum.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0.0
                },
                'SecondaryYAxisMaximum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.secondary-y-axis-maximum.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 100.0
                },
                'SecondaryYAxisAutoscale': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.secondary-y-axis-auto-scale.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'SecondaryYAxisZeroscale': {
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.secondary-y-axis-zero-scale.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'AllowSelection': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.allow-selection.description'),
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true
                },
                'EnableHover': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.enable-hover.description'),
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true
                },
                'ShowXAxisGrid': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-x-axis-grid.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowYAxisGrid': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.show-y-axis-grid.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'GridStyle': {
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.grid-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartGridStyle'
                },
                'Width': {
                    'defaultValue': 640,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.width.description')
                },
                'Height': {
                    'defaultValue': 240,
                    'description': TW.IDE.I18NController.translate('tw.labelchart-ide.properties.height.description')
                }
            }
        };

        var seriesNumber;
        for (seriesNumber = 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
            var datasetProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.data-set-property.description') + seriesNumber,
                'isBindingTarget': true,
                'isEditable': false,
                'baseType': 'INFOTABLE',
                'warnIfNotBoundAsTarget': false,
                'isVisible': true
            };

            var datalabelProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.data-label-property.description') + seriesNumber,
                'baseType': 'STRING',
                'isBindingTarget': true,
                'isVisible': true,
                'isLocalizable': true
            };

            var datafieldProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.data-field-property.description') + seriesNumber,
                'baseType': 'FIELDNAME',
                'sourcePropertyName': 'Data',
                'isBindingTarget': false,
                'baseTypeRestriction': 'NUMBER',
                'isVisible': true
            };

            var xaxisfieldProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.x-axis-field-property.description') + seriesNumber,
                'baseType': 'FIELDNAME',
                'sourcePropertyName': 'Data',
                'isBindingTarget': false,
                'isVisible': true
            };

            var seriestypeProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-type-property.description'),
                'baseType': 'STRING',
                'defaultValue' : 'chart',
                'selectOptions': [
                    { value: 'chart', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-type-property.select-options.chart') },
                    { value: 'line', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-type-property.select-options.line') },
                    { value: 'linemarker', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-type-property.select-options.line-marker') },
                    { value: 'marker', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-type-property.select-options.marker') },
                    { value: 'bar', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-type-property.select-options.bar') }
                ]
            };

            var seriesmarkertypeProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-marker-type-property.description'),
                'baseType': 'STRING',
                'defaultValue': 'chart',
                'selectOptions': [
                    { value: 'chart', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-marker-type-property.select-options.chart') },
                    { value: 'circle', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-marker-type-property.select-options.circle') },
                    { value: 'square', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-marker-type-property.select-options.square') },
                    { value: 'triangle', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-marker-type-property.select-options.triangle') },
                    { value: 'diamond', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-marker-type-property.select-options.diamond') },
                    { value: 'image', text: TW.IDE.I18NController.translate('tw.labelchart-ide.series-marker-type-property.select-options.image') }
                ]
            };

            var seriesStyleProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-style-property.description') + seriesNumber,
                'baseType': 'STYLEDEFINITION',
                'isVisible': true
            };

            var seriesDataStyleProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-data-style-property.description') + seriesNumber,
                'baseType': 'STATEFORMATTING',
                'baseTypeInfotableProperty': 'Data',
                'isVisible': true
            };

            var seriesUseSecondaryYAxisProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-use-secondary-y-axis-property.description'),
                'baseType': 'BOOLEAN',
                'defaultValue' : false,
                'isVisible' : true
            };

            var seriescustomAxisFormatProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-custom-axis-format-property.description'),
                'baseType': 'STRING',
                'defaultValue' : '0000.0',
                'isVisible' : false
            };

            var seriescustomAxisMinimumProperty = {
                'isBindingTarget': true,
                'isVisible': true,
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-custom-axis-minimum-property.description'),
                'baseType': 'NUMBER',
                'defaultValue': 0.0,
                'isVisible' : false
            };

            var seriescustomAxisMaximumProperty = {
                'isBindingTarget': true,
                'isVisible': true,
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-custom-axis-maximum-property.description'),
                'baseType': 'NUMBER',
                'defaultValue': 100.0,
                'isVisible' : false
            };

            var seriescustomAxisAutoscaleProperty = {
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-custom-axis-auto-scale-property.description'),
                'baseType': 'BOOLEAN',
                'defaultValue': true,
                'isVisible' : false
            };

            var seriescustomAxisZeroscaleProperty = {
                'isVisible': true,
                'description': TW.IDE.I18NController.translate('tw.labelchart-ide.series-custom-axis-zero-scale-property.description'),
                'baseType': 'BOOLEAN',
                'defaultValue': false,
                'isVisible' : false
            };

            properties.properties['DataSource' + seriesNumber] = datasetProperty;
            properties.properties['DataField' + seriesNumber] = datafieldProperty;
            properties.properties['DataLabel' + seriesNumber] = datalabelProperty;
            properties.properties['XAxisField' + seriesNumber] = xaxisfieldProperty;
            properties.properties['SeriesType' + seriesNumber] = seriestypeProperty;
            properties.properties['SeriesMarkerType' + seriesNumber] = seriesmarkertypeProperty;
            properties.properties['UseSecondaryAxis' + seriesNumber] = seriesUseSecondaryYAxisProperty;
            properties.properties['AxisFormat' + seriesNumber] = seriescustomAxisFormatProperty;
            properties.properties['AxisMinimum' + seriesNumber] = seriescustomAxisMinimumProperty;
            properties.properties['AxisMaximum' + seriesNumber] = seriescustomAxisMaximumProperty;
            properties.properties['AxisAutoscale' + seriesNumber] = seriescustomAxisAutoscaleProperty;
            properties.properties['AxisZeroscale' + seriesNumber] = seriescustomAxisZeroscaleProperty;
            properties.properties['SeriesStyle' + seriesNumber] = seriesStyleProperty;
            properties.properties['SeriesStyle' + seriesNumber]['defaultValue'] = 'DefaultChartStyle' + seriesNumber;
            properties.properties['SeriesDataStyle' + seriesNumber] = seriesDataStyleProperty;
        }

        return properties;
    };

    this.setSeriesAxisProperties = function(value) {
        var allWidgetProps = this.allWidgetProperties();

        var mode = this.getProperty('YAxisMode');

        var seriesNumber;

        if(mode == 'multi') {
            for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = true;
            }
            for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
        }
        else if(mode == 'dual') {
            for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
            for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
        }
        else {
            for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
            for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
        }
    };

    this.setSeriesProperties = function (value, singleSource) {
        var allWidgetProps = this.allWidgetProperties();

        var seriesNumber;

        for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
            allWidgetProps['properties']['DataField' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['DataSource' + seriesNumber]['isVisible'] = !singleSource;
            allWidgetProps['properties']['XAxisField' + seriesNumber]['isVisible'] = !singleSource;
            allWidgetProps['properties']['SeriesStyle' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['SeriesType' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['SeriesMarkerType' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['DataLabel' + seriesNumber]['isVisible'] = true;
        }

        for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
            allWidgetProps['properties']['DataField' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['DataSource' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['XAxisField' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesStyle' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesMarkerType' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesType' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['DataLabel' + seriesNumber]['isVisible'] = false;
        }

        if (singleSource) {
            for (seriesNumber = 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['DataField' + seriesNumber]['sourcePropertyName'] = 'Data';
                allWidgetProps['properties']['XAxisField' + seriesNumber]['sourcePropertyName'] = 'Data';
                allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['baseTypeInfotableProperty'] = 'Data';
            }

            allWidgetProps['properties']['Data']['isVisible'] = true;
            allWidgetProps['properties']['XAxisField']['isVisible'] = true;
        }
        else {
            for (seriesNumber = 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['DataField' + seriesNumber]['sourcePropertyName'] = 'DataSource' + seriesNumber;
                allWidgetProps['properties']['XAxisField' + seriesNumber]['sourcePropertyName'] = 'DataSource' + seriesNumber;
                allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['baseTypeInfotableProperty'] = 'DataSource' + seriesNumber;
            }
            allWidgetProps['properties']['Data']['isVisible'] = false;
            allWidgetProps['properties']['XAxisField']['isVisible'] = false;
        }
    };

    this.widgetEvents = function () {
        return {
        	'DoubleClicked': {}
        };
    };


    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-labelchart"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span>'+ TW.IDE.I18NController.translate('tw.labelchart-ide.label-chart') +'</span></td></tr></table></div>';
        return html;
    };

    this.afterLoad = function () {
        this.setSeriesProperties(this.getProperty('NumberOfSeries'), this.getProperty('SingleDataSource'));
        this.setSeriesAxisProperties(this.getProperty('NumberOfSeries'));
    };

    this.afterSetProperty = function (name, value) {
        if (name === 'Width' || name === 'Height') {
            return true;
        }

        if (name.indexOf('YAxisMode') === 0) {
            this.setSeriesAxisProperties(this.getProperty('NumberOfSeries'));
            this.updatedProperties();

            return true;
        }

        if (name === 'NumberOfSeries' || name === 'SingleDataSource') {

            this.setSeriesProperties(this.getProperty('NumberOfSeries'), this.getProperty('SingleDataSource'));
            this.updatedProperties();

            return true;
        }
    };

    this.beforeSetProperty = function (name, value) {
        if (name === 'NumberOfSeries') {
            value = parseInt(value, 10);
            if (value <= 0 || value > 24)
                return TW.IDE.I18NController.translate('tw.labelchart-ide.number-series-warning');
        }
    };

    this.validate = function () {
        var result = [];

        if (!this.isPropertyBoundAsTarget('Data')) {
        	var bound = false;

            for (var seriesNumber = 1; seriesNumber <= 24; seriesNumber++) {
                var dsProperty = 'DataSource' + seriesNumber;
                if(this.isPropertyBoundAsTarget(dsProperty)) {
                	bound = true;
                	break;
                }
            }

            if(!bound)
            	result.push({ severity: 'warning', message: TW.IDE.I18NController.translate('tw.labelchart-ide.data-source-warning') });
        }
        return result;
    };

    this.afterAddBindingSource = function (bindingInfo) {
        if (bindingInfo.targetProperty == "Data") {
            this.setProperty('SingleDataSource', true);

            this.setSeriesProperties(this.getProperty('NumberOfSeries'), this.getProperty('SingleDataSource'));
            this.updatedProperties();
        }
    };};