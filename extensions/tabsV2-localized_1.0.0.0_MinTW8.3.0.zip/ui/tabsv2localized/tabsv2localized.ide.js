TW.IDE.Widgets.tabsv2localized = function () {
	var thisWidget = this;
	var tabContainer; // the tabsv2localized is a special container.  The ID ends up on an inner div
	var overallJqElement, tabViewport, tabsRow, nextScrollBtn, backScrollBtn, tabSlider;
	var nTabs;
	var tabMaxWidth;
	var curTab = 0, tabPageOffset = 0, tabSlideWidth;
	var tabHeight = 29;
	var tabSpacing = 2;
	var defaultNumberOfTabs = 2;
	var roundedCorners = true, cornerRadius;
	var priorNumberOfTabs = undefined;

	this.MAX_TABS = 16;

	this.widgetProperties = function () {
		var properties = {
				'name': "Pf_Tabs - Localized Responsive",
				'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.widget.description'),
				'category': ['Common', 'Containers'],
				'isContainer': true,
				'allowPasteOrDrop': false,
				'isDraggable': false,
				'allowPositioning': false,
				'supportsAutoResize': true,
				'onlySupportedInResponsiveParents': false,
				'isContainerWithDeclarativeSpotsForSubWidgets': true,
				'isVisible': true,
				'iconImage': 'tabsv2localized.ide.png',
				'properties': {
					'CustomClass': {
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.custom-class.description'),
						'baseType': 'STRING',
						'isLocalizable': false,
						'isBindingSource': true,
						'isBindingTarget': true,
						'isVisible': false
					},
					'NumberOfTabs': {
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.number-of-tabs.description'),
						'defaultValue': 2,
						'baseType': 'NUMBER'
					},
					'DefaultTabAtRuntime': {
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.default-tab-at-runtime.description'),
						'defaultValue': 1,
						'baseType': 'NUMBER'
					},
					'CurrentTab': {
						'defaultValue': 1,
						'baseType': 'NUMBER',
						'isVisible': false
					},
					'Width': {
						'baseType': 'NUMBER',
						'defaultValue': 300,
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.width.description')
					},
					'Height': {
						'baseType': 'NUMBER',
						'defaultValue': 300,
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.height.description')
					},
					'SelectedTabValue': {
						'baseType': 'STRING',
						'isBindingTarget': true,
						'isBindingSource': true,
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.selected-tab-value.description')
					},
					'SelectedTabName': {
						'baseType': 'STRING',
						'isBindingTarget': true,
						'isBindingSource': true,
						'isLocalizable': true,
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.selected-tab-name.description')
					},
					'TabHeight': {
						'baseType': 'NUMBER',
						'defaultValue': 27,
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.tab-height.description')
					},
					'MaxTabWidth':{
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.tab-max-width.description'),
						'baseType': 'NUMBER',
						'defaultValue':256
					},
					'TabSpacing': {
						'baseType': 'NUMBER',
						'defaultValue': 2,
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.tab-spacing.description')
					},
					'RoundedCorners': {
						'baseType': 'BOOLEAN',
						'defaultValue': true,
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.rounded-corners.description')
					},
					'TabSelectedStyle': {
						'baseType': 'STYLEDEFINITION',
						'defaultValue': 'DefaultTabSelectedStyle',
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.tab-selected-style.description')
					},
					'TabUnselectedStyle': {
						'baseType': 'STYLEDEFINITION',
						'defaultValue': 'DefaultTabUnselectedStyle',
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.tab-unselected-style.description')
					},
					'TabContentStyle': {
						'baseType': 'STYLEDEFINITION',
						'defaultValue': 'DefaultTabContentStyle',
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.tab-content-style.description')
					},
					'TabDisabledStyle': {
						'baseType': 'STYLEDEFINITION',
						'defaultValue': 'DefaultTabDisabledStyle',
						'description': TW.IDE.I18NController.translate('tw.tabsv2r-ide.properties.tab-disabled-style.description')
					}
				}
		};

		var tabsv2r_name_i18n = TW.IDE.I18NController.translate('tw.tabsv2r-ide.tab-name.description');
		var tabsv2r_value_i18n = TW.IDE.I18NController.translate('tw.tabsv2r-ide.tab-value.description');
		var tabsv2r_image_i18n = TW.IDE.I18NController.translate('tw.tabsv2r-ide.tab-image.description');
		var tabsv2r_visible_i18n = TW.IDE.I18NController.translate('tw.tabsv2r-ide.tab-visible.description');
		var tabsv2r_disabled_i18n = TW.IDE.I18NController.translate('tw.tabsv2r-ide.tab-disabled.description');

		for (var tabNumber = 1; tabNumber <= this.MAX_TABS; tabNumber++) {
			// Added binding target property to true to tab name at line 133
			properties.properties['Tab' + tabNumber + 'Name'] = {
					'description': tabsv2r_name_i18n + tabNumber,
					'baseType': 'STRING',
					'defaultValue': 'Tab' + tabNumber + 'Name',
					'isLocalizable': true,
					'isBindingTarget': true,
					'isVisible': (tabNumber <= defaultNumberOfTabs)
			};
			properties.properties['Tab' + tabNumber + 'Value'] = {
					'description':  tabsv2r_value_i18n + tabNumber,
					'baseType': 'STRING',
					'defaultValue': 'Tab' + tabNumber + 'Value',
					'isVisible': (tabNumber <= defaultNumberOfTabs)
			};
			properties.properties['Tab' + tabNumber + 'Image'] = {
					'description':  tabsv2r_image_i18n + tabNumber,
					'baseType': 'IMAGELINK',
					'defaultValue': '',
					'isVisible': (tabNumber <= defaultNumberOfTabs)
			};
			properties.properties['Tab' + tabNumber + 'Visible'] = {
					'description': tabsv2r_visible_i18n + tabNumber,
					'baseType': 'BOOLEAN',
					'defaultValue': true,
					'isBindingTarget': true,
					'isVisible': (tabNumber <= defaultNumberOfTabs)
			};
			properties.properties['Tab' + tabNumber + 'Disabled'] = {
					'description': tabsv2r_disabled_i18n + tabNumber,
					'baseType': 'BOOLEAN',
					'defaultValue': false,
					'isBindingTarget': true,
					'isVisible': (tabNumber === 1)
			};
		}

		return properties;
	};

	this.afterCreate = function() {

		for( var i=0; i<defaultNumberOfTabs; i++ ) {
			var widgetToAdd = TW.IDE.Widget.factory({ 'Type': 'container' });
			var newId = TW.IDE.Workspace.Mashups.NewID('container');
			widgetToAdd.setProperty('Id', newId);
			widgetToAdd.setInternalProperty('DisplayName', 'Tab #' + (i+1));
			widgetToAdd.setInternalProperty('ResponsiveLayout', true);
			thisWidget.addWidget(widgetToAdd, true /*new*/);
		}
	};

	this.updateNumberOfTabs = function (numberOfTabs) {
		var allWidgetProps = this.allWidgetProperties();
		for (var tabNumber = 1; tabNumber <= numberOfTabs; tabNumber++) {
			allWidgetProps['properties']['Tab' + tabNumber + 'Name']['isVisible'] = true;
			allWidgetProps['properties']['Tab' + tabNumber + 'Value']['isVisible'] = true;
			allWidgetProps['properties']['Tab' + tabNumber + 'Image']['isVisible'] = true;
			allWidgetProps['properties']['Tab' + tabNumber + 'Visible']['isVisible'] = true;
			allWidgetProps['properties']['Tab' + tabNumber + 'Disabled']['isVisible'] = true;
		}
		for (var tabNumber = numberOfTabs + 1; tabNumber <= this.MAX_TABS; tabNumber++) {
			allWidgetProps['properties']['Tab' + tabNumber + 'Name']['isVisible'] = false;
			allWidgetProps['properties']['Tab' + tabNumber + 'Value']['isVisible'] = false;
			allWidgetProps['properties']['Tab' + tabNumber + 'Image']['isVisible'] = false;
			allWidgetProps['properties']['Tab' + tabNumber + 'Visible']['isVisible'] = false;
			allWidgetProps['properties']['Tab' + tabNumber + 'Disabled']['isVisible'] = false;
		}
	};

	this.widgetEvents = function () {
		return {
			'TabSelected': { 'warnIfNotBound': false, 'description': TW.IDE.I18NController.translate('tw.tabs-ide.events.tab-selected.description') }
		}
	};

	this.widgetServices = function () {
		return {
			'SelectDefaultTab': { 'warnIfNotBound': false, 'description': TW.IDE.I18NController.translate('tw.tabs-ide.services.select-default-tab.description') }
		};
	};

	this.beforeSetProperty = function (name, value) {
		if (name === 'NumberOfTabs') {
			priorNumberOfTabs = this.getProperty('NumberOfTabs');
			value = parseInt(value, 10);
			if (isNaN(value) || value <= 0 || value > this.MAX_TABS) {
				return TW.IDE.I18NController.translate('tw.tabsv2r-ide.number-of-tabs-warning') + this.MAX_TABS.toString();
			}
		}
	};

	this.afterSetProperty = function (name, value) {
		var result = false;
		switch (name) {
		case 'NumberOfTabs':
			result = true;
			if (this.getProperty('CurrentTab') >= value) {
				thisWidget.properties['CurrentTab'] = value;
			}

			var nNewNumberOfTabsRequested = this.getProperty('NumberOfTabs');
			if( nNewNumberOfTabsRequested > priorNumberOfTabs ) {
				// adding tabs
				for( var i=priorNumberOfTabs; i<nNewNumberOfTabsRequested; i++ ) {
					var widgetToAdd = TW.IDE.Widget.factory({ 'Type': 'container' });
					var newId = TW.IDE.Workspace.Mashups.NewID('container');
					widgetToAdd.setProperty('Id', newId);
					widgetToAdd.setInternalProperty('DisplayName', 'Tab #' + (i+1));
					widgetToAdd.setInternalProperty('ResponsiveLayout', true);
					thisWidget.addWidget(widgetToAdd, true /*new*/);
				}
			} else {
				thisWidget.widgets.splice(nNewNumberOfTabsRequested,priorNumberOfTabs-nNewNumberOfTabsRequested);
			}
			this.updateNumberOfTabs(nNewNumberOfTabsRequested);
			this.updatedProperties();
			TW.IDE.updateWorkspaceExplorer();
			break;
		case 'CurrentTab':
			result = false;
			break;
		case 'TabHeight':
		case 'TabSpacing':
		case 'RoundedCorners':
		default:
			result = true;
		break;
		}
		return result;
		this.updateTabsRow();
	};

	this.renderHtml = function () {
		var tabMaxWidth = parseInt(thisWidget.getProperty("MaxTabWidth"));
		var htmlTabs = '';
		var htmlTabContents = '';
		var curTabNumber = this.getProperty('CurrentTab') || 1;

		tabHeight = thisWidget.getProperty('TabHeight',29);

		nTabs = this.getProperty('NumberOfTabs');

		for (var tabNumber = 1; tabNumber <= nTabs; tabNumber++) {
			var tagImageUrl = this.getProperty('Tab' + tabNumber + 'Image');
			if (tagImageUrl !== undefined && tagImageUrl.length > 0) {
				tagImageUrl = TW.convertImageLink(tagImageUrl);
			}
			htmlTabs +=
				'<div class="tabsv2localized-tab ' + (tabNumber === curTabNumber ? 'selected' : '') + '" tab-number="' + tabNumber + '" tab-value="' + XSS.encodeHTML(this.getProperty('Tab' + tabNumber + 'Value')) + '">' +
				'<div  style="max-width:'+tabMaxWidth+'px;"class="tab-content-table-wrapper" tab-number="' + tabNumber + '" tab-value="' + XSS.encodeHTML(this.getProperty('Tab' + tabNumber + 'Value')) + '" >' +
				'<div style="max-width:'+tabMaxWidth+'px;" class="tab-text" tab-number="' + tabNumber + '" tab-value="' + XSS.encodeHTML(this.getProperty('Tab' + tabNumber + 'Value')) + '"  title="' + XSS.encodeHTML(this.getProperty('Tab' + tabNumber + 'Name')) + '" style="height:' + tabHeight + 'px;">' +
				(tagImageUrl ? '<img class="tab-image" src="' + tagImageUrl + '" />' : '') +
				Encoder.htmlEncode(this.getProperty('Tab' + tabNumber + 'Name')) +
				'</div>' +
				'</div>' +
				'</div>';

			// next and back tabs
			var tabNextImage =  ('<img class="tab-back-image" src="/Thingworx/MediaEntities/VerticalMenuArrow" />');
			var tabBackImage =  ('<img class="tab-next-image" style="-webkit-transform: rotate(180deg) translate(24px,0px); transform: rotate(180deg); translate(24px,0px);" src="/Thingworx/MediaEntities/VerticalMenuArrow" />');

			htmlTabContents +=
				'<div class="tabsv2localized-actual-tab-contents" tab-number="' + tabNumber + '" sub-widget-container-id="' + this.properties.Id + '"  sub-widget="' + tabNumber + '">' +
				'</div>';
		}

		var html = '';
		html +=
			'<div class="widget-tabsv2localized widget-content automatically-resize-contents">' +
			'<div class="tabsv2localized-content">' +
			'<div class="tabsv2localized-tab back-scroll-btnv2 disabled" >' +
			'<div class="tab-content-table-wrapper">' +
			'<div class="tab-text" title="Back">'+tabBackImage+'</div>' +
			'</div>' +
			'</div>' +
			'<div class="tabsv2localized-viewport">' +
			'<div class="tabsv2localized-slider">' +
			'<div class="tab-content-tabsv2localized">' +
			htmlTabs +
			'</div>' +
			'</div>' +
			'</div>' +
			'<div class="tabsv2localized-tab next-scroll-btnv2 enabled" >' +
			'<div class="tab-content-table-wrapper">' +
			'<div class="tab-text" title="Next">'+tabNextImage+'</div>' +
			'</div>' +
			'</div>' +
			'</div>' +
			'<div class="actual-tabs" style="top: '+ tabHeight + 'px;">' +
			htmlTabContents +
			'</div>' +
			'</div>';
		return html;
	};

	this.afterRender = function () {
		overallJqElement = this.jqElement.closest('.widget-tabsv2localized');
		tabViewport = overallJqElement.find(".tabsv2localized-viewport");
		tabsRow = overallJqElement.find(".tab-content-tabsv2localized");
		nextScrollBtn = overallJqElement.find(".next-scroll-btnv2");
		backScrollBtn = overallJqElement.find(".back-scroll-btnv2");
		tabSlider = overallJqElement.find(".tabsv2localized-slider");
		tabContainer = overallJqElement.find('.tabsv2localized-content').first();

		tabContainer.find('.tabsv2localized-tab').mousedown(function (e) {
			var tabLi = $(e.target);
			var tabNumber = parseInt(tabLi.attr('tab-number'));
			thisWidget.selectTab(tabNumber);
		});

		nextScrollBtn.click(function (e) {
			if (curTab < nTabs-1 && nextScrollBtn.hasClass("enabled")) {
				var lastTab = tabsRow.children().eq(nTabs-1);
				// how far should tabsRow move for last page?
				if((lastTab.offset().left) <= (tabViewport.offset().left+tabSlideWidth)){
					nextScrollBtn.switchClass("enabled", "disabled");
				}
				curTab++;
				var thisTabPos = tabsRow.children().eq(curTab-1).offset().left;
				var nextTabPos = tabsRow.children().eq(curTab).offset().left;
				var nextTabOffset = nextTabPos - thisTabPos;
				tabPageOffset -= nextTabOffset;
				tabSlider.css({left: tabPageOffset});
				backScrollBtn.switchClass("disabled", "enabled");
				if (curTab === nTabs-1) {
					nextScrollBtn.switchClass("enabled", "disabled");
				}
			}
		});

		backScrollBtn.click(function (e) {
			if (curTab > 0) {
				// get the Left of the next tab to the Left
				var thisTabPos = tabsRow.children().eq(curTab).offset().left;
				var prevTabPos = tabsRow.children().eq(curTab-1).offset().left;
				var prevTabOffset = thisTabPos - prevTabPos;
				tabPageOffset += prevTabOffset;
				tabSlider.css({left: tabPageOffset});
				nextScrollBtn.switchClass("disabled", "enabled");
				curTab--;
				if (curTab === 0) {
					backScrollBtn.switchClass("enabled", "disabled");
				}
			}
		});

		var TabContentStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TabContentStyle'));
		var TabUnselectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TabUnselectedStyle'));
		var TabSelectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TabSelectedStyle'));

		var TabContentBG = TW.getStyleCssGradientFromStyle(TabContentStyle);
		var TabBorder = TW.getStyleCssBorderFromStyle(TabContentStyle);
		var TabBorderSize = TabContentStyle.lineThickness;

		var TabUnselectedBG = TW.getStyleCssGradientFromStyle(TabUnselectedStyle);
		var TabUnselectedText = TW.getStyleCssTextualNoBackgroundFromStyle(TabUnselectedStyle);
		var TabSelectedBG = TW.getStyleCssGradientFromStyle(TabSelectedStyle);
		var TabSelectedText = TW.getStyleCssTextualNoBackgroundFromStyle(TabSelectedStyle);

		var TabUnselectedTextSize = TW.getTextSize(TabUnselectedStyle.textSize);

		var tabHeight = thisWidget.getProperty('TabHeight',27);

		roundedCorners = thisWidget.getProperty('RoundedCorners');
		if (roundedCorners == true) {
			cornerRadius = 6
		} else {
			cornerRadius = 0
		}

		var resource = TW.IDE.getMashupResource();
		var widgetStyles = 
			'#' + thisWidget.jqElementId + ' .tabsv2localized-actual-tab-contents { '+ TabContentBG + TabBorder + ' } ' +
			'#' + thisWidget.jqElementId + ' .tabsv2localized-tab.selected, #' + thisWidget.jqElementId + ' .tabsv2localized-tab { margin-right:'+ tabSpacing + 'px; } ' +
			'#' + thisWidget.jqElementId + ' > .tabsv2localized-actual-tab-contents, #' + thisWidget.jqElementId + ' > .widget-container-contents, #' + thisWidget.jqElementId + ' > .widget-container-widget, #' + thisWidget.jqElementId + ' > .widget-panel { border-bottom-left-radius:'+ cornerRadius + 'px; border-bottom-right-radius:'+ cornerRadius + 'px; border-top-right-radius:'+ cornerRadius + 'px; } ' +
			'#' + thisWidget.jqElementId + ' .tabsv2localized-tab { border-top-left-radius:'+ cornerRadius + 'px; border-top-right-radius:'+ cornerRadius + 'px; } ' +
			'#' + thisWidget.jqElementId + ' .tab-text { '+ TabUnselectedText + TabUnselectedTextSize +' line-height:'+ (tabHeight - TabBorderSize) + 'px; } ' +
			'#' + thisWidget.jqElementId + ' .tab-content-table-wrapper { '+ TabUnselectedBG + TabBorder + ' border-top-left-radius:'+ cornerRadius + 'px; border-top-right-radius:'+ cornerRadius + 'px; }' +
			'#' + thisWidget.jqElementId + ' .selected .tab-content-table-wrapper { ' + TabSelectedBG + ' } ' +
			'#' + thisWidget.jqElementId + ' .selected .tab-text { ' + TabSelectedText + ' } ' +
			'#' + thisWidget.jqElementId + ' .tabsv2localized-tab {max-width:'+tabMaxWidth+'%; }';
		resource.styles.append(widgetStyles);
	};

	this.descendantSelected = function (myChildWidget, originallySelectedWidget) {
		var idOfMyChild = myChildWidget.properties['Id'];

		var tabEl = originallySelectedWidget.jqElement.closest('.tabsv2localized-actual-tab-contents[sub-widget-container-id="' + thisWidget.properties.Id + '"]');
		var tabNumberToShow = parseInt(tabEl.attr('tab-number'),10);

		if (tabNumberToShow === undefined) {
			TW.log.warn('Odd ... tabsv2localized::descendantSelected called with myChildId "' + idOfMyChild + '" ... this tab ID is "' + this.properties['Id'] + '"');
		} else {
			this.selectTab(tabNumberToShow);
		}
	};

	this.selectTab = function (tabNumber) {
		if(!isNaN(tabNumber)&& tabNumber !== null && tabNumber != undefined) {
			thisWidget.jqElement.find('.tabsv2localized-actual-tab-contents[sub-widget-container-id="' + thisWidget.properties.Id + '"]')
			.addClass('unselected-tabv2localized-container');
			thisWidget.jqElement.find('.tabsv2localized-actual-tab-contents[sub-widget-container-id="' + thisWidget.properties.Id + '"][tab-number="' + tabNumber + '"]')
			.removeClass('unselected-tabv2localized-container');

			tabContainer.find('.tabsv2localized-tab').removeClass('selected');
			tabContainer.find('.tabsv2localized-tab[tab-number="' + tabNumber.toString() + '"]').addClass('selected');

			thisWidget.properties['CurrentTab'] = tabNumber;
		}
		this.updateTabsRow();
	};

	this.ideResized = function(){
		thisWidget.updateTabsRow();
	};

	this.updateTabsRow = function() {
		//get widths required to determine if paging is needed
		var thisWidgetCurrentWidth = overallJqElement.width();
		var tabsWidth = 0;
		//set common parameters
		tabSlider.css({"top":0,"height":tabHeight});
		tabViewport.css({"top":0,"height":tabHeight});
		tabsRow.css({"top":0,"left":0,"height":tabHeight,"width":"100%"});
		var myTabs = 0;
		// calculate width required to display row of tabs in one line
		thisWidget.jqElement.find('.tab-content-tabsv2localized .tabsv2localized-tab').each(function(index) {
			if(myTabs < nTabs) {
				tabsWidth += $(this).width() + tabSpacing;
			}
			myTabs++;
		});
		tabsRow.width(tabsWidth+20);
		// show tab paging

		if(tabsWidth>overallJqElement.width()) {
			$(tabsWidth>overallJqElement.width() && ".tab-container-background-wrapper").css("border-top-right-radius",0);
			var scrollBtnWidth = nextScrollBtn.outerWidth();
			tabSlideWidth = thisWidgetCurrentWidth-((scrollBtnWidth+tabSpacing)*2);
			tabSlider.css({"width":"100%"});
			tabViewport.css({
				"left":scrollBtnWidth+tabSpacing,
				"width":tabSlideWidth,
				"margin-right":(scrollBtnWidth+tabSpacing)*-3
			});
			nextScrollBtn.css("visibility","visible");
			backScrollBtn.show();
		}else{
			$(".tab-container-background-wrapper").css("border-top-right-radius",cornerRadius);
			nextScrollBtn.css("visibility","hidden");
			backScrollBtn.hide();
			tabSlider.css({"width":overallJqElement.width()-1,"left":0});
			tabViewport.css({"left":0,"width":"100%"});
		}
	};
	this.afterWidgetsRendered = function () {
		this.updateNumberOfTabs(this.getProperty('NumberOfTabs'));
		this.selectTab(this.getProperty('CurrentTab'));
	};

	this.beforeDestroy = function () {
		if (tabContainer !== undefined && tabContainer.length > 0) {
			tabContainer.find('.tabsv2localized-tab').unbind('mousedown');
		}
		thisWidget = null;
		tabContainer = null;
		overallJqElement = null;
	};

};