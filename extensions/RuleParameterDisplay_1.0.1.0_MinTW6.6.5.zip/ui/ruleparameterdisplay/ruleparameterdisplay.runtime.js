﻿/*
    Still todo for editing:

        - maybe google location picker for LOCATION?  Or look through available widgets that have "Location Picker" in the name?
            - or maybe just two input boxes for lat and lng?
        - figure out a way to handle undefined dates for DATETIME - right now we end up passing current time as default

        Ideally it would be awesome if we didn't have to have this hack "DataForDatashapeIfNoRows" ... ideally, the runtime engine would support the ability to ask for a datashape callback so
        that if it's bound to selected rows, when the service returns it would tell the widget the datashape
 */

TW.Runtime.Widgets.ruleparameterdisplay = function () {
	var thisWidget = this;

    var locationPickerAvailable = false;

    var buildTagsPropertyHtml = function (tags, fldDef) {
        var nTags = 0,
            html = '',
            tag;
        if( tags !== undefined ) {
            nTags = tags.length;
            for (var i = 0; i < nTags; i += 1) {
                tag = tags[i];
                html += '<div class="tag-term-container"><div class="tag-vocabulary"><span>' + tag.vocabulary + '</span></div><div class="tag-term"><span>' + tag.vocabularyTerm + '</span></div></div>';
            }
        }
        return html;
    };
    
    var buildInfotableHtml = function (infotable) {
        if (infotable === undefined) {
            return '';
        }
        var rows = infotable.rows,
                fldDefs = infotable.dataShape.fieldDefinitions,
                resultsHtml = '',
                row,
                col,
                baseType,
                colInfo = {},
                infotableId,
                itemId;

        colInfo.properties = 0;

        if( thisWidget.showAllColumns ) {
            var initialFldDefs = JSON.parse(thisWidget.getProperty('InfotableInfo'));
            _.each(initialFldDefs,function(initialFldDef) {
               if( initialFldDef.__showThisField === false ) {
                   // don't show this field
                   delete fldDefs[initialFldDef.name];
               }
            });
        } else {
            fldDefs = JSON.parse(thisWidget.getProperty('InfotableInfo'));
        }

        var props = _.toArray(fldDefs);
        if( thisWidget.showAllColumns ) {
            TW.sortArrayByStringField(props, 'name');
            TW.sortArrayByNumberField(props, 'ordinal');
        }

        // do we have any rows of data?
        if( rows.length === 0 ) {
            if( thisWidget.allowEditing && thisWidget.showEditorsIfNoRowData ) {
                // if allow editing and show if no data, then we go ahead and use a blank row to start with
                thisWidget.lastRows.push({});
                row = thisWidget.lastRows[0];
                if( thisWidget.showAllColumns && thisWidget.lastDatashape !== undefined ) {
                    fldDefs = thisWidget.lastDatashape;
                }
            } else {
                return resultsHtml;
            }
        } else {
            row = rows[0];
        }

        resultsHtml += '<div class="table-border"><table class="component-table" cellspacing="0" cellpadding="0">';

        _.each(fldDefs,function(fld) {
            var displayThisColumn = true;
            if( fld.__showThisField === false ) {
                displayThisColumn = false;
            }

            if (displayThisColumn) {
                col = fld.name;
                var title = col; // assume field name as title

                if (fld.Title) {
                    // The field title is specified explicitly.
                    title = TW.Runtime.convertLocalizableString(fld.Title);
                }

                colInfo.properties += 1;
                baseType = fld.baseType;
                var stringValue = '';
                if( row[col] !== undefined ) {
                    try {
                        stringValue = row[col].toString();
                    } catch(err) {}
                }
                if (baseType === 'DATETIME') {
                    if (row[col] !== undefined && row[col] !== '') {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '"  base-type="' + baseType + '">' + TW.DateUtilities.formatDate(row[col], TW.Runtime.convertLocalizableString(TW.Renderer.DATETIME.defaultFormat)) + '</td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                    }
                } else if (baseType === 'TAGS') {
                    var tagType = "ModelTags";
                    try {
                        tagType = fld.aspects.tagType;
                    } catch (err) {}
                    resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '" tag-type="' + tagType + '">' + buildTagsPropertyHtml(row[col], fld) + '</td></tr>';
                } else if (baseType === 'LOCATION') {
                    if( thisWidget.allowEditing ) {
                        var latString = '';
                        var lngString = '';

                        if (row[col] !== undefined) {
                            var latitude = parseFloat(row[col].latitude);
                            var longitude = parseFloat(row[col].longitude);

                            var labelFormat = TW.Renderer.LOCATION.defaultFormat;

                            latString = latitude.format(labelFormat);
                            lngString = longitude.format(labelFormat);
                        }
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><span>Lat:</span><input class="property-display-editor latitude basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + latString + '"/><span>&nbsp;Lng:</span><input class="property-display-editor longitude basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + lngString + '"/></td></tr>';
                    } else {
                        if (row[col] !== undefined) {

                            var latitude = parseFloat(row[col].latitude);
                            var longitude = parseFloat(row[col].longitude);

                            var labelFormat = TW.Renderer.LOCATION.defaultFormat;
                            formattedValue = latitude.format(labelFormat) + " : " + longitude.format(labelFormat);

                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><span class="ruleparameterdisplay-location" latitude="' + row[col].latitude + '" longitude="' + row[col].longitude + '" title="' + row[col].latitude + ', ' + row[col].longitude + '">' + formattedValue + '</span></td></tr>';
                        } else {
                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">---- : ----</td></tr>';
                        }
                    }
                } else if (baseType === 'VEC2' || baseType === 'VEC3' || baseType === 'VEC4') {
                    var xValStr = '', yValStr = '', zValStr = '', wValStr = '';
                    var xVal, yVal, zVal = undefined, wVal = undefined;
                    
                    if (row[col] !== undefined) {
                        xVal = parseFloat(row[col].x);
                        yVal = parseFloat(row[col].y);
                        
                        if (!_.isUndefined(row[col].z)) {
                            zVal = parseFloat(row[col].z);
                        }
                        
                        if (!_.isUndefined(row[col].w)) {
                            wVal = parseFloat(row[col].w);
                        }

                        var labelFormat = TW.Renderer[baseType].defaultFormat;

                        xValStr = xVal.format(labelFormat);
                        yValStr = yVal.format(labelFormat);
                        
                        if (zVal !== undefined) {
                            zValStr = zVal.format(labelFormat);
                        }
                        
                        if (wVal !== undefined) {
                            wValStr = wVal.format(labelFormat);
                        }
                    } else {
                        switch (baseType) {
                            case 'VEC3':
                                zVal = null;
                                break;
                            case 'VEC4':
                                zVal = null;
                                wVal = null;
                                break;
                        }
                    }
                    
                    if( thisWidget.allowEditing ) {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">'
                        // x
                        resultsHtml += '<input class="property-display-editor x-axis basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + xValStr + '"/><br/>'
                        // y
                        resultsHtml += '<input class="property-display-editor y-axis basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + yValStr + '"/>';
                        // z
                        if (!_.isUndefined(zVal)) {
                            resultsHtml += '<input class="property-display-editor z-axis basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + zValStr + '"/>';
                        }
                        // w
                        if (!_.isUndefined(wVal)) {
                            resultsHtml += '<input class="property-display-editor w-axis basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + wValStr + '"/>';
                        }
                        resultsHtml += '</td></tr>';
                    } else {
                        var vecStr;
                        
                        if (row[col] !== undefined) {
                            vecStr = xValStr + ' , ' + yValStr;
                            
                            if (!_.isUndefined(zVal)) {
                                vecStr += ' , ' + zValStr;
                            }
                            
                            if (!_.isUndefined(wVal)) {
                                vecStr += ' , ' + wValStr;
                            }
                            
                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><span class="ruleparameterdisplay-vector" title="' + vecStr + '">' + vecStr + '</span></td></tr>';
                        } else {
                            vecStr = '? , ?';
                            
                            if (!_.isUndefined(zVal)) {
                                vecStr += ' , ?';
                            }
                            
                            if (!_.isUndefined(wVal)) {
                                vecStr += ' , ?';
                            }
                            
                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">' + vecStr + '</td></tr>';
                        }
                    }
                } else if (baseType === 'THINGCODE') {
                    var domainStr = '', instanceStr = '';
                    var domainId, instanceId;
                    
                    if (row[col] !== undefined) {
                        domainId = parseInt(row[col].domainId);
                        instanceId = parseInt(row[col].instanceId);
                        
                        domainStr = domainId.format('0');
                        instanceStr = instanceId.format('0');
                    }
                    
                    if( thisWidget.allowEditing ) {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">'
                        resultsHtml += '<span>Domain ID:</span><input class="property-display-editor domain-id basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + domainStr + '"/><br/>'
                        resultsHtml += '<span>Instance ID:</span><input class="property-display-editor instance-id basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + instanceStr + '"/>';
                        resultsHtml += '</td></tr>';
                    } else {
                        var thingcode;
                        
                        if (row[col] !== undefined) {
                            thingcode = domainStr + ':' + instanceStr;
                            
                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><span class="ruleparameterdisplay-vector" title="' + thingcode + '">' + thingcode + '</span></td></tr>';
                        } else {
                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">???:???</td></tr>';
                        }
                    }
                } else if (baseType === 'IMAGELINK') {
                    if (row[col] !== undefined && row[col] !== '') {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><a href="' + stringValue + '" target="_blank"><img alt="' + col + '" src="' + stringValue + '" /></a></td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                    }
                } else if (baseType === 'INFOTABLE' || baseType === 'VALUES') {
                    if (row[col] !== undefined && row[col].rows.length > 0) {
                        infotableId = 'x' + '-' + col + '-' + TW.uniqueId();
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '" id="' + infotableId + '"><span class="could-be-infotable-link-eventually">Infotable</span></td></tr>';
                       /* thisPlugin.infotableData.push({
                            id: infotableId,
                            data: row[col],
                            displayName: col
                        });*/
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                    }
                } else if (baseType === 'HYPERLINK') {
                    if( thisWidget.allowEditing ) {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><input class="property-display-editor basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + (Encoder.htmlEncode(stringValue) || '') + '"/></td></tr>';
                    } else {
                        if (row[col] !== undefined && row[col] !== '') {
                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><a href="' + stringValue + '" target="_blank">Open</a></td></tr>';
                        } else {
                            resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                        }
                    }
                } else if (baseType === 'HTML') {
                    if (row[col] !== undefined && row[col] !== '') {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><div>' + row[col] + '</div></td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                    }
                } else if (baseType === 'IMAGE') {
                    if (row[col] !== undefined && row[col] !== '') {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><img alt="' + col + '" src="data:image/png;base64,' + row[col] + '"/></td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                    }
                } else if (baseType === 'PASSWORD') {
                    resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">*****</td></tr>';
                } else if (baseType === 'XML') {
                    if (row[col] !== undefined && row[col] !== '') {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">XML</td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                    }
                } else if (baseType === 'JSON') {
                    if (row[col] !== undefined && row[col] !== '') {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">JSON</td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"></td></tr>';
                    }
                } else if (baseType === 'BOOLEAN') {
                    if( thisWidget.allowEditing ) {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><input class="property-display-editor basetype="' + baseType + '" field-name="' + col + '" type="checkbox" ' + (stringValue === 'true' ? ' checked="checked"' : '') + '/></td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">' + Encoder.htmlEncode(stringValue) || ''  + '</td></tr>';
                    }
                } else {
                    if( thisWidget.allowEditing ) {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '"><input class="property-display-editor basetype="' + baseType + '" field-name="' + col + '" type="text" value="' + (Encoder.htmlEncode(stringValue) || '') + '"/></td></tr>';
                    } else {
                        resultsHtml += '<tr><td class="property-name">' + title + '</td><td class="property-value" field-name="' + col + '" base-type="' + baseType + '">' + Encoder.htmlEncode(stringValue) || ''  + '</td></tr>';
                    }
                }

            }
        });
        resultsHtml += '</table></div>';

        return resultsHtml;
    };

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': true
        };
    };

    this.renderHtml = function () {
        thisWidget.showAllColumns = thisWidget.getProperty('ShowAllColumns',false);
        thisWidget.allowEditing = thisWidget.getProperty('AllowEditing',false);
        thisWidget.showEditorsIfNoRowData = thisWidget.getProperty('ShowEditorsIfNoRowData',false);
        thisWidget.dataHasArrived = false;

        var html = '<div class="widget-content widget-ruleparameterdisplay"></div>';

        return html;
    };
	
	this.afterRender = function() {

        var parseLocation = function(stringValueLatitude,stringValueLongitude) {
            var returnLocation = {
                latitude: 0.0,
                longitude: 0.0
            };

            if( stringValueLatitude.length === 0 || stringValueLongitude.length === undefined) {
                return undefined;
            }
            try {
                returnLocation.latitude = parseFloat(stringValueLatitude);
                returnLocation.longitude = parseFloat(stringValueLongitude);
            } catch(err) {

            }

            return returnLocation;

        };

        thisWidget.jqElement.on('change','.property-display-editor',function(e) {
            var el = $(e.target).closest('.property-display-editor');
            var colName = el.attr('field-name');
            var baseType = el.closest('.property-value').attr('base-type');
            try {
                var newValue = el.val();
                if( baseType === 'LOCATION') {
                    var tdEl = el.closest('td.property-value');

                    thisWidget.lastRows[0][colName] = parseLocation(tdEl.find('input.latitude').val(),tdEl.find('input.longitude').val());
                } else if( baseType === 'BOOLEAN') {
                    thisWidget.lastRows[0][colName] = el.is(':checked');
                } else {
                    thisWidget.lastRows[0][colName] = newValue;
                }
                thisWidget.setProperty('Data',{ dataShape: { fieldDefinitions: thisWidget.lastDatashape }, rows: thisWidget.lastRows });
            } catch( err ) {
                TW.log.error('error updating column "' + colName + '"', err);
            }
        });
	};

    this.updateProperty = function (updatePropertyInfo) {
        var buildTable = function() {
            TW.emptyJqElement(thisWidget.jqElement);

            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style', 'DefaultruleparameterdisplayStyle'));

            var cssPropDisplayBackground = TW.getStyleCssGradientFromStyle(formatResult);
            var cssPropDisplayText = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
            var cssPropDisplayBackground = TW.getStyleCssGradientFromStyle(formatResult);
            var cssPropDisplayBorder = TW.getStyleCssBorderFromStyle(formatResult);

            var styleBlock =
			'<style>' +
				'#' + thisWidget.jqElementId + ' .component-table tbody td{' + cssPropDisplayBackground + cssPropDisplayBorder + cssPropDisplayText + ' border-left: none; border-top: none;}' +
				'#' + thisWidget.jqElementId + ' .table-border {' + cssPropDisplayBorder + 'border-bottom: none; border-right: none;}' +
			'</style>';

            thisWidget.lastRows = updatePropertyInfo.ActualDataRows;
            thisWidget.lastDatashape = updatePropertyInfo.DataShape;
            thisWidget.setProperty('Data', { dataShape: { fieldDefinitions: thisWidget.lastDatashape }, rows: thisWidget.lastRows });

            thisWidget.jqElement.html(styleBlock + buildInfotableHtml({ dataShape: { fieldDefinitions: updatePropertyInfo.DataShape }, rows: updatePropertyInfo.ActualDataRows }));

            if( thisWidget.allowEditing ) {
                _.each(thisWidget.jqElement.find('.property-value[base-type="NUMBER"]','.property-value[base-type="INTEGER"]','.property-value[base-type="LONG"]'),function(el) {
                    var el = $(el);
                    var colName = el.attr('field-name');
                    var baseType = el.attr('base-type');


                    el.widget({
                        widgetProperties: {
                            "Interval": 0,
                            "Top" : 0,
                            "NumericEntryFocusStyle" : "DefaultFocusStyle",
                            "Value" : 0,
                            "Visible" : true,
                            "ValueAlign" : "right",
                            "__TypeDisplayName" : "Numeric Entry",
                            "ResponsiveLayout" : false,
                            "TabSequence" : 0,
                            "Type" : "numericentry",
                            "Maximum" : 100,
                            "Area" : "UI",
                            "Style" : "DefaultTextBoxStyle",
                            "Z-index" : 10,
                            "Height" : 24,
                            "AllowDecimals" : ((baseType === 'INTEGER' || baseType === 'LONG') ? false : true),
                            "DisplayName" : "NumericEntry-2",
                            "Left" : 0,
                            "AllowNegatives" : true,
                            "NumericEntryLabelStyle" : "DefaultWidgetLabelStyle",
                            "__supportsLabel" : true,
                            "FixedDigits" : 0,
                            "Minimum" : 0,
                            "Id" : "NumericEntry-" + TW.uniqueId(),
                            "Label" : "",
                            "Width" : 200,
                            "ConstrainValue" : false,
                            "Value": thisWidget.lastRows[0][colName]
                        },
                        info: {
                            colName: colName.substring(0)
                        },
                        propertyUpdated: function (name, value, info) {
                            if (name === 'Value') {
                                thisWidget.lastRows[0][info.colName] = value;
                                thisWidget.setProperty('Data', { dataShape: { fieldDefinitions: thisWidget.lastDatashape }, rows: thisWidget.lastRows });
                            }
                        }
                    });
                });

                _.each(thisWidget.jqElement.find('.property-value[base-type="DATETIME"]'),function(el) {
                    var el = $(el);
                    var colName = el.attr('field-name');
                    var dateTimeToUse = thisWidget.lastRows[0][colName];
                    if (dateTimeToUse === undefined || isNaN(dateTimeToUse.getTime())) {
                        dateTimeToUse = undefined;
                    }

                    el.widget({
                        widgetProperties: {
                            "Top": 0,
                            "Interval": 0,
                            "Visible": true,
                            "__TypeDisplayName": "Date Time Picker",
                            "ResponsiveLayout": false,
                            "Type": "datetimepicker",
                            "TabSequence": 0,
                            "Area": "UI",
                            "Style": "DefaultTimePickerStyle",
                            "Z-index": 10,
                            "Height": 28,
                            "DateOnly": false,
                            "DisplayName": "DateTimePicker-1",
                            "Left": 0,
                            "__supportsLabel": true,
                            "InitializeWithCurrentDateTime": true,
                            "DateTime": dateTimeToUse,
                            "IntervalType": "h",
                            "Id": "DateTimePicker-" + TW.uniqueId(),
                            "Label": "",
                            "Width": 200
                        },
                        info: {
                            colName: colName.substring(0)
                        },
                        propertyUpdated: function (name, value, info) {
                            if (name === 'DateTime') {
                                thisWidget.lastRows[0][info.colName] = value;
                                thisWidget.setProperty('Data', { dataShape: { fieldDefinitions: thisWidget.lastDatashape }, rows: thisWidget.lastRows });
                            }
                        }
                    });
                });

                _.each(thisWidget.jqElement.find('.property-value[base-type="TAGS"]'),function(el) {
                    var el = $(el);
                    var colName = el.attr('field-name');
                    var tagsToUse = thisWidget.lastRows[0][colName];

                    el.widget({
                        widgetProperties: {
                            "Top" : 0,
                            "MultiSelect" : true,
                            "__TypeDisplayName" : "Tag Picker",
                            "Visible" : true,
                            "ResponsiveLayout" : false,
                            "Type" : "tagpicker",
                            "Area" : "UI",
                            "Height" : 24,
                            "Z-index" : 10,
                            "DisplayName" : "TagPicker-1",
                            "TagType" : el.attr('tag-type'),
                            "Left" : 0,
                            "Id" : "TagPicker-" + TW.uniqueId(),
                            "VocabularyRestriction" : "",
                            "Width" : 35,
                            "Tags": tagsToUse
                        },
                        info: {
                            colName: colName.substring(0)
                        },
                        propertyUpdated: function (name, value, info) {
                            if (name === 'Tags') {
                                thisWidget.lastRows[0][info.colName] = value;
                                thisWidget.setProperty('Data', { dataShape: { fieldDefinitions: thisWidget.lastDatashape }, rows: thisWidget.lastRows });
                            }
                        }
                    });

                });

                _.each(thisWidget.jqElement.find('.property-value[base-type="THINGNAME"],.property-value[base-type="THINGSHAPENAME"],.property-value[base-type="THINGTEMPLATENAME"],.property-value[base-type="USERNAME"]'),function(el) {
                    var el = $(el);
                    var colName = el.attr('field-name');
                    var baseType = el.attr('base-type');
                    var entityType = "Things";

                    switch( baseType ) {
                        case 'THINGNAME':
                            entityType = "Things";
                            break;
                        case 'THINGTEMPLATENAME':
                            entityType = "ThingTemplates";
                            break;
                        case 'THINGSHAPENAME':
                            entityType = "ThingShapes";
                            break;
                        case 'USERNAME':
                            entityType = "Users";
                            break;
                    }
                    el.widget({
                        widgetProperties: {
                            "UseMostRecentlyUsed" : true,
                            "Top" : 0,
                            "FocusStyle" : "DefaultFocusStyle",
                            "Visible" : true,
                            "__TypeDisplayName" : "Entity Picker",
                            "ResponsiveLayout" : false,
                            "Type" : "entitypicker",
                            "SearchTerm" : "",
                            "TabSequence" : 0,
                            "Area" : "UI",
                            "Z-index" : 10,
                            "Height" : 30,
                            "DisplayName" : "EntityPicker-4",
                            "Left" : 0,
                            "SearchIncludesDescriptions" : true,
                            "ShowAdvanced" : true,
                            "EntityType" : entityType,
                            "Id" : "EntityPicker-" + TW.uniqueId(),
                            "Width" : 175,
                            "IncludeSystemObjects" : false,
                            Entity: thisWidget.lastRows[0][colName]
                        },
                        info: {
                            colName: colName.substring(0)
                        },
                        propertyUpdated: function (name, value, info) {
                            if (name === 'Entity') {
                                thisWidget.lastRows[0][info.colName] = value;
                                thisWidget.setProperty('Data', { dataShape: { fieldDefinitions: thisWidget.lastDatashape }, rows: thisWidget.lastRows });
                            }
                        }
                    });

                });
            }
			
        };

        if (updatePropertyInfo.TargetProperty === 'DataForDatashapeIfNoRows') {
            if( thisWidget.lastDatashape === undefined ) {
                thisWidget.lastDatashape = updatePropertyInfo.DataShape;
            }
            if( thisWidget.dataHasArrived !== true && thisWidget.showEditorsIfNoRowData ) {
                buildTable();
            }
        } else if (updatePropertyInfo.TargetProperty === 'Data') {
            thisWidget.dataHasArrived = true;
            buildTable();
        }

    };
	
};