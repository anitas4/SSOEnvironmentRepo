﻿TW.IDE.Widgets.ruleparameterdisplay = function () {


    var buildInfotableHtml = function (infoTableDataShape) {
        if (infoTableDataShape === undefined) {
            return '<div class="property-name-column">' + 
						'<div class="property-name-column-wrapper">' +
								'<span class="no-data-bound"> Must be bound to data </span>' +
							
						'</div>' +
					'</div>'
					/*'<div class="property-value-column">' + 
						'<div class="property-value-column-wrapper">' +
							'<div class="property-value-column-wrapper-grid"></div>' +
						'</div>' +
					'</div>';*/
        }
        var resultsHtml = '<table class="component-table" cellspacing="0" cellpadding="0">';


        var props = _.toArray(infoTableDataShape);
        TW.sortArrayByStringField( props, 'name');
        TW.sortArrayByNumberField( props, 'ordinal');

        _.each(props,function(prop) {
            if( prop.__showThisField !== false ) {
                var baseType = prop.baseType;
                var propValue = 'Sample';
                if (baseType === 'TAGS') {
                    propValue = '<div class="tag-term-container"><div class="tag-vocabulary"><span>vocabulary</span></div><div class="tag-term"><span>term</span></div></div>';
                }
                resultsHtml += '<tr><td class="property-name">' + (prop.Title || prop.name) + '</td><td class="property-value">' + propValue + '</td></tr>';
            }
        });
        resultsHtml += '</table>';
        return resultsHtml;
    };


    this.widgetProperties = function () {
        return {
            'name': 'RuleParameterDisplay',
            'description': '',
            'category': ['Common', 'Data'],
            'supportsAutoResize': true,
            'customEditor': 'DataFilterCustomEditor',
            'defaultBindingTargetProperty': 'Data',
            'properties': {
                'Data': {
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.data.description'),
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'InfotableInfo': {
                    'isVisible': false,
                    'baseType': 'STRING'
                },
                'ShowAllColumns': {
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.show-all-columns.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'AllowEditing': {
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.allow-editing.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'ShowEditorsIfNoRowData': {
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.show-editors-if-no-row-data.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'DataForDatashapeIfNoRows': {
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.data-for-data-shape-if-no-rows.description'),
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'Width': {
                    'defaultValue': 250,
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.width.description')
                },
                'Height': {
                    'defaultValue': 200,
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.height.description')
                },
                'Style': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultruleparameterdisplayStyle',
                    'description': TW.IDE.I18NController.translate('tw.ruleparameterdisplay-ide.properties.style.description')
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
            'Changed': { 'warnIfNotBound': true }
        }
    };

    this.afterSetProperty = function (name, value) {
        var thisWidget = this;
        var refreshHtml = false;
        switch (name) {
            case 'Style':
            case 'Data':
            case 'InfotableInfo':
                refreshHtml = true;
                break;
            default:
                break;
        }
        return refreshHtml;
    };

    // afterAddBindingSource is called immediately after the user adds a binding source to your object
    this.afterAddBindingSource = function (bindingInfo) {
        if (bindingInfo['targetProperty'] === 'Data') {
            // get the infoTableDataShape associated with this property
            var infotableInfo = this.getInfotableMetadataForProperty('Data');
            this.setProperty('InfotableInfo', infotableInfo === undefined ? undefined : JSON.stringify(infotableInfo));
            this.jqElement.find('.property-display-innards').html(buildInfotableHtml(infotableInfo));
        }
        return true;
    }

    this.renderHtml = function () {
    	
		
		
        var cssInfo = '';
        var infotableInfo = this.getProperty('InfotableInfo');
        if (infotableInfo !== undefined) {
            infotableInfo = JSON.parse(infotableInfo);
        }
        var html = '<div class="widget-content widget-ruleparameterdisplay" ' + cssInfo + '><div style="position:absolute;width:100%;height:100%;z-index:51;"></div><div class="property-display-innards">' + buildInfotableHtml(infotableInfo) + '</div></div>';
        return html;
        //var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style'));
        //var textSizeClass = 'textsize-normal';
        //if (this.getProperty('Style') !== undefined) {
        //    textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
        //}

        //var cssInfo = TW.getStyleCssTextualFromStyleDefinition(this.getProperty('Style')) + ' text-align:' + (this.getProperty('Alignment') || 'left') + ' ';

        //// if no style, just let standard CSS define the label style
        //var styleName = this.getProperty('Style');
        //if (styleName === undefined || styleName.length === 0) {
        //    cssInfo = cssInfo.replace(/font-weight:normal;/g, '');
        //}

        //if (cssInfo.length > 0) {
        //    cssInfo = 'style="' + cssInfo + '"';
        //}

        //var html = '<span class="widget-content widget-label ' + textSizeClass + '" ' + cssInfo + '><span class="label-text">' + (this.getProperty('Text') !== undefined ? this.getProperty('Text') : this.getProperty('Id')) + '</span></span>';
        //return html;
    };

	this.afterRender = function() {
		var thisWidget = this;
		var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style'));
	
		var cssPropDisplayBackground = TW.getStyleCssGradientFromStyle(formatResult);
		var cssPropDisplayText = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
		var cssPropDisplayBackground = TW.getStyleCssGradientFromStyle(formatResult);
		var cssPropDisplayBorder = TW.getStyleCssBorderFromStyle(formatResult);
		
		var resource = TW.IDE.getMashupResource();
		var widgetStyles = 
			'#' + thisWidget.jqElementId + ' .component-table tbody td {'+ cssPropDisplayBackground  + cssPropDisplayBorder + cssPropDisplayText + ' border-left: none; border-top: none;} ' +
			'#' + thisWidget.jqElementId + ' .component-table {'+ cssPropDisplayBorder + 'border-bottom: none; border-right: none;} ' +
			//'#' + thisWidget.jqElementId + ' .property-display-innards { '+ cssPropDisplayBorder + '}' +
			'#' + thisWidget.jqElementId + ' .property-name-column {'+ cssPropDisplayBackground + cssPropDisplayBorder + cssPropDisplayText +  '}';
		resource.styles.append(widgetStyles);
		
	}

};