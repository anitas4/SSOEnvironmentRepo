/*global TW */

(function () {

    TW.Runtime.Widgets.propertytable = function () {

        this.renderHtml = function () {
            return '<div class="widget-content widget-propertytable"></div>';
        };

        /**
         * Find a human-friendly rendering of a given property name.
         *
         * @param  {String} propName property name in internal format (presumed to be camel case)
         * @return {String}          property name in title case
         */
        this.makeDisplayableName = function (propName) {
            // TODO get property name from widget's row configuration; translate it if it's
            // a localization token. Similar to column formatting in Grid widget.

            var camelCase = propName || '';
            camelCase = camelCase.trim();

            if (camelCase.length === 0) {
                return '';
            }

            var titleCase = camelCase.replace(/([a-z])([A-Z])/g, '$1 $2'); // separate words
            titleCase = titleCase.charAt(0).toUpperCase() + titleCase.substr(1); // capitalize first word

            return TW.escapeHTML(titleCase);
        };

        this.updateProperty = function (updatePropertyInfo) {

            if (updatePropertyInfo.TargetProperty !== "Data") {
                TW.log.error('Unsupported property in TW.Runtime.Widgets.propertytable.updateProperty: ', updatePropertyInfo.TargetProperty);
                return;
            }

            // CSS and HTML for the properties table.
            var tableTemplate = _.template(
                '<style>' +
                    '#<%= id %> {<%= div %> <%= borders %>} ' +
                    '#<%= id %> tr:nth-child(odd) {<%= row %>} ' +
                    '#<%= id %> tr:nth-child(even) {<%= altRow %>} ' +
                    '#<%= id %> tr:hover {<%= hoverRow %>} ' +
                    '#<%= id %> tr td {<%= borders %> <%= cellPadding %>} ' +
                    '#<%= id %> tr td:nth-child(1) {<%= prop %> width:<%= propWidth %>%;} ' +
                    '#<%= id %> tr td:nth-child(2) {<%= val %>}' +
                '</style>' +
                '<table id="<%= id %>" width="100%">' +
                    '<% rowData.forEach(function (row) { %>' +
                        '<tr>' +
                            '<td><span class="<%= propClass %>"><%= myself.makeDisplayableName(row.name) %></span></td>' +
                            '<td><span class="<%= valClass %>"><%= TW.escapeHTML(row.value) %></span></td>' +
                        '</tr>' +
                    '<% }); %>' +
                '</table>'
            );
            var tableConfig = {
                id:     this.idOfThisElement,
                myself: this
            };

            // Filter for simple values of general interest.

            tableConfig.rowData = updatePropertyInfo.ActualDataRows.filter(
                function (propertyItem) {
                    // Display simple data types; skip THINGNAME, LOCATION, IMAGE, etc.
                    // The values have already been rendered in string form.
                    switch (propertyItem.baseType) {
                        case 'BOOLEAN':
                        case 'DATETIME':
                        case 'INTEGER':
                        case 'NUMBER':
                        case 'STRING':
                            return true;
                        default:
                            return false;
                    }
                }
            );

            // Gather applicable styles.

            var aStyle = TW.getStyleFromStyleDefinition(this.getProperty('PropertyTableBackgroundStyle'));
            tableConfig.div = TW.getStyleCssGradientFromStyle(aStyle);
            tableConfig.borders = TW.getStyleCssBorderFromStyle(aStyle);

            aStyle = TW.getStyleFromStyleDefinition(this.getProperty('RowBackgroundStyle'));
            tableConfig.row = TW.getStyleCssGradientFromStyle(aStyle);

            aStyle = TW.getStyleFromStyleDefinition(this.getProperty('RowAlternateBackgroundStyle'));
            tableConfig.altRow = TW.getStyleCssGradientFromStyle(aStyle);

            aStyle = TW.getStyleFromStyleDefinition(this.getProperty('RowHoverStyle'));
            tableConfig.hoverRow = TW.getStyleCssGradientFromStyle(aStyle);

            aStyle = TW.getStyleFromStyleDefinition(this.getProperty('PropertyStyle'));
            tableConfig.prop = TW.getStyleCssTextualNoBackgroundFromStyle(aStyle);
            tableConfig.propClass = TW.getTextSizeFromStyleDefinition(this.getProperty('PropertyStyle'));
            tableConfig.propWidth = this.getProperty('PropertyColumnWidth', 50);

            aStyle = TW.getStyleFromStyleDefinition(this.getProperty('ValueStyle'));
            tableConfig.val = TW.getStyleCssTextualNoBackgroundFromStyle(aStyle);
            tableConfig.valClass = TW.getTextSizeFromStyleDefinition(this.getProperty('ValueStyle'));

            // TODO padding should be a property but there's no precedent for exposing it.
            tableConfig.cellPadding = 'padding: 2px 4px;';

            // Create the table and update the display.

            this.jqElement.empty().html(tableTemplate(tableConfig));
        };

        this.beforeDestroy = function () {
            var widgetElement = this.jqElement;

            try {
                widgetElement.unbind();
            }
            catch (destroyErr) {
            }

            try {
                widgetElement.empty();
            }
            catch (destroyErr) {
            }
        };
    };
}());
