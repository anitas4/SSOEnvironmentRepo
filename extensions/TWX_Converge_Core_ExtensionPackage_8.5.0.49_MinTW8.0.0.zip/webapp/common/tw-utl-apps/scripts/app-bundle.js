define('app',['exports', 'thingworx-ui-platform/helpers/loader-helper'], function (exports, _loaderHelper) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.App = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    _loaderHelper.LoaderHelper.importAppCss('/app.css');

    var App = exports.App = function () {
        function App() {
            _classCallCheck(this, App);
        }

        App.prototype.configureRouter = function configureRouter(config, router) {
            this.router = router;
            config.title = 'TWX Utilities - Applications';
            config.map([{
                route: '',
                redirect: 'createAsset'
            }, {
                route: 'createAsset',
                name: 'createAsset',
                moduleId: './views/create-asset/create-asset',
                nav: true,
                title: 'Create New Asset'
            }, {
                route: 'bulkLoadAssets',
                name: 'bulkLoadAssets',
                moduleId: './views/bulk-load-assets/bulk-load-assets',
                nav: true,
                title: 'Bulk Load Assets'
            }, {
                route: 'assetSearchConfig',
                redirect: 'assetSearchConfig/DEFAULT'
            }, {
                route: 'assetSearchConfig/:resourceProvider',
                name: 'assetSearchConfig',
                moduleId: './views/asset-search-config/asset-search-config',
                title: 'Asset Search Config'
            }]);
        };

        return App;
    }();
});
define('environment',["exports"], function (exports) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = {
    debug: true,
    testing: true
  };
});
define('main',['exports', 'thingworx-ui-platform/ui-platform-bootstrap'], function (exports, _uiPlatformBootstrap) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.configure = configure;
    function configure(aurelia) {
        _uiPlatformBootstrap.UiPlatformBootstrap.start(aurelia, 'app');
    }
});
define('services/asset-types-service',['exports', 'aurelia-framework', 'thingworx-ui-platform/services/invoker/invoker-factory', 'thingworx-ui-platform/events/event-helper'], function (exports, _aureliaFramework, _invokerFactory, _eventHelper) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.AssetTypesService = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var AssetTypesService = exports.AssetTypesService = (_dec = (0, _aureliaFramework.inject)(_invokerFactory.InvokerFactory), _dec(_class = function () {
        function AssetTypesService(invokerFactory) {
            _classCallCheck(this, AssetTypesService);

            this.assetTypes = null;

            this.invokerFactory = invokerFactory;
            this.eventHelper = new _eventHelper.EventHelper('AssetTypesService');
        }

        AssetTypesService.prototype.getAssetTypes = function getAssetTypes() {
            var self = this;
            return new Promise(function (resolve) {
                if (self.assetTypes && self.assetTypes.rows && self.assetTypes.rows.length > 0) {
                    resolve(self.assetTypes);
                    return;
                }

                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Resources').withEntityName('PTC.Asset.AssetMonitorUtilities').withServiceType('Services').withServiceName('GetAssetTypes').asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        self.assetTypes = JSON.parse(results.response);
                        resolve(self.assetTypes);
                    } else {
                        throw new Error('failed to get asset types');
                    }
                });
            });
        };

        return AssetTypesService;
    }()) || _class);
});
define('services/bulk-load-service',['exports', 'aurelia-framework', 'thingworx-ui-platform/services/invoker/invoker-factory', 'thingworx-ui-platform/events/event-helper'], function (exports, _aureliaFramework, _invokerFactory, _eventHelper) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.BulkLoadService = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var BulkLoadService = exports.BulkLoadService = (_dec = (0, _aureliaFramework.inject)(_invokerFactory.InvokerFactory), _dec(_class = function () {
        function BulkLoadService(invokerFactory) {
            _classCallCheck(this, BulkLoadService);

            this.uploadedFiles = null;
            this.fileRepositories = null;
            this.validationResults = null;

            this.invokerFactory = invokerFactory;
            this.eventHelper = new _eventHelper.EventHelper('BulkLoadService');
        }

        BulkLoadService.prototype.getUploadedFiles = function getUploadedFiles(repository, params) {
            var self = this;
            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Things').withEntityName(repository).withServiceType('Services').withServiceName('GetFileListing').withParams(params).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        var uploadedFiles = JSON.parse(results.response);
                        self.uploadedFiles = [];
                        if (uploadedFiles.rows && uploadedFiles.rows.length > 0) {
                            self.uploadedFiles = uploadedFiles.rows;
                        }
                        resolve(self.uploadedFiles);
                    } else {
                        throw new Error('failed to get uploaded files from repository');
                    }
                });
            });
        };

        BulkLoadService.prototype.getFileRepositories = function getFileRepositories() {
            var self = this;
            return new Promise(function (resolve) {
                if (self.fileRepositories && self.fileRepositories.length > 0) {
                    resolve(self.fileRepositories);
                    return;
                }

                var params = { thingTemplate: 'FileRepository' };

                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Resources').withEntityName('SearchFunctions').withServiceType('Services').withServiceName('SearchThingsByTemplate').withParams(params).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {

                        var fileRepositories = JSON.parse(results.response);
                        self.fileRepositories = [];
                        if (fileRepositories.rows && fileRepositories.rows.length > 0) {
                            self.fileRepositories = fileRepositories.rows;
                        }
                        resolve(self.fileRepositories);
                    } else {
                        throw new Error('failed to get uploaded files from repository');
                    }
                });
            });
        };

        BulkLoadService.prototype.getFileRepositoryStructure = function getFileRepositoryStructure(repository) {
            var self = this;
            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Things').withEntityName(repository).withServiceType('Services').withServiceName('GetDirectoryStructure').asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        var uploadedFiles = JSON.parse(results.response);
                        self.uploadedFiles = [];
                        if (uploadedFiles.rows && uploadedFiles.rows.length > 0) {
                            self.uploadedFiles = uploadedFiles.rows;
                        }
                        resolve(self.uploadedFiles);
                    } else {
                        throw new Error('failed to get uploaded files from repository');
                    }
                });
            });
        };

        BulkLoadService.prototype.validateSelectedFile = function validateSelectedFile(params) {
            var self = this;

            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Resources').withEntityName('PTC.Asset.BulkImporter').withServiceType('Services').withServiceName('Validate').withParams(params).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        var validationResults = JSON.parse(results.response);
                        self.validationResults = [];
                        if (validationResults.rows && validationResults.rows.length > 0) {
                            self.validationResults = validationResults.rows;
                        }
                        resolve(self.validationResults);
                    } else {
                        throw new Error('failed to get uploaded files from repository');
                    }
                });
            });
        };

        BulkLoadService.prototype.importSelectedFile = function importSelectedFile(params) {
            var self = this;

            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Resources').withEntityName('PTC.Asset.BulkImporter').withServiceType('Services').withServiceName('Import').withParams(params).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        var importResults = JSON.parse(results.response);
                        self.importResults = [];
                        if (importResults.rows && importResults.rows.length > 0) {
                            self.importResults = importResults.rows;
                        }
                        resolve(self.importResults);
                    } else {
                        throw new Error('failed to get uploaded files from repository');
                    }
                });
            });
        };

        return BulkLoadService;
    }()) || _class);
});
define('services/converge-layout-provider',['exports', 'thingworx-ui-platform/helpers/loader-helper'], function (exports, _loaderHelper) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.ConvergeLayoutProvider = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var ConvergeLayoutProvider = exports.ConvergeLayoutProvider = function () {
        function ConvergeLayoutProvider() {
            _classCallCheck(this, ConvergeLayoutProvider);

            this.layouts = {};
        }

        ConvergeLayoutProvider.prototype.getLayoutDefinition = function getLayoutDefinition(setName) {
            var self = this;
            return new Promise(function (resolve) {
                if (self.layouts[setName]) {
                    resolve(self.layouts[setName]);
                    return;
                }

                _loaderHelper.LoaderHelper.loadJson('layouts/' + setName + '.json').then(function (result) {
                    self.layouts[setName] = result;
                    resolve(self.layouts[setName]);
                });
            });
        };

        ConvergeLayoutProvider.prototype.getLayout = function getLayout() {
            var _this = this;

            var args = [].splice.call(arguments, 0);
            var characteristic = args.shift();
            return new Promise(function (resolve) {
                _this.getLayoutDefinition(characteristic).then(function (layout) {
                    var result = layout;
                    while (args.length > 0 && result[args[0]]) {
                        result = result[args.shift()];
                    }
                    resolve(result);
                });
            });
        };

        return ConvergeLayoutProvider;
    }();
});
define('services/file-upload-service',['exports', 'aurelia-framework', '../services/invoker-custom/invoker-factory-custom', 'thingworx-ui-platform/events/event-helper'], function (exports, _aureliaFramework, _invokerFactoryCustom, _eventHelper) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.FileUploadService = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var FileUploadService = exports.FileUploadService = (_dec = (0, _aureliaFramework.inject)(_invokerFactoryCustom.InvokerFactoryCustom), _dec(_class = function () {
        function FileUploadService(invokerFactoryCustom) {
            _classCallCheck(this, FileUploadService);

            this.invokerFactory = invokerFactoryCustom;
            this.eventHelper = new _eventHelper.EventHelper('FileUploadService');
        }

        FileUploadService.prototype.uploadFile = function uploadFile(repository, path, file) {
            var self = this;

            var headers = {
                'X-XSRF-TOKEN': 'TWX-XSRF-TOKEN-VALUE',
                'X-Requested-With': 'XMLHttpRequest'
            };

            var headersToRemove = ['Content-Type'];

            var formData = new FormData();
            formData.append('upload-repository-1', repository);
            formData.append('upload-path-1', path);
            formData.append('file', file);

            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('FileRepositoryUploader').withHeaders(headers).removeHeaders(headersToRemove).asPost().withContent(formData).invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        resolve();
                    } else {
                        throw new Error('failed to get uploaded files from repository');
                    }
                });
            });
        };

        FileUploadService.prototype.fileExists = function fileExists(repository, pathToFile) {
            var self = this;

            var params = { path: pathToFile };

            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Things').withEntityName(repository).withServiceType('Services').withServiceName('GetFileInfo').withParams(params).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                }).catch(function (err) {
                    resolve(false);
                });
            });
        };

        FileUploadService.prototype.deleteImportFile = function deleteImportFile(repository, pathToFile) {
            var self = this;

            var params = { path: pathToFile };

            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Things').withEntityName(repository).withServiceType('Services').withServiceName('DeleteFile').withParams(params).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                }).catch(function (err) {
                    resolve(false);
                });
            });
        };

        return FileUploadService;
    }()) || _class);
});
define('services/resource-provider-fields-service',['exports', 'aurelia-framework', 'thingworx-ui-platform/services/invoker/invoker-factory', 'thingworx-ui-platform/events/event-helper'], function (exports, _aureliaFramework, _invokerFactory, _eventHelper) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.ResourceProviderFieldsService = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var ResourceProviderFieldsService = exports.ResourceProviderFieldsService = (_dec = (0, _aureliaFramework.inject)(_invokerFactory.InvokerFactory), _dec(_class = function () {
        function ResourceProviderFieldsService(invokerFactory) {
            _classCallCheck(this, ResourceProviderFieldsService);

            this.fields = {};

            this.invokerFactory = invokerFactory;
            this.eventHelper = new _eventHelper.EventHelper('ResourceProviderFieldsService');
        }

        ResourceProviderFieldsService.prototype.getFields = function getFields(forceReload, resourceProvider) {
            var self = this;
            var rp = resourceProvider || "default";
            return new Promise(function (resolve) {
                if (!forceReload && self.fields[rp] && self.fields[rp].length > 0) {
                    resolve(self.fields[rp]);
                    return;
                }

                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Resources').withEntityName('PTC.Asset.AssetMonitorUtilities').withServiceType('Services').withServiceName('GetAssetSearchConfig').withParams({ resourceProvider: resourceProvider }).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        var fields = JSON.parse(results.response);
                        self.fields[rp] = fields;
                        resolve(self.fields[rp]);
                    } else {
                        throw new Error('failed to get resource provider fields');
                    }
                });
            });
        };

        ResourceProviderFieldsService.prototype.saveFieldConfig = function saveFieldConfig(fieldsTable, resourceProvider) {
            var self = this;
            return new Promise(function (resolve) {
                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Resources').withEntityName('PTC.Asset.AssetMonitorUtilities').withServiceType('Services').withServiceName('SaveAssetSearchConfig').withParams({ resourceProvider: resourceProvider }).withContent({ configTable: fieldsTable }).asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        resolve();
                    } else {
                        throw new Error('failed to save asset search fields');
                    }
                });
            });
        };

        return ResourceProviderFieldsService;
    }()) || _class);
});
define('services/resource-provider-thingshapes-service',['exports', 'aurelia-framework', 'thingworx-ui-platform/services/invoker/invoker-factory', 'thingworx-ui-platform/events/event-helper'], function (exports, _aureliaFramework, _invokerFactory, _eventHelper) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.ResourceProviderThingshapesService = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var ResourceProviderThingshapesService = exports.ResourceProviderThingshapesService = (_dec = (0, _aureliaFramework.inject)(_invokerFactory.InvokerFactory), _dec(_class = function () {
        function ResourceProviderThingshapesService(invokerFactory) {
            _classCallCheck(this, ResourceProviderThingshapesService);

            this.thingShapes = null;
            this.rpExtraThingShapeMap = {
                'PTC.Resource.Asset.SCMResourceThingShape': 'TW.RSM.SFW.ThingShape.Updateable',
                'PTC.Resource.Asset.RSMUpdatableResourceThingShape': 'TW.RSM.SFW.ThingShape.Updateable'
            };

            this.invokerFactory = invokerFactory;
            this.eventHelper = new _eventHelper.EventHelper('ResourceProviderThingshapesService');
        }

        ResourceProviderThingshapesService.prototype.getThingShapes = function getThingShapes() {
            var self = this;
            return new Promise(function (resolve) {
                if (self.thingShapes && self.thingShapes.rows && self.thingShapes.rows.length > 0) {
                    resolve(self.thingShapes);
                    return;
                }

                self.invokerFactory.getInvoker().createRequest().withEntityCollectionName('Things').withEntityName('PTC.Asset.AssetHelper').withServiceType('Services').withServiceName('GetResourceProviderThingShapes').asPost().invoke().then(function (results) {
                    if (results.statusCode === 200) {
                        self.thingShapes = JSON.parse(results.response);
                        resolve(self.thingShapes);
                    } else {
                        throw new Error('failed to get asset types');
                    }
                });
            });
        };

        ResourceProviderThingshapesService.prototype.getRpExtraThingShape = function getRpExtraThingShape(rpThingShape) {
            return this.rpExtraThingShapeMap[rpThingShape] ? this.rpExtraThingShapeMap[rpThingShape] : '';
        };

        return ResourceProviderThingshapesService;
    }()) || _class);
});
define('services/thing-generate-properties-service',['exports', 'aurelia-framework', 'thingworx-ui-platform/events/event-helper', 'thingworx-ui-platform/services/entity-service-base', 'lodash'], function (exports, _aureliaFramework, _eventHelper, _entityServiceBase, _lodash) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.ThingGeneratePropertiesService = undefined;

    var _lodash2 = _interopRequireDefault(_lodash);

    function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : {
            default: obj
        };
    }

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var ThingGeneratePropertiesService = exports.ThingGeneratePropertiesService = (_dec = (0, _aureliaFramework.inject)(_entityServiceBase.EntityServiceBase), _dec(_class = function () {
        function ThingGeneratePropertiesService(entityService) {
            _classCallCheck(this, ThingGeneratePropertiesService);

            this.thingTemplateProps = {};
            this.thingShapeProps = {};

            this.entityService = entityService;
            this.eventHelper = new _eventHelper.EventHelper('ThingGeneratePropertiesService');
        }

        ThingGeneratePropertiesService.prototype.getPropsAndLayout = function getPropsAndLayout(thingTemplateName, thingShapeName) {
            var self = this;
            return new Promise(function (resolve) {
                if (!thingTemplateName) {
                    resolve({});
                    return;
                }
                self.getThingTemplateProperties(thingTemplateName).then(function (thingTemplateProps) {
                    self.getThingShapeProperties(thingShapeName).then(function (thingShapesProps) {
                        resolve(self.organizePropsAndLayout(self.combineProperties(thingTemplateProps, thingShapesProps)));
                    });
                });
            });
        };

        ThingGeneratePropertiesService.prototype.getThingTemplateProperties = function getThingTemplateProperties(thingTemplateName) {
            var self = this;
            return new Promise(function (resolve) {
                if (!thingTemplateName) {
                    resolve({});
                    return;
                }
                if (self.thingTemplateProps[thingTemplateName]) {
                    resolve(self.thingTemplateProps[thingTemplateName]);
                    return;
                }
                self.entityService.getEntity('ThingTemplate', thingTemplateName).then(function (result) {
                    self.thingTemplateProps[thingTemplateName] = result.effectiveShape.propertyDefinitions;
                    resolve(self.thingTemplateProps[thingTemplateName]);
                });
            });
        };

        ThingGeneratePropertiesService.prototype.getThingShapeProperties = function getThingShapeProperties(thingShapeName) {
            var self = this;
            return new Promise(function (resolve) {
                if (!thingShapeName) {
                    resolve({});
                    return;
                }
                if (self.thingShapeProps[thingShapeName]) {
                    resolve(self.thingShapeProps[thingShapeName]);
                    return;
                }
                self.entityService.getEntity('ThingShape', thingShapeName).then(function (result) {
                    self.thingShapeProps[thingShapeName] = result.effectiveShape.propertyDefinitions;
                    resolve(self.thingShapeProps[thingShapeName]);
                });
            });
        };

        ThingGeneratePropertiesService.prototype.combineProperties = function combineProperties(thingTemplateProperties, thingShapeProperties) {
            return _lodash2.default.extend({}, thingTemplateProperties, thingShapeProperties);
        };

        ThingGeneratePropertiesService.prototype.organizePropsAndLayout = function organizePropsAndLayout(propDefs) {
            return {
                propertyDefinitions: propDefs,
                editableProperties: this.genEditableDefaults(propDefs),
                layout: this.genPropertyLayout(propDefs)
            };
        };

        ThingGeneratePropertiesService.prototype.genEditableDefaults = function genEditableDefaults(propertyDefinitions) {
            var properties = [];
            for (var i in propertyDefinitions) {
                var prop = propertyDefinitions[i];
                if (prop.aspects.isReadOnly || prop.aspects.isLogged || prop.name === 'isAlerted' || ['BOOLEAN', 'INTEGER', 'LONG', 'NUMBER', 'STRING', 'DATETIME'].indexOf(prop.baseType) === -1) {
                    continue;
                }
                var obj = { name: prop.name };
                switch (prop.baseType) {
                    case 'STRING':
                        break;
                    case 'DATETIME':
                        obj.value = new Date();
                        break;
                    case 'BOOLEAN':
                        obj.value = false;
                        break;
                    default:
                        obj.value = 0;
                        break;
                }
                properties.push(obj);
            }
            return properties;
        };

        ThingGeneratePropertiesService.prototype.genPropertyLayout = function genPropertyLayout(propertyDefinitions) {
            var columns = [];
            for (var i in propertyDefinitions) {
                var prop = propertyDefinitions[i];
                if (prop.aspects.isReadOnly || prop.aspects.isLogged || prop.name === 'isAlerted' || ['BOOLEAN', 'INTEGER', 'LONG', 'NUMBER', 'STRING', 'DATETIME'].indexOf(prop.baseType) === -1) {
                    continue;
                }
                columns.push({
                    name: 'entity.thingProperties.' + prop.name,
                    label: prop.name.split(/(?=[A-Z])/).join(' '),
                    baseType: prop.baseType,
                    i18n: {
                        label: false
                    }
                });
            }
            columns = _lodash2.default.sortBy(columns, ['name']);
            return [{
                collapsible: false,
                groupName: 'editableProperties',
                columns: [columns]
            }];
        };

        return ThingGeneratePropertiesService;
    }()) || _class);
});
define('value-converters/sort-value-converter',['exports', 'lodash'], function (exports, _lodash) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.SortValueConverter = undefined;

    var _lodash2 = _interopRequireDefault(_lodash);

    function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : {
            default: obj
        };
    }

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var SortValueConverter = exports.SortValueConverter = function () {
        function SortValueConverter() {
            _classCallCheck(this, SortValueConverter);
        }

        SortValueConverter.prototype.toView = function toView(array, propertyName) {
            array = _lodash2.default.sortBy(array, propertyName);
            return array;
        };

        return SortValueConverter;
    }();
});
define('services/invoker-custom/http-invoker-custom',['exports', 'thingworx-ui-platform/services/invoker/http-invoker', './invoker-builder-custom'], function (exports, _httpInvoker, _invokerBuilderCustom) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.HttpInvokerCustom = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    function _possibleConstructorReturn(self, call) {
        if (!self) {
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }

        return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }

    function _inherits(subClass, superClass) {
        if (typeof superClass !== "function" && superClass !== null) {
            throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
        }

        subClass.prototype = Object.create(superClass && superClass.prototype, {
            constructor: {
                value: subClass,
                enumerable: false,
                writable: true,
                configurable: true
            }
        });
        if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }

    var HttpInvokerCustom = exports.HttpInvokerCustom = function (_HttpInvoker) {
        _inherits(HttpInvokerCustom, _HttpInvoker);

        function HttpInvokerCustom(options) {
            _classCallCheck(this, HttpInvokerCustom);

            return _possibleConstructorReturn(this, _HttpInvoker.call(this, options));
        }

        HttpInvokerCustom.prototype.createRequest = function createRequest() {
            var builder = new _invokerBuilderCustom.InvokerBuilderCustom(this);
            return builder;
        };

        return HttpInvokerCustom;
    }(_httpInvoker.HttpInvoker);
});
define('services/invoker-custom/invoker-builder-custom',['exports', 'thingworx-ui-platform/services/invoker/invoker-builder'], function (exports, _invokerBuilder) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.InvokerBuilderCustom = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    function _possibleConstructorReturn(self, call) {
        if (!self) {
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }

        return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }

    function _inherits(subClass, superClass) {
        if (typeof superClass !== "function" && superClass !== null) {
            throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
        }

        subClass.prototype = Object.create(superClass && superClass.prototype, {
            constructor: {
                value: subClass,
                enumerable: false,
                writable: true,
                configurable: true
            }
        });
        if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }

    var InvokerBuilderCustom = exports.InvokerBuilderCustom = function (_InvokerBuilder) {
        _inherits(InvokerBuilderCustom, _InvokerBuilder);

        function InvokerBuilderCustom(invoker) {
            _classCallCheck(this, InvokerBuilderCustom);

            var _this = _possibleConstructorReturn(this, _InvokerBuilder.call(this, invoker));

            _this.transformers = [];
            return _this;
        }

        return InvokerBuilderCustom;
    }(_invokerBuilder.InvokerBuilder);

    _invokerBuilder.InvokerBuilder.addHelper('removeHeaders', function (headers) {
        return function (invoker, message) {
            var length = headers.length;
            for (var i = 0; i < length; i++) {
                delete message.headers[headers[i]];
            }
        };
    });
});
define('services/invoker-custom/invoker-factory-custom',['exports', './http-invoker-custom', 'thingworx-ui-platform/services/invoker/websocket-invoker', 'thingworx-ui-platform/services/invoker/invoker-factory'], function (exports, _httpInvokerCustom, _websocketInvoker, _invokerFactory) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.InvokerFactoryCustom = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    function _possibleConstructorReturn(self, call) {
        if (!self) {
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }

        return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }

    function _inherits(subClass, superClass) {
        if (typeof superClass !== "function" && superClass !== null) {
            throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
        }

        subClass.prototype = Object.create(superClass && superClass.prototype, {
            constructor: {
                value: subClass,
                enumerable: false,
                writable: true,
                configurable: true
            }
        });
        if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }

    var _class, _temp2;

    var InvokerFactoryCustom = exports.InvokerFactoryCustom = (_temp2 = _class = function (_InvokerFactory) {
        _inherits(InvokerFactoryCustom, _InvokerFactory);

        function InvokerFactoryCustom() {
            var _temp, _this, _ret;

            _classCallCheck(this, InvokerFactoryCustom);

            for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
                args[_key] = arguments[_key];
            }

            return _ret = (_temp = (_this = _possibleConstructorReturn(this, _InvokerFactory.call.apply(_InvokerFactory, [this].concat(args))), _this), _this._instances = {}, _temp), _possibleConstructorReturn(_this, _ret);
        }

        InvokerFactoryCustom.prototype.getInvoker = function getInvoker(type) {
            if (!type) {
                type = 'http';
            }

            var inst = this._instances[type];

            if (!inst) {
                switch (type) {
                    case 'http':
                        this._instances[type] = new _httpInvokerCustom.HttpInvokerCustom(_invokerFactory.InvokerFactory.config);
                        break;
                    case 'websocket':
                        this._instances[type] = new _websocketInvoker.WebsocketInvoker(_invokerFactory.InvokerFactory.config);
                        break;
                    default:
                        this._instances[type] = new _httpInvokerCustom.HttpInvokerCustom(_invokerFactory.InvokerFactory.config);
                }
                inst = this._instances[type];
            }

            return inst;
        };

        return InvokerFactoryCustom;
    }(_invokerFactory.InvokerFactory), _class.config = {
        baseUri: 'http://services.thingworx.com/',
        appRoot: 'Thingworx/'
    }, _temp2);
});
define('views/asset-search-config/asset-search-config',['exports', 'jquery', 'lodash', 'aurelia-templating-resources', 'aurelia-dialog', 'thingworx-ui-platform/events/event-helper', 'aurelia-framework', 'thingworx-ui-platform/helpers/loader-helper', './config-saved-dialog', '../../services/resource-provider-fields-service'], function (exports, _jquery, _lodash, _aureliaTemplatingResources, _aureliaDialog, _eventHelper, _aureliaFramework, _loaderHelper, _configSavedDialog, _resourceProviderFieldsService) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.AssetSearchConfig = undefined;

    var _jquery2 = _interopRequireDefault(_jquery);

    var _lodash2 = _interopRequireDefault(_lodash);

    function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : {
            default: obj
        };
    }

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    _loaderHelper.LoaderHelper.importAppCss('/views/asset-search-config/asset-search-config.css');

    var AssetSearchConfig = exports.AssetSearchConfig = (_dec = (0, _aureliaFramework.inject)(_resourceProviderFieldsService.ResourceProviderFieldsService, _aureliaTemplatingResources.BindingSignaler, _aureliaDialog.DialogService), _dec(_class = function () {
        function AssetSearchConfig(rpFieldService, signaler, dialogService) {
            _classCallCheck(this, AssetSearchConfig);

            this.fieldsTable = {};
            this.fields = [];
            this.showRps = false;
            this.lastSortOrder = 1;
            this.resourceProvider = null;

            this.eventHelper = new _eventHelper.EventHelper('AssetSearchConfig');
            this.rpFieldService = rpFieldService;
            this.signaler = signaler;
            this.dialogService = dialogService;
        }

        AssetSearchConfig.prototype.attached = function attached() {
            this.getFields();
        };

        AssetSearchConfig.prototype.detached = function detached() {
            this.eventHelper.destroyAll();
        };

        AssetSearchConfig.prototype.activate = function activate(params) {
            this.resourceProvider = params.resourceProvider && params.resourceProvider !== "DEFAULT" ? params.resourceProvider : null;
        };

        AssetSearchConfig.prototype.getFields = function getFields() {
            var self = this;
            this.rpFieldService.getFields(true, this.resourceProvider).then(function (fields) {
                self.fieldsTable = fields;
                self.fields = fields.rows;
                self.genLastSortOrder();
            }).catch(function (err) {
                alert('Could not load fields.');
            });
        };

        AssetSearchConfig.prototype.addField = function addField(field, evt) {
            field.Selected = true;
            field.SortOrder = this.lastSortOrder + 1;
            evt.preventDefault();
            this.cleanSortOrders();
        };

        AssetSearchConfig.prototype.removeField = function removeField(field, evt) {
            field.Selected = false;
            this.preSelectFieldOptions(field);
            evt.preventDefault();
            this.cleanSortOrders();
        };

        AssetSearchConfig.prototype.preSelectFieldOptions = function preSelectFieldOptions(field, evt) {
            field.IsFilterField = field.Selected;
            field.IsGridField = field.Selected;
        };

        AssetSearchConfig.prototype.moveFieldSortUp = function moveFieldSortUp(field, evt) {
            field.SortOrder--;
            evt.preventDefault();
            this.cleanSortOrders(field);
            (0, _jquery2.default)(evt.target).blur();
        };

        AssetSearchConfig.prototype.moveFieldSortDown = function moveFieldSortDown(field, evt) {
            field.SortOrder++;
            evt.preventDefault();
            this.cleanSortOrders(field);
            (0, _jquery2.default)(evt.target).blur();
        };

        AssetSearchConfig.prototype.genLastSortOrder = function genLastSortOrder() {
            var total = 0;
            for (var i = 0, l = this.fields.length; i < l; i++) {
                if (this.fields[i].Selected) {
                    total++;
                }
            }
            this.lastSortOrder = total;
        };

        AssetSearchConfig.prototype.cleanSortOrders = function cleanSortOrders(updatedField) {
            var sortNum = 1;
            this.fields = _lodash2.default.sortBy(this.fields, ['SortOrder']);
            for (var i = 0, l = this.fields.length; i < l; i++) {
                var field = this.fields[i];
                if (field.Selected) {
                    if (updatedField && updatedField.id === field.id) {
                        continue;
                    } else if (updatedField && sortNum === updatedField.SortOrder) {
                        sortNum++;
                    }
                    field.SortOrder = sortNum++;
                }
            }
            this.genLastSortOrder();
            this.signaler.signal('sort-signal');
        };

        AssetSearchConfig.prototype.saveFieldConfig = function saveFieldConfig(evt) {
            var self = this;
            this.rpFieldService.saveFieldConfig(this.fieldsTable, this.resourceProvider).then(function () {
                self.getFields();
                self.dialogService.open({ viewModel: _configSavedDialog.ConfigSavedDialog, model: {} });
            }).catch(function (err) {
                alert('Could not save asset search config.');
            });
            (0, _jquery2.default)(evt.target).blur();
        };

        AssetSearchConfig.prototype.resetFields = function resetFields(evt) {
            this.getFields();
            (0, _jquery2.default)(evt.target).blur();
        };

        AssetSearchConfig.prototype.isAvailForDetailImage = function isAvailForDetailImage(field) {
            return field.BaseType === 'IMAGE';
        };

        AssetSearchConfig.prototype.isAvailForDetailProp = function isAvailForDetailProp(field) {
            switch (field.BaseType) {
                case 'BOOLEAN':
                case 'DATETIME':
                case 'INTEGER':
                case 'NUMBER':
                case 'STRING':
                    return true;
            }
            return false;
        };

        AssetSearchConfig.prototype.changeStep = function changeStep(stepValue, evt) {
            this.step = stepValue;
            (0, _jquery2.default)(evt.target).blur();
        };

        return AssetSearchConfig;
    }()) || _class);
});
define('views/asset-search-config/config-saved-dialog',['exports', 'aurelia-dialog', 'aurelia-framework'], function (exports, _aureliaDialog, _aureliaFramework) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.ConfigSavedDialog = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var ConfigSavedDialog = exports.ConfigSavedDialog = (_dec = (0, _aureliaFramework.inject)(_aureliaDialog.DialogController), _dec(_class = function () {
        function ConfigSavedDialog(dialogController) {
            _classCallCheck(this, ConfigSavedDialog);

            this.results = {};

            this.dialogController = dialogController;
        }

        ConfigSavedDialog.prototype.activate = function activate(results) {
            this.results = results;
        };

        return ConfigSavedDialog;
    }()) || _class);
});
define('views/bulk-load-assets/bulk-load-assets',['exports', 'aurelia-framework', 'aurelia-dialog', 'thingworx-ui-platform/events/event-helper', 'thingworx-ui-platform/services/invoker/invoker-factory', 'thingworx-ui-platform/helpers/loader-helper', '../../services/asset-types-service', '../../services/bulk-load-service', '../../services/file-upload-service', '../../services/resource-provider-thingshapes-service', './file-exists-dialog', './import-dialog', './validate-dialog'], function (exports, _aureliaFramework, _aureliaDialog, _eventHelper, _invokerFactory, _loaderHelper, _assetTypesService, _bulkLoadService, _fileUploadService, _resourceProviderThingshapesService, _fileExistsDialog, _importDialog, _validateDialog) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.BulkLoadAssets = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _createClass = function () {
        function defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
                var descriptor = props[i];
                descriptor.enumerable = descriptor.enumerable || false;
                descriptor.configurable = true;
                if ("value" in descriptor) descriptor.writable = true;
                Object.defineProperty(target, descriptor.key, descriptor);
            }
        }

        return function (Constructor, protoProps, staticProps) {
            if (protoProps) defineProperties(Constructor.prototype, protoProps);
            if (staticProps) defineProperties(Constructor, staticProps);
            return Constructor;
        };
    }();

    function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
        var desc = {};
        Object['ke' + 'ys'](descriptor).forEach(function (key) {
            desc[key] = descriptor[key];
        });
        desc.enumerable = !!desc.enumerable;
        desc.configurable = !!desc.configurable;

        if ('value' in desc || desc.initializer) {
            desc.writable = true;
        }

        desc = decorators.slice().reverse().reduce(function (desc, decorator) {
            return decorator(target, property, desc) || desc;
        }, desc);

        if (context && desc.initializer !== void 0) {
            desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
            desc.initializer = undefined;
        }

        if (desc.initializer === void 0) {
            Object['define' + 'Property'](target, property, desc);
            desc = null;
        }

        return desc;
    }

    var _dec, _dec2, _class, _desc, _value, _class2;

    _loaderHelper.LoaderHelper.importAppCss('/views/bulk-load-assets/bulk-load-assets.css');

    var BulkLoadAssets = exports.BulkLoadAssets = (_dec = (0, _aureliaFramework.inject)(_bulkLoadService.BulkLoadService, _resourceProviderThingshapesService.ResourceProviderThingshapesService, _assetTypesService.AssetTypesService, _invokerFactory.InvokerFactory, _fileUploadService.FileUploadService, _aureliaDialog.DialogService), _dec2 = (0, _aureliaFramework.computedFrom)('assetTypeSelected', 'rpThingShapeSelected', 'files'), _dec(_class = (_class2 = function () {
        function BulkLoadAssets(bulkLoadService, resourceProviderThingshapesService, assetTypesService, invokerFactory, fileUploadService, dialogService) {
            _classCallCheck(this, BulkLoadAssets);

            this.eventHelper = new _eventHelper.EventHelper('BulkLoadAssets');
            this.assetTypesService = assetTypesService;
            this.bulkLoadService = bulkLoadService;
            this.fileUploadService = fileUploadService;
            this.resourceProviderThingShapeService = resourceProviderThingshapesService;
            this.invokerFactory = invokerFactory;
            this.dialogService = dialogService;

            this.assetTypes = [];
            this.files = [];
            this.fileRepositories = [];
            this.importResults = [];
            this.resourceProviderThingShapes = [];
            this.repositoryStructure = [];
            this.uploadedFiles = [];
            this.validationResults = [];

            this.assetTypeSelected = '';
            this.customFilePath = '';
            this.fileRepositorySelected = 'SystemRepository';
            this.filePathSelected = '';
            this.rpThingShapeSelected = '';
            this.thingShapeSelected = '';
            this.uploadFilePath = '/AssetManager/BulkLoad';
            this.currentFileValidated = false;
        }

        BulkLoadAssets.prototype.attached = function attached() {
            this.getAssetTypes();
            this.getFileRepositories();
            this.getResourceProviderThingShapes();
        };

        BulkLoadAssets.prototype.detached = function detached() {
            this.eventHelper.destroyAll();
        };

        BulkLoadAssets.prototype.activate = function activate(params) {};

        BulkLoadAssets.prototype.updateConfiguration = function updateConfiguration() {
            this.currentFileValidated = false;
        };

        BulkLoadAssets.prototype.getUploadedFiles = function getUploadedFiles() {
            var _this = this;

            var path = this.uploadFilePath ? this.uploadFilePath : '/';

            var params = {
                path: path
            };

            this.bulkLoadService.getUploadedFiles(this.fileRepositorySelected, params).then(function (uploadedFiles) {
                _this.uploadedFiles = uploadedFiles;
            }).catch(function (err) {
                alert('Could not load uploaded files.');
            });
        };

        BulkLoadAssets.prototype.getFileRepositoryStructure = function getFileRepositoryStructure() {
            var _this2 = this;

            this.bulkLoadService.getFileRepositoryStructure(this.fileRepositorySelected).then(function (repositoryStructure) {
                _this2.repositoryStructure = repositoryStructure;
            }).catch(function (err) {
                alert('Could not load repository structure');
            });
        };

        BulkLoadAssets.prototype.getFileRepositories = function getFileRepositories() {
            var _this3 = this;

            this.bulkLoadService.getFileRepositories().then(function (fileRepositories) {
                _this3.fileRepositories = fileRepositories;
            }).catch(function (err) {
                alert('Could not load file repositories');
            });
        };

        BulkLoadAssets.prototype.getResourceProviderThingShapes = function getResourceProviderThingShapes() {
            var _this4 = this;

            return new Promise(function (resolve, reject) {
                _this4.resourceProviderThingShapeService.getThingShapes().then(function (thingShapes) {
                    resolve(thingShapes);
                }).catch(function (err) {
                    reject(err);
                });
            });
        };

        BulkLoadAssets.prototype.getAssetTypes = function getAssetTypes() {
            var _this5 = this;

            return new Promise(function (resolve, reject) {
                _this5.assetTypesService.getAssetTypes().then(function (assetTypes) {
                    resolve(assetTypes);
                }).catch(function (err) {
                    reject(err);
                });
            });
        };

        BulkLoadAssets.prototype.uploadImportFile = function uploadImportFile(action) {
            var _this6 = this;

            this.filePathSelected = this.uploadFilePath + '/' + this.files[0].name;

            this.fileExists(this.filePathSelected).then(function (fileExists) {
                if (fileExists) {
                    _this6.dialogService.open({ viewModel: _fileExistsDialog.FileExistsDialog, model: {} }).then(function (response) {
                        if (!response.wasCancelled) {
                            _this6.fileUploadService.uploadFile(_this6.fileRepositorySelected, _this6.uploadFilePath, _this6.files[0]).then(function (results) {
                                if (action === 'validate') {
                                    _this6.validateSelectedFile();
                                } else {
                                    _this6.importSelectedFile();
                                }
                            }).catch(function (error) {
                                alert('Could not upload file');
                            });
                        }
                    });
                } else {
                    _this6.fileUploadService.uploadFile(_this6.fileRepositorySelected, _this6.uploadFilePath, _this6.files[0]).then(function (results) {
                        if (action === 'validate') {
                            _this6.validateSelectedFile();
                        } else {
                            _this6.importSelectedFile();
                        }
                    }).catch(function (error) {
                        alert('Could not upload file');
                    });
                }
            });
        };

        BulkLoadAssets.prototype.fileExists = function fileExists(pathToFile) {
            return this.fileUploadService.fileExists(this.fileRepositorySelected, pathToFile);
        };

        BulkLoadAssets.prototype.validateSelectedFile = function validateSelectedFile() {
            var _this7 = this;

            var params = {
                filePath: this.filePathSelected,
                fileRepository: this.fileRepositorySelected,
                resourceProviderThingShape: this.rpThingShapeSelected,
                thingShape: this.buildThingShapeString(),
                thingTemplate: this.assetTypeSelected
            };
            this.bulkLoadService.validateSelectedFile(params).then(function (validationResults) {
                _this7.validationResults = validationResults;

                _this7.deleteImportFile(_this7.filePathSelected);
                _this7.dialogService.open({ viewModel: _validateDialog.ValidateDialog, model: _this7.validationResults }).then(function (response) {});
            }).catch(function (err) {
                alert('Could not load validation results');
            });
        };

        BulkLoadAssets.prototype.importSelectedFile = function importSelectedFile() {
            var _this8 = this;

            var params = {
                filePath: this.filePathSelected,
                fileRepository: this.fileRepositorySelected,
                resourceProviderThingShape: this.rpThingShapeSelected,
                thingShape: this.buildThingShapeString(),
                thingTemplate: this.assetTypeSelected
            };
            this.bulkLoadService.importSelectedFile(params).then(function (importResults) {
                _this8.importResults = importResults;

                _this8.deleteImportFile(_this8.filePathSelected);
                _this8.dialogService.open({ viewModel: _importDialog.ImportDialog, model: _this8.importResults }).then(function (response) {});
            }).catch(function (err) {
                alert('Could not load validation results');
            });
        };

        BulkLoadAssets.prototype.deleteImportFile = function deleteImportFile(pathToFile) {
            return this.fileUploadService.deleteImportFile(this.fileRepositorySelected, pathToFile);
        };

        BulkLoadAssets.prototype.buildThingShapeString = function buildThingShapeString() {
            var a = [];
            if (this.thingShapeSelected) {
                a.push(this.thingShapeSelected);
            }
            if (this.rpThingShapeSelected) {
                var ts = this.resourceProviderThingShapeService.getRpExtraThingShape(this.rpThingShapeSelected);
                if (ts) {
                    a.push(ts);
                }
            }
            return a.join(',');
        };

        _createClass(BulkLoadAssets, [{
            key: 'isValid',
            get: function get() {
                if (this.assetTypeSelected && this.rpThingShapeSelected && this.files && this.files[0]) {
                    return true;
                }
                return false;
            }
        }]);

        return BulkLoadAssets;
    }(), (_applyDecoratedDescriptor(_class2.prototype, 'isValid', [_dec2], Object.getOwnPropertyDescriptor(_class2.prototype, 'isValid'), _class2.prototype)), _class2)) || _class);
});
define('views/bulk-load-assets/file-exists-dialog',['exports', 'aurelia-dialog', 'aurelia-framework'], function (exports, _aureliaDialog, _aureliaFramework) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.FileExistsDialog = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var FileExistsDialog = exports.FileExistsDialog = (_dec = (0, _aureliaFramework.inject)(_aureliaDialog.DialogController), _dec(_class = function () {
        function FileExistsDialog(dialogController) {
            _classCallCheck(this, FileExistsDialog);

            this.results = {};

            this.dialogController = dialogController;
        }

        FileExistsDialog.prototype.activate = function activate(results) {
            this.results = results;
        };

        return FileExistsDialog;
    }()) || _class);
});
define('views/bulk-load-assets/import-dialog',['exports', 'aurelia-dialog', 'aurelia-framework'], function (exports, _aureliaDialog, _aureliaFramework) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.ImportDialog = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var ImportDialog = exports.ImportDialog = (_dec = (0, _aureliaFramework.inject)(_aureliaDialog.DialogController), _dec(_class = function () {
        function ImportDialog(dialogController) {
            _classCallCheck(this, ImportDialog);

            this.results = {};

            this.dialogController = dialogController;
        }

        ImportDialog.prototype.activate = function activate(results) {
            this.results = results;
        };

        return ImportDialog;
    }()) || _class);
});
define('views/bulk-load-assets/validate-dialog',['exports', 'aurelia-dialog', 'aurelia-framework'], function (exports, _aureliaDialog, _aureliaFramework) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.ValidateDialog = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var ValidateDialog = exports.ValidateDialog = (_dec = (0, _aureliaFramework.inject)(_aureliaDialog.DialogController), _dec(_class = function () {
        function ValidateDialog(dialogController) {
            _classCallCheck(this, ValidateDialog);

            this.results = {};

            this.dialogController = dialogController;
        }

        ValidateDialog.prototype.activate = function activate(results) {
            this.results = results;
        };

        return ValidateDialog;
    }()) || _class);
});
define('views/create-asset/create-asset-basics',['exports', 'thingworx-ui-platform/services/entity-view-manager', 'thingworx-ui-platform/events/event-helper', 'aurelia-framework', '../../services/asset-types-service', '../../services/resource-provider-thingshapes-service'], function (exports, _entityViewManager, _eventHelper, _aureliaFramework, _assetTypesService, _resourceProviderThingshapesService) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.CreateAssetBasics = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _createClass = function () {
        function defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
                var descriptor = props[i];
                descriptor.enumerable = descriptor.enumerable || false;
                descriptor.configurable = true;
                if ("value" in descriptor) descriptor.writable = true;
                Object.defineProperty(target, descriptor.key, descriptor);
            }
        }

        return function (Constructor, protoProps, staticProps) {
            if (protoProps) defineProperties(Constructor.prototype, protoProps);
            if (staticProps) defineProperties(Constructor, staticProps);
            return Constructor;
        };
    }();

    var _dec, _class;

    var CreateAssetBasics = exports.CreateAssetBasics = (_dec = (0, _aureliaFramework.inject)(_entityViewManager.EntityViewManager, _assetTypesService.AssetTypesService, _resourceProviderThingshapesService.ResourceProviderThingshapesService), _dec(_class = function () {
        function CreateAssetBasics(entityViewManager, assetTypesService, rpThingShapesService) {
            _classCallCheck(this, CreateAssetBasics);

            this.eventHelper = new _eventHelper.EventHelper('CreateAssetBasics');
            this.viewManager = entityViewManager;
            this.assetTypesService = assetTypesService;
            this.rpThingShapesService = rpThingShapesService;
            this.assetTypes = [];
            this.rpThingShapes = [];
            this.lastExtraThingShape = '';
        }

        CreateAssetBasics.prototype.attached = function attached() {
            var _this = this;

            this.getAssetTypes();
            this.getResourceProviderThingShapes();

            this.eventHelper.subscribe('assetUpdated', function () {
                _this.setModel();
            });
        };

        CreateAssetBasics.prototype.detached = function detached() {
            this.eventHelper.destroyAll();
        };

        CreateAssetBasics.prototype.activate = function activate(params) {
            this.setModel();
            this.lastExtraThingShape = this.model.extraThingShape;
        };

        CreateAssetBasics.prototype.setModel = function setModel() {
            this.model = this.viewManager.getSelected();
            this.asset = this.model.entity;
        };

        CreateAssetBasics.prototype.getAssetTypes = function getAssetTypes() {
            var _this2 = this;

            return new Promise(function (resolve, reject) {
                _this2.assetTypesService.getAssetTypes().then(function (assetTypes) {
                    resolve(assetTypes);
                }).catch(function (err) {
                    reject(err);
                });
            });
        };

        CreateAssetBasics.prototype.typeSelected = function typeSelected() {
            this.eventHelper.publish('assetTypeSelected', {});
        };

        CreateAssetBasics.prototype.getResourceProviderThingShapes = function getResourceProviderThingShapes() {
            var _this3 = this;

            return new Promise(function (resolve, reject) {
                _this3.rpThingShapesService.getThingShapes().then(function (thingShapes) {
                    resolve(thingShapes);
                }).catch(function (err) {
                    reject(err);
                });
            });
        };

        CreateAssetBasics.prototype.next = function next() {
            if (this.isValid) {
                this.eventHelper.publish('assetBasicsAdded', {});
            }
        };

        CreateAssetBasics.prototype.cancel = function cancel() {
            this.eventHelper.publish('assetCancelRequest', {});
        };

        _createClass(CreateAssetBasics, [{
            key: 'isValid',
            get: function get() {
                if (this.asset.thingTemplate && this.asset.name && this.model.rpThingShape) {
                    return true;
                }
                return false;
            }
        }]);

        return CreateAssetBasics;
    }()) || _class);
});
define('views/create-asset/create-asset-properties',['exports', 'aurelia-framework', 'thingworx-ui-platform/services/entity-view-manager', 'thingworx-ui-platform/events/event-helper', 'thingworx-ui-platform/util/common-definitions', '../../services/converge-layout-provider', '../../services/thing-generate-properties-service'], function (exports, _aureliaFramework, _entityViewManager, _eventHelper, _commonDefinitions, _convergeLayoutProvider, _thingGeneratePropertiesService) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.CreateAssetProperties = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var CreateAssetProperties = exports.CreateAssetProperties = (_dec = (0, _aureliaFramework.inject)(_entityViewManager.EntityViewManager, _thingGeneratePropertiesService.ThingGeneratePropertiesService, _convergeLayoutProvider.ConvergeLayoutProvider), _dec(_class = function () {
        function CreateAssetProperties(entityViewManager, propertyService, layoutProvider) {
            _classCallCheck(this, CreateAssetProperties);

            this.eventHelper = new _eventHelper.EventHelper('CreateAssetProperties');
            this.viewManager = entityViewManager;
            this.propertyService = propertyService;
            this.layoutProvider = layoutProvider;
        }

        CreateAssetProperties.prototype.activate = function activate() {
            var _this = this;

            this.model = this.viewManager.getSelected();

            this.propertyService.getPropsAndLayout(this.model.entity.thingTemplate, this.model.extraThingShape).then(function (result) {
                if (_this.model.entity.thingPropertiesCleared) {
                    _this.model.entity.thingProperties = {};
                    _this.model.entity.thingPropertiesCleared = false;
                    for (var i = 0, l = result.editableProperties.length; i < l; i++) {
                        var obj = result.editableProperties[i];
                        _this.model.entity.thingProperties[obj.name] = obj.value;
                    }
                }
                _this.propertiesLayout = result.layout;
            });
            this.layoutProvider.getLayout('asset-basics', _commonDefinitions.Mode.read).then(function (layout) {
                _this.basicsLayout = layout;
            });
        };

        CreateAssetProperties.prototype.deactivate = function deactivate() {
            this.basicsLayout = null;
            this.propertiesLayout = null;
            this.eventHelper.destroyAll();
        };

        CreateAssetProperties.prototype.back = function back() {
            this.eventHelper.publish('backToAssetBasics', {});
        };

        CreateAssetProperties.prototype.save = function save() {
            this.eventHelper.publish('assetSaveRequest', {});
        };

        CreateAssetProperties.prototype.cancel = function cancel() {
            this.eventHelper.publish('assetCancelRequest', {});
        };

        return CreateAssetProperties;
    }()) || _class);
});
define('views/create-asset/create-asset-saved-dialog',['exports', 'aurelia-dialog', 'aurelia-framework'], function (exports, _aureliaDialog, _aureliaFramework) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.CreateAssetSavedDialog = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    var CreateAssetSavedDialog = exports.CreateAssetSavedDialog = (_dec = (0, _aureliaFramework.inject)(_aureliaDialog.DialogController), _dec(_class = function () {
        function CreateAssetSavedDialog(dialogController) {
            _classCallCheck(this, CreateAssetSavedDialog);

            this.dialogController = dialogController;
            this.error = '';
        }

        CreateAssetSavedDialog.prototype.activate = function activate(data) {
            this.error = data.error;
        };

        return CreateAssetSavedDialog;
    }()) || _class);
});
define('views/create-asset/create-asset',['exports', 'aurelia-dialog', 'thingworx-ui-platform/events/event-helper', 'thingworx-ui-platform/services/entity-view-manager', 'thingworx-ui-platform/services/entity-service-base', 'aurelia-framework', 'thingworx-ui-platform/helpers/loader-helper', 'thingworx-ui-platform/util/common-definitions', './create-asset-saved-dialog', '../../services/resource-provider-thingshapes-service'], function (exports, _aureliaDialog, _eventHelper, _entityViewManager, _entityServiceBase, _aureliaFramework, _loaderHelper, _commonDefinitions, _createAssetSavedDialog, _resourceProviderThingshapesService) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.CreateAsset = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var _dec, _class;

    _loaderHelper.LoaderHelper.importAppCss('/views/create-asset/create-asset.css');

    var CreateAsset = exports.CreateAsset = (_dec = (0, _aureliaFramework.inject)(_entityViewManager.EntityViewManager, _entityServiceBase.EntityServiceBase, _aureliaDialog.DialogService, _resourceProviderThingshapesService.ResourceProviderThingshapesService), _dec(_class = function () {
        function CreateAsset(entityViewManager, entityService, dialogService, rpThingShapesService) {
            _classCallCheck(this, CreateAsset);

            this.eventHelper = new _eventHelper.EventHelper('CreateAsset');
            this.viewManager = entityViewManager;
            this.entityService = entityService;
            this.dialogService = dialogService;
            this.rpThingShapesService = rpThingShapesService;
            this.model = {};
        }

        CreateAsset.prototype.configureRouter = function configureRouter(config, router) {
            this.router = router;
            config.map([{
                route: '',
                redirect: 'basicInfo'
            }, {
                route: 'basicInfo',
                name: 'basicInfo',
                moduleId: './create-asset-basics',
                nav: true,
                title: 'Asset Information'
            }, {
                route: 'assetProperties',
                name: 'assetProperties',
                moduleId: './create-asset-properties',
                nav: true,
                title: 'Asset Properties'
            }]);
        };

        CreateAsset.prototype.attached = function attached() {
            if (!this.viewManager.getSelected().entity.thingTemplate) {
                this.router.navigate('basicInfo');
            }
        };

        CreateAsset.prototype.detached = function detached() {
            this.eventHelper.destroyAll();
        };

        CreateAsset.prototype.canActivate = function canActivate(params, routeConfig, navigationInstruction) {
            return this.setInitialAssetStructure();
        };

        CreateAsset.prototype.activate = function activate(params) {
            var _this = this;

            this.eventHelper.subscribe('assetTypeSelected', function (data) {
                _this.clearProperties();
            });
            this.eventHelper.subscribe('assetBasicsAdded', function (data) {
                _this.router.navigate('assetProperties');
            });
            this.eventHelper.subscribe('backToAssetBasics', function (data) {
                _this.router.navigate('basicInfo');
            });
            this.eventHelper.subscribe('assetSaveRequest', function (data) {
                _this.saveNewAsset();
            });
            this.eventHelper.subscribe('assetCancelRequest', function (data) {
                _this.setInitialAssetStructure().then(function () {
                    _this.router.navigate('basicInfo');
                    _this.eventHelper.publish('assetUpdated');
                });
            });
        };

        CreateAsset.prototype.setInitialAssetStructure = function setInitialAssetStructure() {
            var _this2 = this;

            var entityPathName = this.viewManager.getViewPath('Thing');
            return new Promise(function (resolve) {
                _this2.viewManager.loadEntityFromPath(entityPathName, true).then(function (entity) {
                    if (entity) {
                        _this2.model = entity;
                        _this2.model.mode = _commonDefinitions.Mode.create;
                        _this2.model.extraThingShape = '';
                        _this2.viewManager.select(_this2.model);
                        if (_this2.thingShapeSubscribe) {
                            _this2.thingShapeSubscribe.dispose();
                        }
                        _this2.eventHelper.subscribeProperty(_this2.model, 'extraThingShape', _this2.clearProperties.bind(_this2));
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                }).catch(function (err) {
                    resolve(false);
                });
            });
        };

        CreateAsset.prototype.clearProperties = function clearProperties() {
            if (this.model) {
                this.model.entity.thingProperties = null;
                this.model.entity.thingPropertiesCleared = true;
            }
        };

        CreateAsset.prototype.saveNewAsset = function saveNewAsset() {
            var _this3 = this;

            var asset = this.viewManager.getSelected();
            if (asset) {
                this.addThingShapesToAsset(asset);
                this.entityService.createEntity(asset).then(function (newModel) {
                    _this3.dialogService.open({ viewModel: _createAssetSavedDialog.CreateAssetSavedDialog, model: {} });
                    _this3.setInitialAssetStructure().then(function () {
                        _this3.router.navigate('basicInfo');
                    });
                }).catch(function (err) {
                    _this3.dialogService.open({
                        viewModel: _createAssetSavedDialog.CreateAssetSavedDialog,
                        model: {
                            error: err.response
                        }
                    });
                });
            }
        };

        CreateAsset.prototype.addThingShapesToAsset = function addThingShapesToAsset(asset) {
            asset.entity.implementedShapes = {};
            if (asset.extraThingShape) {
                asset.entity.implementedShapes[asset.extraThingShape] = {
                    name: asset.extraThingShape,
                    type: 'ThingShape'
                };
            }
            if (asset.rpThingShape) {
                asset.entity.implementedShapes[asset.rpThingShape] = { name: asset.rpThingShape, type: 'ThingShape' };
                var extraThingShape = this.rpThingShapesService.getRpExtraThingShape(asset.rpThingShape);
                if (extraThingShape) {
                    asset.entity.implementedShapes[extraThingShape] = { name: extraThingShape, type: 'ThingShape' };
                }
            }
        };

        return CreateAsset;
    }()) || _class);
});
define('text!app.html', ['module'], function(module) { module.exports = "<template>\n    <router-view></router-view>\n</template>\n"; });
define('text!views/asset-search-config/asset-search-config.html', ['module'], function(module) { module.exports = "<template>\n    <require from=\"thingworx-ui-platform/value-converters/as-numeric\"></require>\n    <require from=\"../../value-converters/sort-value-converter\"></require>\n\n    <div class=\"tw-utl-asset-search-config\">\n        <div class=\"section-title\">\n            <div class=\"asset-search-icon\"></div>\n            <div class=\"asset-search-header\">\n                ${'tw.composer.assetSearch.assetSearchTitle' | t}\n            </div>\n        </div>\n        <div class=\"section-body container-fluid\">\n            <div class=\"btn-group\" role=\"group\" aria-label=\"...\">\n                <button type=\"button\" class=\"btn btn-secondary ${!step || step == 'pickFields' ? 'active' : ''}\"\n                        click.trigger=\"changeStep('pickFields', $event)\">\n                    ${'tw.composer.assetSearch.fieldSelection' | t}\n                </button>\n                </button>\n                <button type=\"button\" class=\"btn btn-secondary ${step == 'configFields' ? 'active' : ''}\"\n                        click.trigger=\"changeStep('configFields', $event)\">\n                    ${'tw.composer.assetSearch.fieldConfiguration' | t}\n                </button>\n            </div>\n            <div class=\"row\" if.bind=\"!step || step == 'pickFields'\">\n                <div class=\"col-sm-5\">\n                    <h5>${'tw.composer.assetSearch.fieldsAvailable' | t}</h5>\n                    <div class=\"fields fields-avail\">\n                        <div class=\"fields-container\">\n                            <table class=\"table table-bordered table-hover\">\n                                <thead>\n                                <tr>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.field' | t }</span>\n                                        <div>${'tw.composer.assetSearch.field' | t}</div>\n                                    </th>\n                                    <th>\n                                        ${'tw.composer.assetSearch.type' | t}\n                                        <div>${'tw.composer.assetSearch.type' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>&nbsp;</span>\n                                        <div>&nbsp;</div>\n                                    </th>\n                                </tr>\n                                </thead>\n                                <tbody>\n                                <tr repeat.for=\"field of fields | sort:'Name' & signal:'sort-signal'\"\n                                    class=\"${!field.Required && !field.Selected ? 'row-active' : 'row-inactive'}\">\n                                    <td>${field.Name}</td>\n                                    <td>${field.BaseType}</td>\n                                    <td class=\"action\">\n                                        <a href=\"\" click.trigger=\"addField(field, $event)\">\n                                            ${'tw.composer.buttons.add' | t}\n                                        </a>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"col-sm-7\">\n                    <h5>${'tw.composer.assetSearch.currentDatashapeFields' | t}</h5>\n                    <div class=\"fields fields-selected\">\n                        <div class=\"fields-container\">\n                            <table class=\"table table-bordered table-hover\">\n                                <thead>\n                                <tr>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.field' | t }</span>\n                                        <div>${'tw.composer.assetSearch.field' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.type' | t }</span>\n                                        <div>${'tw.composer.assetSearch.type' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.sort' | t }</span>\n                                        <div>${'tw.composer.assetSearch.sort' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>&nbsp;</span>\n                                        <div>&nbsp;</div>\n                                    </th>\n                                </tr>\n                                </thead>\n                                <tbody>\n                                <tr repeat.for=\"field of fields | sort:'SortOrder' & signal:'sort-signal'\"\n                                    class=\"${field.Required || field.Selected ? 'row-active' : 'row-inactive'}\">\n                                    <td>${field.Name}</td>\n                                    <td>${field.BaseType}</td>\n                                    <td class=\"sort-btns\">\n                                        <button class=\"btn btn-secondary ${field.SortOrder > 1 ? 'active' : 'deactive'}\"\n                                                click.trigger=\"moveFieldSortUp(field, $event)\">&#8593;</button>\n                                        <button class=\"btn btn-secondary ${field.SortOrder < lastSortOrder ? 'active' : 'deactive'}\"\n                                                click.trigger=\"moveFieldSortDown(field, $event)\">&#8595;</button>\n                                    </td>\n                                    <td class=\"action\">\n                                        <a if.bind=\"!field.Required\" href=\"\"\n                                           click.trigger=\"removeField(field, $event)\">\n                                            ${'tw.composer.buttons.remove' | t}\n                                        </a>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div class=\"row\" if.bind=\"step == 'configFields'\">\n                <div class=\"col-sm-12\">\n                    <h5>${'tw.composer.assetSearch.configureDatashapeFields' | t}</h5>\n                    <div class=\"fields fields-selected\">\n                        <div class=\"fields-container\">\n                            <table class=\"table table-bordered table-hover\">\n                                <thead>\n                                <tr>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.field' | t }</span>\n                                        <div>${'tw.composer.assetSearch.field' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.type' | t }</span>\n                                        <div>${'tw.composer.assetSearch.type' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.label' | t }</span>\n                                        <div>${'tw.composer.assetSearch.label' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.filter' | t }</span>\n                                        <div>${'tw.composer.assetSearch.filter' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.table' | t }</span>\n                                        <div>${'tw.composer.assetSearch.table' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.tableWidth' | t }</span>\n                                        <div>${'tw.composer.assetSearch.tableWidth' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.tableAlign' | t }</span>\n                                        <div>${'tw.composer.assetSearch.tableAlign' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetDetail.property' | t }</span>\n                                        <div>${'tw.composer.assetDetail.property' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetDetail.image' | t }</span>\n                                        <div>${'tw.composer.assetDetail.image' | t}</div>\n                                    </th>\n                                    <th>\n                                        <span>${'tw.composer.assetSearch.sort' | t }</span>\n                                        <div>${'tw.composer.assetSearch.sort' | t}</div>\n                                    </th>\n                                </tr>\n                                </thead>\n                                <tbody>\n                                <tr repeat.for=\"field of fields | sort:'SortOrder' & signal:'sort-signal'\"\n                                    class=\"${field.Required || field.Selected ? 'row-active' : 'row-inactive'}\">\n                                    <td>${field.Name}</td>\n                                    <td>${field.BaseType}</td>\n                                    <td><input type=\"text\" class=\"form-control\" value.bind=\"field.Label\"></td>\n                                    <td class=\"boolean\"><input type=\"checkbox\" checked.bind=\"field.IsFilterField\"></td>\n                                    <td class=\"boolean\"><input type=\"checkbox\" checked.bind=\"field.IsGridField\"></td>\n                                    <td>\n                                        <select class=\"form-control\" disabled.bind=\"!field.IsGridField\"\n                                                value.bind=\"field.ExtraData.GridOptions.Width\">\n                                            <option value=\"auto\">auto</option>\n                                            <option value=\"50\">50</option>\n                                            <option value=\"60\">60</option>\n                                            <option value=\"70\">70</option>\n                                            <option value=\"75\">75</option>\n                                            <option value=\"80\">80</option>\n                                            <option value=\"90\">90</option>\n                                            <option value=\"100\">100</option>\n                                            <option value=\"110\">110</option>\n                                            <option value=\"120\">120</option>\n                                            <option value=\"125\">125</option>\n                                            <option value=\"130\">130</option>\n                                            <option value=\"140\">140</option>\n                                            <option value=\"150\">150</option>\n                                            <option value=\"160\">160</option>\n                                            <option value=\"170\">170</option>\n                                            <option value=\"175\">175</option>\n                                            <option value=\"180\">180</option>\n                                            <option value=\"190\">190</option>\n                                            <option value=\"200\">200</option>\n                                            <option value=\"225\">225</option>\n                                            <option value=\"250\">250</option>\n                                            <option value=\"275\">275</option>\n                                            <option value=\"300\">300</option>\n                                            <option value=\"325\">325</option>\n                                            <option value=\"350\">350</option>\n                                            <option value=\"375\">375</option>\n                                            <option value=\"400\">400</option>\n                                        </select>\n                                    </td>\n                                    <td>\n                                        <select class=\"form-control\" disabled.bind=\"!field.IsGridField\"\n                                                value.bind=\"field.ExtraData.GridOptions.Align\">\n                                            <option value=\"left\">\n                                                ${'tw.composer.align.left' | t}\n                                            </option>\n                                            <option value=\"center\">\n                                                ${'tw.composer.align.center' | t}\n                                            </option>\n                                            <option value=\"right\">\n                                                ${'tw.composer.align.right' | t}\n                                            </option>\n                                        </select>\n                                    </td>\n                                    <td class=\"boolean\">\n                                        <input if.bind=\"isAvailForDetailProp(field)\" type=\"checkbox\"\n                                               checked.bind=\"field.ExtraData.DetailOptions.DetailProperty\">\n                                    </td>\n                                    <td class=\"boolean\">\n                                        <input if.bind=\"isAvailForDetailImage(field)\" type=\"checkbox\"\n                                               checked.bind=\"field.ExtraData.DetailOptions.DetailImage\">\n                                    </td>\n                                    <td class=\"sort-btns\">\n                                        <button class=\"btn btn-secondary ${field.SortOrder > 1 ? 'active' : 'deactive'}\"\n                                                click.trigger=\"moveFieldSortUp(field, $event)\">&#8593;</button>\n                                        <button class=\"btn btn-secondary ${field.SortOrder < lastSortOrder ? 'active' : 'deactive'}\"\n                                                click.trigger=\"moveFieldSortDown(field, $event)\">&#8595;</button>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div class=\"row\">\n                <div class=\"col-sm-12 step-btns\">\n                    <button class=\"btn btn-primary\" click.trigger=\"saveFieldConfig($event)\">\n                        ${'tw.composer.buttons.save' | t}\n                    </button>\n                    <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"resetFields($event)\">\n                        ${'tw.composer.buttons.reset' | t}\n                    </button>\n                </div>\n            </div>\n        </div>\n    </div>\n</template>\n"; });
define('text!views/asset-search-config/config-saved-dialog.html', ['module'], function(module) { module.exports = "<template>\r\n    <div class=\"tw-utl-asset-search-config-saved-dialog\">\r\n        <ai-dialog>\r\n            <ai-dialog-body>\r\n                <p>${'tw.composer.assetSearch.searchSaved' | t}</p>\r\n            </ai-dialog-body>\r\n\r\n            <ai-dialog-footer>\r\n                <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"dialogController.ok()\">\r\n                    ${'tw.composer.buttons.close' | t}\r\n                </button>\r\n            </ai-dialog-footer>\r\n        </ai-dialog>\r\n    </div>\r\n</template>\r\n"; });
define('text!views/bulk-load-assets/bulk-load-assets.html', ['module'], function(module) { module.exports = "<template>\n    <div class=\"tw-utl-bulk-load-assets\">\n        <div class=\"section-title\">\n            <div class=\"create-asset-icon\"></div>\n            <div class=\"create-asset-header\">${'tw.composer.bulkLoad.bulkLoadTitle' | t}</div>\n        </div>\n        <div class=\"section-body\">\n            <h4>${'tw.composer.bulkLoad.importConfigHeader' | t}</h4>\n            <form role=\"form\" name=\"upload-form\" id=\"upload-form\" enctype=\"multipart/form-data\"\n                  submit.delegate=\"uploadImportFile()\">\n                <div class=\"form-group row\">\n                    <label class=\"col-sm-3 form-control-label required\">\n                        ${'tw.composer.bulkLoad.assetType' | t}:\n                    </label>\n                    <div class=\"col-sm-9\">\n                        <entity-picker custom-query.bind=\"getAssetTypes\" entity-type=\"ThingTemplate\" multiple=\"false\"\n                                       value.two-way=\"assetTypeSelected\"></entity-picker>\n                    </div>\n                </div>\n                <div class=\"form-group row\">\n                    <label class=\"col-sm-3 form-control-label required\">\n                        ${'tw.composer.bulkLoad.resourceProvider' | t}:\n                    </label>\n                    <div class=\"col-sm-9\">\n                        <entity-picker custom-query.bind=\"getResourceProviderThingShapes\" entity-type=\"ThingShape\" multiple=\"false\"\n                                       value.two-way=\"rpThingShapeSelected\"></entity-picker>\n                    </div>\n                </div>\n                <div class=\"form-group row\">\n                    <label class=\"col-sm-3 form-control-label\">\n                        ${'tw.composer.bulkLoad.thingShape' | t}:\n                    </label>\n                    <div class=\"col-sm-9\">\n                        <entity-picker entity-type=\"ThingShape\" multiple=\"false\" value.two-way=\"thingShapeSelected\"></entity-picker>\n                    </div>\n                </div>\n                <div class=\"form-group row\">\n                    <label class=\"col-sm-3 form-control-label required\">\n                        ${'tw.composer.bulkLoad.sourceFile' | t}:\n                    </label>\n                    <div class=\"col-sm-9\">\n                        <div class=\"input-group\">\n                            <input value.bind=\"importFileSelected\" type=\"text\" class=\"form-control import-file\" readonly=\"readonly\">\n                            <span class=\"btn btn-primary btn-file\">\n                                ${'tw.composer.bulkLoad.browse' | t }\n                                <input type=\"file\" id=\"upload-file\" value.bind=\"importFileSelected\" files.bind=\"files\"\n                                       change.trigger=\"updateConfiguration()\">\n                            </span>\n                        </div>\n                    </div>\n                </div>\n                <br>\n                <div class=\"step-btns\">\n                    <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"uploadImportFile('validate')\"\n                            disabled.one-way=\"!isValid\">${'tw.composer.buttons.validate' | t}\n                    </button>\n                    <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"uploadImportFile('import')\"\n                            disabled.one-way=\"!isValid\">${'tw.composer.buttons.import' | t}\n                    </button>\n                </div>\n            </form>\n            <br><br>\n        </div>\n    </div>\n</template>\n"; });
define('text!views/bulk-load-assets/file-exists-dialog.html', ['module'], function(module) { module.exports = "<template>\r\n    <div class=\"tw-utl-bulk-load-assets-file-exists-dialog\">\r\n        <ai-dialog>\r\n            <ai-dialog-body>\r\n                <h3>${'tw.composer.bulkLoad.fileExistsHeader' | t}</h3>\r\n                <br>\r\n                <p>${'tw.composer.bulkLoad.fileExistsMessage' | t}</p>\r\n            </ai-dialog-body>\r\n\r\n            <ai-dialog-footer>\r\n                <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"dialogController.cancel()\">\r\n                    ${'tw.composer.buttons.cancel' | t}\r\n                </button>\r\n                <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"dialogController.ok()\">\r\n                    ${'tw.composer.buttons.continue' | t}\r\n                </button>\r\n            </ai-dialog-footer>\r\n        </ai-dialog>\r\n    </div>\r\n</template>\r\n"; });
define('text!views/bulk-load-assets/import-dialog.html', ['module'], function(module) { module.exports = "<template>\r\n    <div class=\"tw-utl-bulk-load-assets-import-dialog\">\r\n        <ai-dialog>\r\n            <ai-dialog-body>\r\n                <h3>${'tw.composer.bulkLoad.importResultsHeader' | t}</h3>\r\n                <br>\r\n                <div class=\"form-group\">\r\n                    <table class=\"table table-bordered table-striped table-hover\">\r\n                        <tbody repeat.for=\"result of results\">\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.total' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.total}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.valid' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.valid}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.invalid' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.invalid}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.updates' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.updates}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.created' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.creates}</td>\r\n                        </tr>\r\n                        </tbody>\r\n                    </table>\r\n                    <br>\r\n                    <div repeat.for=\"result of results\">\r\n                        <span if.bind=\"result.invalid > 0\">\r\n                            ${'tw.composer.bulkLoad.invalidWarning' | t}\r\n                        </span>\r\n                        <div if.bind=\"result.unmatchedHeaders > 0\">\r\n                            <span>\r\n                                <strong>${'tw.composer.bulkLoad.warning' |t}</strong>:\r\n                                ${'tw.composer.bulkLoad.unmatchedWarning' | t}\r\n                            </span>: ${result.unmatchedHeaders}\r\n                        </div>\r\n                        <br>\r\n                        <p>${'tw.composer.bulkLoad.logMessage' | t}</p>\r\n                    </div>\r\n                </div>\r\n            </ai-dialog-body>\r\n\r\n            <ai-dialog-footer>\r\n                <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"dialogController.cancel()\">\r\n                    ${'tw.composer.bulkLoad.close' | t}\r\n                </button>\r\n            </ai-dialog-footer>\r\n        </ai-dialog>\r\n    </div>\r\n</template>\r\n"; });
define('text!views/bulk-load-assets/validate-dialog.html', ['module'], function(module) { module.exports = "<template>\r\n    <div class=\"tw-utl-bulk-load-assets-validate-dialog\">\r\n        <ai-dialog>\r\n            <ai-dialog-body>\r\n                <h3>${'tw.composer.bulkLoad.validationResultsHeader' | t}</h3>\r\n                <br>\r\n                <div class=\"form-group\">\r\n                    <table class=\"table table-bordered table-striped table-hover\">\r\n                        <tbody repeat.for=\"result of results\">\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.total' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.total}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.valid' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.valid}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.invalid' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.invalid}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.updates' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.updates}</td>\r\n                        </tr>\r\n                        <tr>\r\n                            <td>${'tw.composer.bulkLoad.creates' | t}</td>\r\n                            <td class=\"text-xs-right\">${result.creates}</td>\r\n                        </tr>\r\n                        </tbody>\r\n                    </table>\r\n                    <br>\r\n                    <div repeat.for=\"result of results\">\r\n                        <span if.bind=\"result.invalid > 0\">\r\n                            ${'tw.composer.bulkLoad.invalidWarning' | t}\r\n                        </span>\r\n                        <div if.bind=\"result.unmatchedHeaders > 0\">\r\n                            <span>\r\n                                <strong>${'tw.composer.bulkLoad.warning' |t}</strong>:\r\n                                ${'tw.composer.bulkLoad.unmatchedWarning' | t}\r\n                            </span>: ${result.unmatchedHeaders}\r\n                        </div>\r\n                        <br>\r\n                        <p>${'tw.composer.bulkLoad.logMessage' | t}</p>\r\n                    </div>\r\n                </div>\r\n            </ai-dialog-body>\r\n\r\n            <ai-dialog-footer>\r\n                <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"dialogController.cancel()\">\r\n                    ${'tw.composer.bulkLoad.close' | t}\r\n                </button>\r\n            </ai-dialog-footer>\r\n        </ai-dialog>\r\n    </div>\r\n</template>\r\n"; });
define('text!views/create-asset/create-asset-basics.html', ['module'], function(module) { module.exports = "<template>\n    <require from=\"thingworx-ui-platform/widgets/nav-button\"></require>\n    <h4>${'tw.composer.assetInformation' | t}</h4>\n    <div class=\"form-group\">\n        <label for=\"entity.thingTemplate\">${'tw.composer.createAsset.assetType' | t}</label>\n        <entity-picker change.trigger=\"typeSelected()\" custom-query.bind=\"getAssetTypes\" entity-type=\"ThingTemplate\" multiple=\"false\"\n                       value.two-way=\"model.entity.thingTemplate\"></entity-picker>\n    </div>\n    <div class=\"form-group\">\n        <label for=\"entity.name\">${'tw.composer.createAsset.assetName' | t}</label>\n        <input type=\"text\" class=\"form-control\" value.bind=\"model.entity.name\">\n    </div>\n    <div class=\"form-group\">\n        <label for=\"entity.description\">${'tw.composer.createAsset.assetDescription' | t}</label>\n        <input type=\"text\" class=\"form-control\" value.bind=\"model.entity.description\">\n    </div>\n    <div class=\"form-group\">\n        <label for=\"rpThingShape\">${'tw.composer.createAsset.resourceProvider' | t}</label>\n        <entity-picker custom-query.bind=\"getResourceProviderThingShapes\" entity-type=\"ThingShape\" multiple=\"false\"\n                       value.two-way=\"model.rpThingShape\"></entity-picker>\n    </div>\n    <div class=\"form-group\">\n        <label for=\"extraThingShape\">${'tw.composer.createAsset.assetThingShape' | t}</label>\n        <entity-picker entity-type=\"ThingShape\" multiple=\"false\" value.two-way=\"model.extraThingShape\"></entity-picker>\n    </div>\n    <div class=\"step-btns\">\n        <button class=\"btn btn-primary\" disabled.one-way=\"!isValid\" click.trigger=\"next()\">\n            ${'tw.composer.buttons.next' | t}\n        </button>\n        <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"cancel()\">\n            ${'tw.composer.buttons.cancel' | t}\n        </button>\n    </div>\n</template>\n"; });
define('text!views/create-asset/create-asset-properties.html', ['module'], function(module) { module.exports = "<template>\n    <property-panel model.bind=\"model\" layout.bind=\"basicsLayout\" mode=\"read\"></property-panel>\n    <property-panel model.bind=\"model\" layout.bind=\"propertiesLayout\" mode.bind=\"model.mode\"></property-panel>\n    <div class=\"step-btns\">\n        <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"back()\">\n            ${'tw.composer.buttons.back' | t}\n        </button>\n        <button class=\"btn btn-primary\" click.trigger=\"save()\">\n            ${'tw.composer.buttons.save' | t}\n        </button>\n        <button class=\"btn btn-primary btn-primary-outline\" click.trigger=\"cancel()\">\n            ${'tw.composer.buttons.cancel' | t}\n        </button>\n    </div>\n</template>\n"; });
define('text!views/create-asset/create-asset-saved-dialog.html', ['module'], function(module) { module.exports = "<template>\n    <ai-dialog>\n        <ai-dialog-body>\n            <p if.bind=\"!error\">${'tw.composer.createAsset.assetCreatedMessage' | t}</p>\n            <p if.bind=\"error\">${error}</p>\n        </ai-dialog-body>\n\n        <ai-dialog-footer>\n            <button class=\"btn btn-primary\" click.trigger=\"dialogController.cancel()\">\n                ${'tw.composer.buttons.close' | t}\n            </button>\n        </ai-dialog-footer>\n    </ai-dialog>\n</template>\n"; });
define('text!views/create-asset/create-asset.html', ['module'], function(module) { module.exports = "<template>\n    <div class=\"tw-utl-create-asset\">\n        <div class=\"section-title\">\n            <div class=\"create-asset-icon\"></div>\n            <div class=\"create-asset-header\">\n                ${'tw.composer.createAsset.createAssetTitle' | t}\n            </div>\n        </div>\n        <div class=\"section-body\">\n            <router-view></router-view>\n        </div>\n    </div>\n</template>\n"; });
//# sourceMappingURL=app-bundle.js.map