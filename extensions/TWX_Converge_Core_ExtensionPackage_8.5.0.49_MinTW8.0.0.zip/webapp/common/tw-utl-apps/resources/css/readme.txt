This directory is for temporary styling patches. It should normally be empty.
Turn patches into fixes in the proper source file.
