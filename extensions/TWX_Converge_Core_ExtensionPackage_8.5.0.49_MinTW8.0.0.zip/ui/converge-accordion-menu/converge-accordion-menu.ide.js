TW.IDE.Widgets["converge-accordion-menu"] = function () {

    this.widgetIconUrl = function () {
        return "../Common/extensions/TWX_Converge_Core_ExtensionPackage/ui/converge-accordion-menu/converge-accordion-menu.ide.png";
    };

    this.widgetEvents = function () {
        return {
            'Clicked': { 'warnIfNotBound': true }
        };
    };

    this.widgetProperties = function () {
        return {
            'name': 'TWX Utilities Accordion Menu',
            'description': 'DO NOT USE. Custom short term widget for TWX Utilities.',
            'category': ['Data','Navigation'],
            'defaultBindingTargetProperty': 'Data',
            'supportsAutoResize': true,
            'customEditor': 'converge-accordion-menu-editor',
            'customEditorMenuText': 'Configure Menu Data to Mashup Parameters',
            'properties': {
                'Padding': {
                    'description': 'Accordion Padding',
                    'baseType': 'STRING',
                    'defaultValue': '10px'
                },
                'ConfiguredOrDataDriven': {
                    'baseType': 'STRING',
                    'description': 'You can either pre-configure the \'Menu\' to use or bind it to \'MenuData\'',
                    'defaultValue': 'configured',
                    'selectOptions': [
                        { value: 'configured', text: 'Configured' },
                        { value: 'datadriven', text: 'Data-driven' }
                    ]
                },
                'Menu': {
                    'description': 'The menu that this widget uses to display child/parent links',
                    'baseType': 'MENUNAME',
                    'warnIfNotBoundAsTarget': false
                },
                'MenuData': {
                    'description' : 'Bind to data. DataShape should be \'MenuEntry\' or one that implements similar fields.',
                    'isBindingTarget': true,
                    'baseType': 'INFOTABLE'
                },
                'Groupings': {
                    'baseType': 'STRING',
                    'description': 'No groupings, group by a field, group by a title separator.',
                    'defaultValue': 'none',
                    'selectOptions': [
                        { value: 'none', text: 'No groupings' },
                        { value: 'field', text: 'Data field' },
                        { value: 'separator', text: 'Title separator' }
                    ]
                },
                'GroupField': {
                    'description': 'Field used to look for group.',
                    'baseType': 'STRING',
                    'defaultValue': 'group'
                },
                'TitleSeparator': {
                    'description': 'Character(s) used to separate group and title in title field value. Default is hyphen (group-title).',
                    'baseType': 'STRING',
                    'defaultValue': '-'
                },
                'AreaStyle': {
                    'description': 'Define areas using AREA-TITLE for the name of menus',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLabelStyle'
                },
                'TitleStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLabelStyle'
                },
                'TitleHoverStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLabelStyle'
                },
                'ChildStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLabelStyle'
                },
                'ChildHoverStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLabelStyle'
                },
                'ChildSelectedStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLabelStyle'
                }
            }
        };
    };

    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-accordion"></div>';
        return html;
    };

    this.validate = function () {
        var result = [];

        if (this.isPropertyBoundAsTarget('MenuData')) {
            if (this.getProperty('MenuData') === undefined || this.getProperty('MenuData').length === 0) {
                result.push({ severity: 'warning', message: 'MenuData must be chosen' });
            }
        }

        return result;
    };
};
