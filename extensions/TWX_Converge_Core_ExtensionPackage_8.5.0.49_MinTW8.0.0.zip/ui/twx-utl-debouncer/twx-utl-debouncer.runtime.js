TW.Runtime.Widgets["twx-utl-debouncer"] = function () {
    var thisWidget = this;
    var timer;

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': false
        };
    };

    this.renderHtml = function () {
        var html = '';
        html = '<div class="widget-content widget-twx-utl-debouncer"></div>';
        return html;
    };

    this.afterRender = function () {
        this.jqElement.hide();
        this.jqElement.closest('.widget-bounding-box').hide();
    };

    this.serviceInvoked = function (serviceName) {
        switch (serviceName) {
            case "Debounce":
                this.startTimer();
                break;
            case "FireImmediately":
                this.fireAndClearTimer();
                break;
            case "Cancel":
                this.clearTimer();
                break;
            default:
                TW.log.error('twx-utl-debouncer widget, unexpected serviceName invoked "' + serviceName + '"');
                break;
        }
    };

    this.startTimer = function() {
        this.clearTimer();
        timer = setTimeout(function() {
            thisWidget.fireAndClearTimer();
        }, this.getProperty('TimerDuration', 500));
    };

    this.clearTimer = function () {
        if (timer) {
            clearTimeout(timer);
            timer = null;
        }
    };

    this.fireAndClearTimer = function() {
        this.clearTimer();
        thisWidget.jqElement.triggerHandler("Fired");
    };

    this.beforeDestroy = function () {
        try {
            this.clearTimer();
        } catch (err) {
            TW.log.error('Error in TW.Runtime.Widgets["twx-utl-debouncer"].beforeDestroy', err);
        }
        thisWidget = null;
    };
};


