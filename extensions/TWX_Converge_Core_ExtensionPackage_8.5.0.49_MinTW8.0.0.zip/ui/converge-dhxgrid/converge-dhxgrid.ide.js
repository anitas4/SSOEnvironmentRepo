TW.IDE.Widgets["converge-dhxgrid"] = function () {
    var columnFormatDefault = { formatInfo: [] };

    this.widgetIconUrl = function () {
        return "../Common/thingworx/widgets/dhxgrid/dhxgrid.ide.png";
    };

    this.widgetProperties = function () {
        return {
            'name': 'TWX Utilities Grid',
            'description': 'DO NOT USE. Custom short term widget for TWX Utilities.',
            'category': ['Common', 'Data'],
            'defaultBindingTargetProperty': 'Data',
	        'supportsAutoResize': true,
            'customEditor': 'GridCustomEditor',
            'customEditorMenuText': TW.IDE.I18NController.translate('tw.dhxgrid-ide.widget.custom-editor-menu-text'),
            'properties': {
                'CustomClass': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.custom-class.description'),
                    'baseType': 'STRING',
                    'isLocalizable': false,
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isVisible': false
                },
                'ColumnFormat': {
                    'isBindingTarget': true,
                    'baseType': 'JSON',
                    'default': columnFormatDefault
                },
                'RowFormat': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.row-format.description'),
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'Data'    // which property's datashape to use and require being bound in order to configure the renderer, etc.
                },
                'AlignHeader': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.align-header.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'MultiSelect': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.multi-select.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'IsEditable': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.is-editable.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'AutoSelectFirstRow': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.auto-select-first-row.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'CellTextWrapping': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.cell-text-wrapping.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'Width': {
                    'defaultValue': 400,
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.width.description')
                },
                'Height': {
                    'defaultValue': 200,
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.height.description')
                },
                'TabSequence': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.tab-sequence.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'Data': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.data.description'),
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'EditedTable': {
                    'isBindingSource': true,
                    'baseType': 'INFOTABLE',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.edited-table.description')
                },
                'CurrentScrollTop': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.current-scroll-top.description'),
                    'defaultValue': 0,
                    'isBindingSource': true,
                    'baseType': 'NUMBER'
                },
                'ScrollTop': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.scroll-top.description'),
                    'defaultValue': 0,
                    'isBindingTarget': true,
                    'baseType': 'NUMBER'
                },
                'RowHeight': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.row-height.description'),
                    'defaultValue': 30,
                    'baseType': 'NUMBER'
                },
                'ShowAllColumns': {
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.show-all-columns.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
//                'ExpandGridToShowAllRows': {
//                    'description': 'Make the grid take up all the vertical room needed to display all the rows',
//                    'defaultValue': false,
//                    'baseType': 'BOOLEAN'
//                },
//                'ExpandGridToShowAllColumns': {
//                    'description': 'Make the grid take up all the horizontal room needed to display all the columns.  Only in effect if ExpandGridToShowAllRows is checked',
//                    'defaultValue': false,
//                    'baseType': 'BOOLEAN'
//                },
                'GridBackgroundStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultGridBackgroundStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-background-style.description')
                },
                'GridEditableFieldStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultGridEditableFieldStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-editable-field-style.description')
                },
                'GridInvalidFieldStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultGridInvalidFieldStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-invalid-field-style.description')
                },
                'GridHeaderStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultGridHeaderStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-header-style.description')
                },
                'GridHeaderTextCase': {
                    'baseType': 'STRING',
                    'defaultValue': 'capitalize',
                    'selectOptions': [
                        { value: 'capitalize', text: TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-header-text-case.select-options.capitalize') },
                        { value: 'lowercase', text: TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-header-text-case.select-options.lower-case') },
                        { value: 'uppercase', text: TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-header-text-case.select-options.upper-case') },
                        { value: 'none', text: TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-header-text-case.select-options.none') }
                    ],
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.grid-header-text-case.description')
                },
                'FocusStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultFocusStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.focus-style.description')
                },
                'RowBackgroundStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRowBackgroundStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.row-background-style.description')
                },
                'RowAlternateBackgroundStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRowAlternateBackgroundStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.row-alternate-background-style.description')
                },
                'RowHoverStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRowHoverStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.row-hover-style.description')
                },
                'RowSelectedStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRowSelectedStyle',
                    'description': TW.IDE.I18NController.translate('tw.dhxgrid-ide.properties.row-selected-style.description')
                },
                'IsPrintLayout': {
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    isVisible: false //(TW.IDE.supportPrinting === true ? true : false)
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
        	'DoubleClicked': {}
        };
    };

    this.widgetServices = function () {
        return {
            'ClearData': {},
            'CheckAll': {},
            'UncheckAll': {}
        };
    };

    this.renderHtml = function () {
        var html = '';
//        html += '<div class="widget-content widget-dhxgrid"><div style="position:absolute;width:100%;height:100%;z-index:2;"></div><div class="dhxgrid-wrapper"><div class="widget-dhxgrid-outer-container"><div class="dhtmlxgrid-container" width="100%" height="100%"></div></div></div></div>';
        html += '<div class="widget-content widget-dhxgrid"></div>';
        return html;
    };

    this.afterRender = function () {
        this.beforeDestroy();

        // dhtmlxgrid needs an ID to work off of ... we will create an ID based on the ID of the widget itself and pass that to dhtmlxgrid
        var domElementIdOfDhxGrid = this.properties['Id'] + '-dhxtmlgrid';
//	    var gridTableEl = this.jqElement.find('.dhtmlxgrid-container');
	    var gridTableEl = this.jqElement;

		var formatRowBackgroundResult = TW.getStyleFromStyleDefinition(this.getProperty('RowBackgroundStyle'));
		var formatRowAlternateBackgroundResult = TW.getStyleFromStyleDefinition(this.getProperty('RowAlternateBackgroundStyle'));
		var formatRowHoverResult = TW.getStyleFromStyleDefinition(this.getProperty('RowHoverStyle'));
		var formatRowSelectedResult = TW.getStyleFromStyleDefinition(this.getProperty('RowSelectedStyle'));
		var formatGridHeaderResult = TW.getStyleFromStyleDefinition(this.getProperty('GridHeaderStyle'));
		var formatGridBackgroundResult = TW.getStyleFromStyleDefinition(this.getProperty('GridBackgroundStyle'));

		var cssRowBackground = TW.getStyleCssGradientFromStyle(formatRowBackgroundResult);
		var cssRowBackgroundText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowBackgroundResult);
		var cssRowAlternateBackground = TW.getStyleCssGradientFromStyle(formatRowAlternateBackgroundResult);
		var cssRowAlternateBackgroundText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowAlternateBackgroundResult);
		var cssRowHover = TW.getStyleCssGradientFromStyle(formatRowHoverResult);
		var cssRowHoverText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowHoverResult);
		var cssRowSelected = TW.getStyleCssGradientFromStyle(formatRowSelectedResult);
		var cssRowSelectedText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowSelectedResult);
		var cssGridHeaderBackground = TW.getStyleCssGradientFromStyle(formatGridHeaderResult);
		var cssGridHeaderText = TW.getStyleCssTextualNoBackgroundFromStyle(formatGridHeaderResult);
		var cssGridBackground = TW.getStyleCssGradientFromStyle(formatGridBackgroundResult);
		var cssGridBorder = TW.getStyleCssBorderFromStyle(formatGridBackgroundResult);

        var textSizeClass = TW.getTextSizeClassName(formatGridHeaderResult.textSize);

		var resource = TW.IDE.getMashupResource();
        var widgetStyles =
            '#' + this.properties['Id'] + '.widget-dhxgrid .dhxgrid-table-simulator {'+ cssGridBackground + '} ' +
            '#' + this.properties['Id'] + '.widget-dhxgrid .dhxgrid-table-simulator-wrapper {'+ cssGridBorder +'} ' +
            '#' + this.properties['Id'] + '.widget-dhxgrid .dhxgrid-table-simulator th {'+ cssGridHeaderBackground + cssGridBorder + '} ' +
            //'#' + this.properties['Id'] + '.widget-dhxgrid .gridbox table.obj td > div {'+ cssRowBackground + cssRowBackgroundText +'} ' +
            //'#' + this.properties['Id'] + '.widget-dhxgrid .gridbox table.obj tr.even td > div {'+ cssRowAlternateBackground + cssRowAlternateBackgroundText +'} ' +
            //'#' + this.properties['Id'] + '.widget-dhxgrid .gridbox table.obj tr:hover td > div {'+ cssRowHover + cssRowHoverText +'} ' +
            //'#' + this.properties['Id'] + '.widget-dhxgrid .gridbox table.obj tr.rowselected td > div {'+ cssRowSelected + cssRowSelectedText +'} ' +
            //'#' + this.properties['Id'] + '.widget-dhxgrid .gridbox table.hdr td { '+ cssGridHeaderBackground + ' } ' +
            '#' + this.properties['Id'] + '.widget-dhxgrid .dhxgrid-table-simulator th { '+ cssGridHeaderText +'text-transform:'+this.getProperty("GridHeaderTextCase")+'; text-shadow: none; }';
        resource.styles.append(widgetStyles);

        var colModel = [];

        var gridHeader = '';
        var gridInitWidths = '';
        var gridColAlign = '';
        var gridColTypes = '';
        var gridColSorting = '';
        var gridEnableResizing = '';
        var nColumns = 0;

        var autoWidthColumns = [];
        var colFormat = this.getProperty('ColumnFormat');


        var html = '<div class="dhxgrid-table-simulator-wrapper"><table class="dhxgrid-table-simulator">';

        if (colFormat !== undefined && colFormat.formatInfo.length > 0) {

	        html += '<tr>';

            // use the defined column formatting to format the grid identically to the runtime so it's WYSIWYG
            for (var i = 0; i < colFormat.formatInfo.length; i++) {
                var col = colFormat.formatInfo[i];

	            var addlStyle = '';
                var thisWidth = 100;
                if (col.Width === 'auto') {
	                addlStyle = ' style="width:' + (TW.IDE.convertLocalizableString(col.Title).length * 6 + 20) + 'px;" ';
                } else {
                    thisWidth = col.Width;
	                addlStyle = ' style="width:' + thisWidth + 'px;" ';
                }

	            html += '<th ' + addlStyle + '><div title="'+ TW.IDE.convertLocalizableString(Encoder.htmlEncode(col.Title)) +'">' + TW.IDE.convertLocalizableString(Encoder.htmlEncode(col.Title)) + '</div></th>';

                nColumns++;
            }

	        html += '</tr>';
        } else {
	        html += '<tr><th>'+ TW.IDE.I18NController.translate('tw.dhxgrid-ide.must-be-bound-to-data') +'</th></tr>';
        }

        html += '</table></div>';

	    gridTableEl.html(html);
        this.jqElement.find('table.dhxgrid-table-simulator th').addClass(textSizeClass);

	    // if print layout mashup and we're responsive, let the user know that we'll spread it across pages
	    try {
		    if( $('.widget-mashup').hasClass('is-print-mashup') && this.jqElement.closest('.widget-bounding-box').hasClass('responsive') ) {
			    $(this.jqElement.find('.dhxgrid-table-simulator').children()[0]).append('<tr class="notify-user-print-grid"><td class="td-for-print-message" colspan="' + (nColumns <= 1 ? 1 : nColumns) + '"><div class="actual-message"><span>'+ TW.IDE.I18NController.translate('tw.dhxgrid-ide.print-layout-message') +'</span></div></td></tr>')
		    }
	    } catch(err) {}
    };

	this.getSourceDatashape = function(propertyName) {
        var infoTableDataShape = this.getInfotableMetadataForProperty('Data');
		return infoTableDataShape;
	};

    // afterAddBindingSource is called immediately after the user adds a binding source to your object
    this.afterAddBindingSource = function (bindingInfo) {
        if (bindingInfo['targetProperty'] === 'ColumnFormat') {
            this.setProperty('ColumnFormat', columnFormatDefault);
        }
        if (bindingInfo['targetProperty'] === 'Data') {

            // get the infoTableDataShape associated with this property
            var infoTableDataShape = this.getInfotableMetadataForProperty('Data');

            var resetColumnFormat = true;

            var curColFormat = this.getProperty('ColumnFormat');
            if (curColFormat !== undefined && curColFormat.formatInfo !== undefined && curColFormat.formatInfo.length > 0 && infoTableDataShape !== undefined) {
                // see if we have column format that's worth trying to save

                resetColumnFormat = false;
                for (var i = 0; i < curColFormat.formatInfo.length && !resetColumnFormat; i++) {
                    var curFld = curColFormat.formatInfo[i];
                    var curFldName = curFld.FieldName;
                    var found = false;
                    for (var fieldName in infoTableDataShape) {
                        if (fieldName === curFldName) {
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        // field not found ... blow off the format
                        resetColumnFormat = true;
                    }
                }

            }

            if (resetColumnFormat) {
                // start out resetting the ColumnFormat ... i.e. delete anything that's already there
                this.setProperty('ColumnFormat', columnFormatDefault);

                if (infoTableDataShape !== undefined) {
                    var sortedDataShape;
                    sortedDataShape = _.sortBy(infoTableDataShape, function(val, key, obj){
                        return val['name'].toLowerCase();
                    });
                    sortedDataShape = _.sortBy(sortedDataShape, function(val, key, obj){
                        return (val['ordinal'] || 0);
                    });
                    // build the ColumnFormat based on that DataShape
                    var colFormat = _clone(columnFormatDefault);
                    _.each(sortedDataShape, function(fieldDef, key, list){
                        var thisColumnFormatInfo = {
                            FieldName: fieldDef.name,
                            Title: fieldDef.name,
                            Width: "auto",
                            AllowEdit: false,
                            ValidationExpression : "",
                            ValidationMessage : "",
                            Align: "left",
                            "FormatOptions": {
                                renderer: "STRING"
                            }
                        };

                        // if you update this, also update dhxgrid.runtime.js to update the defaults at runtime
                        switch (fieldDef.baseType) {
                            case 'DATETIME':
                                thisColumnFormatInfo.FormatOptions.renderer = 'DATETIME';
                                break;
                            case 'LOCATION':
                                thisColumnFormatInfo.FormatOptions.renderer = 'LOCATION';
                                break;
                            case 'TAGS':
                                thisColumnFormatInfo.FormatOptions.renderer = 'TAGS';
                                break;
                            case 'HYPERLINK':
                                thisColumnFormatInfo.FormatOptions.renderer = 'HYPERLINK';
                                break;
                            case 'IMAGELINK':
                                thisColumnFormatInfo.FormatOptions.renderer = 'IMAGELINK';
                                break;
                            case 'IMAGE':
                                thisColumnFormatInfo.FormatOptions.renderer = 'IMAGE';
                                break;
                            case "NUMBER":
                                thisColumnFormatInfo.FormatOptions.renderer = 'NUMBER';
                                thisColumnFormatInfo.Align = 'right';
                                break;
                            case "STRING":
                                thisColumnFormatInfo.FormatOptions.renderer = 'STRING';
                                break;
                            case "BOOLEAN":
                                thisColumnFormatInfo.FormatOptions.renderer = 'BOOLEAN';
                                break;
                            case "THINGNAME":
                                thisColumnFormatInfo.FormatOptions.renderer = 'THINGNAME';
                                break;
                            case "THINGSHAPENAME":
                                thisColumnFormatInfo.FormatOptions.renderer = 'THINGSHAPENAME';
                                break;
                            case "THINGTEMPLATENAME":
                                thisColumnFormatInfo.FormatOptions.renderer = 'THINGTEMPLATENAME';
                                break;
                            case "MASHUPNAME":
                                thisColumnFormatInfo.FormatOptions.renderer = 'STRING';
                                break;
                            case "USERNAME":
                                thisColumnFormatInfo.FormatOptions.renderer = 'USERNAME';
                                break;
                            case "THINGCODE":
                                thisColumnFormatInfo.FormatOptions.renderer = 'THINGCODE';
                                break;
                            case "VEC2":
                                thisColumnFormatInfo.FormatOptions.renderer = 'VEC2';
                                break;
                            case "VEC3":
                                thisColumnFormatInfo.FormatOptions.renderer = 'VEC3';
                                break;
                            case "VEC4":
                                thisColumnFormatInfo.FormatOptions.renderer = 'VEC4';
                                break;
                            default:
                                thisColumnFormatInfo.FormatOptions.renderer = 'DEFAULT';
                        }
                        if (TW.Renderer[thisColumnFormatInfo.FormatOptions.renderer].defaultFormat !== undefined) {
                            thisColumnFormatInfo.FormatOptions.FormatString = TW.Renderer[thisColumnFormatInfo.FormatOptions.renderer].defaultFormat;
                        }
                        colFormat.formatInfo.push(thisColumnFormatInfo);
                    });

                    // set the ColumnFormat property based on this InfoTableShape
                    this.setProperty('ColumnFormat', colFormat);
                }
            }
        }
        return true;
    };

    // called whenever any property is set ... return true if we want to be re-rendered based on the change
    this.afterSetProperty = function (name, value) {

        var result = false;
        switch (name) {
            case 'Width':
			case 'Height':
			case 'ColumnFormat':
			case 'GridHeaderStyle':
			case 'RowBackgroundStyle':
			case 'RowAlternateBackgroundStyle':
			case 'RowHoverStyle':
			case 'RowSelectedStyle':
			case 'GridBackgroundStyle':
			case 'GridHeaderTextCase':
                result = true;
                break;
            default:
                break;
        }
        return result;

    };

    this.beforeDestroy = function () {
    };

    return this;
};
