gaRequire.require.config({
    baseUrl: '../Common/extensions/grid-advanced_ExtensionPackage/ui/gridadvanced/include'
});
TW.Runtime.Widgets.treegridadvanced.getWidgetStyleDict = function() {
    return [
        {
            class:  '.widget-gridadvanced',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        'border-width':                 '${treegrid-borderthickness}',
                        'border-color':                 '${treegrid-bordercolor}',
                        'border-style':                 'solid'
                    }
                }
            ]
        },
        {
            class:  '.objbox',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:                     '${gridBackgroundColor}'
                    }
                }
            ]
        },
        {
            class:  '.xhdr table tbody tr td',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        color:                          '${treegrid-header-label-fontcolor}',
                        background :                    '${treegrid-header-backgroundcolor}',
                        'text-transform':               '${treegrid-header-label-fontstyle}',
                        'font-style':                   '${font-style-cond(treegrid-header-label-fontstyle)}',
                        'font-weight':                  '${treegrid-header-label-fontweight}',
                        'font-family':                  '${treegrid-header-label-fontfamily}',
                        'font-size':                    '${treegrid-header-label-fontsize}',
                        'text-decoration':              '${text-decoration-cond(treegrid-header-label-fontstyle)}',
                        'border-color':                 '${treegrid-header-divider-color}',
                        'border-width':                 '${treegrid-header-divider-thickness}',
                        'border-style':                 '${treegrid-header-divider-style}'
                    }
                }
            ]
        },
        {
            class:  '.xhdr',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background :                    '${treegrid-header-backgroundcolor}'
                    }
                }
            ]
        },
        {
            class:  '.top-container',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:                     '${toolbar-backgroundcolor}',
                        filter:                         'none',
                        'border-color':                 '${toolbar-bordercolor}',
                        'border-style':                 'solid',
                        'border-width':                 '${toolbar-borderthickness}'
                    }
                }
            ]
        },
        {
            class:  '.bottom-container',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:                     '${toolbar-backgroundcolor}',
                        filter:                         'none',
                        'border-color':                 '${toolbar-bordercolor}',
                        'border-style':                 'solid',
                        'border-width':                 '${toolbar-borderthickness}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr td .treegrid_cell img:nth-last-child(2)',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        width:                          '${icon-width}',
                        height:                         '${icon-height}',
                        background:                     '${icon-color}',
                        'box-sizing':                   'border-box',
                        'padding-left':                 '${icon-width}',
                        'background-size':              '${icon-width} ${icon-width}',
                        'background-repeat':            'no-repeat',
                        'margin-top':                   '1px'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr td .treegrid_cell img.grid_collapse_icon[src*="minus.gif"]',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        width:                          '${icon-width}',
                        height:                         '${icon-height}',
                        background:                     '${icon-color}',
                        'box-sizing':                   'border-box',
                        'padding-left':                 '${icon-width}',
                        'background-size':              '${icon-width} ${icon-width}',
                        'background-repeat':            'no-repeat',
                        'margin-top':                   '1px'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr td .treegrid_cell img.grid_collapse_icon[src*="plus.gif"]',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        width:                          '${icon-width}',
                        height:                         '${icon-height}',
                        background:                     '${icon-color}',
                        'box-sizing':                   'border-box',
                        'padding-left':                 '${icon-width}',
                        'background-size':              '${icon-width} ${icon-width}',
                        'background-repeat':            'no-repeat',
                        'margin-top':                   '1px'
                    }
                }
            ]
        },
        {
            class:  '.objbox table.obj tbody tr td',
            states:
            [
                {
                    state:  '',
                    styles: {
                        color:                          '${treegrid-cell-text-fontcolor}',
                        background:                     '${treegrid-cell-backgroundcolor}',
                        filter:                         'none',
                        'text-align':                   '${treegrid-cell-text-text-alignment}',
                        'font-weight':                  '${treegrid-cell-text-fontweight}',
                        'font-style':                   '${font-style-cond(treegrid-cell-text-fontstyle)}',
                        'text-decoration':              '${text-decoration-cond(treegrid-cell-text-fontstyle)}',
                        'font-size':                    '${treegrid-cell-text-fontsize}',
                        'font-family':                  '${treegrid-cell-text-fontfamily}',
                        'border-width':                 '${treegrid-cell-borderthickness}',
                        'border-color':                 '${treegrid-cell-bordercolor}',
                        'border-style':                 '${treegrid-cell-border-style}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.odd_material',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background:                     '${if(treegrid-row-backgroundcolor-usealternating, treegrid-row-backgroundcolor-alt, treegrid-row-backgroundcolor)}',
                        'border-width':                 '${alternateRowActiveBorderThickness}',
                        'border-color':                 '${alternateRowActiveBorderColor}',
                        'border-style':                 '${alternateRowActiveBorderStyle}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.ev_material',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background:                     '${treegrid-row-backgroundcolor}',
                        'border-width':                 '${rowActiveBorderThickness}',
                        'border-color':                 '${rowActiveBorderColor}',
                        'border-style':                 '${rowActiveBorderStyle}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.ev_material td.grid_hover',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background:                     '${treegrid-row-backgroundcolor-hover}',
                        filter:                         'none',
                        color:                          '${treegrid-cell-text-fontcolor-hover}',
                        'text-align':                   '${treegrid-cell-text-text-alignment-hover}',
                        'font-weight':                  '${treegrid-cell-text-fontweight-hover}',
                        'font-style':                   '${font-style-cond(treegrid-cell-text-fontstyle-hover)}',
                        'text-decoration':              '${text-decoration-cond(treegrid-cell-text-fontstyle-hover)}',
                        'font-size':                    '${treegrid-cell-text-fontsize-hover}',
                        'font-family':                  '${treegrid-cell-text-fontfamily-hover}',
                        'border-width':                 '${treegrid-cell-borderthickness-hover}',
                        'border-color':                 '${treegrid-cell-bordercolor-hover}',
                        'border-style':                 '${treegrid-cell-border-style-hover}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.ev_material.rowselected td',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background:                     '${treegrid-row-backgroundcolor-selected}',
                        filter:                         'none',
                        color:                          '${treegrid-cell-text-fontcolor-selected}',
                        'text-align':                   '${treegrid-cell-text-text-alignment-selected}',
                        'font-weight':                  '${treegrid-cell-text-fontweight-selected}',
                        'font-style':                   '${font-style-cond(treegrid-cell-text-fontstyle-selected)}',
                        'text-decoration':              '${text-decoration-cond(treegrid-cell-text-fontstyle-selected)}',
                        'font-size':                    '${treegrid-cell-text-fontsize-selected}',
                        'font-family':                  '${treegrid-cell-text-fontfamily-selected}',
                        'border-width':                 '${treegrid-cell-borderthickness-selected}',
                        'border-color':                 '${treegrid-cell-bordercolor-selected}',
                        'border-style':                 '${treegrid-cell-border-style-selected}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.odd_material td.grid_hover',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background:                     '${treegrid-row-backgroundcolor-alt-hover}',
                        filter:                         'none',
                        color:                          '${treegrid-cell-text-fontcolor-hover}',
                        'text-align':                   '${treegrid-cell-text-text-alignment-hover}',
                        'font-weight':                  '${treegrid-cell-text-fontweight-hover}',
                        'font-style':                   '${font-style-cond(treegrid-cell-text-fontstyle-hover)}',
                        'text-decoration':              '${text-decoration-cond(treegrid-cell-text-fontstyle-hover)}',
                        'font-size':                    '${treegrid-cell-text-fontsize-hover}',
                        'font-family':                  '${treegrid-cell-text-fontfamily-hover}',
                        'border-width':                 '${treegrid-cell-borderthickness-hover}',
                        'border-color':                 '${treegrid-cell-bordercolor-hover}',
                        'border-style':                 '${treegrid-cell-border-style-hover}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.odd_material.rowselected td',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background:                     '${treegrid-row-backgroundcolor-alt-selected}',
                        filter:                         'none',
                        color:                          '${treegrid-cell-text-fontcolor-selected}',
                        'text-align':                   '${treegrid-cell-text-text-alignment-selected}',
                        'font-weight':                  '${treegrid-cell-text-fontweight-selected}',
                        'font-style':                   '${font-style-cond(treegrid-cell-text-fontstyle-selected)}',
                        'text-decoration':              '${text-decoration-cond(treegrid-cell-text-fontstyle-selected)}',
                        'font-size':                    '${treegrid-cell-text-fontsize-selected}',
                        'font-family':                  '${treegrid-cell-text-fontfamily-selected}',
                        'border-width':                 '${treegrid-cell-borderthickness-selected}',
                        'border-color':                 '${treegrid-cell-bordercolor-selected}',
                        'border-style':                 '${treegrid-cell-border-style-selected}'
                    }
                }
            ]
        },
        {
            class:  '#tiptip_content',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background:                     '${tooltip-backgroundcolor}',
                        filter:                         'none',
                        'border-width':                 '1px',
                        'border-color':                 '${tooltip-bordercolor}',
                        'border-style':                 'solid',
                        color:                          '${tooltip-text-color}',
                        'font-weight':                  '${tooltip-text-fontweight}',
                        'font-style':                   '${font-style-cond(tooltip-text-fontstyle)}',
                        'text-decoration':              '${text-decoration-cond(tooltip-text-fontstyle)}',
                        'font-size':                    '${tooltip-text-fontsize}'
                    }
                }
            ]
        },
        {
            class:  '#tiptip_arrow_inner',
            states:
            [
                {
                    state:  '',
                    styles: {
                        'border-color':          '${tooltip-box-shadow}'
                    }
                }
            ]
        },
        //Button Active
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_def',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor}',
                        'border-color':                 '${button-transparent-bordercolor}',
                        'border-width':                 '${button-transparent-borderthickness}',
                        'border-style':                 '${button-transparent-border-style}',
                        'border-radius':                '${button-transparent-radius}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_def div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor}',
                        color:                          '${button-transparent-text-color}',
                        'font-family':                  '${button-transparent-fontfamily}',
                        'font-size':                    '${button-transparent-fontsize}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle)}',
                        'font-weight':                  '${button-transparent-fontweight}',
                        'line-height':                  '32px',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonActiveLabelBorderColor}',
                        'border-width':                 '${buttonActiveLabelBorderThickness}',
                        'border-style':                 '${buttonActiveLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        //Button Hover
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_over',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor-hover}',
                        'border-color':                 '${button-transparent-bordercolor-hover}',
                        'border-width':                 '${button-transparent-borderthickness-hover}',
                        'border-style':                 '${button-transparent-border-style-hover}',
                        'border-radius':                '${button-transparent-radius-hover}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_over div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor-hover}',
                        color:                          '${button-transparent-text-color-hover}',
                        'font-family':                  '${button-transparent-fontfamily-hover}',
                        'font-size':                    '${button-transparent-fontsize-hover}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle-hover)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle-hover)}',
                        'font-weight':                  '${button-transparent-fontweight-hover}',
                        'line-height':                  '32px',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonHoverLabelBorderColor}',
                        'border-width':                 '${buttonHoverLabelBorderThickness}',
                        'border-style':                 '${buttonHoverLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        //Button Selected
        /*
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor-selected}',
                        'border-color':                 '${button-transparent-bordercolor-selected}',
                        'border-width':                 '${button-transparent-borderthickness-selected}',
                        'border-style':                 '${button-transparent-border-style-selected}',
                        'border-radius':                '${button-transparent-radius-selected}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn  div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor-selected}',
                        color:                          '${button-transparent-text-color-selected}',
                        'font-family':                  '${button-transparent-fontfamily-selected}',
                        'font-size':                    '${button-transparent-fontsize-selected}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle-selected)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle-selected)}',
                        'font-weight':                  '${button-transparent-fontweight-selected}',
                        'line-height':                  '32px',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonSelectedLabelBorderColor}',
                        'border-width':                 '${buttonSelectedLabelBorderThickness}',
                        'border-style':                 '${buttonSelectedLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        */
        //Button Pressed
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_pres',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor-pressed}',
                        'border-color':                 '${button-transparent-bordercolor-pressed}',
                        'border-width':                 '${button-transparent-borderthickness-pressed}',
                        'border-style':                 '${button-transparent-border-style-pressed}',
                        'border-radius':                '${button-transparent-radius-pressed}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_pres div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor-pressed}',
                        color:                          '${button-transparent-text-color-pressed}',
                        'font-family':                  '${button-transparent-fontfamily-pressed}',
                        'font-size':                    '${button-transparent-fontsize-pressed}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle-pressed)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle-pressed)}',
                        'font-weight':                  '${button-transparent-fontweight-pressed}',
                        'line-height':                  '32px',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonPressedLabelBorderColor}',
                        'border-width':                 '${buttonPressedLabelBorderThickness}',
                        'border-style':                 '${buttonPressedLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        //Button Disabled
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_dis',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor-disabled}',
                        'border-color':                 '${button-transparent-bordercolor-disabled}',
                        'border-width':                 '${button-transparent-borderthickness-disabled}',
                        'border-style':                 '${button-transparent-border-style-disabled}',
                        'border-radius':                '${button-transparent-radius-disabled}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_dis div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor-disabled}',
                        color:                          '${button-transparent-text-color-disabled}',
                        'font-family':                  '${button-transparent-fontfamily-disabled}',
                        'font-size':                    '${button-transparent-fontsize-disabled}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle-disabled)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle-disabled)}',
                        'font-weight':                  '${button-transparent-fontweight-disabled}',
                        'line-height':                  '32px',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonDisabledLabelBorderColor}',
                        'border-width':                 '${buttonDisabledLabelBorderThickness}',
                        'border-style':                 '${buttonDisabledLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-search-theming div.dhx_toolbar_btn.dhxtoolbar_btn_def input.dhxtoolbar_input',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        color:              '${textfield-field-text-color}',
                        background:         '${textfield-field-backgroundcolor}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily}',
                        'font-size':        '${textfield-field-fontsize}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle)}',
                        'font-weight':      '${textfield-field-fontweight}',
                        'line-height':      '${searchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor}',
                        'border-width':     '${textfield-field-borderthickness}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                },
                {
                    state:  'hover',
                    styles:
                    {
                        color:              '${textfield-field-text-color-hover}',
                        background:         '${textfield-field-backgroundcolor-hover}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily-hover}',
                        'font-size':        '${textfield-field-fontsize-hover}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle-hover)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle-hover)}',
                        'font-weight':      '${textfield-field-fontweight-hover}',
                        'line-height':      '${hoverSearchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor-hover}',
                        'border-width':     '${textfield-field-borderthickness-hover}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                },
                {
                    state:  'active',
                    styles:
                    {
                        color:              '${textfield-field-text-color-pressed}',
                        background:         '${textfield-field-backgroundcolor-pressed}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily-pressed}',
                        'font-size':        '${textfield-field-fontsize-pressed}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle-pressed)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle-pressed)}',
                        'font-weight':      '${textfield-field-fontweight-pressed}',
                        'line-height':      '${pressedSearchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor-pressed}',
                        'border-width':     '${textfield-field-borderthickness-pressed}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                },
                {
                    state:  'disabled',
                    styles:
                    {
                        color:              '${textfield-field-text-color-disabled}',
                        background:         '${textfield-field-backgroundcolor-disabled}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily-disabled}',
                        'font-size':        '${textfield-field-fontsize-disabled}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle-disabled)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle-disabled)}',
                        'font-weight':      '${textfield-field-fontweight-disabled}',
                        'line-height':      '${disabledSearchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor-disabled}',
                        'border-width':     '${textfield-field-borderthickness-disabled}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                }
            ]
        },
        //Search Label
        {
            class:  '.toolbar-search-theming div.dhx_toolbar_text',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        color:              '${textfield-text-label-color}',
                        background:         '${label-backgroundcolor}',
                        filter:             'none',
                        'font-family':      '${textfield-text-label-fontfamily}',
                        'font-size':        '${textfield-text-label-fontsize}',
                        'font-style':       '${font-style-cond(textfield-text-label-fontstyle)}',
                        'text-decoration':  '${text-decoration-cond(textfield-text-label-fontstyle)}',
                        'font-weight':      '${textfield-text-label-fontweight}',
                        'line-height':      '32px',
                        'letter-spacing':   '${label-letterspacing}',
                        'text-align':       '${label-alignment}',
                        'border-color':     '${label-bordercolor}',
                        'border-width':     '${label-borderthickness}',
                        'border-style':     '${label-border-style}'
                    }
                }
            ]
        }
    ];
};

TW.Runtime.Widgets.treegridadvanced.getDefaultWidgetStyleFlat = function() {
    return {
        //grid
        gridBackgroundColor:                                        'transparent',
        'treegrid-bordercolor':                                     '#D8DBDE',
        'treegrid-borderthickness':                                 '1px',

        //header
        'treegrid-header-label-fontsize':                           '11px',
        'treegrid-header-label-fontstyle':                          'uppercase',
        'treegrid-header-label-fontweight':                         'bold',
        'treegrid-header-label-fontfamily':                         'helvetica, arial',
        'treegrid-header-label-fontcolor':                          '#6E717C',
        'treegrid-header-backgroundcolor':                          '#202020',
        'treegrid-header-divider-color':                            '#FFFFFF',
        'treegrid-header-divider-thickness':                        '1px',
        'treegrid-header-divider-style':                            'solid',

        //toolbar
        'toolbar-backgroundcolor':                                  '#F7F7F7',
        'toolbar-bordercolor':                                      '#DFDFDF',
        'toolbar-borderthickness':                                  '1px',

        //icon
        'icon-width':                                               '18px',
        'icon-height':                                              '18px',
        'icon-color':                                               '',

        //row
        'treegrid-row-backgroundcolor':                             '#FFFFFF',
        rowActiveBorderColor:                                       '#DDDDDD',
        rowActiveBorderThickness:                                   '1px',
        rowActiveBorderStyle:                                       'solid',
        'treegrid-row-backgroundcolor-hover':                       '#F7F7F7',
        'treegrid-row-backgroundcolor-selected':                    '#EAF6FF',

        //alternateRow
        'treegrid-row-backgroundcolor-alt':                         '#F5F5F5',
        alternateRowActiveBorderColor:                              '#DDDDDD',
        alternateRowActiveBorderThickness:                          '1px',
        alternateRowActiveBorderStyle:                              'solid',
        'treegrid-row-backgroundcolor-alt-hover':                   '#F7F7F7',
        'treegrid-row-backgroundcolor-alt-selected':                '#EAF6FF',

        //cell
        'treegrid-cell-backgroundcolor':                            '',
        'treegrid-cell-bordercolor':                                '',
        'treegrid-cell-borderthickness':                            '1px',
        'treegrid-cell-border-style':                               'solid',
        'treegrid-cell-text-fontfamily':                            'Roboto, Arial, Helvetica',
        'treegrid-cell-text-fontsize':                              '11px',
        'treegrid-cell-text-fontstyle':                             'normal',
        'treegrid-cell-text-fontweight':                            'normal',
        'treegrid-cell-text-fontcolor':                             '#232B2D',
        'treegrid-cell-text-text-alignment':                        '',
        'treegrid-cell-bordercolor-hover':                          '',
        'treegrid-cell-borderthickness-hover':                      '1px',
        'treegrid-cell-border-style-hover':                         'solid',
        'treegrid-cell-text-fontfamily-hover':                      'Roboto, Arial, Helvetica',
        'treegrid-cell-text-fontsize-hover':                        '11px',
        'treegrid-cell-text-fontstyle-hover':                       'normal',
        'treegrid-cell-text-fontweight-hover':                      'bold',
        'treegrid-cell-text-fontcolor-hover':                       '#232B2D',
        'treegrid-cell-text-text-alignment-hover':                  '',
        'treegrid-cell-bordercolor-selected':                       '',
        'treegrid-cell-borderthickness-selected':                   '1px',
        'treegrid-cell-border-style-selected':                      'solid',
        'treegrid-cell-text-fontfamily-selected':                   'Roboto, Arial, Helvetica',
        'treegrid-cell-text-fontsize-selected':                     '11px',
        'treegrid-cell-text-fontstyle-selected':                    'normal',
        'treegrid-cell-text-fontweight-selected':                   'bold',
        'treegrid-cell-text-fontcolor-selected':                    '#232B2D',
        'treegrid-cell-text-text-alignment-selected':               '',

        //tooltip
        'tooltip-backgroundcolor':                                  '#E6E8EA',
        'tooltip-bordercolor':                                      '#C2C7CE',
        'tooltip-text-fontfamily':                                  '',
        'tooltip-text-fontsize':                                    '11px',
        'tooltip-text-fontstyle':                                   'normal',
        'tooltip-text-color':                                       '#232B2D',
        'tooltip-text-fontweight':                                  'normal',
        'tooltip-height':                                           '',
        'tooltip-width':                                            '',
        'tooltip-text-linespacing':                                 '',
        'tooltip-text-letterspacing':                               '',
        'tooltip-box-shadow':                                       '0px 2px 4px 0px #000000',

        //Button Active
        'button-transparent-backgroundcolor':                       'transparent',
        'button-transparent-bordercolor':                           '#FAFAFA',
        'button-transparent-borderthickness':                       '0 1px 0 1px',
        'button-transparent-border-style':                          'solid',
        'button-transparent-radius':                                '0px',
        'button-transparent-width':                                 '',
        'button-transparent-height':                                '32px',
        'button-transparent-padding':                               '0 5px',
        'button-transparent-alignment':                             '',
        'button-transparent-text-backgroundcolor':                  'inherit',
        'button-transparent-text-color':                            '#6E717C',
        'button-transparent-fontfamily':                            'inherit',
        'button-transparent-fontsize':                              'inherit',
        'button-transparent-fontstyle':                             'inherit',
        'button-transparent-fontweight':                            'inherit',
        'button-transparent-linespacing':                           '32px',
        'button-transparent-letterspacing':                         '',
        'button-transparent-text-alignment':                        'center',
        buttonActiveLabelBorderColor:                               '',
        buttonActiveLabelBorderThickness:                           '',
        buttonActiveLabelBorderStyle:                               '',

        //Button Hover
        'button-transparent-backgroundcolor-hover':                 '#236192',
        'button-transparent-bordercolor-hover':                     '#EBEBEB',
        'button-transparent-borderthickness-hover':                 '0 1px 0 1px',
        'button-transparent-border-style-hover':                    'solid',
        'button-transparent-radius-hover':                          '0px',
        buttonHoverWidth:                                           '',
        buttonHoverHeight:                                          '32px',
        buttonHoverPadding:                                         '0 5px',
        buttonHoverAlignment:                                       '',
        'button-transparent-text-backgroundcolor-hover':            'inherit',
        'button-transparent-text-color-hover':                      '#FFFFFF',
        'button-transparent-fontfamily-hover':                      'inherit',
        'button-transparent-fontsize-hover':                        'inherit',
        'button-transparent-fontstyle-hover':                       'inherit',
        'button-transparent-fontweight-hover':                      'inherit',
        buttonHoverLabelLineSpacing:                                '32px',
        buttonHoverLabelLetterSpacing:                              '',
        buttonHoverLabelTextAlignment:                              'center',
        buttonHoverLabelBorderColor:                                '',
        buttonHoverLabelBorderThickness:                            '',
        buttonHoverLabelBorderStyle:                                '',

        //Button Selected
        // 'button-transparent-backgroundcolor-selected':           '#0094C8',
        // 'button-transparent-bordercolor-selected':               '#D2D2D2',
        // 'button-transparent-borderthickness-selected':           '0 1px 0 1px',
        // 'button-transparent-border-style-selected':              'solid',
        // 'button-transparent-radius-selected':                    '0px',
        // buttonSelectedWidth:                                     '',
        // buttonSelectedHeight:                                    '32px',
        // buttonSelectedPadding:                                   '0 5px',
        // buttonSelectedAlignment:                                 '',
        // 'button-transparent-text-backgroundcolor-selected':      'inherit',
        // 'button-transparent-text-color-selected':                '#FFFFFF',
        // 'button-transparent-fontfamily-selected':                'inherit',
        // 'button-transparent-fontsize-selected':                  'inherit',
        // 'button-transparent-fontstyle-selected':                 'inherit',
        // 'button-transparent-fontweight-selected':                'inherit',
        // buttonSelectedLabelLineSpacing:                          '32px',
        // buttonSelectedLabelLetterSpacing:                        '',
        // buttonSelectedLabelTextAlignment:                        'center',
        // buttonSelectedLabelBorderColor:                          '',
        // buttonSelectedLabelBorderThickness:                      '',
        // buttonSelectedLabelBorderStyle:                          '',

        //Button Pressed
        'button-transparent-backgroundcolor-pressed':               '#005878',
        'button-transparent-bordercolor-pressed':                   '#D2D2D2',
        'button-transparent-borderthickness-pressed':               '0 1px 0 1px',
        'button-transparent-border-style-pressed':                  'solid',
        'button-transparent-radius-pressed':                        '0px',
        buttonPressedWidth:                                         '',
        buttonPressedHeight:                                        '32px',
        buttonPressedPadding:                                       '0 5px',
        buttonPressedAlignment:                                     '',
        'button-transparent-text-backgroundcolor-pressed':          'inherit',
        'button-transparent-text-color-pressed':                    '#FFFFFF',
        'button-transparent-fontfamily-pressed':                    'inherit',
        'button-transparent-fontsize-pressed':                      'inherit',
        'button-transparent-fontstyle-pressed':                     'inherit',
        'button-transparent-fontweight-pressed':                    'inherit',
        buttonPressedLabelLineSpacing:                              '32px',
        buttonPressedLabelLetterSpacing:                            '',
        buttonPressedLabelTextAlignment:                            'center',
        buttonPressedLabelBorderColor:                              '',
        buttonPressedLabelBorderThickness:                          '',
        buttonPressedLabelBorderStyle:                              '',

        //Button Disabled
        'button-transparent-backgroundcolor-disabled':              'transparent',
        'button-transparent-bordercolor-disabled':                  '#FAFAFA',
        'button-transparent-borderthickness-disabled':              '0px',
        'button-transparent-border-style-disabled':                 'solid',
        'button-transparent-radius-disabled':                       '0px',
        buttonDisabledWidth:                                        '',
        buttonDisabledHeight:                                       '32px',
        buttonDisabledPadding:                                      '0 5px',
        buttonDisabledAlignment:                                    '',
        'button-transparent-text-backgroundcolor-disabled':         'inherit',
        'button-transparent-text-color-disabled':                   '#adb5bd',
        'button-transparent-fontfamily-disabled':                   'inherit',
        'button-transparent-fontsize-disabled':                     'inherit',
        'button-transparent-fontstyle-disabled':                    'inherit',
        'button-transparent-fontweight-disabled':                   'inherit',
        buttonDisabledLabelLineSpacing:                             '32px',
        buttonDisabledLabelLetterSpacing:                           '',
        buttonDisabledLabelTextAlignment:                           'center',
        buttonDisabledLabelBorderColor:                             '',
        buttonDisabledLabelBorderThickness:                         '',
        buttonDisabledLabelBorderStyle:                             '',

        //Search Active
        'textfield-field-text-color':                               '#404040',
        'textfield-field-fontfamily':                               'Roboto,Arial,Helvetica',
        'textfield-field-fontsize':                                 '14px',
        'textfield-field-fontstyle':                                '',
        'textfield-field-fontweight':                               '',
        'textfield-field-letterspacing':                            '',
        searchFieldLineSpacing:                                     'normal',
        'textfield-field-alignment':                                '',
        'textfield-field-borderthickness':                          '1px',
        'textfield-field-bordercolor':                              '#DFDFDF',
        'textfield-field-border-style':                             'solid',
        'textfield-field-backgroundcolor':                          '#FFFFFF',

        //Search Hover
        'textfield-field-text-color-hover':                         '#404040',
        'textfield-field-fontfamily-hover':                         'Roboto,Arial,Helvetica',
        'textfield-field-fontsize-hover':                           '14px',
        'textfield-field-fontstyle-hover':                          '',
        'textfield-field-fontweight-hover':                         '',
        hoverSearchFieldLetterSpacing:                              '',
        hoverSearchFieldLineSpacing:                                'normal',
        hoverSearchFieldTextAlignment:                              '',
        'textfield-field-borderthickness-hover':                    '1px',
        'textfield-field-bordercolor-hover':                        '#DFDFDF',
        hoverSearchFieldBorderStyle:                                'solid',
        'textfield-field-backgroundcolor-hover':                    '#FFFFFF',

        //Search Pressed
        'textfield-field-text-color-pressed':                       '#404040',
        'textfield-field-fontfamily-pressed':                       'Roboto,Arial,Helvetica',
        'textfield-field-fontsize-pressed':                         '14px',
        'textfield-field-fontstyle-pressed':                        '',
        'textfield-field-fontweight-pressed':                       '',
        pressedSearchFieldLetterSpacing:                            '',
        pressedSearchFieldLineSpacing:                              'normal',
        pressedSearchFieldTextAlignment:                            '',
        'textfield-field-borderthickness-pressed':                  '1px',
        'textfield-field-bordercolor-pressed':                      '#DFDFDF',
        pressedSearchFieldBorderStyle:                              'solid',
        'textfield-field-backgroundcolor-pressed':                  '#FFFFFF',

        //Search Disabled
        'textfield-field-text-color-disabled':                      '#404040',
        'textfield-field-fontfamily-disabled':                      'Roboto,Arial,Helvetica',
        'textfield-field-fontsize-disabled':                        '14px',
        'textfield-field-fontstyle-disabled':                       '',
        'textfield-field-fontweight-disabled':                      '',
        disabledSearchFieldLetterSpacing:                           '',
        disabledSearchFieldLineSpacing:  	                        'normal',
        disabledSearchFieldTextAlignment:                           '',
        'textfield-field-borderthickness-disabled':  		        '1px',
        'textfield-field-bordercolor-disabled':  		            '#DFDFDF',
        disabledSearchFieldBorderStyle:  		                    'solid',
        'textfield-field-backgroundcolor-disabled':                 '#FFFFFF',

        //Search Label Active
        'textfield-text-label-color':                               '#232B2D',
        'textfield-text-label-fontfamily':                          'inherit',
        'textfield-text-label-fontsize':                            'inherit',
        'textfield-text-label-fontstyle':                           'inherit',
        'textfield-text-label-fontweight':                          'inherit',
        'label-letterspacing':                                      '',
        'label-linespacing':                                        '32px',
        'label-alignment':                                          '',
        'label-borderthickness':                                    '',
        'label-bordercolor':                                        '',
        'label-border-style':                                       '',
        'label-backgroundcolor':                                    '',

        //Search Label Disabled
        // disabledSearchLabelFontColor:                            '',
        // disabledSearchLabelFontFamily:                           '',
        // disabledSearchLabelFontSize:                             '',
        // disabledSearchLabelFontStyle:                            '',
        // disabledSearchLabelFontWeight:                           '',
        // disabledSearchLabelLetterSpacing:                        '',
        // disabledSearchLabelLineSpacing:                          '',
        // disabledSearchLabelTextAlignment:                        '',
        // disabledSearchLabelBorderWidth:                          '',
        // disabledSearchLabelBorderColor:                          '',
        // disabledSearchLabelBorderStyle:                          '',
        // disabledSearchLabelBackgroundColor:                      ''
    };
};
