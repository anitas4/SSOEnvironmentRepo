TW.IDE.Widgets.actionvaluesetter = function () {
	var thisWidget = this;

	this.widgetIconUrl = function () {
		return "'../Common/extensions/actionvaluesetter/ui/actionvaluesetter/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'actionvaluesetter',
			'description': '',
			'category': ['Common'],
			'supportsAutoResize': false,
			'properties': {
				'Data': {
					'description': '',
					'isBindingTarget': true,
                    'isBindingSource': true,
					'isEditable': false,
					'baseType': 'INFOTABLE',
					'warnIfNotBoundAsTarget': true
				}
			}
		}
	};

    this.widgetServices = function () {
        return {
            'PushData': { 'warnIfNotBound': true }
        };
    };


	this.afterSetProperty = function (name, value) {
		return true;
	};

	this.renderHtml = function () {
		return '<div class="widget-content avs-widget">AVS</div>';
	};

	this.afterRender = function () {
	};
};