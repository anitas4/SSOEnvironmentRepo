﻿TW.Runtime.Widgets.actionvaluesetter = function () {
    var thisWidget = this;
	var data;

	this.updateProperty = function (updatePropertyInfo) {
		if (updatePropertyInfo.TargetProperty === 'Data') {
			data = TW.InfoTableUtilities.CloneInfoTable({ "dataShape" : { "fieldDefinitions" : updatePropertyInfo.DataShape}, "rows" : updatePropertyInfo.ActualDataRows });
		}
	};

    this.renderHtml = function () {
        var html = '';
        html = '<div class="widget-content widget-expression" style="display:none;"></div>';
        return '<div class="widget-content widget-avs" style="display:none;"></div>';
    };

    this.afterRender = function () {
		// if we never show at runtime, we should hide ourselves completely - Safari and Firefox will show scrollbars if the container is too narrow / short
		this.jqElement.hide();
		this.jqElement.closest('.widget-bounding-box').hide();
    };

    this.serviceInvoked = function (serviceName) {
        if (serviceName === 'PushData') {
			thisWidget.setProperty('Data', data);
        }
    };
};