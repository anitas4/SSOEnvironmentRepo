﻿TW.IDE.checkCustomCSS = true;

TW.IDE.Widgets.CustomCSS = function () {
    "use strict";
};