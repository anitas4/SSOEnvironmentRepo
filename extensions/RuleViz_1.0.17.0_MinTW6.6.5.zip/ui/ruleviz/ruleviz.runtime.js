TW.Runtime.Widgets.ruleviz= function () {
    var thisWidget = this;
	var dataRows = undefined;
	var clonedTable = undefined;
	var selectedRow = -1;
	var errorRow = -1;
	
	var isEditable = false;
	var isSortable = false;

	var startIndex = -1;
	var endIndex = -1;

	var dragOverWidget = true;
	var displayFld = '';


	this.renderHtml = function () {
		var html = '<div class="widget-content ruleviz-widget">'
		+ '</div>';
		return html;
	};

	var segmentOnClick = function(e) {
		thisWidget.jqElement.triggerHandler('Clicked');
		selectedRow = $(this).index() - 1;
		thisWidget.updateSelection('Data', [selectedRow]);
		thisWidget.updateSelectedRow();
		e.preventDefault();
	};

	// called whenever we need to redraw the widget
	var updateWidget = function() {
		$('#' + thisWidget.jqElementId + '> .ruleviz-segment').remove();
		if (clonedTable.rows && clonedTable.rows.length > 0) {
			for (var i = 0; i < clonedTable.rows.length; ++i) {
				var row = clonedTable.rows[i];

				var html = '';

				if (isEditable && row.type === 'PROPERTY' ) {
					html = '<input class="ruleviz-segment ruleviz-segment-' + row.type + '" placeholder="' + row[displayFld] +'">'
						+ '</input>';
				} else { 
					html = '<div class="ruleviz-segment ruleviz-segment-' + row.type + '">'
						+ row[displayFld]
						+ '</div>';
				}
				thisWidget.jqElement.append(html);
			}
		}

		// If the table is editable then only to selection/on click on the inputs and not the divs.
		if (isEditable) {
			$('#' + thisWidget.jqElementId + '> input.ruleviz-segment').bind('click', segmentOnClick);
			thisWidget.jqElement.find('input').bind('change', function() {
				var index = $(this).index() - 1;
				clonedTable.rows[index].value = $(this).val();
				thisWidget.setProperty('EditedTable',clonedTable);
			});
		} else {
			$('#' + thisWidget.jqElementId + '> .ruleviz-segment').bind('click', segmentOnClick);
			thisWidget.setProperty('EditedTable',clonedTable);
		}
	};



	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'Data') {
			dataRows = updatePropertyInfo.ActualDataRows;
			clonedTable = TW.InfoTableUtilities.CloneInfoTable({ "dataShape" : { "fieldDefinitions" : updatePropertyInfo.DataShape}, "rows" : updatePropertyInfo.ActualDataRows });

			if(thisWidget.getProperty("IsEditable") === true) {
		    	thisWidget.setProperty('EditedTable', clonedTable);
	        }

			updateWidget();
		} else if (updatePropertyInfo.TargetProperty === 'ErrorIndex') {
			errorRow = parseInt(updatePropertyInfo.SinglePropertyValue);
			thisWidget.updateErrorRow();
		}
	};

    this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
		selectedRow = selectedRowIndices[0];
		thisWidget.updateSelectedRow();
    };	

	this.updateSelectedRow = function() {
		var row = selectedRow + 2; // TODO: WTF? Is the Style block along with index being 1 based messing this up?
		$('#' + thisWidget.jqElementId + '> .ruleviz-segment').removeClass('selected');

		var selectedRowType = dataRows[selectedRow].type;
		if (!isEditable ||
		    (isEditable && selectedRowType === 'PROPERTY')) {
			$('#' + thisWidget.jqElementId + '> .ruleviz-segment:nth-child('+row+')').addClass('selected');
		}
	}

	this.updateErrorRow = function() {
		var row = errorRow + 2; // TODO: WTF? Is the Style block along with index being 1 based messing this up?

		$('#' + thisWidget.jqElementId + '> .ruleviz-segment').removeClass('error');

		if (errorRow >= 0) { 
			$('#' + thisWidget.jqElementId + '> .ruleviz-segment:nth-child('+row+')').addClass('error');		
		}
	}

	var getCSSFromStyle = function(styleName, style) {
		var color = style.foregroundColor;
		var backgroundColor = style.backgroundColor;
		var borderSize = style.lineThickness;
		if (borderSize === '') {
			borderSize = 0;
		}

		var borderColor = style.lineColor;
		if (borderColor === '') {
			borderColor = 'rgba(0, 0, 0, 0.0)';
		}

		return '#' + thisWidget.jqElementId + styleName + ' {'
					+ 'background-color: ' + backgroundColor + '; '
					+ 'color: ' + color + '; '
					+ 'border: ' + borderSize + 'px solid ' + borderColor + '; '
					+ '} '; 
	};	

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()
		isEditable = thisWidget.getProperty("IsEditable", false);
		isSortable = thisWidget.getProperty("IsSortable", false);
		displayFld = thisWidget.getProperty("DisplayField", "name");

		var propertyStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('PropertyStyle','DefaultRepeaterStyle'));
		var valueStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ValueStyle','DefaultRepeaterStyle'));
		var operatorStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('OperatorStyle','DefaultRepeaterStyle'));
		var serviceStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ServiceStyle','DefaultRepeaterStyle'));
		var selectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SelectedStyle','DefaultRepeaterStyle'));
		var hoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle','DefaultRepeaterStyle'));
		var errorStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ErrorStyle','DefaultRepeaterStyle'));

		var margin = thisWidget.getProperty("PartMargin");
		var padding = thisWidget.getProperty("PartPadding");
		var partHeight = thisWidget.getProperty("PartHeight");

		var style = '<style>'
			+ getCSSFromStyle("> .ruleviz-segment-PROPERTY",propertyStyle)
			+ getCSSFromStyle("> .ruleviz-segment-VALUE",valueStyle)
			+ getCSSFromStyle("> .ruleviz-segment-OPERATOR",operatorStyle)
			+ getCSSFromStyle("> .ruleviz-segment-SERVICE",serviceStyle)
			+ getCSSFromStyle("> .ruleviz-segment.selected",selectedStyle)
			+ getCSSFromStyle("> .ruleviz-segment.error",errorStyle)
			+ '#' + thisWidget.jqElementId + '> .ruleviz-segment { margin: ' + margin + '; padding: ' + padding + '; height: ' + partHeight + '}';

		if (isEditable === true) {
			style += getCSSFromStyle("> input.ruleviz-segment:hover",hoverStyle);
		} else {
			style += getCSSFromStyle("> .ruleviz-segment:hover",hoverStyle) +
					'#' + thisWidget.jqElementId + '> .ruleviz-segment:hover { cursor:pointer; }';
		}
			
		style += '</style>';
		
		$(style).prependTo(thisWidget.jqElement);

		if (isEditable === false && isSortable === true) {
			// Make it sortable
			thisWidget.jqElement.sortable();
			thisWidget.jqElement.on('sortstart', function(event, ui) {
				startIndex = ui.item.index() - 1;
			});
			thisWidget.jqElement.on('sortupdate', function( event, ui ) {
				endIndex = ui.item.index() - 1;
				var row = clonedTable.rows.splice(startIndex, 1);
				clonedTable.rows.splice(endIndex, 0, row[0]);
				thisWidget.setProperty('EditedTable', clonedTable);
			});
			thisWidget.jqElement.on('sortover', function(event, ui) {
				dragOverWidget = true;
			});
			thisWidget.jqElement.on('sortout', function(event, ui) {
				dragOverWidget = false;
			});
			thisWidget.jqElement.on('sortbeforestop', function(event, ui) {
				// if we are dragging this element out of the widget
				if (dragOverWidget == false) {
					// we need to remove the element from the dom
					ui.item.remove();

					// we need to remove the element from the edited table
					clonedTable.rows.splice(startIndex, 1);
					
					thisWidget.setProperty('EditedTable', clonedTable);
				}
			});
		}
	};
};