TW.IDE.Widgets.ruleviz = function () {
	var thisWidget = this;

	this.widgetIconUrl = function () {
		return "'../Common/extensions/FontAwesomeIcon/ui/ruleviz/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'RuleViz',
			'description': '',
			'category': ['Common'],
			'supportsAutoResize': true,
			'properties': {
				'Data': {
					'description': '',
					'isBindingTarget': true,
					'isEditable': false,
					'baseType': 'INFOTABLE',
					'warnIfNotBoundAsTarget': true
				},
                'DisplayField': {
                    'description': '',
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data'
                },				
                'IsSortable': {
                    'description': '',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN',
					'isVisible': true
                },
                'IsEditable': {
                    'description': '',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN',
					'isVisible': true
                },				
                'EditedTable': {
                    'isBindingSource': true,
                    'baseType': 'INFOTABLE',
                    'description': '',
					'isVisible': true
                },
				'OperatorStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'PropertyStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'ServiceStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'ValueStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'HoverStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'SelectedStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'ErrorStyle': {
					'description':'',
					'baseType':'STYLEDEFINITION',
					'defaultValue':'DefaultRepeaterStyle'
				},
				'ErrorIndex': {
					'description':'',
					'baseType':'NUMBER',
					'isBindingTarget': true,
					'defaultValue': -1
				},
				'PartMargin': {
					'description':'',
					'baseType':'STRING',
					'defaultValue':'2px'
				},
				'PartPadding': {
					'description':'',
					'baseType':'STRING',
					'defaultValue':'5px'
				},
				'PartHeight': {
					'description':'',
					'baseType':'STRING',
					'defaultValue':'1.5em'
				},
			}
		}
	};

	this.widgetEvents = function () {
		return {
			'Clicked': { 'warnIfNotBound': false }
		};
	};


	this.afterSetProperty = function (name, value) {
		return true;
	};

	this.renderHtml = function () {
		var html = '<div class="widget-content ruleviz-widget">'
			+ '<div class="ruleviz-segment ruleviz-segment-PROPERTY">Property</div>'
			+ '<div class="ruleviz-segment ruleviz-segment-VALUE">Value</div>'
			+ '<div class="ruleviz-segment ruleviz-segment-OPERATOR">Operator</div>'
			+ '<div class="ruleviz-segment ruleviz-segment-SERVICE">Service</div>'
			+ '<div class="ruleviz-segment ruleviz-segment-SERVICE selected">Selected</div>'
			+ '<div class="ruleviz-segment ruleviz-segment-SERVICE error">Error</div>'
		+ '</div>';

		return html;
	};

	var getCSSFromStyle = function(styleName, style) {

		var color = style.foregroundColor;
		var backgroundColor = style.backgroundColor;
		var borderSize = style.lineThickness;
		if (borderSize === '') {
			borderSize = 0;
		}

		var borderColor = style.lineColor;
		if (borderColor === '') {
			borderColor = 'rgba(0, 0, 0, 0.0)';
		}

		return '#' + thisWidget.jqElementId + styleName + ' {'
					+ 'background-color: ' + backgroundColor + '; '
					+ 'color: ' + color + '; '
					+ 'border: ' + borderSize + 'px solid ' + borderColor + '; '
					+ '} '; 
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()
		var propertyStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('PropertyStyle','DefaultRepeaterStyle'));
		var valueStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ValueStyle','DefaultRepeaterStyle'));
		var operatorStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('OperatorStyle','DefaultRepeaterStyle'));
		var serviceStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ServiceStyle','DefaultRepeaterStyle'));
		var selectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SelectedStyle','DefaultRepeaterStyle'));
		var hoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle','DefaultRepeaterStyle'));
		var errorStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ErrorStyle','DefaultRepeaterStyle'));

		var margin = thisWidget.getProperty("PartMargin");
		var padding = thisWidget.getProperty("PartPadding");
		var partHeight = thisWidget.getProperty("PartHeight");

		var style = '<style>'
			+ getCSSFromStyle("> .ruleviz-segment-PROPERTY",propertyStyle)
			+ getCSSFromStyle("> .ruleviz-segment-VALUE",valueStyle)
			+ getCSSFromStyle("> .ruleviz-segment-OPERATOR",operatorStyle)
			+ getCSSFromStyle("> .ruleviz-segment-SERVICE",serviceStyle)
			+ getCSSFromStyle("> .ruleviz-segment.selected",selectedStyle)
			+ getCSSFromStyle("> .ruleviz-segment.error",errorStyle)
			+ getCSSFromStyle("> .ruleviz-segment:hover",hoverStyle)
			+ '#' + thisWidget.jqElementId + '> .ruleviz-segment:hover { cursor:pointer; }'
			+ '#' + thisWidget.jqElementId + '> .ruleviz-segment { vertical-align: middle; margin: ' + margin + '; padding: ' + padding + '; height: ' + partHeight + '}'
			+ '</style>';
		
		$(style).prependTo(thisWidget.jqElement);
	};

};