﻿/*global Encoder,TW */

(function () {
    "use strict";
    var addedDefaultButtonStyles = false;

    TW.Runtime.Widgets.backButton = function () {
        var thisWidget = this;
        var roundedCorners = true;

        this.runtimeProperties = function () {
            return {
                'needsDataLoadingAndError': false,
                'supportsTooltip': true,
                'propertyAttributes': {
                    'Label': {
                        'isLocalizable': true
                    },
                    'ContextId': {
                        'isLocalizable': false
                    },
                    'ToolTipField': {
                        'isLocalizable': true
                    }
                }
            };
        };

        this.renderHtml = function () {
            var isButtonDisabled = thisWidget.getProperty('Disabled', false);
            var styleToUse = isButtonDisabled ? 'DisabledStyle' : 'Style'; //if disabled, use disabled style instead.
            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty(styleToUse, 'PTC.Factory.BackToOverviewBTN'));
            var formatResult2 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle'));
            var formatResult3 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ActiveStyle'));
            var textSizeClass = 'textsize-normal';
            if (this.getProperty('Style') !== undefined) {
                textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
            }

            // The Disabled property is used for programmatic control of the button state. There is
            // also a class, widget-button-disabled, which is used internally to debounce button
            // click events.
            var buttonState = isButtonDisabled ? ' disabled' : '';

            var html =
                '<div class="widget-content widget-button">'
                    + '<button class="button-element ' + textSizeClass + '" tabindex="' + thisWidget.getProperty('TabSequence') + '"' + buttonState + '>'
                        + '<span class="widget-button-icon">'
                            + ((formatResult.image !== undefined && formatResult.image.length > 0) ? '<img class="default" src="' + formatResult.image + '"/>' : '')
                            + ((formatResult2.image !== undefined && formatResult2.image.length > 0) ? '<img class="hover" src="' + formatResult2.image + '"/>' : '')
                            + ((formatResult3.image !== undefined && formatResult3.image.length > 0) ? '<img class="active" src="' + formatResult3.image + '"/>' : '')
                        + '</span>'
                        + '<span class="widget-button-text">' + (thisWidget.getProperty('Label') === undefined ? 'Button' : Encoder.htmlEncode(thisWidget.getProperty('Label'))) + '</span>'
                    + '</button>'
                + '</div>';
            return html;
        };

        this.renderStyles = function () {
            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style', 'PTC.Factory.BackToOverviewBTN'));
            var buttonHoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle'));

            var buttonActiveStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ActiveStyle'));
            var buttonFocusStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('FocusStyle'));
            var buttonDisabledStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('DisabledStyle'));

            var cssInfo = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
            var cssButtonBackground = TW.getStyleCssGradientFromStyle(formatResult);
            var cssButtonBorder = TW.getStyleCssBorderFromStyle(formatResult);

            var cssButtonHoverText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonHoverStyle);
            var cssButtonHoverBackground = TW.getStyleCssGradientFromStyle(buttonHoverStyle);
            var cssButtonHoverBorder = TW.getStyleCssBorderFromStyle(buttonHoverStyle);

            var cssButtonActiveText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonActiveStyle);
            var cssButtonActiveBackground = TW.getStyleCssGradientFromStyle(buttonActiveStyle);
            var cssButtonActiveBorder = TW.getStyleCssBorderFromStyle(buttonActiveStyle);

            var cssButtonFocusBorder = TW.getStyleCssBorderFromStyle(buttonFocusStyle);

            var cssButtonDisabledText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonDisabledStyle);
            var cssButtonDisabledBackground = TW.getStyleCssGradientFromStyle(buttonDisabledStyle);
            var cssButtonDisabledBorder = TW.getStyleCssBorderFromStyle(buttonDisabledStyle);

            var styleBlock =
                        '#' + thisWidget.jqElementId + ' .button-element { ' + cssButtonBackground + cssButtonBorder +' } ' +
                        '#' + thisWidget.jqElementId + ' .button-element:hover { ' + cssButtonHoverBackground + cssButtonHoverBorder +' } ' +
                        '#' + thisWidget.jqElementId + ' .button-element:active { ' + cssButtonActiveBackground + cssButtonActiveBorder +' }' +
                        '#' + thisWidget.jqElementId + ' .button-element:disabled {' + cssButtonDisabledBackground + cssButtonDisabledBorder + '}' +
                        '#' + thisWidget.jqElementId + ' .button-element span { ' + cssInfo + ' } ' +
                        '#' + thisWidget.jqElementId + ' .button-element:hover span { ' + cssButtonHoverText + ' } ' +
                        '#' + thisWidget.jqElementId + ' .button-element:active span { ' + cssButtonActiveText + ' } ' +
                        '#' + thisWidget.jqElementId + ' .button-element:disabled span {' + cssButtonDisabledText + '}' +
                        '#' + thisWidget.jqElementId + '.focus .button-element { ' + cssButtonFocusBorder + ' }';

            return styleBlock;
        };

        this.afterRender = function () {
            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style', 'PTC.Factory.BackToOverviewBTN'));
            var buttonHoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle'));

            roundedCorners = this.getProperty('RoundedCorners');
            if (roundedCorners === undefined) {
                roundedCorners = true;
            }

            if (roundedCorners === true) {
                thisWidget.jqElement.addClass('roundedCorners');
            }

            if (formatResult.image.length > 0) {
                thisWidget.jqElement.addClass('hasImage');
            }

            if (buttonHoverStyle.image.length === 0) {
                thisWidget.jqElement.addClass('singleImageOnly');
            }

            var iconAlignment = this.getProperty('IconAlignment');
            var iconElement = thisWidget.jqElement.find('.widget-button-icon');
            var buttonText = thisWidget.jqElement.find('.widget-button-text');

            if (buttonText.html().length === 0) {
                thisWidget.jqElement.addClass('iconOnly'); // don't pad for text
            }
            else {
                if (iconAlignment === 'right') {
                    $(iconElement).insertAfter(buttonText);
                    thisWidget.jqElement.addClass('iconRight');
                }
            }

            var widgetProperties = thisWidget.properties;

            var widgetSelector = '#' + thisWidget.jqElementId + ' .button-element';
            var widgetContainer = '#' + thisWidget.jqElementId;

            $(widgetSelector).on('focus', function () {
                $(widgetContainer).addClass('focus');
            });

            $(widgetSelector).on('blur', function (e) {
                $(widgetContainer).removeClass('focus');

            });

            updateVisitedPages(window.location.href);

            thisWidget.jqElement.bind('click', function (e) {

                var isWidgetDisabled = widgetProperties.Disabled ||
                    thisWidget.jqElement.hasClass('widget-button-disabled');

                if (!isWidgetDisabled) {
                    visitPreviousPage();
                }
                e.preventDefault();
            });
        };

        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.button.beforeDestroy', err);
            }
        };

        this.updateProperty = function (updatePropertyInfo) {
            if (updatePropertyInfo.TargetProperty === 'Disabled') {
                this.jqElement.find('button').prop('disabled', updatePropertyInfo.RawSinglePropertyValue);
                this.setProperty('Disabled', updatePropertyInfo.RawSinglePropertyValue);
            }

            if (updatePropertyInfo.TargetProperty === 'ToolTipField') {
                thisWidget.setProperty('ToolTipField', updatePropertyInfo.SinglePropertyValue);
            }

            if (updatePropertyInfo.TargetProperty === 'ContextId') {
                thisWidget.setProperty('ContextId', updatePropertyInfo.RawSinglePropertyValue);
            }
        };

        function updateVisitedPages(url) {
            var visitedPages = sessionStorage.visitedPages;
            if (!visitedPages) {
                sessionStorage.visitedPages = url;
            } else {
                var list = visitedPages.split(",");
                var previousUrl = list[list.length - 1];

                if (areDifferentUrls(previousUrl, url)) {
                    list.push(url);
                    sessionStorage.visitedPages = list;
                }
            }
        };

        function areDifferentUrls(url1, url2) {
            url1 = removeNoiseParams(url1);
            url2 = removeNoiseParams(url2);

            return url1 != url2;
        };

        var noiseParams = [/&numAdditionalBack=\d+/g, /&__applyThemeName=[^&]*/g,
                           /&defaultMashup=[^&]+/g, /&nestedMashup=[^&]+/g];

        function removeNoiseParams(url) {
            var len = noiseParams.length;
            for (var i=0; i < len; i++) {
                url = url.replace(noiseParams[i], '');
            }

            return url;
        };

        function visitPreviousPage() {
            var visitedPages = sessionStorage.visitedPages;
            var url = '';
            if (visitedPages) {
                var list = visitedPages.split(",");
                var length = list.length;

                if (length > 0) {
                    list.pop();
                    if (length > 1) {
                        url = list.pop();
                    }
                }

                sessionStorage.visitedPages = list;
            }

            if (url === '') {
                var currentLocation = window.location.href;
                var index = currentLocation.indexOf('#') + 1;
                var url = currentLocation.substr(0, index) + 'master=PTC.FactoryConsole.Master&mashup=PTC.FactoryConsole';
            }
            TW.openUrl('location',url);

        };
    };
}());
