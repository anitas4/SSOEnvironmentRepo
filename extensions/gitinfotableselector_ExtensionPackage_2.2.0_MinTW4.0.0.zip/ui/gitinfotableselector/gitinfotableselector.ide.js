TW.IDE.Widgets.gitinfotableselector = function () {
    this.widgetIconUrl = function() {
        return  "../Common/extensions/gitinfotableselector_ExtensionPackage/ui/gitinfotableselector/gitinfotableselector.ide.png";
    };

    this.widgetProperties = function () {
        return {
            'name': 'GitBackup Infotable Selector',
            'description': 'Can help with clearing selection, selecting previous or next row or dynamically letting you know if any rows are selected, useful for hiding and showing various parts of the UI',
            'category': ['Data'],
            'defaultBindingTargetProperty': 'Data',
            'supportsAutoResize': true,
            'properties': {
                'Data': {
                    'description': 'Data source',
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
				'RowCount': {
                    'description': 'Row count for the infotable provided in the Data property',
                    'isBindingTarget': false,
                    'isBindingSource': true,
                    'isEditable': false,
                    'baseType': 'NUMBER'
                },
                'HasRows': {
                    'description': 'True when the infotable contains at least one row',
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'NoRows': {
                    'description': 'True when the infotable does not contain any row. Reverse of HasRows.',
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'SelectRowNumber': {
                    'description': 'Row number to select or is selected in the infotable',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': false,
                    'baseType': 'NUMBER'
                },
                'MultiSelectRowNumbers': {
                    'description': 'Row numbers to select or are selected in the infotable',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE'
                },
                'SelectRowNumberField': {
                    'description': 'Field for the indices of rows to select',
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'MultiSelectRowNumbers'
                },
                'AnyRowsSelected': {
                    'description': 'True when one or rows are selected',
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'NoRowsSelected': {
                    'description': 'True when no rows are selected',
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'Width': {
                    'description': 'Widget width',
                    'defaultValue': 200
                },
                'Height': {
                    'description': 'Widget height',
                    'defaultValue': 28
                }
            }
        };
    };

    this.widgetServices = function () {
        return {
            'ClearSelectedRows': { 'warnIfNotBound': false },
            'SelectFirstRow': { 'warnIfNotBound': false },
            'SelectNextRow': { 'warnIfNotBound': false },
            'SelectPreviousRow': { 'warnIfNotBound': false }
        };
    };

    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-gitinfotableselector">Invisible at runtime</div>';
        return html;
    };

    this.validate = function () {
        var result = [];

        return result;
    };
};
