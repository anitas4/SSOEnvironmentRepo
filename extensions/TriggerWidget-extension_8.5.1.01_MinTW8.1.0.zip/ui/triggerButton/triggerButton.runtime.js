﻿/*global Encoder,TW */

(function () {
    var addedDefaultButtonStyles = false;

    TW.Runtime.Widgets.triggerButton = function () {
        "use strict";
        var thisWidget = this;

        this.runtimeProperties = function () {
            return {
                'needsDataLoadingAndError': false,
                'propertyAttributes': {}
                }
        };

        this.renderHtml = function () {
            var html =
                '<div class="widget-content widget-triggerButton"></div>';
            return html;
        };

        this.serviceInvoked = function (serviceName) {
            var widgetReference = this;
            if (serviceName.indexOf('Trigger') !== -1) {
                var index = serviceName.substr('Trigger'.length, serviceName.length);
                widgetReference.setProperty('TriggerIndex',index);
                widgetReference.jqElement.trigger('Triggered');
            }
        };
        
        this.afterRender = function () {
            thisWidget.jqElement.bind('click', function (e) {
                // Widget is hidden by default. Do nothing.
            });
        };

        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.TriggerWidget.beforeDestroy', err);
            }
        };

        this.updateProperty = function (updatePropertyInfo) {

        };
    };
}());
