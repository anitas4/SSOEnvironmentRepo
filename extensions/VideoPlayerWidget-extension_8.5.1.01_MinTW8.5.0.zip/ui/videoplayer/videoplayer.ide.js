﻿TW.IDE.Widgets.videoplayer = function() {

    this.widgetProperties = function() {
        return {
            name:        "Video Player", // TW.IDE.I18NController.translate('tw.videoplayer-ide.widget.name'),
            description: "Video Player", // TW.IDE.I18NController.translate('tw.videoplayer-ide.widget.description'),
            category:    ['Common'],
            iconClass:   'widgets-videoplayer',
            properties:  {
                ShowControls: {
                    description:     "Show or hide controls for video playback", // TW.IDE.I18NController.translate('tw.videoplayer-ide.properties.show-controls.description'),
                    isEditable:      true,
                    isVisible:       true,
                    isBindingSource: true,
                    defaultValue:    true,
                    baseType:        'BOOLEAN'
                },
                VideoURL: {
                    description:     "The URL to the video", //TW.IDE.I18NController.translate('tw.videoplayer-ide.properties.video-url.description'),
                    isBindingTarget: true,
                    defaultValue:    '',
                    baseType:        'STRING'
                },
                Width: {
                    description:  "Width of widget", //TW.IDE.I18NController.translate('tw.videoplayer-ide.properties.width.description'),
                    defaultValue: 240
                },
                Height: {
                    description:  "Height of widget", //TW.IDE.I18NController.translate('tw.videoplayer-ide.properties.height.description'),
                    defaultValue: 180
                }
            }
        };
    };

    this.widgetEvents = function() {
        return {
            LocationChanged: {}
        };
    };

    this.widgetServices = function() {
        return {
            Play:  {warnIfNotBound: false},
            Pause: {warnIfNotBound: false}
        };
    };

    this.renderHtml = function() {
        var html = '<div class="widget-content widget-video">Video Player</div>';
        return html;
    };

    this.beforeDestroy = function() {

    };
};
