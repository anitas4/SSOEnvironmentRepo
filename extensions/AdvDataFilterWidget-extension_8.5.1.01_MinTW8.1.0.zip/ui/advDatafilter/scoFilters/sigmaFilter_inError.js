/* Custom filter for the 'inError' property. */
/* The purpose of this filter is to present the states to filter on in a drop-down list.*/
/* Author: jgoudreau */

(function ($) {

    // Here we register the plugin with the ThingWorx jquery plugin framework
    $.registerJqPlugin("sigmaFilter_inError");

    // These prototype items get assigned to every instance of TW.jqPlugins.sigmaFilter_inError
    TW.jqPlugins.sigmaFilter_inError.prototype = {
        defaultProperties: {
            'filterInfo': {
                'baseType': 'INTEGER',
                'fieldName': undefined,
                'fieldTitle': undefined,
                'description': undefined,
                'currentFilter': undefined
            },
            'showEdit': true,
            'isFilterValid':false
        },

        _plugin_afterSetProperties: function () {
            // call this if you want to reset yourself every time properties are updated.
            this._plugin_beforeDestroy();

            var thisPlugin = this;

            if (thisPlugin.properties.filterInfo.currentFilter !== undefined) {
                thisPlugin.properties.isFilterValid = true;
            } else {
                thisPlugin.properties.filterInfo.currentFilter =
                    {
                        fieldName: thisPlugin.properties.filterInfo.fieldName,
                        type: 'unspecified',
                        value: 0
                    };
            }

            thisPlugin.jqElement.html(
				'<span class="filter-pointer-arrow"></span>' +
                '<div class="filter-twFilter_number">' +
					'<div class="filter-twFilter-options-container">' +
	                    '<span class="filter-fieldName" base-type="'+ thisPlugin.properties.filterInfo.baseType + '" title="' + (thisPlugin.properties.filterInfo.fieldTitle !== undefined ? TW.Runtime.convertLocalizableString(thisPlugin.properties.filterInfo.fieldTitle):thisPlugin.properties.filterInfo.fieldName) + '">' + (thisPlugin.properties.filterInfo.fieldTitle !== undefined ? TW.Runtime.convertLocalizableString(thisPlugin.properties.filterInfo.fieldTitle):thisPlugin.properties.filterInfo.fieldName) + '</span>' +
	                    '<select class="filter-editing-value">' +
	                        '<option value="0" selected="true">' + TW.Runtime.convertLocalizableString('[[PTC.Factory.Good]]') + '</option>"' +
	                        '<option value="1">' + TW.Runtime.convertLocalizableString('[[PTC.Factory.InError]]') + '</option>"' +
	                        '<option value="2">' + TW.Runtime.convertLocalizableString('[[PTC.Factory.InError24h]]') + '</option>"' +
	                        '<option value="3">' + TW.Runtime.convertLocalizableString('[[PTC.Factory.Disabled]]') + '</option>"' +
                            '<option value="4">' + TW.Runtime.convertLocalizableString('[[PTC.Factory.UnavailableStatus]]') + '</option>"' +
	                    '</select>' +
					'</div>' +
					'<div class="filter-twFilter-savecancel">' +
	                    '<span class="filter-editing-update-button">' + TW.Runtime.convertLocalizableString('[[save]]') + '</span>' +
	                    '<span class="filter-editing-cancel-button">' + TW.Runtime.convertLocalizableString('[[cancel]]') + '</span>' +
					'</div>' +
                '</div>');

            thisPlugin.filterEditingSaveBtn = thisPlugin.jqElement.find('.filter-editing-update-button');
            thisPlugin.filterEditingCancelBtn = thisPlugin.jqElement.find('.filter-editing-cancel-button');

            thisPlugin.filterValueElem = thisPlugin.jqElement.find('.filter-editing-value');

            var buildDescriptionFromFilter = function (filter, populateUiAsWell) {
                if( filter.type === 'unspecified' )  {
                    thisPlugin.properties.descriptionHtml =
                        '<span class="filter-item-label">' + (thisPlugin.properties.filterInfo.fieldTitle !== undefined ? TW.Runtime.convertLocalizableString(thisPlugin.properties.filterInfo.fieldTitle):thisPlugin.properties.filterInfo.fieldName) + '</span>' +
                        '&nbsp;' +
                        '<span class="filter-item-error">' + TW.Runtime.convertLocalizableString('[[filterHasNotBeenSpecifiedYet]]') + '</span>';
                } else {
                    var value = filter.value;
                    var operator;

                    switch( filter.value )  {
                        case 0:
                            operator = 'is ' + TW.Runtime.convertLocalizableString('[[PTC.Factory.Good]]');
                            break;
                        case 1:
                            operator = 'is ' + TW.Runtime.convertLocalizableString('[[PTC.Factory.InError]]');
                            break;
                        case 2:
                            operator = 'is ' + TW.Runtime.convertLocalizableString('[[PTC.Factory.InError24h]]');
                            break;
                        case 3:
                            operator = 'is ' + TW.Runtime.convertLocalizableString('[[PTC.Factory.Disabled]]');
                            break;
                        case 4:
                             operator = 'is ' + TW.Runtime.convertLocalizableString('[[PTC.Factory.UnavailableStatus]]');
                            break;
                        default:
                            TW.log.error('unknown operator selected "' + value + '"');
                    }

                    if (populateUiAsWell) {
                        thisPlugin.filterValueElem.val(value);
                    }

                    thisPlugin.properties.descriptionHtml =
                        '<span class="filter-item-label">' + (thisPlugin.properties.filterInfo.fieldTitle !== undefined ? TW.Runtime.convertLocalizableString(thisPlugin.properties.filterInfo.fieldTitle):thisPlugin.properties.filterInfo.fieldName) + '</span>' +
                        '&nbsp;' +
                        '<span class="filter-item-operator">' + operator + '</span>';
                }
            };

            thisPlugin.properties.descriptionHtml = '<span class="filter-item-label">' + (thisPlugin.properties.filterInfo.fieldTitle !== undefined ? TW.Runtime.convertLocalizableString(thisPlugin.properties.filterInfo.fieldTitle):thisPlugin.properties.filterInfo.fieldName) + '</span>';

            buildDescriptionFromFilter(thisPlugin.properties.filterInfo.currentFilter, thisPlugin.properties.isFilterValid /*populateUiAsWell*/);

            thisPlugin.filterEditingCancelBtn.click(function(e) {
                thisPlugin.jqElement.triggerHandler('filterUpdateCancelled');
                e.stopPropagation();
            });

            thisPlugin.jqElement.find('input').keydown(function (e) {
            	if (e.which === 13) {
            		thisPlugin.filterEditingSaveBtn.click();
            	}
            });

            thisPlugin.filterEditingSaveBtn.click(function (e) {

                var val = parseInt(thisPlugin.filterValueElem.val());
                thisPlugin.properties.filterInfo.currentFilter.type = 'EQ';
                thisPlugin.properties.filterInfo.currentFilter.value = val;

                buildDescriptionFromFilter(thisPlugin.properties.filterInfo.currentFilter, false /*populateUiAsWell*/);

                thisPlugin.properties.isFilterValid = true;

                // notify the twFilter that our properties have changed
                thisPlugin.jqElement.triggerHandler('filterPropertiesUpdated',[thisPlugin.properties]);
                thisPlugin.jqElement.triggerHandler('filterUpdated', [thisPlugin.properties.filterInfo.currentFilter]);

                e.stopPropagation();
            });
            // notify the twFilter that our properties have changed
            thisPlugin.jqElement.triggerHandler('filterPropertiesUpdated',[thisPlugin.properties]);
        },

        // this is called whenever the caller calls .sigmaFilter_inError(‘destroy’)
        _plugin_beforeDestroy: function () {
            this.jqElement.empty().unbind();
        }
    };

})(jQuery);
