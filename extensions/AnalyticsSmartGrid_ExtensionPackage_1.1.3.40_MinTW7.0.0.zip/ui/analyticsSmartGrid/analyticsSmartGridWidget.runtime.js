/*
 * Copyright (c) 2015 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 */

/* var s_runtimePluginVersion = "10.2.30.38"; */

TW.Runtime.Widgets.analyticsSmartGridWidget = function () {
    var thisWidget = this;
    thisWidget.selectedRows = [];
    thisWidget.selectedInstances = [];
    var editedTable;
    var savedDataProperty;
    var dataRendered = true;
    var tableRendered = false;
    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': false
        };
    };

    this.renderHtml = function () {
        var pre = this.getProperty('PreHTML') ? this.getProperty('PreHTML') : "";
        var post = this.getProperty('PostHTML') ? this.getProperty('PostHTML') : "";
        return pre + '<table class="widget-content append-grid-table" style="display:block;"></table>' + post;  
    };

    this.resize = function (width, height) {
        this.terminal.resize();
    };

    this.afterRender = function () {
      this.customAfterRender();
    };

    this.customAfterRender = function() {

      //if the table is already displayed, remove it and render it again
        if(this.jqElement.html().length > 0){
          this.jqElement.empty();
        }

        if(!this.getProperty('TableDefinition'))
          return;
        var tableDefinition = JSON.parse(this.getProperty('TableDefinition'));

        for(var col in tableDefinition.columns){
          var column = tableDefinition.columns[col];
          column.onChange = function(evt, rowIndex){
            constructEditedTableRows(thisWidget, editedTable);
          };
          
          var tooltipConfig = column.dynamicUiTooltip;
          if (tooltipConfig) {
            var uiTooltip = new Object();
            if (tooltipConfig.classes)
              uiTooltip.classes = eval(tooltipConfig.classes);
            if (tooltipConfig.items)
              uiTooltip.items = eval(tooltipConfig.items);
            if (tooltipConfig.content)
              uiTooltip.content = eval(tooltipConfig.content);
            if (tooltipConfig.show)
              uiTooltip.show = eval(tooltipConfig.show);
            if (tooltipConfig.hide)
              uiTooltip.hide = eval(tooltipConfig.hide);
            if (tooltipConfig.disabled)
              uiTooltip.disabled = eval(tooltipConfig.disabled);
            if (tooltipConfig.position)
              uiTooltip.position = eval(tooltipConfig.position);
            if (tooltipConfig.track)
              uiTooltip.track = eval(tooltipConfig.track);
            
            column.uiTooltip = uiTooltip;
          }
          
          var onClickConfig = column.dynamicOnClick;
          if (onClickConfig) {
            column.onClick = eval(onClickConfig);
          }
        };
        tableDefinition.afterRowSwapped = function (caller, oldRowIndex, newRowIndex) {constructEditedTableRows(thisWidget, editedTable)};
        tableDefinition.afterRowRemoved = function (caller, rowIndex) {constructEditedTableRows(thisWidget, editedTable)};
        this.jqElement.appendGrid(tableDefinition);

        if(!dataRendered && savedDataProperty){
          var dataToLoad = this.prepareDataToRender(savedDataProperty);
          this.jqElement.appendGrid('load', dataToLoad);
          //initialize the EditedTable object
          var editedTableRows = [];
          editedTable = TW.InfoTableUtilities.CloneInfoTable({ "dataShape" : { "fieldDefinitions" : savedDataProperty.DataShape}, "rows" : editedTableRows });
          constructEditedTableRows(this, editedTable);
          dataRendered = true;
        }
    }

    this.updateProperty = function (updatePropertyInfo) {
      if(updatePropertyInfo.TargetProperty==='Data') {

        if(!this.getProperty('TableDefinition')){
          savedDataProperty = updatePropertyInfo;
          dataRendered = false;
          return;
        }

        var infoTableDataShape = updatePropertyInfo.DataShape;
        var dataToLoad = this.prepareDataToRender(updatePropertyInfo);
        this.jqElement.appendGrid('load', dataToLoad);
        //initialize the EditedTable object
        var editedTableRows = [];
        editedTable = TW.InfoTableUtilities.CloneInfoTable({ "dataShape" : { "fieldDefinitions" : infoTableDataShape}, "rows" : editedTableRows });
        constructEditedTableRows(this, editedTable);
      } else if(updatePropertyInfo.TargetProperty === 'TableDefinition') {
        if(!this.getProperty('TableDefinition')) {
          this.setProperty('TableDefinition', updatePropertyInfo.SinglePropertyValue);
          this.customAfterRender();
        }
      }
    };

    this.prepareDataToRender = function (data) {
      var fieldDefinitions = Object.keys(data.DataShape);
      var fieldCount = fieldDefinitions.length;
      var rows = data.ActualDataRows;
      var dataToRender = [];
      for(var j=0; j<rows.length; j++){
        var row = rows[j];
        var rowToRender = {};
        for(var i=0; i<fieldCount; i++){
          var propName = fieldDefinitions[i];
          rowToRender[propName] = row[propName];
        }
        dataToRender.push(rowToRender);
      }
      return dataToRender;
    }

    var constructEditedTableRows = function(thisWidget, editedTable){
      editedTable.rows = thisWidget.jqElement.appendGrid('getAllValue');
      thisWidget.setProperty('EditedTable', editedTable);
    }
    
    // Modified from https://stackoverflow.com/a/14991797
    // This function is available to dynamicOnClick handlers
    function parseCSV(str) {
        var arr = [];
        var quote = false;  // true means we're inside a quoted field

        // iterate over each character, keep track of current column (of the returned array)
        var col, c;
        for (col = c = 0; c < str.length; c++) {
            var cc = str[c], nc = str[c+1];        // current character, next character (empty if out of range)
            arr[col] = arr[col] || '';             // create a new column (start with empty string) if necessary

            // If the current character is a quotation mark, and we're inside a
            // quoted field, and the next character is also a quotation mark,
            // add a quotation mark to the current column and skip the next character
            if (cc == '"' && quote && nc == '"') { arr[col] += cc; ++c; continue; }  

            // If it's just one quotation mark, begin/end quoted field
            if (cc == '"') { quote = !quote; continue; }

            // If it's a comma and we're not in a quoted field, move on to the next column
            if (cc == ',' && !quote) { ++col; continue; }

            // Otherwise, append the current character to the current column
            arr[col] += cc;
        }
        
        // Does not handle errors with even numbers of unescaped quotes inside values
        if (quote) {
            throw "Invalid CSV: '" + str + "'. Make sure all quoted values are closed, and literal double-quotes are quoted and escaped as \"\".";
        }
        return arr.join("\n");
    }
    
};

// This function is available to event handlers in PreHTML and PostHTML
TW.Runtime.Widgets.analyticsSmartGridWidget.toCSVLine = function(str) {
    var arr = str.split("\n");
    for (var i=0; i < arr.length; i++) {
        var value = arr[i];
        if (value.indexOf(',') > -1 || value.indexOf('"') > -1) {
            arr[i] = '"' + value.replace(/"/g, '""') + '"';
        }
    }
    return arr.join(",");
};