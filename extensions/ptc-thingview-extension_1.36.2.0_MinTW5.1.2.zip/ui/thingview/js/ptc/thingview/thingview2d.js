"use strict";

var ThingView2D = (function () {
    var _currentCanvasId = "";
    var _parentCanvasId = "";
    //SVG VARS
    var _calloutColors = [];
    var _calloutsSelected = [];
    var _partColors = [];
    var _partsSelected = [];
    var _svgCalloutCB;
    var _zoomWindow = false;
    var _zoomButton = false;
    var _zoomButtonScale;
    //PDF VARS
    var __PDF_DOC = null;
    var __CANVAS = null;
    var __CANVAS_CTX = null;
    var __CURRENT_PAGE = 0;
    var __TOTAL_PAGES = 0;
    var __ZOOMSCALE = 1;
    var _pdfCallback = null;
    var _pageMode = "Original";
    var _cursorMode = "pan";
    var _ignoreScrollEvent = false;
    var _marginSize = 26;
    var _toolbarEnabled = false;
    var _toolbarHeight = 40;
    var _miniToolbar = false;
    var _toolbarButtonsWidth = 0;
    var _toolbarGroups = {pages: true, zoom: true, cursor: true, search: true, sidebar: true, rotate: true, print: true};
    var _toolbarGroupsLoaded = {targetFull: 13, targetMini: 4, current: 0};
    var _toolbarGroupsValues = {full: [4,2,2,1,1,2,1], mini: [0,2,0,1,0,0,0]};
    var _firstLoadedPage = 0;
    var _lastLoadedPage = 0;
    var _bookmarks = [];
    var _documentLoaded = false;
    var _searchResults = [];
    var _searchTerm = "";
    var _searchResultFocus = 0;
    var _searchCaseMatch = false;
    var _searchWordMatch = false;
    var _sidebarEnabled = false;
    var _navbar = {enabled: true, firstLoadedPage: 0, lastLoadedPage: 0, selectedPage: 0, bufferSize: 5};
    var _bookmarksBar = {enabled: false};
    var _sidebarResize = false;
    var _searchDrag = {enabled: false, x: 0, y: 0};
    var _pageRotation = 0;
    var _print = null;
    var _printEnabled = true;
    var _pdfAnnotationId = -1;
    var _pdfRawAnnotationSet = null;
    var _pdfParsedAnnotationSet = [];
    
    //Public Functions
    var returnObj = {
        //SHARED
        LoadDocument: function (viewable, parentCanvasId, model, callback){
          _LoadDocument(viewable, parentCanvasId, model, callback);  
        },
        LoadPDF: function (parentCanvasId, buffer, callback){
           _LoadPdfFromBuffer(parentCanvasId, buffer, callback); 
        },
        Destroy2DCanvas: function() {
            _destroy2DCanvas();
        },
        ResetTransform: function(elem){
          _resetTransform(elem);  
        },
        SetZoomOnButton: function(scale){
            if (_zoomWindow) {
                _setZoomWindow();
            }
            _setZoomOnButton(scale);
        },
        //SVG
        IsSVGSession: function() {
            return _IsSVGSession();
        },
        ResetTransformSVG: function(){
            if (_zoomButton) {
                _setZoomOnButton(_zoomButtonScale);
            }
            _resetTransform(document.getElementById(_currentCanvasId).childNodes[0]);
        },
        SetZoomWindow: function(){
            if (_zoomButton) {
                _setZoomOnButton(_zoomButtonScale);
            }
            _setZoomWindow();
        },
        GetCallouts: function(){
            return _getCallouts();
        },
        SelectCallout: function(callout){
            if(!(_calloutsSelected.indexOf(callout.id) != -1)){
                _selectCallout(callout);
            }
        },
        DeselectCallout: function(callout){
            if(_calloutsSelected.indexOf(callout.id) != -1){
                _deselectCallout(callout);
                var index = _calloutsSelected.indexOf(callout.id);
                if (index !=-1){
                    _calloutsSelected.splice(index,1);
                }
            }
        },
        GetSVGParts: function(partNo){
            return _getSVGParts(partNo);
        },
        SetSVGCalloutCallback: function(callback){
            if(typeof callback === "function"){
                _svgCalloutCB = callback;
            }
        },
        //PDF
        CreatePDFSession: function(parentCanvasId, callback) {
            _createPDFSession(parentCanvasId, callback);
        },
        SetPDFCallback: function (callback) {
            if (typeof callback === "function"){
                _pdfCallback = callback;
            }
        },
        IsPDFSession: function() {
            return _IsPDFSession();
        },
        LoadPrevPage: function (callback) {
            _LoadPrevPage(callback);
        },
        LoadNextPage: function (callback) {
            _LoadNextPage(callback);
        },
        LoadPage: function (callback, pageNo) {
            _LoadPage(callback, pageNo);
        },
        GetCurrentPDFPage: function () {
            if (_IsPDFSession()){
                return __CURRENT_PAGE;
            }
        },
        GetTotalPDFPages: function () {
            if (_IsPDFSession()){
                return __TOTAL_PAGES;
            }
        },
        GetPdfBookmarks: function() {
            if(_IsPDFSession()){
                return _bookmarks;
            }
        },
        SetDocumentLoaded: function() {
            if(_IsPDFSession()){
                _documentLoaded = true;
            }
        },
        GetDocumentLoaded: function() {
            if(_IsPDFSession()){
                return _documentLoaded;
            }
        },
        ResetTransformPDF: function(){
            if(_zoomButton) {
                _setZoomOnButton(_zoomButtonScale);
            }
            _resetTransformPDF();
        },
        SetPageModePDF: function(pageMode){
            if(_IsPDFSession()){
                _pageMode = pageMode;
                _setPageModePDF(__CURRENT_PAGE);
            }
        },
        SetPanModePDF: function(){
            if(_IsPDFSession()){
                if (_zoomButton) {
                    _setZoomOnButton(_zoomButtonScale);
                }
                _cursorMode = "pan";
                _setUserSelect(document.getElementsByClassName("PdfPageDisplayTextLayer"));
            }
        },
        SetTextModePDF: function(){
            if(_IsPDFSession()){
                if (_zoomButton) {
                    _setZoomOnButton(_zoomButtonScale);
                }
                _cursorMode = "text";
                _setUserSelect(document.getElementsByClassName("PdfPageDisplayTextLayer"));
            }
        },
        SetPdfToolbar: function(parentId, enabled, groups) {
            if(_IsPDFSession()){
                var parent = document.getElementById(parentId);
                _toolbarEnabled = enabled;
                if (groups) {
                    _toolbarGroups = groups;
                    var i = 0;
                    _toolbarGroupsLoaded.targetFull = 0;
                    _toolbarGroupsLoaded.targetMini = 1;
                    for (var value in groups) {
                        if (value) {
                            _toolbarGroupsLoaded.targetFull += _toolbarGroupsValues.full[i];
                            _toolbarGroupsLoaded.targetMini += _toolbarGroupsValues.mini[i];
                        }
                        i++;
                    }
                }
                if (enabled) {
                    _DisplayDocumentToolbar(parent, _toolbarGroups);
                    _resizeDocumentToolbar(parent, _toolbarGroups);
                } else {
                    _RemoveDocumentToolbar(parent);
                }
            }
        },
        SetPdfToolbarGroups: function (groups) {
            _toolbarGroups = groups;
        },
        ShowPdfBookmark: function(bookmarkTitle) {
            if(_IsPDFSession()){
                _ShowPdfBookmark(bookmarkTitle);
            }
        },
        SearchInPdfDocument: function(searchTerm){
            if(_IsPDFSession() && searchTerm != ""){
                _SearchInPdfDocument(searchTerm);
            }
        },
        ClearPdfDocumentSearch: function () {
            if(_IsPDFSession()){
                _searchResults = [];
                _searchTerm = "";
                _removePdfSearchResultHighlights ();
            }
        },
        FocusNextPdfDocumentSearch: function () {
            if(_IsPDFSession() && _searchResults.length > 1){
                if(_searchResultFocus == _searchResults.length-1){
                    _focusPdfSearchResult(0);
                } else {
                    _focusPdfSearchResult(_searchResultFocus+1);
                }
            }
        },
        FocusPrevPdfDocumentSearch: function () {
            if(_IsPDFSession() && _searchResults.length > 1){
                if(_searchResultFocus == 0){
                    _focusPdfSearchResult(_searchResults.length-1);
                } else {
                    _focusPdfSearchResult(_searchResultFocus-1);
                }
            }
        },
        SetPdfSearchCaseMatch: function (matchCase) {
            if(_IsPDFSession()){
                _searchCaseMatch = matchCase;
            }
        },
        SetPdfSearchWordMatch: function (matchWord) {
            if(_IsPDFSession()){
                _searchWordMatch = matchWord;
            }
        },
        TogglePdfSidePane: function () {
            if (_IsPDFSession()) {
                _togglePdfSidePane();
            }
        },
        RotateDocumentPages: function (clockwise) {
            if (_IsPDFSession()) {
                if (clockwise) {
                    _RotateDocumentPages(90 + _pageRotation);
                } else {
                    _RotateDocumentPages(_pageRotation - 90);
                }
            }
        },
        PrintPdf: function () {
            if (_IsPDFSession() && _printEnabled) {
                _PrintPdf(document.getElementById(_currentCanvasId).parentNode.parentNode);
            }
        },
        LoadPdfAnnotationSet: function(documentViewable, parentCanvasId, docScene, structure, annoSet, documentCallback) {
            _LoadPdfAnnotationSet(documentViewable, parentCanvasId, docScene, structure, annoSet, documentCallback);
        },
        ApplyPdfAnnotationSet: function(annoSet, documentCallback) {
            _ApplyPdfAnnotationSet(annoSet, documentCallback);
        }
    };
    
    extendObject(ThingView, returnObj);

    //Private Functions
    
    //SHARED
    function extendObject (obj1, obj2) {
        for (var key in obj2) {
            if (obj2.hasOwnProperty(key)) {
                obj1[key] = obj2[key];
            }
        }
        return obj1;
    }
    
    function _stringToFloatArray(string) {
        var stringArray = string.split(", ");
        var floatArray = [];
        for (var i = 0; i < stringArray.length; i++){
            floatArray.push(parseFloat(stringArray[i]));
        }
        return floatArray;
    }
    
    function _LoadDocument(viewable, parentCanvasId, model, callback){
        if(viewable && model){
            if(viewable.type==Module.ViewableType.DOCUMENT && viewable.fileSource.indexOf(".pdf", viewable.fileSource.length - 4) != -1){
                if (!_IsPDFSession()){
                    _createPDFSession(parentCanvasId, function(){
                        _cursorMode = "pan";
                        _pageMode = "Original";
                        _bookmarks = [];
                        _documentLoaded = false;
                        model.GetFromLoadedDataSource(viewable.idPath, viewable.index, function(val){
                            _LoadPDF(val, callback);
                        });
                    });
                } else {
                    model.GetFromLoadedDataSource(viewable.idPath, viewable.index, function(val){
                        _LoadPDF(val, callback)
                    });
                }
            }
            else if (viewable.type==Module.ViewableType.ILLUSTRATION && viewable.fileSource.indexOf(".svg", viewable.fileSource.length - 4) != -1){
                if(!_IsSVGSession()){
                    _createSVGSession(parentCanvasId);
                }
                model.GetFromLoadedDataSource(viewable.idPath, viewable.index, function(val){
                    _LoadSVG(decodeURIComponent(escape(val)), callback);
                });
            } else callback(false);
        } else {
            callback(false);
        }
    }
    
    function _LoadPdfFromBuffer (parentCanvasId, buffer, callback){
        if (parentCanvasId && buffer) {
            if (!_IsPDFSession()){
                _createPDFSession(parentCanvasId, function(){
                    _documentLoaded = false;
                    _cursorMode = "pan";
                    _pageMode = "Original";
                    _bookmarks = [];
                    _pdfAnnotationId = -1;
                    _pdfParsedAnnotationSet = [];
                    _LoadPDF(buffer, callback);
                });
            } else {
                _LoadPDF(buffer, callback);
            }
        }
    }
    
    function _resetTransform(elem){
        _setTransformMatrix(elem, 1, 0, 0, 1, 0, 0);
    }
    
    function _destroy2DCanvas(){
        _removeWindowEventListenersSVG();
        _removeWindowEventListenersPDF();
        var currentCanvas =  document.getElementById(_currentCanvasId);
        var parent = currentCanvas.parentNode;
        parent.style.cursor = "auto";
        parent.removeChild(currentCanvas);
        if(_IsPDFSession()){
            _RemoveDocumentToolbar(parent.parentNode);
            _RemovePdfSideBar (parent.parentNode);
            parent.parentNode.removeChild(document.getElementById("CreoDocumentScrollWrapper"));
        }
        _currentCanvasId = "";
    }
    
    //SVG
    function _createSVGSession(parentCanvasId){
        if(_IsPDFSession()){
            _destroy2DCanvas();
        }
        else if (!_IsSVGSession()){
            ThingView.Hide3DCanvas();
        }
        _currentCanvasId = "";
        var svgWrapper = document.createElement("div");
        var parent = document.getElementById(parentCanvasId);
        svgWrapper.id = parentCanvasId + "_CreoViewSVGDiv" + ThingView.GetNextCanvasID();
        var width = parent.clientWidth;
        var height = parent.clientHeight;
        svgWrapper.setAttribute('style',"position: relative; height: 100%; width: 100%; overflow: hidden");
        parent.style.overflow = "hidden";
        var svgHolder = document.createElement("div");
        svgHolder.setAttribute("type", "image/svg+xml");
        
        var deselect = {
            x:0,
            y:0
        };
        var drag = {
            x: 0,
            y: 0,
            state: false,
        };
        var rightClickDrag = {
            x: 0,
            y: 0,
            lastY: 0,
            state: false
        };
        var zoomDrag = {
            x1: 0,
            y1: 0,
            x2: 0,
            y2: 0,
            state: false
        };
        var zoomPinch = {
            xCenter: 0,
            yCenter: 0,
            oldXs : new Object(),
            oldYs : new Object(),
            newXs : new Object(),
            newYs : new Object(),
            state: false
        };
        var twoPointDrag = {
            x: 0,
            y: 0,
            state: false,
        };
        
        var rectCanvas = document.createElement("canvas");
        rectCanvas.setAttribute('style',"position: absolute; top: 0%; left: 0%");
        rectCanvas.setAttribute('width',width);
        rectCanvas.setAttribute('height',height);
        
        svgWrapper.addEventListener("wheel", _zoomOnWheelSVG);
        svgWrapper.addEventListener("dblclick", function(){
            if(!_zoomButton){
                _resetTransform(svgHolder);
            }
        },{passive: false});
        
        svgWrapper.addEventListener("mousedown", function(e){
            e.preventDefault();
            if (_zoomWindow) {
                _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
            } else if (_zoomButton) {
                _zoomOnButton(e);
            } else if (!drag.state && e.button==0) {
                _handlePanEvent(e, drag)
            } else if (!rightClickDrag.state && e.button==2) {
                _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper)
            }
            deselect.x = e.pageX;
            deselect.y = e.pageY;
        },{passive: false});
        
        svgWrapper.addEventListener("mouseup", function(e){
            e.preventDefault();
            if(_zoomWindow && zoomDrag.state){
                _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
            } else if(drag.state){
                _handlePanEvent(e, drag);
            } else if(rightClickDrag.state){
                _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper)
            }
            var target = String(e.target.className.baseVal);
            target = target != "" ? target : String(e.target.parentNode.className.baseVal);
            if(e.pageX == deselect.x && e.pageY == deselect.y && !(e.ctrlKey || e.metaKey) && !(target.indexOf("hotspot") != -1) && !(target.indexOf("callout") != -1)){
                _deselectAllCallouts();
            }
        }, {passive: false});
        
        svgWrapper.addEventListener("mousemove", function(e){
            e.preventDefault();
            if (!_zoomWindow) {
                if(drag.state){
                    _handlePanEvent(e, drag);
                } else if(rightClickDrag.state){
                    _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper);
                }
            } else if (_zoomWindow && zoomDrag.state) {
               _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
            }
        }, {passive: false});
        
        svgWrapper.addEventListener("mouseleave", function(){
            if (_zoomWindow && zoomDrag.state){
                window.addEventListener("mouseup", function(e){
                    if(_zoomWindow && zoomDrag.state){
                        _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
                    }
                });
                window.addEventListener("mousemove", function(e){
                    if (_zoomWindow && zoomDrag.state) {
                        _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
                    }
                });
            } else if(drag.state){
                window.addEventListener("mouseup", function(e){
                    if(drag.state){
                        _handlePanEvent(e, drag);
                    }
                });
                window.addEventListener("mousemove", function(e){
                    e.stopPropagation();
                    if(drag.state){
                        _handlePanEvent(e, drag);
                    }
                });
            } else if (rightClickDrag.state){
                window.addEventListener("mouseup", function(e){
                    if(rightClickDrag.state){
                        _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper)
                    }
                });
                window.addEventListener("mousemove", function(e){
                    e.stopPropagation();
                    if(rightClickDrag.state){
                        _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper)
                    }
                });
            }
        },{passive: false});
        svgWrapper.addEventListener("mouseenter", function(){
            _removeWindowEventListenersSVG(drag, rightClickDrag, svgWrapper, zoomDrag);
        },{passive: false});
        
        var touchMoved = false;        
        svgWrapper.addEventListener("touchstart", function(e){
            touchMoved = false;
            if (e.touches.length <= 1) {
                if (_zoomWindow) {
                    _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
                } else if (_zoomButton) {
                    _zoomOnButton(e);
                } else {
                    _handlePanEvent(e, drag);
                }
            } else {
                _handleZoomOnPinchEvent(e, zoomPinch);
                _handleTwoPointPanEvent(e, twoPointDrag);
            }
        },{passive: false});
        
        var lastTap = 0;
        svgWrapper.addEventListener("touchend", function(e){
            e.preventDefault();
            if (!zoomPinch.state) {
                var currTime = new Date().getTime();
                var tapLength = currTime - lastTap;
                if (tapLength < 200 && tapLength > 0){
                    if(!_zoomButton){
                        _resetTransform(svgHolder);
                        drag.state = false;
                    }
                } else if(_zoomWindow && zoomDrag.state){
                    _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
                } else if(drag.state){
                    _handlePanEvent(e, drag);
                } else if(twoPointDrag.state) {
                    _handleTwoPointPanEvent(e, twoPointDrag);
                }
                lastTap = currTime;
                e.stopPropagation();
                if(!touchMoved && !(e.ctrlKey || e.metaKey)){
                    _deselectAllCallouts();
                }
            } else {
                _handleZoomOnPinchEvent(e, zoomPinch)
                if(drag.state){
                    _handlePanEvent(e, drag);
                } 
            }
            touchMoved = false;
        }, {passive: false});
        
        svgWrapper.addEventListener("touchmove", function(e){
            e.preventDefault();
            if (!zoomPinch.state) {
                if (!_zoomWindow) {
                    if (drag.state){
                        _handlePanEvent(e, drag);
                    }
                } else if (_zoomWindow && zoomDrag.state) {
                   _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
                }
            } else  if (zoomPinch.state && e.touches.length == 2){
                _handleZoomOnPinchEvent(e, zoomPinch);
            }
            if (twoPointDrag.state) {
                _handleTwoPointPanEvent(e, twoPointDrag);
            }
            touchMoved = true;
        }, {passive: false});
        
        svgWrapper.insertBefore(svgHolder, svgWrapper.childNodes[0]);
        svgHolder.setAttribute('style',"position: relative; height: inherit; width: inherit");
        parent.insertBefore(svgWrapper, parent.childNodes[0]);
        _currentCanvasId = svgWrapper.id;
        return;
    }
        
    function _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper){
        if (e.type == "mousedown" || e.type == "touchstart") {
            zoomDrag.x1 = e.type.indexOf("touch") != -1 ? e.touches[0].pageX : e.pageX;
            zoomDrag.y1 = e.type.indexOf("touch") != -1 ? e.touches[0].pageY : e.pageY;
            zoomDrag.state = true;
            rectCanvas.getContext('2d').clearRect(0,0,rectCanvas.width,rectCanvas.height);
            svgWrapper.insertBefore(rectCanvas, svgWrapper.childNodes[1]);
        } else if (e.type == "mouseup" || e.type == "touchend") {
            _zoomOnWindowSVG(e, zoomDrag);
            svgWrapper.removeChild(rectCanvas);
            zoomDrag.state = false;
            _setZoomWindow();
        } else if (e.type == "mousemove" || e.type == "touchmove") {
            _drawZoomWindow(rectCanvas, zoomDrag, e);
            zoomDrag.x2 = e.type.indexOf("touch") != -1 ? e.touches[0].pageX : e.pageX;
            zoomDrag.y2 = e.type.indexOf("touch") != -1 ? e.touches[0].pageY : e.pageY;
        }
    }
    
    function _handlePanEvent(e, drag){
        if (e.type == "mousedown" || e.type == "touchstart") {
            drag.x = e.type.indexOf("touch") != -1 ? Math.floor(e.touches[0].pageX) : e.pageX;
            drag.y = e.type.indexOf("touch") != -1 ? Math.floor(e.touches[0].pageY) : e.pageY;
            drag.state = true;
        } else if (e.type == "mouseup" || e.type == "touchend") {
            document.body.style.cursor = "auto";
            drag.state = false;
        } else if (e.type == "mousemove" || e.type == "touchmove") {
            document.body.style.cursor = "url(" + ThingView.resourcePath + "/cursors/pan.cur),auto";
            _panSVG(e, drag);
        }
    }
    
    function _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper){
        if (e.type == "mousedown") {
            rightClickDrag.x = e.pageX;
            rightClickDrag.y = e.pageY;
            rightClickDrag.lastY = e.pageY;
            rightClickDrag.state = true;
            svgWrapper.oncontextmenu = function(){return true;}
        } else if (e.type == "mouseup") {
            document.body.style.cursor = "auto";
            rightClickDrag.state = false;
        } else if (e.type == "mousemove") {
            svgWrapper.oncontextmenu = function(){return false;}
            document.body.style.cursor = "url(" + ThingView.resourcePath + "/cursors/zoom.cur),auto";
            _zoomOnRightClickSVG(e, rightClickDrag);
        }        
    }
    
    function _handleZoomOnPinchEvent(e, zoomPinch){
        var lastTouch = 0;
        if (e.type == "touchstart") {
            var touchCenter = _getTouchCenter(e);
            zoomPinch.xCenter = touchCenter.x;
            zoomPinch.yCenter = touchCenter.y;
            zoomPinch.oldXs = {x0: e.touches[0].pageX, x1: e.touches[1].pageX};
            zoomPinch.oldYs = {y0: e.touches[0].pageY, y1: e.touches[1].pageY};
            zoomPinch.state = true;
        } else if (e.type == "touchend") {
            zoomPinch.state = false;
        } else if (e.type == "touchmove") {
            zoomPinch.newXs = {x0: e.touches[0].pageX, x1: e.touches[1].pageX};
            zoomPinch.newYs = {y0: e.touches[0].pageY, y1: e.touches[1].pageY};
            _zoomOnPinch(e, zoomPinch);
        }
    }
    
    function _handleTwoPointPanEvent(e, twoPointDrag){
        if (e.type == "touchstart") {
            var touchCenter = _getTouchCenter(e);
            twoPointDrag.x = touchCenter.x;
            twoPointDrag.y = touchCenter.y;
            twoPointDrag.state = true;
        } else if (e.type == "touchend") {
            twoPointDrag.state = false;
        } else if (e.type == "touchmove") {
            _panSVG(e, twoPointDrag);
        }
    }
        
    function _removeWindowEventListenersSVG(drag, rightClickDrag, svgWrapper, zoomDrag) {
        window.removeEventListener("mouseup", function(e){
            if(_zoomWindow && zoomDrag.state){
                _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
            }
        });
        window.removeEventListener("mousemove", function(e){
            if (_zoomWindow && zoomDrag.state) {
                _handleZoomWindowEvent(e, zoomDrag, rectCanvas, svgWrapper);
            }
        });
        window.removeEventListener("mouseup",function(){
            if(drag.state){
                _handlePanEvent(e, drag);
            }
        });
        window.removeEventListener("mousemove", function(e){
            e.stopPropagation();
            if(drag.state){
                _handlePanEvent(e, drag);
            }
        });
        window.removeEventListener("mouseup", function(){
            if(rightClickDrag.state){
                _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper)
            }
        });
        window.removeEventListener("mousemove", function(e){
            e.stopPropagation();
            if(rightClickDrag.state){
                _handleRightClickZoomEvent(e, rightClickDrag, svgWrapper)
            }
        });
    }
        
    function _getTransformMatrix(svgHolder){
        var svgTransform = getComputedStyle(svgHolder).getPropertyValue('transform');
        if(svgTransform=="none"){
            svgTransform = "matrix(1, 0, 0, 1, 0, 0)";
        }
        var matrix = svgTransform.replace(/[^\d.,-]/g, '').split(',').map(Number);
        return matrix;
    }
    
    function _setTransformMatrix(elem, scaleX, skewX, skewY, scaleY, transX, transY){
        var newTransform = "transform: matrix(" + scaleX + "," + skewX + "," + skewY + "," + scaleY + "," + transX + "," + transY + ")";
        var currentStyle = elem.style.cssText;
        var newStyle = "";
        if(currentStyle.indexOf("transform") != -1) {
            var i = currentStyle.indexOf("transform");
            var j = currentStyle.indexOf(";", i)+1;
            newStyle = currentStyle.substr(0, i) + currentStyle.substr(j);
        } else {
            newStyle = currentStyle;
        }
        newStyle = newStyle + newTransform;
        elem.setAttribute('style',newStyle);
    }
    
    function _getTouchCenter (e){
        var sumX = 0;
        var sumY = 0;
        for (var i=0; i < e.touches.length; i++){
            sumX += e.touches[i].pageX;
            sumY += e.touches[i].pageY;
        }        
        return {x: Math.floor(sumX / i), y: Math.floor(sumY / i)};
    }
    
    function _panSVG(e, drag){
        e.preventDefault();
        var pageX = e.type.indexOf("touch") == -1 ? e.pageX : _getTouchCenter(e).x;
        var pageY = e.type.indexOf("touch") == -1 ? e.pageY : _getTouchCenter(e).y;
        var svgHolder = document.getElementById(_currentCanvasId).childNodes[0];
        var deltaX = pageX - drag.x;
        var deltaY = pageY - drag.y;
        var matrix = _getTransformMatrix(svgHolder);
        _setTransformMatrix(svgHolder, matrix[0], matrix[1], matrix[2], matrix[3], (matrix[4] + deltaX), (matrix[5] + deltaY));
        drag.x = pageX;
        drag.y = pageY;
    }
    
    function _getElementCenter(elem) {
        var boundingRect = elem.getBoundingClientRect();
        var centerX = (boundingRect.left + boundingRect.right)/2;
        var centerY = (boundingRect.top + boundingRect.bottom)/2;
        return {x: centerX, y: centerY}
    }
    
    function _zoomOnWheelSVG(e){
        var ZOOMMODIFIER = 0.15
        var MAXZOOM = 10.0
        var MINZOOM = 0.15
        
        var svgHolder = e.currentTarget.childNodes[0];
        var center = _getElementCenter(svgHolder);
        var mouseDeltaX = (center.x - e.pageX) * ZOOMMODIFIER;
        var mouseDeltaY = (center.y - e.pageY) * ZOOMMODIFIER;

        var matrix = _getTransformMatrix(svgHolder);
        
        var delta = e.deltaY > 0 ? 1 : -1;
        
        var newScale = matrix[0] * (1 + (delta * ZOOMMODIFIER));
        if ((newScale <= MAXZOOM && delta == 1) || (newScale >= MINZOOM && delta == -1)) {
            _setTransformMatrix(svgHolder, newScale, matrix[1], matrix[2], newScale,(matrix[4] + (mouseDeltaX * delta)), (matrix[5] + (mouseDeltaY * delta)));
        }
    }
    
    function _setZoomOnButton(scale){
        if(!_zoomButtonScale || !(_zoomButton && _zoomButtonScale != scale)) {
            _zoomButton = !_zoomButton;
        }
        if(_zoomButton) {
            _zoomButtonScale = scale;
            document.body.style.cursor = "url(" + ThingView.resourcePath + "/cursors/zoom.cur),auto";
            document.addEventListener('keydown', function(e){
                if (e.key == "Escape" && _zoomButton) {
                    _setZoomOnButton(scale);
                }
            });
        } else {
            document.body.style.cursor = "auto";
            document.removeEventListener('keydown', function(e){
                if (e.key == "Escape" && _zoomButton) {
                    _setZoomOnButton(scale);
                }
            });
        }
    }
    
    function _zoomOnButton(e) {
        var MAXZOOM = 10.0
        var MINZOOM = 0.15
        
        var svgHolder = e.currentTarget.childNodes[0];
        var center = _getElementCenter(svgHolder);
        
        var pageX = e.type.indexOf("touch") != -1 ? e.touches[0].pageX : e.pageX;
        var pageY = e.type.indexOf("touch") != -1 ? e.touches[0].pageY : e.pageY;
        
        var mouseDeltaX = _zoomButtonScale < 1 ? (center.x - pageX) * (1 - _zoomButtonScale) : (center.x - pageX) * (_zoomButtonScale - 1);
        var mouseDeltaY = _zoomButtonScale < 1 ? (center.y - pageY) * (1 - _zoomButtonScale) : (center.y - pageY) * (_zoomButtonScale - 1);

        var matrix = _getTransformMatrix(svgHolder);
        
        var delta = _zoomButtonScale >= 1 ? 1 : -1;
        
        var newScale = matrix[0] * _zoomButtonScale; 
        if ((newScale <= MAXZOOM && delta == 1) || (newScale >= MINZOOM && delta == -1)) {
            _setTransformMatrix(svgHolder, newScale, matrix[1], matrix[2], newScale,(matrix[4] + (mouseDeltaX * delta)), (matrix[5] + (mouseDeltaY * delta)));
        }
    }

    function _zoomOnRightClickSVG(e, drag){
        e.preventDefault();
        var ZOOMMODIFIER = 0.05
        var MAXZOOM = 10.0
        var MINZOOM = 0.15
        
        var svgHolder = document.getElementById(_currentCanvasId).childNodes[0];
        var matrix = _getTransformMatrix(svgHolder);
        var center = _getElementCenter(svgHolder);
        var mouseDeltaX = (center.x - drag.x) * ZOOMMODIFIER;
        var mouseDeltaY = (center.y - drag.y) * ZOOMMODIFIER;
        
        var delta = (drag.lastY - e.pageY) > 0 ? 1 : (drag.lastY - e.pageY) < 0 ? -1 : 0;
        
        var newScale = matrix[0] * (1 + (delta * ZOOMMODIFIER));
        if ((newScale <= MAXZOOM && delta == 1) || (newScale >= MINZOOM && delta == -1)) {
            _setTransformMatrix(svgHolder, newScale, matrix[1], matrix[2], newScale,(matrix[4] + (delta * mouseDeltaX)), (matrix[5] + (delta * mouseDeltaY)));
        }
        drag.lastY = e.pageY;
    }
    
    function _setZoomWindow(){
        _zoomWindow = !_zoomWindow;
        if (_zoomWindow) {
            document.body.style.cursor = "url(" + ThingView.resourcePath + "/cursors/fly_rectangle.cur),auto";
            document.addEventListener('keydown', function(e){
                _zoomWindowEscapeListener(e);
            });
        } else {
            document.body.style.cursor = "auto";
            document.removeEventListener('keydown', function(e){
                _zoomWindowEscapeListener(e);
            });
        }
    }
    
    function _drawZoomWindow(rectCanvas, zoomDrag, e){
        var boundingClientRect = rectCanvas.getBoundingClientRect();
        var pageX = e.type.indexOf("touch") != -1 ? e.touches[0].pageX : e.pageX;
        var pageY = e.type.indexOf("touch") != -1 ? e.touches[0].pageY : e.pageY;
        var rectW = (pageX-boundingClientRect.left) - (zoomDrag.x1-boundingClientRect.left);
        var rectH = (pageY-boundingClientRect.top) - (zoomDrag.y1-boundingClientRect.top);
        var context = rectCanvas.getContext('2d');
        context.clearRect(0,0,rectCanvas.width,rectCanvas.height);
        context.strokeStyle = "#96ed14";
        context.fillStyle = "rgba(204,204,204,0.5)";
        context.lineWidth = 1;
        context.strokeRect((zoomDrag.x1-boundingClientRect.left), (zoomDrag.y1-boundingClientRect.top), rectW, rectH);
        context.fillRect((zoomDrag.x1-boundingClientRect.left), (zoomDrag.y1-boundingClientRect.top), rectW, rectH);
    }
    
    function _zoomWindowEscapeListener(e){
        if (e.key == "Escape" && _zoomWindow) {
            document.body.style.cursor = "auto";
            if(_IsSVGSession()){
                var svgWrapper = document.getElementById(_currentCanvasId);
                if(svgWrapper.childNodes.length > 1){
                    svgWrapper.removeChild(svgWrapper.childNodes[1]);
                }
            }
            _setZoomWindow();
        }
    }
    
    function _zoomOnWindowSVG(e, zoomDrag){
        var svgHolder = document.getElementById(_currentCanvasId).childNodes[0];
        
        if(zoomDrag.x1 > zoomDrag.x2){
            zoomDrag.x1 = [zoomDrag.x2, zoomDrag.x2=zoomDrag.x1][0];
        }
        if(zoomDrag.y1 > zoomDrag.y2){
            zoomDrag.y1 = [zoomDrag.y2, zoomDrag.y2=zoomDrag.y1][0];
        }
        
        var width = zoomDrag.x2 - zoomDrag.x1;
        var height = zoomDrag.y2 - zoomDrag.y1;
        var holderAspectRatio = svgHolder.clientWidth / svgHolder.clientHeight;
        var zoomAspectRatio = width / height;
        var zoomModifier = (width > height && holderAspectRatio < zoomAspectRatio) ? (svgHolder.clientWidth / width) - 1 : (svgHolder.clientHeight / height) - 1;

        var center = _getElementCenter(svgHolder);
        var newCenterX = zoomDrag.x1 + width/2;
        var newCenterY = zoomDrag.y1 + height/2;
        var deltaX = (center.x - newCenterX) * (1 + zoomModifier);
        var deltaY = (center.y - newCenterY) * (1 + zoomModifier);
        
        var matrix = _getTransformMatrix(svgHolder);
        _setTransformMatrix(svgHolder, (matrix[0] * (1 + zoomModifier)), matrix[1], matrix[2], (matrix[0] * (1 + zoomModifier)), (matrix[4] + deltaX), (matrix[5] + deltaY)); 
        
    }
    
    function _zoomOnPinch(e, zoomPinch) {
        var oldHypth = Math.sqrt(Math.pow(zoomPinch.oldXs.x0 - zoomPinch.oldXs.x1,2) + Math.pow(zoomPinch.oldYs.y0 - zoomPinch.oldYs.y1,2));
        var newHypth = Math.sqrt(Math.pow(zoomPinch.newXs.x0 - zoomPinch.newXs.x1,2) + Math.pow(zoomPinch.newYs.y0 - zoomPinch.newYs.y1,2));
        var delta = (newHypth - oldHypth);
        
        if (delta!=0) {
            var ZOOMMODIFIER = 0.015 * delta;
            var MAXZOOM = 10.0;
            var MINZOOM = 0.15;
            
            var svgHolder = e.currentTarget.childNodes[0];
            var center = _getElementCenter(svgHolder);
            var mouseDeltaX = (center.x - zoomPinch.xCenter) * ZOOMMODIFIER;
            var mouseDeltaY = (center.y - zoomPinch.yCenter) * ZOOMMODIFIER;
            
            var matrix = _getTransformMatrix(svgHolder);
            var newScale = matrix[0] * (1 + ZOOMMODIFIER);
            if(newScale <= MAXZOOM && newScale >= MINZOOM){
                _setTransformMatrix(svgHolder, newScale, matrix[1], matrix[2], newScale,(matrix[4] + mouseDeltaX), (matrix[5] + mouseDeltaY));                
            }
            
            zoomPinch.oldXs.x0 = zoomPinch.newXs.x0;
            zoomPinch.oldXs.x1 = zoomPinch.newXs.x1;
            zoomPinch.oldYs.y0 = zoomPinch.newYs.y0;
            zoomPinch.oldYs.y1 = zoomPinch.newYs.y1;
        }
    }
    
    function _IsSVGSession()
    {
        var retVal = false;
        if (!_currentCanvasId=="") {
            retVal = _currentCanvasId.indexOf("_CreoViewSVGDiv") != -1 ? true : false;
        }
        return retVal;
    }
    
    function _LoadSVG(val, callback){
        if(_IsSVGSession())
        {
            var canvasId = _currentCanvasId;
            var svgHolder = document.getElementById(canvasId).childNodes[0];
            _resetTransform(svgHolder);
            svgHolder.innerHTML = val;
            _setCalloutListeners(svgHolder);
            var svg = svgHolder.getElementsByTagName("svg")[0];
            svg.setAttribute('height',"100%");
            svg.setAttribute('width',"100%");
            _calloutsSelected = [];
            _partsSelected = [];
            _calloutColors = [];
            callback(true);
        }
    }
    
    function _getCallouts(){
        var svgHolder = document.getElementById(_currentCanvasId).childNodes[0];
        var callouts = svgHolder.querySelectorAll('[class^="callout"]');
        return callouts;
    }
    
    function _getSVGElementColors(elem, colorsList){
        var colors = [];
        colors[0] = elem.id;
        for (var i = 1; i < elem.childNodes.length; i++){
            colors = _addNodeColor(elem.childNodes[i], colors);
        }
        colorsList.push(colors);
    }
    
    function _addNodeColor(node, colors){
        var obj = new Object();
        if(node.nodeName == "path" || node.nodeName == "line" || node.nodeName == "text" || node.nodeName == "polyline"){
            obj['fill'] = node.getAttribute("fill") ? node.getAttribute("fill") : null;
            obj['stroke'] = node.getAttribute("stroke") ? node.getAttribute("stroke") : null;
            colors.push(obj);
        } else if(node.nodeName == "g") {
            for (var i = 0; i < node.childNodes.length; i++){
                colors = _addNodeColor(node.childNodes[i], colors);
            }
        }
        return colors;
    }
    
    function _setCalloutListeners(svgHolder){
        var hotspots = svgHolder.querySelectorAll('[class^="hotspot"]');
        if(hotspots.length==0){
            hotspots = svgHolder.querySelectorAll('[class^="callout"]');            
        }
        var startX = 0;
        var startY = 0;
        var touchMoved = false;
        for (var i=0; i < hotspots.length; i++){
            hotspots[i].addEventListener("mousedown", function(e){
                startX = e.pageX;
                startY = e.pageY;
            }, false);
            hotspots[i].addEventListener("mouseup", function(e){
                if(startX == e.pageX && startY == e.pageY){
                    if (!(e.ctrlKey || e.metaKey)) {
                        _deselectAllCallouts();
                    }
                    _toggleCalloutSelection(e);
                }
            }, false);
            hotspots[i].addEventListener("touchstart", function(e){
                touchMoved = false;
            });
            hotspots[i].addEventListener("touchmove", function(e){
                touchMoved = true;
            });
            hotspots[i].addEventListener("touchend", function(e){
                if(!touchMoved){
                    e.stopPropagation();
                    e.preventDefault();
                    if (!(e.ctrlKey || e.metaKey)) {
                        _deselectAllCallouts();
                    }
                    _toggleCalloutSelection(e);
                    touchMoved = false;
                }
            }, {passive: false});
        }
    }  
    
    function _getCalloutForToggle(e){
        var targetClass = e.currentTarget.getAttribute("class");
        if (targetClass.indexOf("callout") != -1){
            return e.currentTarget;
        } else if(targetClass.indexOf("hotspot") != -1){
            var noIndex = targetClass.indexOf("_");
            var calloutNo = targetClass.substr(noIndex);
            var svgHolder = document.getElementById(_currentCanvasId).childNodes[0];
            var callouts = svgHolder.querySelectorAll('[class^="callout"]');
            var callout;
            for (var i=0; i<callouts.length; i++){
                if(callouts[i].getAttribute('class').indexOf(calloutNo, callouts[i].getAttribute('class').length - calloutNo.length) != -1){
                    callout = callouts[i];
                }
            }
            return callout;
        } else {
            return;
        }
    }
    
    function _toggleCalloutSelection(e){
        var callout = _getCalloutForToggle(e);
        if(callout){
            if (_calloutsSelected.indexOf(callout.id) != -1){
                _deselectCallout(callout);
                var index = _calloutsSelected.indexOf(callout.id);
                if (index !=-1){
                    _calloutsSelected.splice(index,1);
                }
            } else {
                _selectCallout(callout);
            }
            if(_svgCalloutCB){
                _svgCalloutCB(callout.id);
            }
        }
    }
    
    function _setSVGElementColors(callout, mainColor, textColor){
        _setNodeColor(callout.childNodes[0], mainColor, textColor, false);
    }
    
    function _setNodeColor(node, mainColor, textColor, background){
        if(node){
            if (node.nodeName == "path") {
                if (node.getAttribute("fill")) {
                    node.setAttribute("fill", mainColor);
                    background = true;
                }
            }
            if (node.nodeName == "path" || node.nodeName == "line" || node.nodeName == "polyline") {
                node.setAttribute("stroke", mainColor);
            } else if (node.nodeName == "text") {
                if (background) {
                    node.setAttribute("fill", textColor);
                } else {
                    node.setAttribute("fill", mainColor);
                }
            } else if (node.nodeName == "g"){
                _setNodeColor(node.childNodes[0], mainColor, textColor, background);
                for (var i = 0; i < node.childNodes.length; i++) {
                    if (node.childNodes[i].nodeName == "path" && node.childNodes[i].getAttribute("fill")) {
                        background = true;
                    }
                }
            }
            _setNodeColor(node.nextSibling, mainColor, textColor, background)
        }
    }
    
    function _resetSVGElementColors (elem, colorsList){
        var colors = [];
        for (var i = 0; i < colorsList.length; i++){
            if (colorsList[i][0] == elem.id) {
                colors = colorsList[i];
                break;
            }
        }
        colors.shift();
        _resetNodeColor(elem.childNodes[0], colors);
        colorsList.splice(colorsList.indexOf(colors), 1);
    }
    
    function _resetNodeColor (node, colors){
        if (node) {
            if (node.nodeName == "line" || node.nodeName == "path" || node.nodeName == "text" || node.nodeName == "polyline") {
                var obj = colors.shift();
                if(obj['fill'] != null){
                    node.setAttribute('fill', obj['fill']);
                } else {
                    node.removeAttribute('fill');
                }
                if (obj['stroke'] != null){
                    node.setAttribute('stroke', obj['stroke']);
                } else {
                    node.removeAttribute('stroke');
                }
            } else if (node.nodeName == "g") {
                _resetNodeColor(node.childNodes[0], colors);
            }
            _resetNodeColor(node.nextSibling, colors);
        }
    }
    
    function _selectCallout(callout){
        _getSVGElementColors(callout, _calloutColors);
        _setSVGElementColors(callout, "rgb(102,153,255)", "rgb(255,255,255)");
        _calloutsSelected.push(callout.id);
        var parts = _getSVGParts(callout.getElementsByTagName("desc")[0].textContent);
        if(parts.length > 0){
        _selectSVGPart(parts);
        }
    }
    
    function _deselectAllCallouts(){
        for (var j=0; j<_calloutsSelected.length; j++){
            var callout = document.getElementById(_calloutsSelected[j]);
            _deselectCallout(callout);
            if(_svgCalloutCB) {
                _svgCalloutCB(callout.id);
            }
        }
        _calloutsSelected = [];
    }
    
    function _deselectCallout(callout){
        _resetSVGElementColors(callout, _calloutColors);
        var parts = _getSVGParts(callout.getElementsByTagName("desc")[0].textContent);
        if(parts.length > 0){
        _deselectSVGPart(parts);
        }
    }
    
    function _getSVGParts(partNo){
        return document.getElementsByClassName("part part_" + partNo);
    }
  
    function _selectSVGPart(parts){
        for (var i = 0; i < parts.length; i++){
            var part = parts.item(i);
            if(part){
                _getSVGElementColors(part, _partColors);
                _setSVGElementColors(part, "rgb(102,153,255)", "rgb(0,0,0)");
                _partsSelected.push(part.id);
            }
        }
    }
    
    function _deselectSVGPart(parts){
        for (var i = 0; i < parts.length; i++){
            var part = parts.item(i);
            if(part){
                _resetSVGElementColors(part, _partColors);
                var index = _partsSelected.indexOf(part.id);
                if (index !=-1){
                    _partsSelected.splice(index,1);
                }
            }
        }
    }
    
    //PDF
    function _createPDFSession(parentCanvasId, callback) {
        
        if(_IsSVGSession()){
            _destroy2DCanvas();
        }
        else if (!_IsPDFSession()){
            ThingView.Hide3DCanvas();
        }
        var head = document.getElementsByTagName('head').item(0);
        if (!document.getElementById("pdfjs")) {
            var script_pdf = document.createElement("SCRIPT");
            script_pdf.src = ThingView.modulePath + "pdfjs/pdf.js";
            script_pdf.id = "pdfjs";
            script_pdf.async = false;
            head.appendChild(script_pdf);

            script_pdf.onload = function() {
                PDFJS.workerSrc = ThingView.modulePath + "pdfjs/pdf.worker.js";
                _buildPDFSession(parentCanvasId, callback);
            }
        } else {
            _buildPDFSession(parentCanvasId, callback);
        }
        return;
    }
    
    function _buildPDFSession(parentCanvasId, callback){
        _currentCanvasId = "";
        var canvasWrapper = document.createElement("div");
        var parent = document.getElementById(parentCanvasId);
        _parentCanvasId = parentCanvasId;
        parent.style.fontSize = "12pt";
        canvasWrapper.id = parentCanvasId + "_CreoViewDocumentCanvas" + ThingView.GetNextCanvasID();
        canvasWrapper.setAttribute('style', "min-height: 100%; background-color: #80858E; position: absolute")
        
        var scrollWrapper = document.createElement("div");
        scrollWrapper.id = "CreoDocumentScrollWrapper";
        scrollWrapper.setAttribute('style', "overflow: auto; position: relative; height: 100%; -webkit-overflow-scrolling: touch");
        scrollWrapper.appendChild(canvasWrapper);
        parent.insertBefore(scrollWrapper, parent.childNodes[0]);
        parent.style.overflow = "hidden";
        _currentCanvasId = canvasWrapper.id;        
        if ((/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) || /android/.test(navigator.userAgent)) {
            _printEnabled = false;
            _toolbarGroups.print = false;
        } else if (_printEnabled) {
            _addPdfPrintClass(parent);
        }
        _RemoveDocumentToolbar (parent)
        if (_toolbarEnabled){
            _DisplayDocumentToolbar(parent, _toolbarGroups);
        }                
        var drag = {
            x: 0,
            y: 0,
            state: false,
        };
        
        window.addEventListener("keydown", _changePageOnKey);
        
        window.addEventListener("resize", _handleBrowserResize);
        
        scrollWrapper.addEventListener("scroll", _handlePagesOnScroll);
        
        canvasWrapper.addEventListener("wheel", _changePageOnScroll);
        
        canvasWrapper.addEventListener("mousedown", function(e){
            if (_zoomButton) {
                _zoomButtonPDF();
            } else if (_cursorMode == "pan" && e.button == 0) {
                _handlePanEventPDF(e, drag);
            }
        });
        
        canvasWrapper.addEventListener("mouseup", function(e){
            if (drag.state) {
                _handlePanEventPDF(e, drag);
            }
        });
        
        canvasWrapper.addEventListener("mousemove", function(e){
            if (drag.state) {
                _handlePanEventPDF(e, drag);
            }
        });
        
        canvasWrapper.addEventListener("mouseleave", function(e){
            if (drag.state){
                window.addEventListener("mousemove", function(e){
                    if (drag.state) {
                        _handlePanEventPDF(e, drag);
                    }
                });
                window.addEventListener("mouseup", function(e){
                    if (drag.state) {
                        _handlePanEventPDF(e, drag);
                    }
                });
            }
        });
        
        canvasWrapper.addEventListener("mouseenter", function(e){
            window.removeEventListener("mousemove", function(e){
                    if (drag.state) {
                        _handlePanEventPDF(e, drag);
                    }
                });
            window.removeEventListener("mouseup", function(e){
                    if (drag.state) {
                        _handlePanEventPDF(e, drag);
                    }
                });
        });
        
        var lastTap = 0;
        canvasWrapper.addEventListener("touchend", function(e){
            e.preventDefault();
            if (!_zoomButton) {
                var currTime = new Date().getTime();
                var tapLength = currTime - lastTap;
                if (tapLength < 200 && tapLength > 0){
                        _resetTransformPDF();
                        drag.state = false;
                    }
                lastTap = currTime;
            } else {
                _zoomButtonPDF();
            }
        });
        
        callback();
    }
    
    function _getPDFCanvas() {
        var sessionCanvas = document.createElement("canvas");
        var context = sessionCanvas.getContext('2d');
        sessionCanvas.style.display = "inline-block";
        sessionCanvas.oncontextmenu = function (e) {
            e.preventDefault();
            return false;
        };
        return sessionCanvas;
    }
    
    function _removeWindowEventListenersPDF() {
        window.removeEventListener("resize", _handleBrowserResize);
        window.removeEventListener("keydown", _changePageOnKey);
        window.removeEventListener("mousemove", function(e){
            if (drag.state) {
                _handlePanEventPDF(e, drag);
            }
        });
        window.removeEventListener("mouseup", function(e){
            if (drag.state) {
                _handlePanEventPDF(e, drag);
            }
        });
        if (_printEnabled) {
            window.removeEventListener('afterprint', _removePdfPrintDiv);
        }
        document.getElementById(_currentCanvasId).parentNode.removeEventListener("scroll", _changePageOnScroll);
    }
    
    function _handlePanEventPDF(e, drag) {
        if (e.type == "mousedown") {
            drag.x = e.pageX;
            drag.y = e.pageY;
            drag.state = true;
        } else if (e.type == "mousemove") {
            document.body.style.cursor = "url(" + ThingView.resourcePath + "/cursors/pan.cur),auto";
            _panPDF(e, drag);
        } else if (e.type == "mouseup") {
            document.body.style.cursor = "auto";
            drag.state = false;
        }
    }
    
    function _panPDF(e, drag) {
        e.preventDefault();
        var deltaX = 0 - (e.pageX - drag.x);
        var deltaY = 0 - (e.pageY - drag.y);
        var scrollWrapper = document.getElementById(_currentCanvasId).parentNode;
        var scrollTop = scrollWrapper.scrollTop;
        var scrollLeft = scrollWrapper.scrollLeft;
        scrollWrapper.scrollTop = scrollTop + deltaY;
        scrollWrapper.scrollLeft = scrollLeft + deltaX;
        drag.x = e.pageX;
        drag.y = e.pageY;
    }
    
    function _changePageOnScroll() {
        if (!_ignoreScrollEvent) {
            var canvasWrapper = document.getElementById(_currentCanvasId);
            var scrollTop = canvasWrapper.parentNode.scrollTop;
            var traversedHeight = 0;
            var lineHeight = 0;
            var lineWidth = 0;
            var i = 1;
            for (i; i <= __TOTAL_PAGES; i++){
                var child = canvasWrapper.childNodes[i-1];
                if(child) {
                    var childHeight = child.height;
                    var childWidth = child.width;
                    if (_checkPageRotation()){
                        childHeight = child.width;
                        childWidth = child.height;
                    }
                    if (child.style.display == "block"){
                        lineWidth = 0;
                        traversedHeight += childHeight + _marginSize;
                        lineHeight = 0;
                    } else {
                        lineWidth += childWidth + _marginSize;
                        lineHeight = lineHeight < childHeight + _marginSize ? childHeight + _marginSize : lineHeight;
                        if (i < canvasWrapper.childNodes.length) {
                            if (_checkPageRotation()) {
                                if ((lineWidth + canvasWrapper.childNodes[i].height) > canvasWrapper.clientWidth) {
                                    lineWidth = 0;
                                    traversedHeight += lineHeight;
                                    lineHeight = 0;
                                }
                            } else {
                                if ((lineWidth + canvasWrapper.childNodes[i].width) > canvasWrapper.clientWidth) {
                                    lineWidth = 0;
                                    traversedHeight += lineHeight;
                                    lineHeight = 0;
                                }
                            }
                        }
                    }
                } else {
                    i = 1;
                    break;
                }
                if (_checkPageRotation()) {
                    if(traversedHeight >= (scrollTop + (child.width))) {
                        break;
                    }
                } else {
                    if(traversedHeight >= (scrollTop + (child.height / 2))) {
                        break;
                    }
                }
            }
            __CURRENT_PAGE = i;
            if (__CURRENT_PAGE > __TOTAL_PAGES) {
                __CURRENT_PAGE = __TOTAL_PAGES;
            }
            if (_toolbarEnabled && !_miniToolbar && _toolbarGroups.pages){
                document.getElementById("PageCounterInput").value = __CURRENT_PAGE;
            }
            if (_pdfCallback) {
                _pdfCallback(true);
            }
        }
    }
    
    function _handlePagesOnScroll() {
        if (!_ignoreScrollEvent){
            _changePageOnScroll();
            var pagesPerLine = _getNoPagesPerLine(__CURRENT_PAGE);
            var pageBufferSize = pagesPerLine < 4 ? 5 : 2*pagesPerLine - 1;
            if(!document.getElementById("PdfPageDisplayWrapper" + __CURRENT_PAGE).firstChild){
                _ignoreScrollEvent = true;
                var tempPageNo = __CURRENT_PAGE
                var pageWrappers = document.getElementsByClassName("PdfPageDisplayWrapper");
                for (var i = 0; i < pageWrappers.length; i++) {
                    while (pageWrappers[i].firstChild) {
                        pageWrappers[i].removeChild(pageWrappers[i].firstChild);
                    }
                }
                _firstLoadedPage = tempPageNo - pageBufferSize > 0 ? tempPageNo - pageBufferSize : 1;
                _lastLoadedPage = tempPageNo + pageBufferSize <= __TOTAL_PAGES ? tempPageNo + pageBufferSize : __TOTAL_PAGES;
                __CURRENT_PAGE = _firstLoadedPage;
                __PDF_DOC.getPage(__CURRENT_PAGE).then(function(page){
                    handlePages(page, function(success){
                        __CURRENT_PAGE = tempPageNo;
                        _ignoreScrollEvent = false;
                        _handlePagesOnScroll();
                    });
                });
            } else if(__CURRENT_PAGE + pagesPerLine > (_lastLoadedPage - 1) && __CURRENT_PAGE < __TOTAL_PAGES - pagesPerLine) {
                _ignoreScrollEvent = true;
                var tempPageNo = __CURRENT_PAGE;
                for (var i = _firstLoadedPage; i < __CURRENT_PAGE - pageBufferSize; i++){
                    var removePageWrapper = document.getElementById("PdfPageDisplayWrapper" + i);
                    while (removePageWrapper.firstChild){
                        removePageWrapper.removeChild(removePageWrapper.firstChild);
                    }
                }
                _firstLoadedPage = tempPageNo - pageBufferSize > 0 ? tempPageNo - pageBufferSize : 1;
                __CURRENT_PAGE = _lastLoadedPage + 1;
                _lastLoadedPage = tempPageNo + pageBufferSize + 1 <= __TOTAL_PAGES ? tempPageNo + pageBufferSize + 1 : __TOTAL_PAGES;
                __PDF_DOC.getPage(__CURRENT_PAGE).then(function(page){
                    handlePages(page, function(success){
                        __CURRENT_PAGE = tempPageNo;
                        _ignoreScrollEvent = false;
                        if (_sidebarEnabled && _navbar.enabled) {
                            _selectNavPage(document.getElementById("PdfNavPageWrapper" + __CURRENT_PAGE), __CURRENT_PAGE);
                            _scrollNavbarToPage(document.getElementById("CreoViewDocumentNavbar"), __CURRENT_PAGE);
                        }
                    });
                });
            } else if (__CURRENT_PAGE - (2*pagesPerLine - 1) < _firstLoadedPage && __CURRENT_PAGE > (2*pagesPerLine - 1)) {
                _ignoreScrollEvent = true;
                var tempPageNo = __CURRENT_PAGE;
                for (var i = _lastLoadedPage; i > __CURRENT_PAGE + pageBufferSize + 1; i--){
                    var removePageWrapper = document.getElementById("PdfPageDisplayWrapper" + i);
                    while (removePageWrapper.firstChild) {
                        removePageWrapper.removeChild(removePageWrapper.firstChild);
                    }
                    _lastLoadedPage--;
                }
                var tempLastPageNo = _lastLoadedPage;
                _firstLoadedPage = __CURRENT_PAGE - pageBufferSize > 0 ? __CURRENT_PAGE - pageBufferSize : 1;
                __CURRENT_PAGE = _firstLoadedPage;
                _lastLoadedPage = tempPageNo - pagesPerLine < __TOTAL_PAGES ? tempPageNo - pagesPerLine : __TOTAL_PAGES;
                __PDF_DOC.getPage(__CURRENT_PAGE).then(function(page){
                    handlePages(page, function(success){
                        __CURRENT_PAGE = tempPageNo;
                        _lastLoadedPage = tempLastPageNo;
                        _ignoreScrollEvent = false;
                        if (_sidebarEnabled && _navbar.enabled) {
                            _selectNavPage(document.getElementById("PdfNavPageWrapper" + __CURRENT_PAGE), __CURRENT_PAGE);
                            _scrollNavbarToPage(document.getElementById("CreoViewDocumentNavbar"), __CURRENT_PAGE);
                        }
                    });
                });
            } else if (_sidebarEnabled && _navbar.enabled) {
                _selectNavPage(document.getElementById("PdfNavPageWrapper" + __CURRENT_PAGE), __CURRENT_PAGE);
                _scrollNavbarToPage(document.getElementById("CreoViewDocumentNavbar"), __CURRENT_PAGE);
            }
        }
    }
    
    function _changePageOnKey(e) {
        var keyPressed = e.key;
        if (keyPressed == "ArrowRight") {
            _LoadNextPage(_pdfCallback);
        } else if (keyPressed == "ArrowLeft") {
            _LoadPrevPage(_pdfCallback);
        } else if (keyPressed == "Home") {
            _LoadPage(_pdfCallback, 1);
        } else if (keyPressed == "End") {
            _LoadPage(_pdfCallback, __TOTAL_PAGES);
        }
    }

    function _zoomButtonPDF() {
        if (_ignoreScrollEvent) {
            return;
        }
        var pageNo = __CURRENT_PAGE;
        __CURRENT_PAGE = _firstLoadedPage;
        var canvasWrapper = document.getElementById(_currentCanvasId);
        if(__ZOOMSCALE * _zoomButtonScale <= 0.5) {
            return;
        }
        __ZOOMSCALE *= _zoomButtonScale;
        if(canvasWrapper.childNodes[0].style.display == "block"){
            _refreshPDF(function(success){
                for (var i=0; i < canvasWrapper.childNodes.length; i++){
                    canvasWrapper.childNodes[i].style.display = "block";
                    canvasWrapper.childNodes[i].style.margin = _marginSize + "px auto " + _marginSize + "px auto";
                }
                _processPdfAnnotationSet(_pdfRawAnnotationSet);
                showPage(pageNo);
                _handlePagesOnScroll();
                if (_pdfCallback) {
                    _pdfCallback(success);
                }
            });
        } else {
            _refreshPDF(function(success){
                _processPdfAnnotationSet(_pdfRawAnnotationSet);
                showPage(pageNo);
                _handlePagesOnScroll();
                if (_pdfCallback) {
                    _pdfCallback(success);
                }
            });
        }
    }
    
    function _resetTransformPDF () {
        if(_cursorMode != "text"){
            _setPageModePDF(1);
        }
    }
    
    function _refreshPDF(callback) {
        _ignoreScrollEvent = true;
        var canvasWrapper = document.getElementById(_currentCanvasId);
        while(canvasWrapper.firstChild){
            canvasWrapper.removeChild(canvasWrapper.firstChild);
        }
        var tempPage = __CURRENT_PAGE;
        _preparePageWrapper(canvasWrapper, 1, function(){
            var pagesPerLine = _getNoPagesPerLine(__CURRENT_PAGE);
            if (pagesPerLine > 1) {
                for (var i = 1; i < pagesPerLine; i++) {
                    __CURRENT_PAGE -= 1;
                    if (__CURRENT_PAGE <= 1) {
                        __CURRENT_PAGE = 1;
                        break;
                    }
                }
            }
            __PDF_DOC.getPage(__CURRENT_PAGE).then(function(pages){
                handlePages(pages, function(){
                    _ignoreScrollEvent = false;
                    showPage(tempPage, function(){
                        callback(true);
                    })
                });
            });
        });
    }
    
    function _setPageModePDF(pageNo) {
        var canvasWrapper = document.getElementById(_currentCanvasId);
        _pageRotation = 0;
        switch (_pageMode) {
            case "Original":
                __ZOOMSCALE = 1;
                _refreshPDF(function(success){
                    _processPdfAnnotationSet(_pdfRawAnnotationSet);
                    showPage(pageNo, _pdfCallback);
                });
                break;
            case "FitPage":
                var wrapperHeight = canvasWrapper.parentNode.clientHeight;
                var wrapperWidth = canvasWrapper.parentNode.clientWidth;
                if (wrapperHeight <= wrapperWidth) {
                    var pageHeight = _getLargestPageHeight();
                    var heightRatio = wrapperHeight / pageHeight;
                    __ZOOMSCALE *= heightRatio;
                } else {
                    var pageWidth = _getLargestPageWidth();
                    var widthRatio = wrapperWidth / pageWidth;
                    __ZOOMSCALE *= widthRatio;
                }
                _refreshPDF(function(success){
                    if (success) {
                        for (var i=0; i < canvasWrapper.childNodes.length; i++){
                            canvasWrapper.childNodes[i].style.display = "block";
                            canvasWrapper.childNodes[i].style.margin = _marginSize + "px auto " + _marginSize + "px auto";
                        }
                        _processPdfAnnotationSet(_pdfRawAnnotationSet);
                        showPage(pageNo, _pdfCallback);
                    }
                });
                break;
            case "FitWidth":
                var pageWidth = _getLargestPageWidth();
                var wrapperWidth = canvasWrapper.parentNode.clientWidth;
                var widthRatio = wrapperWidth / pageWidth;
                __ZOOMSCALE *= widthRatio;
                _refreshPDF(function(success){
                    if (success) {
                        for (var i=0; i < canvasWrapper.childNodes.length; i++){
                            canvasWrapper.childNodes[i].style.display = "block";
                            canvasWrapper.childNodes[i].style.margin = _marginSize + "px auto " + _marginSize + "px auto";
                        }
                        _processPdfAnnotationSet(_pdfRawAnnotationSet);
                        showPage(pageNo, _pdfCallback);
                    }
                });
                break;
            case "500percent":
                __ZOOMSCALE = 5;
                _refreshPDF(function(success){
                    _processPdfAnnotationSet(_pdfRawAnnotationSet);
                    showPage(pageNo, _pdfCallback);
                });
                break;
            case "250percent":
                __ZOOMSCALE = 2.5;
                _refreshPDF(function(success){
                    _processPdfAnnotationSet(_pdfRawAnnotationSet);
                    showPage(pageNo, _pdfCallback);
                });
                break;
            case "200percent":
                __ZOOMSCALE = 2;
                _refreshPDF(function(success){
                    _processPdfAnnotationSet(_pdfRawAnnotationSet);
                    showPage(pageNo, _pdfCallback);
                });
                break;
            case "100percent":
                __ZOOMSCALE = 1;
                _refreshPDF(function(success){
                    _processPdfAnnotationSet(_pdfRawAnnotationSet);
                    showPage(pageNo, _pdfCallback);
                });
                break;
            case "75percent":
                __ZOOMSCALE = 0.75;
                _refreshPDF(function(success){
                    _processPdfAnnotationSet(_pdfRawAnnotationSet);
                    showPage(pageNo, _pdfCallback);
                });
                break;
            case "50percent":
                __ZOOMSCALE = 0.5;
                _refreshPDF(function(success){
                    _processPdfAnnotationSet(_pdfRawAnnotationSet);
                    showPage(pageNo, _pdfCallback);
                });
                break;
            default:
                console.log("Requested Page Mode is not supported");
                return;
        }
        if (_toolbarEnabled && !_miniToolbar && _toolbarGroups.zoom) {
            var pageModeSelect = document.getElementById("CreoViewDocToolbarPageModeSelect");
            if (pageModeSelect) {
                document.getElementById("CreoViewDocToolbarPageModeSelect").value = _pageMode;
            }
        }
    }
    
    function _getLargestPageWidth() {
        var canvasWrapper = document.getElementById(_currentCanvasId);
        var width = 0;
        for (var i = 0; i < canvasWrapper.childNodes.length; i++){
            if (canvasWrapper.childNodes[i].width > width) {
                width = canvasWrapper.childNodes[i].width;
            }
        }
        return width;
    }
    
    function _getLargestPageHeight() {
        var canvasWrapper = document.getElementById(_currentCanvasId);
        var height = 0;
        for (var i = 0; i < canvasWrapper.childNodes.length; i++){
            if (canvasWrapper.childNodes[i].height > height) {
                height = canvasWrapper.childNodes[i].height;
            }
        }
        return height;
    }
    
    function _IsPDFSession() {
        var retVal = false;
        if (!_currentCanvasId=="") {
            retVal = _currentCanvasId.indexOf("_CreoViewDocumentCanvas") != -1 ? true : false ;
        }
        return retVal;
    }
    
    function _LoadPDF(val, callback) {
        if(_IsPDFSession() && val) {
            _ignoreScrollEvent = true;
            __ZOOMSCALE = 1;
            __CURRENT_PAGE = 1;
            _pageRotation = 0;
            _pdfRawAnnotationSet = null;
            var canvasWrapper = document.getElementById(_currentCanvasId);
            if (_sidebarEnabled){
                _RemovePdfSideBar(canvasWrapper.parentNode.parentNode);
            }
            while(canvasWrapper.firstChild){
                canvasWrapper.removeChild(canvasWrapper.firstChild);
            }
            PDFJS.getDocument({ data: val }).then(function(pdf_doc) {
                __PDF_DOC = pdf_doc;
                __TOTAL_PAGES = __PDF_DOC.numPages;
                _firstLoadedPage = 1;
                _lastLoadedPage = __TOTAL_PAGES <= 11 ? __TOTAL_PAGES : 11;
                _preparePageWrapper(canvasWrapper, 1, function(){
                    __PDF_DOC.getPage(_firstLoadedPage).then(function(pages){
                        handlePages(pages, function(val){
                            __PDF_DOC.getOutline().then(function(outline){
                                if(outline){
                                    _bookmarks = outline;
                                } else {
                                    _bookmarksBar.enabled = false;
                                    _navbar.enabled = true;
                                }
                                if (_sidebarEnabled) {
                                    if (_navbar.enabled) {
                                        _DisplayPdfNavigationBar (_CreateSideBar(canvasWrapper.parentNode.parentNode), 1);
                                    } else if (_bookmarksBar.enabled) {
                                        _DisplayPdfBookmarksBar(_CreateSideBar(canvasWrapper.parentNode.parentNode));
                                    }
                                }
                                if (_toolbarEnabled) {
                                    _resizeDocumentToolbar(canvasWrapper.parentNode.parentNode, _toolbarGroups);
                                }
                                _ignoreScrollEvent = false;
                                if (callback) {
                                    callback(val);
                                }
                            });
                        });
                    });
                });
            }).catch(function(error) {
                console.log("Javascript caught exception in showPDF : " + error.message);
                if (typeof callback === "function") callback(false);
            });
        }
    }
    
    function _preparePageWrapper(canvasWrapper, pageNo, callback) {
        __PDF_DOC.getPage(pageNo).then(function(page){
            var viewport = page.getViewport(__ZOOMSCALE);
            var pageWrapper = document.createElement("div");
            pageWrapper.height = viewport.height;
            pageWrapper.width = viewport.width;
            pageWrapper.setAttribute('style', "width: " + viewport.width + "px; height: " + viewport.height + "px; margin: " + _marginSize/2 + "px auto; box-shadow: 0px 0px 12px rgba(0,0,0,0.5); transform: rotate(" + _pageRotation + "deg)");
            if (! (_pageMode == "FitWidth" || _pageMode == "FitPage")) {
                pageWrapper.style.display = "inline-block";
                if (_checkPageRotation()) {
                    var newTopMargin = _marginSize/2 - (Math.abs(viewport.height - viewport.width) / 2);
                    var newSideMargin = (Math.abs(viewport.width - viewport.height)/2) + _marginSize/2;
                    pageWrapper.style.margin =  newTopMargin + "px " + newSideMargin + "px";
                } else {
                    pageWrapper.style.margin = _marginSize/2 + "px";
                }
            } else {
                pageWrapper.style.display = "block";
            }
            pageWrapper.id = "PdfPageDisplayWrapper" + pageNo;
            pageWrapper.className = "PdfPageDisplayWrapper";
            canvasWrapper.appendChild(pageWrapper);
            if (pageNo < __TOTAL_PAGES) {
                _preparePageWrapper(canvasWrapper, pageNo+1, callback);
            } else {
                if (callback) {
                    callback();
                }
            }
        });
    }
    
    function handlePages(page, callback) {
        var canvasWrapper = document.getElementById(_currentCanvasId);
        var viewport = page.getViewport(__ZOOMSCALE);
        var pageWrapper = document.getElementById("PdfPageDisplayWrapper" + __CURRENT_PAGE);
        var canvas = _getPDFCanvas();
        canvas.id = "PdfPageDisplayCanvas" + __CURRENT_PAGE;
        canvas.className = "PdfPageDisplayCanvas";
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        var context = canvas.getContext('2d', {alpha: false});
        page.render({canvasContext: canvas.getContext('2d'), viewport: viewport}).then(function(){
            pageWrapper.appendChild(canvas);     
            var textLayer = document.createElement("div");
            textLayer.id = "PdfPageDisplayTextLayer" + __CURRENT_PAGE;
            textLayer.className = "PdfPageDisplayTextLayer";
            textLayer.width = canvas.width;
            textLayer.height = canvas.height;
            textLayer.setAttribute('style', "width : " + canvas.width + "px; height: " + canvas.height + "px; position: absolute; color: transparent; z-index: 2; top: 0px; left: 0px");
            pageWrapper.appendChild(textLayer);
            
            page.getTextContent({ normalizeWhitespace: true }).then(function(textContent){
                var lineContainers = [];
                PDFJS.renderTextLayer({
                    textContent: textContent,
                    container: textLayer,
                    viewport: viewport,
                    textDivs: lineContainers,
                    enhanceTextSelection: true
                })._capability.promise.then(function(){
                    for (var i = 0; i < lineContainers.length; i++){
                        lineContainers[i].style.position = "absolute";
                        lineContainers[i].style.lineHeight = lineContainers[i].style.fontSize;
                    }
                    
                    textLayer.style.WebkitUserSelect = _cursorMode == "text" ? "text" : "none";
                    textLayer.style.msUserSelect = _cursorMode == "text" ? "text" : "none";
                    textLayer.style.MozUserSelect = _cursorMode == "text" ? "text" : "none";

                    if (__PDF_DOC !== null && __CURRENT_PAGE < __TOTAL_PAGES && __CURRENT_PAGE < _lastLoadedPage){
                        __CURRENT_PAGE += 1;
                        __PDF_DOC.getPage(__CURRENT_PAGE).then(function(newPage){
                            handlePages(newPage, callback);
                        });
                    } else if(__CURRENT_PAGE == __TOTAL_PAGES || __CURRENT_PAGE == _lastLoadedPage) {
                        __CURRENT_PAGE = 1;
                        canvasWrapper.style.minWidth = "100%"
                        if (_toolbarEnabled && !_miniToolbar && _toolbarGroups.pages){
                            _UpdateDocumentToolbar();
                        }
                        if (callback) {
                            callback(true);
                        }
                    }
                });
            });
        });
    }
    
    function showPage(page_no, callback) {
        if(!_ignoreScrollEvent) {
            _ignoreScrollEvent = true;
            var canvasWrapper = document.getElementById(_currentCanvasId);
            if (page_no > _lastLoadedPage || page_no < _firstLoadedPage) {
                var pageWrappers = document.getElementsByClassName("PdfPageDisplayWrapper");
                for (var i = 0; i < pageWrappers.length; i++){
                    while (pageWrappers[i].firstChild){
                        pageWrappers[i].removeChild(pageWrappers[i].firstChild);
                    }
                }
                var pagesPerLine = _getNoPagesPerLine(page_no);
                var pageBufferSize = pagesPerLine < 4 ? 5 : 2*pagesPerLine + 1;
                _firstLoadedPage = (page_no-pageBufferSize) > 0 ? page_no - pageBufferSize : 1;
                __CURRENT_PAGE = _firstLoadedPage;
                _lastLoadedPage = (page_no+pageBufferSize) < __TOTAL_PAGES ? page_no + pageBufferSize : __TOTAL_PAGES;
                __PDF_DOC.getPage(_firstLoadedPage).then(function(newPage){
                    handlePages(newPage, function(success){
                        _processPdfAnnotationSet(_pdfRawAnnotationSet);
                        _completeScrollShowPage(page_no, callback);
                    });
                });
            } else {
                _completeScrollShowPage(page_no, callback);
            }
        }
    }
    
    function _completeScrollShowPage(page_no, callback){
        __CURRENT_PAGE = page_no;
        var canvasWrapper = document.getElementById(_currentCanvasId);
        var pdfDisplays = document.getElementsByClassName("PdfPageDisplayWrapper");
        var scrollToVal = 0;
        var temp = 0;
        for (var i = 0; i < page_no - 1; i++) {
            var pagesPerLine = _getNoPagesPerLine(i+1);
            var pageHeight = pdfDisplays[i].height + _marginSize;
            if (_checkPageRotation()) {
                pageHeight = pdfDisplays[i].width + _marginSize;
            }
            if (pageHeight > temp) {
                temp = pageHeight;
            }
            if (((i+1) % pagesPerLine) == 0){
                scrollToVal += temp;
                temp = 0;
            }
        }
        if(pdfDisplays[0].style.display == "block"){
            scrollToVal += _marginSize;
        }
        canvasWrapper.parentNode.scrollTop = scrollToVal;
        if (_toolbarEnabled && !_miniToolbar && _toolbarGroups.pages){
            document.getElementById("PageCounterInput").value = __CURRENT_PAGE;
        }
        _ignoreScrollEvent = false;
        if (_sidebarEnabled && _navbar.enabled) {
            _selectNavPage(document.getElementById("PdfNavPageWrapper" + page_no), page_no);
            _scrollNavbarToPage(document.getElementById("CreoViewDocumentNavbar"), page_no);
        }
        if (callback) {
            callback(true);
        }
    }
    
    function _getNoPagesPerLine(page_no) {
        var canvasWrapper = document.getElementById(_currentCanvasId);
        if (canvasWrapper.childNodes[0].style.display == "block") {
            return 1;
        }
        var wrapperWidth = canvasWrapper.clientWidth;
        var sum = 0;
        var count = 0;
        for (var i = 0; i < page_no; i++) {
            if (_checkPageRotation()) {
                var page = canvasWrapper.childNodes[i];
                sum += page.height + _marginSize;
                count += 1;
                if (sum > wrapperWidth) {
                    sum = page.height;
                    count = 1;
                }
            } else {
                var page = canvasWrapper.childNodes[i];
                sum += page.width + _marginSize;
                count += 1;
                if (sum > wrapperWidth) {
                    sum = page.width;
                    count = 1;
                }
            }
        }
        for (var j = page_no; j < canvasWrapper.childNodes.length; j++) {
            var page = canvasWrapper.childNodes[j];
            if (_checkPageRotation()) {
                sum += page.height + _marginSize;
            } else {
                sum += page.width + _marginSize;
            }
            if (sum > wrapperWidth) {
                break;
            }
            count += 1;
        }
        return count;
    }
    
    function _setUserSelect(elems){
        for (var i = 0; i < elems.length; i++) {
            elems[i].style.WebkitUserSelect = _cursorMode == "text" ? "text" : "none";
            elems[i].style.msUserSelect = _cursorMode == "text" ? "text" : "none";
            elems[i].style.MozUserSelect = _cursorMode == "text" ? "text" : "none";
        }
    }
    
    function _LoadPrevPage(callback) {
        if (__CURRENT_PAGE != 1)
            showPage(__CURRENT_PAGE - 1, callback);
    }
    
    function _LoadNextPage(callback) {
        if (__CURRENT_PAGE != __TOTAL_PAGES)
            showPage(__CURRENT_PAGE + 1, callback);
    }
    
    function _LoadPage(callback, pageNo) {
        if ((pageNo > 0) && (pageNo <=__TOTAL_PAGES))
            showPage(pageNo, callback);
    }
    
    //PDF TOOLBAR
    
    function _DisplayDocumentToolbar (parent, groups) {
        if (document.getElementById("CreoViewDocumentToolbar") == null) {
            _buildToolbarCover(parent);
            var toolbarDiv = document.createElement("div");
            toolbarDiv.id = "CreoViewDocumentToolbar";
            toolbarDiv.setAttribute('style',"color: #FFFFFF; background-color: #44474B; height: " + _toolbarHeight + "px; text-align: left; padding-top:1px; z-index: 1; -webkit-user-select: none; -ms-user-select: none; -moz-user-select: none;");
            _BuildDocumentToolbarContent(toolbarDiv, groups, parent);
            parent.insertBefore(toolbarDiv, parent.childNodes[0]);
            document.getElementById(_currentCanvasId).parentNode.style.height = parseInt(parent.clientHeight) - _toolbarHeight + "px";
            if (_sidebarEnabled) {
                var sidebarDiv = document.getElementById("CreoViewDocumentSidebar");
                if (sidebarDiv) {
                    sidebarDiv.style.height = parseInt(parent.clientHeight) - _toolbarHeight + "px";
                }
            }
        }
    }
    
    function _RemoveDocumentToolbar (parent) {
        var toolbarCover = document.getElementById("PdfToolbarCover");
        if (toolbarCover) {
            _toolbarGroupsLoaded.current = 0;
            parent.removeChild(toolbarCover);
        }
        var toolbarDiv = document.getElementById("CreoViewDocumentToolbar");
        if (toolbarDiv){
            parent.removeChild(toolbarDiv);
        }
        var currentCanvas = document.getElementById(_currentCanvasId);
        if (currentCanvas) {
            currentCanvas.parentNode.style.height = "100%";
        }
        if (_sidebarEnabled) {
            var sidebarDiv = document.getElementById("CreoViewDocumentSidebar");
            if (sidebarDiv) {
                sidebarDiv.style.height = "100%";
                sidebarDiv.childNodes[1].style.height = (parseInt(sidebarDiv.childNodes[1].style.height) + _toolbarHeight) + "px";
            }
        }
        if (_searchDrag.enabled){
            _searchDrag.enabled = false;
        }
        parent.removeEventListener("mousemove", function(e){
            _dragSearchBox(parent, e);
        });
        parent.removeEventListener("mouseleave", function(){
            if (_searchDrag.enabled) {
                _searchDrag.enabled = false;
            }
        });
        parent.removeEventListener("mouseup", function(){
            if (_searchDrag.enabled) {
                _searchDrag.enabled = false;
            }
        });
    }
    
    function _BuildDocumentToolbarContent (toolbarDiv, groups, parent) {
        _miniToolbar = false;
        while(toolbarDiv.firstChild){
            toolbarDiv.removeChild(toolbarDiv.firstChild);
        }
        
        var leftContainer = document.createElement("div");
        leftContainer.setAttribute('style',"float: left; height: 100%");
        var rightContainer = document.createElement("div");
        rightContainer.setAttribute('style',"float: right; height: 100%");
        var midContainer = document.createElement("div");
        midContainer.setAttribute('style',"height: " + _toolbarHeight + "px; overflow: hidden; white-space: nowrap");
        toolbarDiv.appendChild(leftContainer);
        toolbarDiv.appendChild(rightContainer);
        toolbarDiv.appendChild(midContainer);
        if (groups.sidebar) {
            leftContainer.appendChild(_buildNavbarGroup());
        }
        if (groups.pages) {
            var pagesGroup = _buildPagesGroup();
            leftContainer.appendChild(pagesGroup);
        }
        if (groups.rotate) {
            var rotateGroup = _buildRotateGroup();
            midContainer.appendChild(rotateGroup);
        }
        if (groups.zoom) {
            var zoomGroup = _buildZoomGroup();
            midContainer.appendChild(zoomGroup);
        }
        if (groups.cursor) {
            var cursorModeGroup = _buildCursorModeGroup();
            midContainer.appendChild(cursorModeGroup);
        }        
        if (groups.search) {
            var searchGroup = _BuildDocumentSearchToolbar(parent);
            searchGroup.style.float = "right";
            searchGroup.className = "CreoToolbarGroup";
            rightContainer.appendChild(searchGroup);
        }
        if (groups.print) {
            var printGroup = _buildPrintGroup(parent);
            printGroup.style.float = "right";
            rightContainer.appendChild(printGroup);
        }
    }
    
    function _buildNavbarGroup() {
        var navbarGroup = _BuildDocumentToolbarButton('/icons/pdf_sidebar.svg', true);
        navbarGroup.id = "CreoToolbarSidebarGroup";
        navbarGroup.style.margin = "auto 5px";
        if(_sidebarEnabled){
            navbarGroup.style.backgroundColor = "#232B2D";
        }
        navbarGroup.addEventListener("click", function(e){
            e.stopPropagation();
            if(!_sidebarEnabled){
                navbarGroup.style.backgroundColor = "#232B2D";
            } else {
                navbarGroup.style.backgroundColor = "inherit";
            }
            _togglePdfSidePane();
        });
        navbarGroup.addEventListener("mouseenter", function(){
            if(!_sidebarEnabled){
                navbarGroup.style.backgroundColor = "#232B2D";
            }
        });
        navbarGroup.addEventListener("mouseleave", function(){
            if(!_sidebarEnabled){
                navbarGroup.style.backgroundColor = "inherit";
            }
        });
        return navbarGroup;
    }
    
    function _buildPagesGroup() {
        var pagesGroup = document.createElement("div");
        pagesGroup.id = "CreoToolbarPagesGroup";
        pagesGroup.className = "CreoToolbarGroup";
        pagesGroup.setAttribute('style', "display: inline-block; margin-left: 15px; height: " + _toolbarHeight + "px");
        var firstPageButton = _BuildDocumentToolbarButton("/icons/pdf_first_page.svg", true);
        _AddToolbarButtonMouseOver(firstPageButton);
        firstPageButton.addEventListener("click", function(){
            _LoadPage(_pdfCallback, 1);
        });
        pagesGroup.appendChild(firstPageButton);
        var prevPageButton = _BuildDocumentToolbarButton("/icons/pdf_previous_page.svg", true);
        _AddToolbarButtonMouseOver(prevPageButton);
        prevPageButton.addEventListener("click", function(){
            _LoadPrevPage(_pdfCallback);
        });
        pagesGroup.appendChild(prevPageButton);
        
        var pageCounterSpan = _buildPagesCounter();
        pagesGroup.appendChild(pageCounterSpan);
        
        var nextPageButton = _BuildDocumentToolbarButton("/icons/pdf_next_page.svg", true);
        nextPageButton.id = "CreoToolbarPagesGroupNextPage";
        _AddToolbarButtonMouseOver(nextPageButton);
        nextPageButton.addEventListener("click", function(){
            _LoadNextPage(_pdfCallback);
        });
        pagesGroup.appendChild(nextPageButton);
        var lastPageButton = _BuildDocumentToolbarButton("/icons/pdf_last_page.svg", true);
        _AddToolbarButtonMouseOver(lastPageButton);
        lastPageButton.addEventListener("click", function(){
            _LoadPage(_pdfCallback, __TOTAL_PAGES);
        });
        pagesGroup.appendChild(lastPageButton);
        return pagesGroup;
    }
    
    function _buildRotateGroup () {
        var rotateGroup = document.createElement("div");
        rotateGroup.id = "CreoToolbarRotateGroup";
        rotateGroup.setAttribute('style', "display: inline-block; margin: auto 7px");
        rotateGroup.className = "CreoToolbarGroup";
        
        var rotateClockwiseButton = _BuildDocumentToolbarButton("/icons/pdf_rotate_clockwise.svg", true);
        rotateClockwiseButton.addEventListener("click", function(){
            _RotateDocumentPages(_pageRotation + 90);
        });
        _AddToolbarButtonMouseOver(rotateClockwiseButton);
        rotateGroup.appendChild(rotateClockwiseButton);
        
        var rotateAntiClockwiseButton = _BuildDocumentToolbarButton("/icons/pdf_rotate_anti_clockwise.svg", true);
        rotateAntiClockwiseButton.addEventListener("click", function(){
            _RotateDocumentPages(_pageRotation - 90);
        });
        _AddToolbarButtonMouseOver(rotateAntiClockwiseButton);
        rotateGroup.appendChild(rotateAntiClockwiseButton);
        
        return rotateGroup;
    }
    
    function _buildPagesCounter () {
        var pageCounterSpan = document.createElement("div");
        pageCounterSpan.id = "PageCounterSpan";
        pageCounterSpan.innerHTML = "  /  " + __TOTAL_PAGES;
        pageCounterSpan.setAttribute('style', "display: inline-block; position: absolute; margin: 10px");
        var pageCounterInput = document.createElement("input");
        pageCounterInput.id = "PageCounterInput";
        pageCounterInput.type = "text";
        pageCounterInput.pattern = "[0-9]+";
        pageCounterInput.size = "3";
        pageCounterInput.value = "1";
        pageCounterInput.addEventListener("keypress", function(e){
            if (!(e.key == "Enter" || /^\d*$/.test(e.key))) {
                e.preventDefault();
            }
        });
        pageCounterInput.addEventListener("change", function(e){
            var pageNo = parseInt(e.target.value);
            if (pageNo) {
                _LoadPage(_pdfCallback, pageNo);
            }
        });
        pageCounterSpan.insertBefore(pageCounterInput, pageCounterSpan.childNodes[0]);     
        return pageCounterSpan;
    }
    
    function _buildZoomGroup () {
        var zoomGroup = document.createElement("div");
        zoomGroup.id = "CreoToolbarZoomGroup";
        zoomGroup.className = "CreoToolbarGroup";
        zoomGroup.setAttribute('style', "display: inline-block; margin: auto 7px;");
        var zoomInButton = _BuildDocumentToolbarButton("./icons/pdf_zoom_in.svg", true);
        _AddToolbarButtonMouseOver(zoomInButton);
        zoomInButton.addEventListener("click", function(){
            _zoomButtonScale = 1.2;
            _zoomButtonPDF();
        });
        zoomGroup.appendChild(zoomInButton);
        var zoomOutButton = _BuildDocumentToolbarButton("./icons/pdf_zoom_out.svg", true);
        _AddToolbarButtonMouseOver(zoomOutButton);
        zoomOutButton.addEventListener("click", function(){
            _zoomButtonScale = 0.8;
            _zoomButtonPDF();
        });
        zoomGroup.appendChild(zoomOutButton);
        
        var pageModeSpan = document.createElement("span");
        pageModeSpan.setAttribute('style', "display: inline-block; position: relative; margin-left: 5px; margin-right: 5px; top: -3px");
        
        var pageModeInput = document.createElement("select");
        pageModeInput.id = "CreoViewDocToolbarPageModeSelect";
        var pageModeTexts = ["Original", "Fit Page", "Fit Width", "500%", "250%", "200%", "100%", "75%", "50%"];
        var pageModeValues = ["Original", "FitPage", "FitWidth", "500percent", "250percent", "200percent", "100percent", "75percent", "50percent"];
        for(var i=0; i < pageModeTexts.length; i++){
            var option = document.createElement("option");
            option.text = pageModeTexts[i];
            option.value = pageModeValues[i];
            pageModeInput.appendChild(option);
        }
        pageModeInput.value = _pageMode;
        pageModeInput.addEventListener("change", function(e){
            _pageMode = e.target.options[e.target.selectedIndex].value;
            _setPageModePDF(__CURRENT_PAGE);
        });
        
        pageModeSpan.appendChild(pageModeInput);
        zoomGroup.appendChild(pageModeSpan);
        return zoomGroup;
    }
    
    function _buildCursorModeGroup(){
        var cursorModeGroup = document.createElement("div");
        cursorModeGroup.id = "CreoToolbarCursorGroup";
        cursorModeGroup.className = "CreoToolbarGroup";
        cursorModeGroup.setAttribute('style', "display: inline-block; margin: auto 7px");
        
        var panModeButton = _BuildDocumentToolbarButton("/icons/pdf_pan_view.svg", true);
        panModeButton.addEventListener("mouseenter", function(){
            if (_cursorMode != "pan") {
                panModeButton.style.backgroundColor = "#232B2D";
            }
        });
        panModeButton.addEventListener("mouseleave", function(){
            if (_cursorMode != "pan") {
                panModeButton.style.backgroundColor = "inherit";
            }
        });
        var textModeButton = _BuildDocumentToolbarButton("/icons/pdf_text_select.svg", true);
        textModeButton.addEventListener("mouseenter", function(){
            if (_cursorMode != "text") {
                textModeButton.style.backgroundColor = "#232B2D";
            }
        });
        textModeButton.addEventListener("mouseleave", function(){
            if (_cursorMode != "text") {
                textModeButton.style.backgroundColor = "inherit";
            }
        });
        
        if (_cursorMode == "pan") {
            panModeButton.style.backgroundColor = "#232B2D";
        } else if (_cursorMode == "text") {
            textModeButton.style.backgroundColor = "#232B2D";
        }
        
        panModeButton.addEventListener("mousedown", function(e){
            if (_zoomButton) {
                _setZoomOnButton(_zoomButtonScale);
            }
            _cursorMode = "pan";
            _setUserSelect(document.getElementsByClassName("PdfPageDisplayTextLayer"));
            panModeButton.style.backgroundColor = "#232B2D";
            textModeButton.style.backgroundColor = "inherit";
        });
        cursorModeGroup.appendChild(panModeButton);
        
        textModeButton.addEventListener("mousedown", function(){
            if (_zoomButton) {
                _setZoomOnButton(_zoomButtonScale);
            }
            _cursorMode = "text";
            _setUserSelect(document.getElementsByClassName("PdfPageDisplayTextLayer"));
            textModeButton.style.backgroundColor = "#232B2D";
            panModeButton.style.backgroundColor = "inherit";
        });
        cursorModeGroup.appendChild(textModeButton);
        
        return cursorModeGroup;
    }
    
    function _buildPrintGroup (parent) {
        var printGroup = document.createElement("div");
        printGroup.id = "CreoToolbarPrintGroup";
        printGroup.setAttribute('style', "display: inline-block; margin: auto 7px");
        printGroup.className = "CreoToolbarGroup";
        
        var printButton = _BuildDocumentToolbarButton("/icons/pdf_print.svg", true);
        printButton.addEventListener("click", function(){
            _PrintPdf(parent);
        });
        _AddToolbarButtonMouseOver(printButton);
        printGroup.appendChild(printButton);
        
        return printGroup;
    }
    
    function _UpdateDocumentToolbar(){
        var pageCounterSpan = document.getElementById("PageCounterSpan");
        var pageCounterInput = document.getElementById("PageCounterInput");
        pageCounterSpan.textContent = " / " + __TOTAL_PAGES;
        pageCounterSpan.insertBefore(pageCounterInput, pageCounterSpan.childNodes[0]);
        if (!_miniToolbar) {
            pageCounterSpan.nextSibling.style.marginLeft = (((__TOTAL_PAGES.toString() + " / ").length + 4) * 10.5) + "px";
        }
    }
    
    function _resizeDocumentToolbar(parent, groups){
        var toolbarDiv = document.getElementById("CreoViewDocumentToolbar");
        document.getElementById(_currentCanvasId).parentNode.style.height = (parseInt(parent.clientHeight) - _toolbarHeight) + "px";
        if (_sidebarEnabled){
            var sidebarDiv = document.getElementById("CreoViewDocumentSidebar");
            if (sidebarDiv) {
                sidebarDiv.style.height = parseInt(parent.clientHeight) - _toolbarHeight + "px";
                sidebarDiv.childNodes[1].style.height = parseInt(parent.clientHeight) - (_toolbarHeight*2) + "px";
            }
        }
        if (!_miniToolbar) {   
            var buttonsWidth = 0;
            var toolbarGroups = document.getElementsByClassName("CreoToolbarGroup");
            for (var i = 0; i < toolbarGroups.length; i++){
                buttonsWidth += parseInt(toolbarGroups[i].clientWidth) + 10;
            }
            _toolbarButtonsWidth = buttonsWidth + 282;
            if(parent.clientWidth <= _toolbarButtonsWidth){
                _toggleToolbarCover("block");
                _BuildDocumentToolbarMenu(toolbarDiv, groups, parent);
            }
        } else {
            if (parent.clientWidth > _toolbarButtonsWidth + 1){
                _toggleToolbarCover("block");
                _BuildDocumentToolbarContent(toolbarDiv, groups, parent);
                document.getElementById("PageCounterInput").value = __CURRENT_PAGE;
            }
        }
        if (!_miniToolbar) {
            var midContainer = toolbarDiv.childNodes[2];
            midContainer.style.position = "absolute";
            midContainer.style.marginLeft = (parseInt(toolbarDiv.clientWidth) - (parseInt(midContainer.clientWidth) + 65))/2 + "px";
            midContainer.style.marginRight = (parseInt(toolbarDiv.clientWidth) - (parseInt(midContainer.clientWidth) + 65))/2 + "px";
            if(_toolbarGroups.pages) {
                var nextPageButton = document.getElementById("CreoToolbarPagesGroupNextPage");
                nextPageButton.style.marginLeft = (parseInt(document.getElementById("PageCounterSpan").clientWidth) + 20) + "px";
            }
        } else {
            var pageModeOptions = document.getElementById("PdfToolbarMiniMenuPageModeOptions");
            pageModeOptions.style.display = "none";
            pageModeOptions.parentNode.style.backgroundColor = "inherit";
            var midContainer = toolbarDiv.childNodes[2];
            midContainer.style.marginLeft = (parseInt(toolbarDiv.clientWidth) - 57)/2 + "px";
            var miniMenuDiv = document.getElementById("PdfToolbarMiniMenuButton").childNodes[1];
            miniMenuDiv.style.maxHeight = (parseInt(parent.clientHeight) - (_toolbarHeight + 15)) + "px";
            _toggleMenuScrollIndicator(miniMenuDiv, parent);;
        }
    }
    
    function _BuildDocumentToolbarMenu(toolbarDiv, groups, parent){
        _miniToolbar = true;        
        while(toolbarDiv.firstChild){
            toolbarDiv.removeChild(toolbarDiv.firstChild);
        }
        parent.removeEventListener("mousemove", function(e){
            _dragSearchBox(parent, e);
        });
        parent.removeEventListener("mouseleave", function(){
            if (_searchDrag.enabled) {
                _searchDrag.enabled = false;
            }
        });
        parent.removeEventListener("mouseup", function(){
            if (_searchDrag.enabled) {
                _searchDrag.enabled = false;
            }
        });
        
        var leftContainer = document.createElement("div");
        leftContainer.setAttribute('style',"float: left");
        var rightContainer = document.createElement("div");
        rightContainer.setAttribute('style',"float: right");
        var midContainer = document.createElement("div");
        midContainer.setAttribute('style',"margin-left: " + (parseInt(toolbarDiv.clientWidth) - 57)/2 + "px");
        toolbarDiv.appendChild(leftContainer);
        toolbarDiv.appendChild(rightContainer);
        toolbarDiv.appendChild(midContainer);
        
        var menuButton = document.createElement("span");
            menuButton.id = "PdfToolbarMiniMenuButton";
            var menuImage = document.createElement("img");
            _AddToolbarButtonLoad(menuImage);
            menuImage.src = ThingView.resourcePath + '/icons/pdf_more_menu.svg';
            menuButton.appendChild(menuImage);
            menuButton.setAttribute('style', "position: absolute; margin: 6px; padding: 6px; -webkit-user-select: none; -ms-user-select: none; -moz-user-select: none; cursor: pointer");
            var menuDiv = document.createElement("div");
            menuDiv.id = "PdfToolbarMiniMenuDiv";
            menuDiv.setAttribute('style', "display: none; background-color: #4D5055; position: absolute; z-index: 5; padding: 5px; margin-top: 12.5px; margin-left: -6px; cursor: auto; color: #FFFFFF; white-space: nowrap; max-height: " + (parseInt(parent.clientHeight) - (_toolbarHeight + 15)) + "px; overflow-y: auto; overflow-x: visible; scrollbar-width: none; -ms-overflow-style: none");
            var newStyle = "#PdfToolbarMiniMenuDiv::-webkit-scrollbar {display: none}";
            if (document.querySelector('style') && 
                document.querySelector('style').textContent.search(newStyle) == -1) {
                document.querySelector('style').textContent += newStyle;
            } else if (!document.querySelector('style')) {
                var style = document.createElement('style');
                style.textContent = newStyle;
                document.getElementsByTagName('head')[0].appendChild(style);
            }
            if (groups.sidebar) {
                _buildMiniSidebarGroup(menuDiv);
            }       
            if (groups.pages) {
                _buildMiniPagesGroup(menuDiv);
                var pagesCounter = _buildPagesCounter();
                pagesCounter.style.marginLeft = "42px";
                leftContainer.appendChild(pagesCounter);
            }
            if (groups.rotate) {
                _buildMiniRotateGroup(menuDiv);
            }
            if (groups.zoom) {
                _buildMiniZoomGroup(menuDiv);
                var zoomGroup = document.createElement("div");
                zoomGroup.setAttribute('style', "display: inline-block; white-space: nowrap");
                var zoomInButton = _BuildDocumentToolbarButton("/icons/pdf_zoom_in.svg", true);
                _AddToolbarButtonMouseOver(zoomInButton);
                zoomInButton.addEventListener("click", function(){
                    _zoomButtonScale = 1.2;
                    _zoomButtonPDF();
                });
                zoomGroup.appendChild(zoomInButton);
                var zoomOutButton = _BuildDocumentToolbarButton("/icons/pdf_zoom_out.svg", true);
                _AddToolbarButtonMouseOver(zoomOutButton);
                zoomOutButton.addEventListener("click", function(){
                    _zoomButtonScale = 0.8;
                    _zoomButtonPDF();
                });
                zoomGroup.appendChild(zoomOutButton);
                midContainer.appendChild(zoomGroup);
            }            
            if (groups.cursor) {
                _buildMiniCursorGroup(menuDiv);
            }
            if (groups.print && _printEnabled) {
                _buildMiniPrintGroup(parent, menuDiv);
            }
            
            menuDiv.addEventListener("scroll", function(){
                _toggleMenuScrollIndicator(menuDiv);
            });
            
            menuButton.appendChild(menuDiv);
            menuButton.addEventListener("click", function(){
                if(menuDiv.style.display == "none"){
                    menuDiv.style.display = "block";
                    menuButton.style.backgroundColor = "#232B2D";
                    _toggleMenuScrollIndicator(menuDiv, parent);
                } else {
                    menuDiv.style.display = "none";
                    menuButton.style.backgroundColor = "inherit";
                }
            });
            menuButton.addEventListener("mouseenter", function(){
                if (menuDiv.style.display == "none") {
                    menuButton.style.backgroundColor = "#232B2D";
                }
            });
            menuButton.addEventListener("mouseleave", function(){
                if (menuDiv.style.display == "none") {
                    menuButton.style.backgroundColor = "inherit";
                }
            });
        
        if (groups.search) {
            var searchButton = _BuildDocumentSearchToolbar(parent);
            rightContainer.appendChild(searchButton);
        }        
        leftContainer.appendChild(menuButton);
    }
    
    function _buildMenuHr () {
        var hr = document.createElement("hr");
        hr.setAttribute('style', "margin-top: 4px; margin-bottom: 4px; color: #44474B; border-style: solid");
        return hr;
    }
    
    function _buildMiniPagesGroup (menuDiv) {
        var firstPageDiv = _createMiniMenuItem("First Page", "/icons/pdf_first_page.svg");
        firstPageDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _LoadPage(_pdfCallback, 1);
        });
        _AddMiniToolbarEvents(firstPageDiv);
        menuDiv.appendChild(firstPageDiv);
        
        var prevPageDiv = _createMiniMenuItem("Previous Page", "/icons/pdf_previous_page.svg");
        prevPageDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _LoadPrevPage(_pdfCallback);
        });
        _AddMiniToolbarEvents(prevPageDiv);
        menuDiv.appendChild(prevPageDiv);
        
        var nextPageDiv = _createMiniMenuItem("Next Page", "/icons/pdf_next_page.svg");
        nextPageDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _LoadNextPage(_pdfCallback);
        });
        _AddMiniToolbarEvents(nextPageDiv);
        menuDiv.appendChild(nextPageDiv);
        
        var lastPageDiv = _createMiniMenuItem("Last Page", "/icons/pdf_last_page.svg");
        lastPageDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _LoadPage(_pdfCallback, __TOTAL_PAGES);
        });
        _AddMiniToolbarEvents(lastPageDiv);
        menuDiv.appendChild(lastPageDiv);
        
        menuDiv.appendChild(_buildMenuHr());
    }
    
    function _buildMiniRotateGroup (menuDiv) {
        var rotateClockwiseDiv = _createMiniMenuItem("Rotate Clockwise", "/icons/pdf_rotate_clockwise.svg");
        rotateClockwiseDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _RotateDocumentPages(_pageRotation + 90);
        });
        _AddMiniToolbarEvents(rotateClockwiseDiv);
        menuDiv.appendChild(rotateClockwiseDiv);
        
        var rotateAntiClockwiseDiv = _createMiniMenuItem("Rotate Anti-clockwise", "/icons/pdf_rotate_anti_clockwise.svg");
        rotateAntiClockwiseDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _RotateDocumentPages(_pageRotation - 90);
        });
        _AddMiniToolbarEvents(rotateAntiClockwiseDiv);
        menuDiv.appendChild(rotateAntiClockwiseDiv);
        _bookmarks.length > 0
        menuDiv.appendChild(_buildMenuHr());
    }
    
    function _buildMiniZoomGroup (menuDiv) {
        var zoomInDiv = _createMiniMenuItem("Zoom In", "/icons/pdf_zoom_in.svg");
        zoomInDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _zoomButtonScale = 1.2;
            _zoomButtonPDF();
        });
        _AddMiniToolbarEvents(zoomInDiv);
        menuDiv.appendChild(zoomInDiv); 
        
        var zoomOutDiv = _createMiniMenuItem("Zoom Out", "/icons/pdf_zoom_out.svg");
        zoomOutDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _zoomButtonScale = 0.8;
            _zoomButtonPDF();
        });
        _AddMiniToolbarEvents(zoomOutDiv);
        menuDiv.appendChild(zoomOutDiv);
        
        menuDiv.appendChild(_buildMenuHr());
        
        var pageModeOptionsDiv = document.createElement("div");
        pageModeOptionsDiv.id = "PdfToolbarMiniMenuPageModeOptions";
        pageModeOptionsDiv.setAttribute('style', "display: none; position: fixed; background-color: #4D5055; padding: 2px auto; overflow-y: scroll; scrollbar-width: none; -ms-overflow-style: none");
        var newStyle = "#PdfToolbarMiniMenuPageModeOptions::-webkit-scrollbar {display: none}";
        if (document.querySelector('style') && 
            document.querySelector('style').textContent.search(newStyle) == -1) {
            document.querySelector('style').textContent += newStyle;
        } else if (!document.querySelector('style')) {
            var style = document.createElement('style');
            style.textContent = newStyle;
            document.getElementsByTagName('head')[0].appendChild(style);
        }
        var pageModeButton = _createMiniMenuItem("Page Mode", null);
        var pageModeArrow = document.createElement("img");
        pageModeArrow.src = ThingView.resourcePath + "/icons/pdf_next_find.svg";
        pageModeArrow.setAttribute('style', "transform: rotate(90deg); float: right; overflow: visible");
        pageModeButton.appendChild(pageModeArrow);
        pageModeButton.addEventListener("click", function(e){
            e.stopPropagation();
            if (pageModeOptionsDiv.style.display == "none") {
                pageModeOptionsDiv.style.left = (parseInt(pageModeButton.getBoundingClientRect().right) + 5) + "px";
                pageModeOptionsDiv.style.top = (parseInt(pageModeButton.getBoundingClientRect().top) + 1) + "px";
                pageModeOptionsDiv.style.maxHeight = (menuDiv.clientHeight - (pageModeButton.getBoundingClientRect().top - menuDiv.getBoundingClientRect().top) - 1) + "px";
                pageModeOptionsDiv.style.display = "block";
                pageModeButton.style.backgroundColor = "#232B2D";
            } else {
                pageModeOptionsDiv.style.display = "none";
                pageModeButton.style.backgroundColor = "inherit";
            }
        });
        pageModeButton.addEventListener("mouseenter", function(){
            if (pageModeOptionsDiv.style.display == "none") {
                pageModeButton.style.backgroundColor = "#232B2D";
            }
        });
        pageModeButton.addEventListener("mouseleave", function(){
            if (pageModeOptionsDiv.style.display == "none") {
                pageModeButton.style.backgroundColor = "inherit";
            }
        });
        pageModeButton.appendChild(pageModeOptionsDiv);
        menuDiv.appendChild(pageModeButton);
        
        var pageModeTexts = ["Original", "Fit Page", "Fit Width", "500%", "250%", "200%", "100%", "75%", "50%"];
        for (var i = 0; i < pageModeTexts.length; i++) {
            var optionDiv = document.createElement("div");
            optionDiv.setAttribute('style', "white-space: nowrap; padding: 2px 5px");
            optionDiv.textContent = pageModeTexts[i];
            optionDiv.addEventListener("click", function(e){
                e.stopPropagation();
                var processedPageMode = e.target.innerHTML.replace(" ", "").replace("%", "percent");
                _pageMode = processedPageMode;
                _setPageModePDF(__CURRENT_PAGE);
                for (var j = 0; j < e.target.parentNode.childNodes.length; j++) {
                    e.target.parentNode.childNodes[j].style.backgroundColor = "inherit";
                }
                e.target.style.backgroundColor = "#232B2D";
            });
            optionDiv.addEventListener("mouseenter", function(e){
                e.target.style.backgroundColor = "#232B2D";
            });
            optionDiv.addEventListener("mouseleave", function(e){
                var processedPageMode = e.target.innerHTML.replace(" ", "").replace("%", "percent");
                if (_pageMode != processedPageMode) {
                    e.target.style.backgroundColor = "inherit";
                }
            });
            pageModeOptionsDiv.appendChild(optionDiv);
        }
        menuDiv.appendChild(_buildMenuHr());
    }
    
    function _buildMiniCursorGroup (menuDiv) {
        var panModeButton = _createMiniMenuItem("Pan Mode", "/icons/pdf_pan_view.svg");
        menuDiv.appendChild(panModeButton);
        var textModeButton = _createMiniMenuItem("Text Select Mode", "/icons/pdf_text_select.svg");
        menuDiv.appendChild(textModeButton);        
        if (_cursorMode == "pan") {
            panModeButton.style.backgroundColor = "#232B2D";
        } else if (_cursorMode == "text") {
            textModeButton.style.backgroundColor = "#232B2D";
        }
        
        panModeButton.addEventListener("click", function(e){
            e.stopPropagation();
            if (_zoomButton) {
                _setZoomOnButton(_zoomButtonScale);
            }
            _cursorMode = "pan";
            _setUserSelect(document.getElementsByClassName("PdfPageDisplayTextLayer"));
            panModeButton.style.backgroundColor = "#232B2D";
            textModeButton.style.backgroundColor = "inherit";
        });
        textModeButton.addEventListener("click", function(e){
            e.stopPropagation();
            if (_zoomButton) {
                _setZoomOnButton(_zoomButtonScale);
            }
            _cursorMode = "text";
            _setUserSelect(document.getElementsByClassName("PdfPageDisplayTextLayer"));
            textModeButton.style.backgroundColor = "#232B2D";
            panModeButton.style.backgroundColor = "inherit";
        });
        
        panModeButton.addEventListener("mouseenter", function(){
            if (_cursorMode != "pan") {
                panModeButton.style.backgroundColor = "#232B2D";
            }
        });
        panModeButton.addEventListener("mouseleave", function(){
            if (_cursorMode != "pan") {
                panModeButton.style.backgroundColor = "inherit";
            }
        });
        textModeButton.addEventListener("mouseenter", function(){
            if (_cursorMode != "text") {
                textModeButton.style.backgroundColor = "#232B2D";
            }
        });
        textModeButton.addEventListener("mouseleave", function(){
            if (_cursorMode != "text") {
                textModeButton.style.backgroundColor = "inherit";
            }
        });
        
        menuDiv.appendChild(_buildMenuHr());
    }
    
    function _buildMiniSidebarGroup (menuDiv) {
        var sidebarToggleDiv = _createMiniMenuItem("Display Sidebar", "/icons/pdf_sidebar.svg");
        if (_sidebarEnabled){
            sidebarToggleDiv.style.backgroundColor = "#232B2D";
        }
        sidebarToggleDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _togglePdfSidePane();
            if (_sidebarEnabled){
                sidebarToggleDiv.style.backgroundColor = "#232B2D";
            } else {
                sidebarToggleDiv.style.backgroundColor = "inherit";
            }
        });
        sidebarToggleDiv.addEventListener("mouseenter", function(){
            if(!_sidebarEnabled){
                sidebarToggleDiv.style.backgroundColor = "#232B2D";
            }
        });
        sidebarToggleDiv.addEventListener("mouseleave", function(){
            if(!_sidebarEnabled){
                sidebarToggleDiv.style.backgroundColor = "inherit";
            }
        });
        menuDiv.appendChild(sidebarToggleDiv);
        menuDiv.appendChild(_buildMenuHr());
    }
    
    function _buildMiniPrintGroup (parent, menuDiv) {
        var printDiv = _createMiniMenuItem("Print PDF", "/icons/pdf_print.svg");
        _AddMiniToolbarEvents(printDiv);
        printDiv.addEventListener("click", function(e){
            e.stopPropagation();
            _PrintPdf(parent);
        });
        menuDiv.appendChild(printDiv);
    }
    
    function _createMiniMenuItem (text, imgURL) {
        var item = document.createElement("div");
        item.setAttribute('style', "background-color: #4D5055; color: #FFFFFF; cursor: pointer; height: 23px; padding-right: 10px; padding-top: 7px");
        item.textContent = text;
        if (imgURL) {
            var itemIcon = document.createElement("img");
            itemIcon.src = ThingView.resourcePath + imgURL;
            itemIcon.setAttribute('style', "margin: 0px 18px 0px 12px");
            item.insertBefore(itemIcon, item.childNodes[0]);
        } else {
            item.style.paddingLeft = "46px";
        }
        return item;
    }
    
    function _AddMiniToolbarEvents (button) {
        button.addEventListener("mouseenter", function(){
            button.style.backgroundColor = "#232B2D";
        });
        button.addEventListener("mouseleave", function(){
            button.style.backgroundColor = "inherit";
        });
    }
    
    function _setDocumentMenuUnderline (target) {
        if (_toolbarEnabled && _miniToolbar) {
            var options = target.parentNode.childNodes;
            for (var i = 0; i < options.length; i++) {
                options[i].style.textDecoration = "none";
            }
            target.style.textDecoration = "underline";
        }
    }
    
    function _BuildDocumentSearchToolbar (parent) {
        var searchButton = document.createElement("div");
            searchButton.id = "CreoToolbarSearchGroup";
            searchButton.setAttribute('style', "display: inline-block; margin: 6px; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none");
            var searchIcon = document.createElement("img");
            _AddToolbarButtonLoad(searchIcon);
            searchIcon.alt = 'Search...';
            searchIcon.src = ThingView.resourcePath + '/icons/pdf_find.svg';
            searchButton.style.padding = "5px";
            searchButton.appendChild(searchIcon);
            searchButton.style.cursor = "pointer";
            
            var searchGroup = document.createElement("div");
            searchGroup.setAttribute('style', "display: none; color: #FFFFFF; background-color: #44474B; position: absolute; z-index: 1; padding: 0px 5px 5px; margin-top: 7.5px; top: 80px; right: 30px; cursor: move");
            searchGroup.id = "PdfToolbarSearchBox";
            _searchDrag.y = 80;
            _searchDrag.x = _toolbarHeight;
            
            var searchTextWrapper = document.createElement("span");
            searchTextWrapper.setAttribute('style', "margin-right: 2px; margin-top: 5px; display: inline-block; vertical-align: middle");
            
            var searchTextBox = document.createElement("input");
            searchTextBox.id = "PdfToolbarSearchTextBox";
            searchTextBox.type = "text";
            searchTextBox.setAttribute('style', "cursor: auto");
            searchTextBox.addEventListener("click", function(e){
                e.stopPropagation();
            });
            searchTextBox.addEventListener("mousedown", function(e){
                e.stopPropagation();
            });
            searchTextBox.addEventListener("keydown", function(e){
                if (e.key == "Enter") {
                    if (_searchTerm != searchTextBox.value) {
                        _SearchInPdfDocument(searchTextBox.value);
                    } else if (_searchResults.length > 1){
                        if(_searchResultFocus == _searchResults.length-1){
                            _focusPdfSearchResult(0);
                        } else {
                            _focusPdfSearchResult(_searchResultFocus+1);
                        }
                    }
                }
            });
            searchTextWrapper.appendChild(searchTextBox);
            searchGroup.appendChild(searchTextWrapper);
            
            var searchQueryButton =_BuildDocumentToolbarButton('/icons/pdf_find.svg', false);
            searchQueryButton.style.verticalAlign = "middle";
            _AddToolbarButtonMouseOver(searchQueryButton);
            searchQueryButton.addEventListener("click", function(e){
                e.stopPropagation();
                _SearchInPdfDocument(searchTextBox.value);
            });
            searchGroup.appendChild(searchQueryButton);
            
            var searchClearButton = _BuildDocumentToolbarButton('/icons/pdf_clear.svg', false);
            searchClearButton.style.backgroundColor = "transparent";
            searchClearButton.style.verticalAlign = "middle";
            searchClearButton.style.position = "absolute";
            searchClearButton.style.float = "right";
            searchClearButton.style.margin = "-1px 0px auto -20px";
            searchClearButton.addEventListener("click", function(e){
                e.stopPropagation();
                _searchResults = [];
                _searchTerm = "";
                searchTextBox.value = "";
                _removePdfSearchResultHighlights ();
            });
            searchTextWrapper.appendChild(searchClearButton);
            
            var searchNextButton = _BuildDocumentToolbarButton('/icons/pdf_previous_find.svg', false);
            searchNextButton.style.verticalAlign = "middle";
            _AddToolbarButtonMouseOver(searchNextButton);
            searchNextButton.addEventListener("click", function(e){
                e.stopPropagation();
                if(_searchResults.length > 1){
                    if(_searchResultFocus == _searchResults.length-1){
                        _focusPdfSearchResult(0);
                    } else {
                        _focusPdfSearchResult(_searchResultFocus+1);
                    }
                }
            });
            searchGroup.appendChild(searchNextButton);
            
            var searchPrevButton = _BuildDocumentToolbarButton('/icons/pdf_next_find.svg', false);
            searchPrevButton.style.verticalAlign = "middle";
            _AddToolbarButtonMouseOver(searchPrevButton);
            searchPrevButton.addEventListener("click", function(e){
                e.stopPropagation();
                if(_searchResults.length > 1){
                    if(_searchResultFocus == 0){
                        _focusPdfSearchResult(_searchResults.length-1);
                    } else {
                        _focusPdfSearchResult(_searchResultFocus-1);
                    }
                }
            });
            searchGroup.appendChild(searchPrevButton);
            
            var searchCloseButton = _BuildDocumentToolbarButton('/icons/pdf_close.svg', false);
            searchCloseButton.style.margin = "0px 0px -20px 12px";
            searchCloseButton.style.padding = "0px";
            _AddToolbarButtonMouseOver(searchCloseButton);
            searchCloseButton.addEventListener("click", function(e){
                e.stopPropagation();
                searchGroup.style.display = "none";
                searchButton.style.backgroundColor = "inherit";
                searchButton.style.color = "inherit";
                _searchResults = [];
                _searchTerm = "";
                _removePdfSearchResultHighlights ();
            });
            searchGroup.appendChild(searchCloseButton);
            
            var searchResultsDiv = document.createElement("div");
            searchResultsDiv.id = "PdfToolbarSearchResultsDiv";
            searchResultsDiv.setAttribute('style', "text-align: center; margin-top: 1px");
            searchResultsDiv.textContent = "Enter a search term";
            searchGroup.appendChild(searchResultsDiv);
            
            searchButton.appendChild(searchGroup);
            
            searchButton.addEventListener("click", function(e){
                e.stopPropagation();
                _toggleSearchBox();
            });
            searchGroup.addEventListener("click", function(e){
                e.stopPropagation();
            });
            searchGroup.addEventListener("mousedown", function(e){
                if (!_searchDrag.enabled) {
                    _searchDrag.enabled = true;
                    _searchDrag.x = e.clientX;
                    _searchDrag.y = e.clientY;
                }
            });
            parent.addEventListener("mousemove", function(e){
                _dragSearchBox(parent, e);
            });
            parent.addEventListener("mouseleave", function(){
                if (_searchDrag.enabled) {
                    _searchDrag.enabled = false;
                }
            });
            parent.addEventListener("mouseup", function(){
                if (_searchDrag.enabled) {
                    _searchDrag.enabled = false;
                }
            });
            searchButton.addEventListener("mouseenter", function(){
                if (searchGroup.style.display == "none") {
                    searchButton.style.backgroundColor = "#232B2D";
                }
            });
            searchButton.addEventListener("mouseleave", function(){
                if (searchGroup.style.display == "none") {
                    searchButton.style.backgroundColor = "inherit";
                }
            });
            
        return searchButton;
    }
    
    function _toggleSearchBox () {
        if (!_IsPDFSession() || !_toolbarEnabled || !_toolbarGroups.search) {
            return;
        }
        _searchDrag.enabled = false;
        var searchGroup = document.getElementById("PdfToolbarSearchBox");
        var searchButton = document.getElementById("CreoToolbarSearchGroup");
        if(searchGroup.style.display == "none"){
            searchGroup.style.display = "block";
            document.getElementById("PdfToolbarSearchTextBox").value = "";
            document.getElementById("PdfToolbarSearchResultsDiv").textContent = "Enter a search term";
            searchButton.style.backgroundColor = "#232B2D";
            searchButton.style.color = "#000000";
        } else {
            searchGroup.style.display = "none";
            searchButton.style.backgroundColor = "inherit";
            searchButton.style.color = "inherit";
        }
    }
    
    function _dragSearchBox (parent, e) {
        if (_searchDrag.enabled) {
            var parentRect = parent.getBoundingClientRect();
            var searchBox = document.getElementById("PdfToolbarSearchBox");
            var searchRect = searchBox.getBoundingClientRect();
            if (!(parentRect.left > searchRect.left - (_searchDrag.x - e.clientX)
                || parentRect.right - 20 < searchRect.right - (_searchDrag.x - e.clientX)
                || parentRect.top + 35 > searchRect.top - (_searchDrag.y - e.clientY)
                || parentRect.bottom - 20 < searchRect.bottom - (_searchDrag.y - e.clientY))) {
                    searchBox.style.right = (parseInt(searchBox.style.right) + (_searchDrag.x - e.clientX)) + "px";
                    searchBox.style.top = (parseInt(searchBox.style.top) - (_searchDrag.y - e.clientY)) + "px";
            }
            _searchDrag.x = e.clientX;
            _searchDrag.y = e.clientY;
        }
    }
    
    function _toggleMenuScrollIndicator (menuDiv, parent) {
        if (!document.getElementById("PdfToolbarMiniMenuScrollIndicator") && !(menuDiv.scrollTop == (menuDiv.scrollHeight - menuDiv.offsetHeight))) {
            var scrollIndicator = document.createElement("div");
            scrollIndicator.id = "PdfToolbarMiniMenuScrollIndicator";
            scrollIndicator.setAttribute('style', "background-color: #4D5055; box-shadow: 0px -7px 6px 0px #4D5055; width: " + (parseInt(menuDiv.clientWidth) - 10) + "px; height: 20px; position: fixed; bottom: " + (window.innerHeight - parseInt(menuDiv.getBoundingClientRect().bottom)) + "px; left: " + (parseInt(menuDiv.getBoundingClientRect().left) + 5) + "px");
            var scrollArrow = document.createElement("img");
            scrollArrow.src = ThingView.resourcePath + "icons/pdf_previous_find.svg";
            scrollArrow.setAttribute('style',"left: " + (parseInt(scrollIndicator.style.width)/2 - 8) + "px; top: 2px; position: absolute");
            scrollIndicator.appendChild(scrollArrow);
            menuDiv.appendChild(scrollIndicator);
        } else if (document.getElementById("PdfToolbarMiniMenuScrollIndicator") && (menuDiv.scrollTop == (menuDiv.scrollHeight - menuDiv.offsetHeight))){
            menuDiv.removeChild(document.getElementById("PdfToolbarMiniMenuScrollIndicator"));
        }
    }
    
    function _buildToolbarCover (parent) {
        var toolbarCover = document.createElement('div');
        toolbarCover.id = "PdfToolbarCover";
        toolbarCover.setAttribute('style', "display: block; z-index: 4; background-color: #44474B; width:" + parseInt(parent.clientWidth) + "px; height: " + _toolbarHeight + "px; position: fixed; top: " + (parseInt(parent.getBoundingClientRect().top) + 2) + "px");
        parent.appendChild(toolbarCover);
    }
    
    function _toggleToolbarCover (state) {
        if (!state) {
            return;
        }
        if (state == "none") {
            _toolbarGroupsLoaded.current += 1;
            if (_toolbarGroupsLoaded.targetFull == 0 || 
               (!_miniToolbar && _toolbarGroupsLoaded.current == _toolbarGroupsLoaded.targetFull) ||
               (_miniToolbar && _toolbarGroupsLoaded.current == _toolbarGroupsLoaded.targetMini)) {
                    document.getElementById("PdfToolbarCover").style.display = state;
            }
        } else if (state == "block"){
            _toolbarGroupsLoaded.current = 0;
             document.getElementById("PdfToolbarCover").style.display = state;
        }
    }
    
    //PDF BOOKMARKS
    
    function _ShowPdfBookmark (bookmarkTitle) {
        var bookmarkData = _GetPdfBookmark(bookmarkTitle, _bookmarks);
        if(!bookmarkData){
            return;
        }
        __PDF_DOC.getDestination(bookmarkData.dest).then(function(val){
            var destination = val ? val : bookmarkData.dest;
            __PDF_DOC.getPageIndex(destination[0]).then(function(pageIndex){
                if(destination[1].name == "FitB") {
                    _pageMode = "FitPage";
                    _setPageModePDF(pageIndex+1);
                } else {
                    _LoadPage(function(success){
                        if (success) {
                            if (destination[1].name == "XYZ" && !_checkPageRotation()) {
                                var scrollWrapper = document.getElementById(_currentCanvasId).parentNode;
                                var scrollTopAdjustment = document.getElementById("PdfPageDisplayCanvas" + (pageIndex + 1)).clientHeight - (destination[3] * __ZOOMSCALE);
                                scrollWrapper.scrollTop += scrollTopAdjustment;
                                scrollWrapper.scrollLeft += destination[2] * __ZOOMSCALE;
                            }
                        }
                        if (_pdfCallback) {
                            _pdfCallback(success);
                        }
                    }, pageIndex+1);
                }
            });
        });
    }
    
    function _GetPdfBookmark(bookmarkTitle, bookmarkList) {
        var returnBookmark = null;
        for(var i = 0; i < bookmarkList.length; i++) {
            if (bookmarkList[i].title == bookmarkTitle) {
                returnBookmark = bookmarkList[i];
            } else if (bookmarkList[i].items.length > 0){
                returnBookmark = _GetPdfBookmark(bookmarkTitle, bookmarkList[i].items);
            }
            if (returnBookmark){
                break;
            }
        }
        return returnBookmark;
    }
    
    //PDF SEARCH
    
    function _SearchInPdfDocument(searchTerm) {
        if(searchTerm == ""){
            return;
        }
        var resultsDisplay = document.getElementById("PdfToolbarSearchResultsDiv");
        _removePdfSearchResultHighlights();
        _searchResults = [];
        _searchTerm = searchTerm;
        _DisplayPdfSearchResultsDialogue(resultsDisplay);
        if (!_searchCaseMatch) {
            searchTerm = searchTerm.toLowerCase();
        }
        _BuildPdfSearchTermResults(searchTerm, [], 1, function(results){;
            if(results.length == 0){
                console.log("Search Term '" + searchTerm + "' not found");
            } else {
                _searchResults = results;
                _focusPdfSearchResult(_getFirstSearchResultForPage(__CURRENT_PAGE));
            }
            _UpdatePdfSearchResultsDialogue(resultsDisplay);
        });
    }
    
    function _BuildPdfSearchTermResults(searchTerm, results, i, callback) {
        if (i <= __TOTAL_PAGES){
            __PDF_DOC.getPage(i).then(function(page){return page.getTextContent();})
                .then (function(textContent){
                    for(var j = 0 ; j<textContent.items.length; j++){
                        var textToSearch = _searchCaseMatch ? textContent.items[j].str : textContent.items[j].str.toLowerCase();
                        if(textToSearch.indexOf(searchTerm) != -1){
                            var resultObject = {pageNo: i, textItem: textContent.items[j]};
                            results.push(resultObject);
                        } else {
                            var count = _CheckForPartialSearchTerm(searchTerm, textContent.items, j, results, i);
                            if (count) {
                                j += count == 0 ? 0 : count-1;
                            }
                        }
                    }
                    _BuildPdfSearchTermResults(searchTerm, results, i+1, callback);
                });
        } else {
            if (callback) {
                callback(results);
            }
        }
    }
    
    function _DisplayPdfSearchResultsDialogue (resultsDisplay) {
        if (!resultsDisplay){
            return;
        }
        resultsDisplay.textContent = "Searching for results...";
    }
    
    function _UpdatePdfSearchResultsDialogue(resultsDisplay) {
        if (!resultsDisplay){
            return;
        }
        if(_searchResults.length == 0) {
            resultsDisplay.textContent = "No results found.";
        } else if (_searchResults.length == 1) {
            resultsDisplay.textContent = "1 result found.";
        } else {
            resultsDisplay.textContent = _searchResults.length + " results found.";
        }
    }
    
    function _CheckForPartialSearchTerm(remainingSearchTerm, items, j, results, page){
        if (j == items.length) {
            return 0;
        } else if (items[j].str == " ") {
            var returnValue = _CheckForPartialSearchTerm(remainingSearchTerm, items, j+1, results, page);
            return returnValue == 0 ? 0 : 1+returnValue;
        }
        if (items[j].str.indexOf(remainingSearchTerm) == 0) {
            var resultObject = {pageNo: page, textItem: items[j]};
            results.push(resultObject);
            return 1;
        } else {
            var splitSearchTerm = remainingSearchTerm.split(" ");
            var compositeSearchTerm = "";
            for (var i = 0; i < splitSearchTerm.length; i++){
                compositeSearchTerm += splitSearchTerm[i];
                var position = items[j].str.indexOf(compositeSearchTerm);
                if (position == -1) {
                    return 0;
                } else if (position + compositeSearchTerm.length == items[j].str.length){
                    var resultObject = {pageNo: page, textItem: items[j]};
                    results.push(resultObject);
                    var newSearchTerm = "";
                    for (var k = i+1; k < splitSearchTerm.length-1; k++) {
                        newSearchTerm += splitSearchTerm[k] + " ";
                    }
                    newSearchTerm += splitSearchTerm[splitSearchTerm.length-1];
                    var returnValue = _CheckForPartialSearchTerm(newSearchTerm, items, j+1, results, page);
                    if (returnValue == 0) {
                        results.pop();
                    }
                    return returnValue == 0 ? 0 : 1+returnValue;
                } else {
                    compositeSearchTerm += " ";
                }
            }
            return 0;
        }
    }
    
    function _HighlightPdfSearchResult (result, searchTerm) {
        if(result.pageNo >= _firstLoadedPage && result.pageNo <= _lastLoadedPage) {
            var textLayer = document.getElementById("PdfPageDisplayTextLayer" + result.pageNo);
            var textElement = null;
            for (var i = 0; i<textLayer.childNodes.length; i++){
                var childNode = textLayer.childNodes[i];
                if(childNode.textContent == result.textItem.str
                   && parseInt(childNode.style.left) == parseInt(result.textItem.transform[4]*__ZOOMSCALE)
                   && parseInt(childNode.style.top) >= parseInt(textLayer.clientHeight - (result.textItem.transform[5]*__ZOOMSCALE))-(result.textItem.height*__ZOOMSCALE)
                   && parseInt(childNode.style.top) <= parseInt(textLayer.clientHeight - (result.textItem.transform[5]*__ZOOMSCALE))+(result.textItem.height*__ZOOMSCALE)) {
                    textElement = textLayer.childNodes[i];
                    break;
                }
            }
            if (!textElement) {
                return;
            }
            var highlightedTextElement = textElement.cloneNode(true);
            var casedSearchTerm = searchTerm;
            var casedInnerHtml = highlightedTextElement.innerHTML;
            if (!_searchCaseMatch) {
                casedSearchTerm = casedSearchTerm.toLowerCase();
                casedInnerHtml = casedInnerHtml.toLowerCase();
            }
            var regEx = new RegExp(casedSearchTerm, 'g');
            highlightedTextElement.className = "PdfSearchResultHighlight";
            highlightedTextElement.style.fontSize = parseInt(highlightedTextElement.style.fontSize) + 1;
            var partialMatch = _HighlightPartialSearchResult(casedInnerHtml, casedSearchTerm);
            if (partialMatch) {
                highlightedTextElement.innerHTML = partialMatch;
            }
            highlightedTextElement.innerHTML = casedInnerHtml.replace(regEx, "<span style='background-color: yellow; opacity: 0.5'>" + searchTerm + "</span>");
            textLayer.appendChild(highlightedTextElement);
        }
    }
    
    function _HighlightPartialSearchResult(innerHTML, remainingSearchTerm){
        var splitSearchTerm = remainingSearchTerm.split(" ");
        var compositeSearchTerm = "";
        for (var i = 0; i < splitSearchTerm.length; i++){
            compositeSearchTerm += splitSearchTerm[i];
            var position = innerHTML.indexOf(compositeSearchTerm);
            var checkIndex = 0;
            var found = position != innerHTML.indexOf(remainingSearchTerm, checkIndex);
            while(!found){
                checkIndex = position + 1;
                if (checkIndex >= innerHTML.length){
                    return null;
                }
                position = innerHTML.indexOf(compositeSearchTerm, checkIndex);
                if (position != innerHTML.indexOf(remainingSearchTerm, checkIndex) || position == -1){
                    found = true;
                }
            }
            if (position == -1) {
                if (compositeSearchTerm.indexOf(" ") != -1) {
                    return null;
                } else {
                    compositeSearchTerm = "";
                }
            } else if (position + compositeSearchTerm.length == innerHTML.length){
                innerHTML = innerHTML.substr(0,position) + "<span style='background-color: yellow; opacity: 0.5'>" + compositeSearchTerm + "</span>";
                return innerHTML;
            } else if (i < splitSearchTerm.length-1){
                compositeSearchTerm += " ";
            }
        }
        if(compositeSearchTerm != "" && innerHTML.indexOf(compositeSearchTerm) == 0){
            innerHTML = innerHTML.replace(compositeSearchTerm, "<span style='background-color: yellow; opacity: 0.5'>" + compositeSearchTerm + "</span>");
            return innerHTML;
        }
        return null;
    }
    
    function _removePdfSearchResultHighlights () {
        var textLayers = document.getElementsByClassName("PdfPageDisplayTextLayer");
        for (var i = 0; i < textLayers.length; i++) {
            var j = 0;
            while (j < textLayers[i].childNodes.length){
                if(textLayers[i].childNodes[j].className == "PdfSearchResultHighlight") {
                    textLayers[i].removeChild(textLayers[i].childNodes[j]);
                } else {
                    j++;
                }
            }
        }
        var resultsDisplay = document.getElementById("PdfToolbarSearchResultsDiv");
        if (resultsDisplay) {
            resultsDisplay.textContent = "Enter a search term";
        }
    }
    
    function _focusPdfSearchResult (resultNumber) {
        if(resultNumber < 0 || resultNumber > _searchResults.length || _searchResults.length == 0){
            return;
        }
        _searchResultFocus = resultNumber;
        _removePdfSearchResultHighlights();
        _LoadPage(function(success){
            _HighlightPdfSearchResult(_searchResults[resultNumber], _searchTerm);
            var scrollWrapper = document.getElementById(_currentCanvasId).parentNode;
            _ignoreScrollEvent = true;
            scrollWrapper.scrollLeft = (_searchResults[resultNumber].textItem.transform[4]*__ZOOMSCALE)-(_searchResults[resultNumber].textItem.height*__ZOOMSCALE);
            scrollWrapper.scrollTop += document.getElementById("PdfPageDisplayTextLayer" + _searchResults[resultNumber].pageNo).clientHeight - (_searchResults[resultNumber].textItem.transform[5]*__ZOOMSCALE) - (_searchResults[resultNumber].textItem.height*__ZOOMSCALE);
            _ignoreScrollEvent = false;
            if (_pdfCallback) {
                _pdfCallback(success);
            }
        }, _searchResults[resultNumber].pageNo);
    }
    
    function _getFirstSearchResultForPage (pageNo) {
        for (var i = 0; i < _searchResults.length; i++) {
            if (_searchResults[i].pageNo >= pageNo){
                return i;
            }
        }
        return 0;
    }
    
    //PDF SIDEBAR
    
    function _DisplayPdfNavigationBar (parent, pageNo) {
        var navDiv = document.getElementById("CreoViewDocumentNavbar");
        _clearNavPages(navDiv);
        if (!navDiv) {
            navDiv = document.createElement("div");
            navDiv.id = "CreoViewDocumentNavbar";
            navDiv.setAttribute('style', "background-color: #656872; height: " + (parseInt(parent.clientHeight) - parseInt(parent.firstChild.clientHeight)) + "px; width: 100%; overflow-y: scroll; -webkit-overflow-scrolling: touch; scrollbar-width: none; -ms-overflow-style: none");
            var newStyle = "#CreoViewDocumentNavbar::-webkit-scrollbar {display: none}";
            if (document.querySelector('style') &&
                document.querySelector('style').textContent.search(newStyle) == -1) {
                document.querySelector('style').textContent += newStyle;
            } else if (!document.querySelector('style')) {
                var style = document.createElement('style');
                style.textContent = newStyle;
                document.getElementsByTagName('head')[0].appendChild(style);
            }
            navDiv.addEventListener("scroll", function(){
                _handleNavOnScroll(navDiv);
            });
            parent.appendChild(navDiv);
        }
        _PopulatePdfNavigationBar(navDiv, pageNo);
    }
    
    function _PopulatePdfNavigationBar (navDiv, pageNo) {
        _prepareNavWrapper(1, navDiv, function(){
            var pageLimit = 11 > __TOTAL_PAGES ? __TOTAL_PAGES : 11;
            _displayNavPages(1, pageLimit, function(){
                _navbar.firstLoadedPage = 1;
                _selectNavPage(document.getElementById("PdfNavPageWrapper" + pageNo), pageNo);
                _scrollNavbarToPage(navDiv, pageNo);
            });
        });
    }
    
    function _prepareNavWrapper (pageNo, navDiv, callback){
        __PDF_DOC.getPage(pageNo).then(function(page){
            var viewport = page.getViewport(0.2);
            var navWrapper = document.createElement("div");
            navWrapper.height = viewport.height;
            navWrapper.width = viewport.width;
            if (parseInt(navDiv.parentNode.clientWidth) > 300) {
                navWrapper.setAttribute('style', "width: " + viewport.width + "px; height: " + viewport.height + "px; margin: 10px 15px; display: inline-block; box-shadow: 3px 3px 12px rgba(0,0,0,0.5); cursor: pointer; transform: rotate(" + _pageRotation + "deg)");
                navDiv.style.textAlign = "left";
            } else {
                navWrapper.setAttribute('style', "width: " + viewport.width + "px; height: " + viewport.height + "px; margin: 10px auto; box-shadow: 3px 3px 12px rgba(0,0,0,0.5); cursor: pointer; transform: rotate(" + _pageRotation + "deg)");
                navDiv.style.textAlign = "center";
            }
            if (_checkPageRotation()) {
                var newTopMargin = 10 - (Math.abs(viewport.height - viewport.width)/2);
                var newBottomMargin = 10 - (Math.abs(viewport.height - viewport.width));
                if (parseInt(navDiv.parentNode.clientWidth) > 300) {
                    var newSideMargin = (Math.abs(viewport.width - viewport.height)/2) + 15;
                    navWrapper.style.margin =  newTopMargin + "px " + newSideMargin + "px " + newBottomMargin + "px";
                } else {
                    navWrapper.style.margin =  newTopMargin + "px auto " + newBottomMargin + "px";
                }
            }
            navWrapper.id = "PdfNavPageWrapper" + pageNo;
            navWrapper.addEventListener("click", function(){
                _selectNavPage(navWrapper, pageNo);
                _LoadPage(_pdfCallback, pageNo);
            });
            navWrapper.addEventListener("mouseenter", function(){
                document.body.style.cursor = "pointer";
            });
            navWrapper.addEventListener("mouseleave", function(){
                document.body.style.cursor = "auto";
            });
            navDiv.appendChild(navWrapper);
            if (pageNo < __TOTAL_PAGES) {
                _prepareNavWrapper(pageNo+1, navDiv, callback);
            } else {
                if (callback) {
                    callback();
                }
            }
        });
    }
    
    function _displayNavPages (pageNo, maxPageNo, callback){
        __PDF_DOC.getPage(pageNo).then(function(page){
            var navWrapper = document.getElementById("PdfNavPageWrapper" + pageNo);
            var viewport = page.getViewport(0.2);
            var canvas = document.createElement("canvas");
            canvas.id = "PdfNavPageCanvas" + pageNo;
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            var context = canvas.getContext('2d', {alpha: false});
            page.render({canvasContext: canvas.getContext('2d'), viewport: viewport}).then(function(){
                navWrapper.appendChild(canvas);
                if (pageNo < maxPageNo && pageNo < __TOTAL_PAGES){
                    _displayNavPages(pageNo+1, maxPageNo, callback);
                } else {
                    _ignoreScrollEvent = false;
                    _navbar.lastLoadedPage = maxPageNo;
                    if (callback) {
                        callback();
                    }
                }
            });
        });
    }
    
    function _RemovePdfSideBar (parent){
        if (_sidebarEnabled) {
            var sideBar = document.getElementById("CreoViewDocumentSidebar");
            if (sideBar) {
                parent.removeChild(sideBar);
                var currentCanvas = document.getElementById(_currentCanvasId);
                if (currentCanvas) {
                    currentCanvas.parentNode.style.marginLeft = "auto";
                }
                parent.removeEventListener("mousemove", function(e){
                    _ResizePdfSideBar(e, parent, sidebarDiv, scrollWrapper);
                });
                parent.removeEventListener("mouseup", function(e){
                    if (_sidebarResize) {
                        parent.style.cursor = "auto";
                        sidebarDiv.style.cursor = "auto";
                        _sidebarResize = false;
                        if (_navbar.enabled) {
                            var navDiv = document.getElementById("CreoViewDocumentNavbar");
                            if ((parseInt(sidebarDiv.clientWidth) > 300 && navDiv.style.textAlign == "center")
                                || (parseInt(sidebarDiv.clientWidth) <= 300 && navDiv.style.textAlign == "left")) {
                                _clearNavPages(navDiv);
                                _PopulatePdfNavigationBar(navDiv, _navbar.selectedPage);
                            }
                        }
                    }
                });
                _sidebarResize = false;
            }
        }
    }
    
    function _RemovePdfNavigationBar (parent){
        if (_sidebarEnabled && _navbar.enabled){
            parent.removeChild(document.getElementById("CreoViewDocumentNavbar"));
        }
    }
    
    function _clearNavPages (navDiv) {
        if (_navbar.enabled && navDiv){
            while (navDiv.firstChild) {
                navDiv.removeChild(navDiv.firstChild);
            }
        }
    }
    
    function _handleNavOnScroll(navDiv) {
        if (_ignoreScrollEvent) {
            return;
        }
        var currentLoadedHeight = _getNavPagesHeight(navDiv, _navbar.firstLoadedPage, _navbar.lastLoadedPage);
        if (currentLoadedHeight < navDiv.clientHeight) {
            if (_navbar._firstLoadedPage == 1 && _navbar._lastLoadedPage == __TOTAL_PAGES) {
                return;
            }                
            _ignoreScrollEvent = true;
            for (var i = _navbar.firstLoadedPage; i <= _navbar.lastLoadedPage; i++){
                var navWrapper = document.getElementById("PdfNavPageWrapper" + i);
                while (navWrapper && navWrapper.firstChild) {
                    navWrapper.removeChild(navWrapper.firstChild);
                }
            }
            var j = _navbar.firstLoadedPage - 1;
            if (_navbar.firstLoadedPage > 1 && document.getElementById("PdfNavPageWrapper" + _navbar.firstLoadedPage).getBoundingClientRect().top > navDiv.scrollTop) {
                var top = document.getElementById("PdfNavPageWrapper" + _navbar.firstLoadedPage).getBoundingClientRect().top;
                for (j; j > 0; j--) {
                    top -= document.getElementById("PdfNavPageWrapper" + j).height;
                    if (top < navDiv.scrollTop) {
                        break;
                    }
                }
            }
            var i = _navbar.lastLoadedPage + 1;
            if (_navbar.lastLoadedPage < __TOTAL_PAGES && document.getElementById("PdfNavPageWrapper" + _navbar.lastLoadedPage).getBoundingClientRect().bottom < navDiv.scrollTop + navDiv.clientHeight) {
                var bottom  = currentLoadedHeight;
                for (i; i < __TOTAL_PAGES; i++) {
                    bottom += document.getElementById("PdfNavPageWrapper" + i).height;
                    if (bottom > navDiv.clientHeight) {
                        break;
                    }
                }
            }
            _navbar.bufferSize = _navbar.firstLoadedPage - j > i - _navbar.lastLoadedPage ? (_navbar.firstLoadedPage - j) + 5 : (i - _navbar.lastLoadedPage) + 5;
            var newFirstPage = _navbar.firstLoadedPage - _navbar.bufferSize > 0 ? _navbar.firstLoadedPage - _navbar.bufferSize : 1;
            var newLastPage = _navbar.lastLoadedPage + _navbar.bufferSize < __TOTAL_PAGES ? _navbar.lastLoadedPage + _navbar.bufferSize : __TOTAL_PAGES;
            _displayNavPages(newFirstPage, newLastPage, function(){
                _ignoreScrollEvent = false;
            });
        } else if (navDiv.scrollTop+navDiv.clientHeight - _getNavPagesHeight(navDiv, 1, _navbar.lastLoadedPage) > navDiv.clientHeight
              || _getNavPagesHeight(navDiv, 1, _navbar.firstLoadedPage) - navDiv.scrollTop > navDiv.clientHeight) {
            _ignoreScrollEvent = true;
            for (var i = _navbar.firstLoadedPage; i <= _navbar.lastLoadedPage; i++){
                var navWrapper = document.getElementById("PdfNavPageWrapper" + i);
                while (navWrapper && navWrapper.firstChild) {
                    navWrapper.removeChild(navWrapper.firstChild);
                }
            }
            var currentNavPage = _getCurrentNavPage(navDiv);
            var newFirstPage = currentNavPage-_navbar.bufferSize > 0 ? currentNavPage-_navbar.bufferSize : 1;
            var newLastPage = currentNavPage+_navbar.bufferSize <= __TOTAL_PAGES ? currentNavPage+_navbar.bufferSize : __TOTAL_PAGES;
            _displayNavPages(newFirstPage, newLastPage, function(){
                _navbar.firstLoadedPage = newFirstPage;
                _ignoreScrollEvent = false;
                _handleNavOnScroll(navDiv);
            });
        } else if (_navbar.lastLoadedPage < __TOTAL_PAGES && _getNavPagesHeight(navDiv, 1, _navbar.lastLoadedPage) < navDiv.scrollTop+navDiv.clientHeight) {
            _ignoreScrollEvent = true;
            for (var i = 0; i < _navbar.bufferSize; i++){
                if (_navbar.firstLoadedPage > __TOTAL_PAGES || _navbar.firstLoadedPage < 1) {
                    break;
                }
                var navWrapper = document.getElementById("PdfNavPageWrapper" + _navbar.firstLoadedPage);
                while (navWrapper.firstChild) {
                    navWrapper.removeChild(navWrapper.firstChild);
                }
                _navbar.firstLoadedPage += 1;
            }
            var newFirstPage = _navbar.lastLoadedPage+1 <= __TOTAL_PAGES ? _navbar.lastLoadedPage+1 : __TOTAL_PAGES;
            var newLastPage = _navbar.lastLoadedPage+_navbar.bufferSize <= __TOTAL_PAGES ? _navbar.lastLoadedPage+_navbar.bufferSize : __TOTAL_PAGES;
            _displayNavPages(newFirstPage, newLastPage, function(){
                _ignoreScrollEvent = false;
            });
        } else if (_navbar.firstLoadedPage > 1 && _getNavPagesHeight(navDiv, 1, _navbar.firstLoadedPage) + (navDiv.clientHeight/2) > navDiv.scrollTop) {
            _ignoreScrollEvent = true;
            for (var i = 0; i < _navbar.bufferSize; i++){
                if (_navbar.lastLoadedPage < 1 || _navbar.lastLoadedPage > __TOTAL_PAGES) {
                    break;
                }
                var navWrapper = document.getElementById("PdfNavPageWrapper" + _navbar.lastLoadedPage);
                while (navWrapper.firstChild) {
                    navWrapper.removeChild(navWrapper.firstChild);
                }
                _navbar.lastLoadedPage -= 1;
            }
            var lastPageTemp = _navbar.lastLoadedPage;
            var newFirstPage = _navbar.firstLoadedPage-_navbar.bufferSize > 0 ? _navbar.firstLoadedPage-_navbar.bufferSize : 1;
            var newLastPage = _navbar.firstLoadedPage-1 > 0 ? _navbar.firstLoadedPage-1 : 1;
            _displayNavPages(newFirstPage, newLastPage, function(){
                _navbar.lastLoadedPage = lastPageTemp;
                _navbar.firstLoadedPage = newFirstPage;
                _ignoreScrollEvent = false;
            });
        }
    }
    
    function _getNavPagesHeight (navDiv, firstPage, lastPage) {
        if (firstPage > lastPage || firstPage == 0 || lastPage == 0) {
            return 0;
        }
        var height = 0;
        for (var i = firstPage; i < lastPage; i++) {
            var navWrapper = document.getElementById("PdfNavPageWrapper" + i);
            if (_checkPageRotation()) {
                height += parseInt(navWrapper.style.width) + 10;
            } else {
                height += parseInt(navWrapper.style.height) + 10;
            }
        }
        return height;
    }
    
    function _getCurrentNavPage (navDiv) {
        var scrollHeight = navDiv.scrollTop + (navDiv.clientHeight/2);
        var height = 0;
        var i = 1;
        for (i; i < __TOTAL_PAGES; i++) {
            var navWrapper = document.getElementById("PdfNavPageWrapper" + i);
            if (_checkPageRotation()) {
                height += parseInt(navWrapper.style.width) + 10;
            } else {
                height += parseInt(navWrapper.style.height) + 10;
            }
            if (height > scrollHeight) {
                break;
            }
        }
        i = i > 1 ? i-1 : 1;
        return i;
    }
    
    function _selectNavPage(navWrapper, pageNo) {
        if (pageNo < 1 || pageNo > __TOTAL_PAGES || !navWrapper) {
            return;
        }
        if (_navbar.selectedPage > 0 && _navbar.selectedPage <= __TOTAL_PAGES) {
            document.getElementById("PdfNavPageWrapper" + _navbar.selectedPage).style.border = "none";
        }
        navWrapper.style.border = "8px solid #80858E";
        _navbar.selectedPage = pageNo;
    }
    
    function _scrollNavbarToPage (navDiv, pageNo) {
        if (pageNo > __TOTAL_PAGES || pageNo < 1 || !navDiv || (pageNo == 1 && __TOTAL_PAGES == 1)) {
            return;
        }
        if (pageNo <= __TOTAL_PAGES) {
            if (_getNavPagesHeight(navDiv, 1, pageNo+1) > navDiv.scrollTop + navDiv.clientHeight || _getNavPagesHeight(navDiv, 1, pageNo) < navDiv.scrollTop) {
                navDiv.scrollTop = _getNavPagesHeight(navDiv, 1, pageNo);
            }
        } else {
            navDiv.scrollTop = _getNavPagesHeight(navDiv, 1, pageNo);
        }
        _handleNavOnScroll(navDiv);
    }
    
    function _togglePdfSidePane () {
        var currentCanvas = document.getElementById(_currentCanvasId);
        if (!currentCanvas){
            return;
        }
        var parentNode = document.getElementById(_currentCanvasId).parentNode.parentNode;
        if (!parentNode){
            return;
        }
        if (_sidebarEnabled){
            _RemovePdfSideBar(parentNode);
            _sidebarEnabled = false;
        } else {
            _sidebarEnabled = true;
            var tempPageNo = __CURRENT_PAGE;
            if (_bookmarks.length <= 0) {
                _bookmarksBar.enabled = false;
                _navbar.enabled = true;
            }
            if (_navbar.enabled){
                _DisplayPdfNavigationBar(_CreateSideBar(parentNode), tempPageNo);
            } else if (_bookmarksBar.enabled){
                _DisplayPdfBookmarksBar(_CreateSideBar(parentNode));
            }
        }
    }
    
    function _CreateSideBar (parent) {
        if (document.getElementById("CreoViewDocumentSidebar")) {
            return;
        }
        var sidebarDiv = document.createElement("div");
        sidebarDiv.id = "CreoViewDocumentSidebar";
        sidebarDiv.style.float = "left";
        sidebarDiv.style.width = "25%";
        sidebarDiv.setAttribute('style', "float: left; width: 300px")
        if (_toolbarEnabled) {
            sidebarDiv.style.height = parseInt(parent.clientHeight) - _toolbarHeight + "px";
        } else {
            sidebarDiv.style.height = "100%";
        }
        var scrollWrapper = document.getElementById(_currentCanvasId).parentNode;
        parent.insertBefore(sidebarDiv, scrollWrapper);
        scrollWrapper.style.marginLeft = "300px";
        var scrollWrapperTop = scrollWrapper.scrollTop;
        var scrollWrapperLeft = scrollWrapper.scrollLeft;
        _refreshPDF(function(){
            scrollWrapper.scrollTop = scrollWrapperTop;
            scrollWrapper.scrollLeft = scrollWrapperLeft;
        });
        
        var tabsDiv = document.createElement("div");
        tabsDiv.setAttribute('style', "width: 100%; height: " + _toolbarHeight + "px; background-color: #656872; position: relative; text-align: left");
        _PopulateSideBarTabs(tabsDiv);
        sidebarDiv.appendChild(tabsDiv);
        
        sidebarDiv.addEventListener("mouseover", function(e){
            if (!_sidebarResize 
                && e.clientX - parent.getBoundingClientRect().left > parseInt(sidebarDiv.style.width) - 5){
                sidebarDiv.style.cursor = "e-resize";
            }
        });
        
        sidebarDiv.addEventListener("mousemove", function(e){
            if (!_sidebarResize 
                && sidebarDiv.style.cursor == "e-resize" 
                && e.clientX - parent.getBoundingClientRect().left <= parseInt(sidebarDiv.style.width) - 5){
                    sidebarDiv.style.cursor = "auto";
            }
        });
        
        sidebarDiv.addEventListener("mousedown", function(e){
            if (!_sidebarResize 
                && e.clientX - parent.getBoundingClientRect().left > parseInt(sidebarDiv.style.width) - 5) {
                parent.style.cursor = "e-resize";
                _sidebarResize = true;
            }
        });
        
        parent.addEventListener("mouseup", function(e){
            if (_sidebarResize) {
                parent.style.cursor = "auto";
                sidebarDiv.style.cursor = "auto";
                _sidebarResize = false;
                if (_navbar.enabled) {
                    var navDiv = document.getElementById("CreoViewDocumentNavbar");
                    if ((parseInt(sidebarDiv.clientWidth) > 300 && navDiv.style.textAlign == "center")
                        || (parseInt(sidebarDiv.clientWidth) <= 300 && navDiv.style.textAlign == "left")) {
                        _clearNavPages(navDiv);
                        _PopulatePdfNavigationBar(navDiv, _navbar.selectedPage);
                    }
                }
            }
        });
        
        parent.addEventListener("mousemove", function(e){
            _ResizePdfSideBar(e, parent, sidebarDiv, scrollWrapper);
        });
        
        return sidebarDiv;
    }
    
    function _ResizePdfSideBar (e, parent, sidebarDiv, scrollWrapper) {
        if (_sidebarResize) {
                var newWidth = e.clientX - parent.getBoundingClientRect().left;
                if (newWidth > 200 && newWidth < parseInt(parent.clientWidth) - 200) {
                    sidebarDiv.style.width = newWidth + "px";
                    scrollWrapper.style.marginLeft = newWidth + "px";
                }
            }
    }
    
    function _PopulateSideBarTabs (tabsDiv) {
        var navbarTab = _BuildDocumentToolbarButton('/icons/pdf_nav_pane.svg', false);
        navbarTab.id = "CreoSidebarNavbarButton";
        navbarTab.style.position = "absolute";
        navbarTab.style.bottom = "6px";
        navbarTab.style.left = "6px";
        navbarTab.style.backgroundColor = "inherit";
        if (_navbar.enabled) {
            navbarTab.style.backgroundColor = "#3B4550";
        }
        tabsDiv.appendChild(navbarTab);
        
        var bookmarksTab = _BuildDocumentToolbarButton('/icons/pdf_bookmark.svg', false);
        bookmarksTab.id = "CreoSidebarBookmarksButton"
        bookmarksTab.style.position = "absolute";
        bookmarksTab.style.bottom = "6px";
        bookmarksTab.style.left = "38px";
        bookmarksTab.style.backgroundColor = "inherit";
        if (_bookmarksBar.enabled && _bookmarks.length > 0) {
            bookmarksTab.style.backgroundColor = "#3B4550";
        }
        if (_bookmarks.length <= 0) {
            bookmarksTab.style.opacity = 0.5;
            bookmarksTab.style.cursor = "auto";
        }
        tabsDiv.appendChild(bookmarksTab);
        
        navbarTab.addEventListener("click", function(){
            if (!_navbar.enabled) {
                navbarTab.style.backgroundColor = "#3B4550";
                bookmarksTab.style.backgroundColor = "#656872";
                _RemovePdfBookmarksBar(tabsDiv.parentNode);
                _navbar.enabled = true;
                _bookmarksBar.enabled = false;
                _DisplayPdfNavigationBar(tabsDiv.parentNode);
            }
        });
        if (_bookmarks.length > 0) {
            bookmarksTab.addEventListener("click", function(){
                if (!_bookmarksBar.enabled) {
                    bookmarksTab.style.backgroundColor = "#3B4550";
                    navbarTab.style.backgroundColor = "#656872";
                    _RemovePdfNavigationBar(tabsDiv.parentNode);
                    _navbar.enabled = false;
                    _bookmarksBar.enabled = true;
                    _DisplayPdfBookmarksBar(tabsDiv.parentNode);
                }
            });
        }
        
        navbarTab.addEventListener("mouseenter", function(){
            if (!_navbar.enabled) {
                navbarTab.style.backgroundColor = "#3B4550";
            }
        });
        navbarTab.addEventListener("mouseleave", function(){
            if (!_navbar.enabled) {
                navbarTab.style.backgroundColor = "#656872";
            }
        });
        if (_bookmarks.length > 0) {
            bookmarksTab.addEventListener("mouseenter", function(){
                if (!_bookmarksBar.enabled) {
                    bookmarksTab.style.backgroundColor = "#3B4550";
                }
            });
            bookmarksTab.addEventListener("mouseleave", function(){
                if (!_bookmarksBar.enabled) {
                    bookmarksTab.style.backgroundColor = "#656872";
                }
            });
        }        
    }
    
    function _DisplayPdfBookmarksBar (parent) {
        var bookmarksDiv = document.createElement("div");
        bookmarksDiv.id = "CreoViewDocumentBookmarksBar";
        bookmarksDiv.setAttribute('style', "background-color: #656872; width: 100%; overflow-y: scroll; overflow-x: hidden; color: #FFFFFF; line-height: 30px; scrollbar-width: none; -ms-overflow-style: none");
        var newStyle = "#CreoViewDocumentBookmarksBar::-webkit-scrollbar {display: none}";
        if (document.querySelector('style') &&
            document.querySelector('style').textContent.search(newStyle) == -1) {
            document.querySelector('style').textContent += newStyle;
        } else if (!document.querySelector('style')) {
            var style = document.createElement('style');
            style.textContent = newStyle;
            document.getElementsByTagName('head')[0].appendChild(style);
        }
        bookmarksDiv.style.height = (parseInt(parent.clientHeight) - parseInt(parent.firstChild.clientHeight)) + "px";
        parent.appendChild(bookmarksDiv);
        _PopulatePdfBookmarksBar(bookmarksDiv);
    }
    
    function _PopulatePdfBookmarksBar (bookmarksDiv) {
        var bookmarksContent = document.createElement("div");
        bookmarksContent.id = "CreoViewDocumentBookmarksTreeWrapper";
        bookmarksContent.style.paddingTop = "5px";
        if(_bookmarks.length == 0){
            return;
        } else {
            _BuildDocumentBookmarksTree(bookmarksContent);
        }
        bookmarksDiv.appendChild(bookmarksContent);
    }
    
    function _BuildDocumentBookmarksTree(container) {
        var bookmarksTree = document.createElement("ul");
        bookmarksTree.id = "CreoViewDocumentBookmarksTree";
        bookmarksTree.setAttribute('style',"-webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; text-align: left; margin-left: -40px");
        for(var i = 0; i<_bookmarks.length; i++){
            _BuildDocumentBookmarksTreeContent(_bookmarks[i], bookmarksTree, 40);
        }
        container.appendChild(bookmarksTree);
    }
    
    function _BuildDocumentBookmarksTreeContent(bookmark, bookmarksTree, marginCul) {
        var liElem = document.createElement("li");
        liElem.className = "CreoBookmarkElement";
        liElem.setAttribute('style',"color: #FFFFFF; background-color: transparent; position: relative; display: block");
        var highlightDiv = document.createElement("div");
        highlightDiv.setAttribute('style', "background-color: inherit; height: 30px; width: 100%; position: absolute; top: 0px; z-index: 1");
        liElem.appendChild(highlightDiv);
        if (bookmark.items.length == 0) {
            var spanElem = document.createElement("span");
            spanElem.textContent = bookmark.title;
            spanElem.setAttribute('style', "cursor: pointer; margin-left: " + (marginCul + 31) + "px; z-index: 2; position: relative; display: block; word-wrap: break-word");
            spanElem.addEventListener("click", function(){
                _ShowPdfBookmark(bookmark.title);
            });
            spanElem.addEventListener("mouseenter", function(){
                highlightDiv.style.height = spanElem.clientHeight;
                highlightDiv.style.backgroundColor = "#3B4550";
            });
            spanElem.addEventListener("mouseleave", function(){
                highlightDiv.style.backgroundColor = "inherit";
            });
            liElem.appendChild(spanElem);
        } else {
            var caretElem = document.createElement("span");
            caretElem.setAttribute('style', "cursor: pointer; z-index: 2; position: absolute; margin-left: " + marginCul + "px;");
            var caretImg = document.createElement("img");
            caretImg.src = ThingView.resourcePath + "icons/pdf_previous_find.svg";
            caretImg.setAttribute('style', "transform: rotate(-90deg); margin-top: 7px");
            caretElem.appendChild(caretImg);
            caretElem.addEventListener("click", function(){
                if(liElem.childNodes[3].style.display == "none"){
                    liElem.childNodes[3].style.display = "block";
                    caretImg.style.transform = "none";
                } else {
                    liElem.childNodes[3].style.display = "none";
                    caretImg.style.transform = "rotate(-90deg)";
                }
            });
            
            var spanElem = document.createElement("span");
            spanElem.setAttribute('style', "cursor: pointer; margin-left: " + (marginCul + 31) + "px; z-index: 2; position: relative; display: block; word-wrap: break-word");
            spanElem.textContent = bookmark.title;
            spanElem.addEventListener("click", function(){
                _ShowPdfBookmark(bookmark.title);
            });
            spanElem.addEventListener("mouseenter", function(){
                highlightDiv.style.height = spanElem.clientHeight;
                highlightDiv.style.backgroundColor = "#3B4550";
            });
            spanElem.addEventListener("mouseleave", function(){
                highlightDiv.style.backgroundColor = "inherit";
            });
            liElem.appendChild(caretElem);
            liElem.appendChild(spanElem);
            var ulElem = document.createElement("ul");
            ulElem.setAttribute('style', "display: none; margin-left: " + (0 - marginCul) + "px");
            liElem.appendChild(ulElem);
            for (var i = 0; i<bookmark.items.length; i++){
                _BuildDocumentBookmarksTreeContent(bookmark.items[i], ulElem, marginCul*2);
            }
        }
        bookmarksTree.appendChild(liElem);
    }
    
    function _ClearPdfBookmarksBar (bookmarksDiv) {
        if (_sidebarEnabled && _bookmarksBar.enabled) {
            while (bookmarksDiv.firstChild) {
                bookmarksDiv.removeChild(bookmarksDiv.firstChild);
            }
        }
    }
    
    function _RemovePdfBookmarksBar (parent) {
        if (_sidebarEnabled && _bookmarksBar.enabled){
            parent.removeChild(document.getElementById("CreoViewDocumentBookmarksBar"));
        }
    }
    
    function _BuildDocumentToolbarButton (imgURL, onLoadEvent) {
        var buttonDiv = document.createElement("div");
        buttonDiv.setAttribute('style', "-webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; background-color: #44474B; margin-top: 6px; padding: 6px; cursor: pointer; display: inline-block; width: 16px; height: 16px");
        var buttonImage = document.createElement("img");
        if (onLoadEvent) {
            _AddToolbarButtonLoad(buttonImage);
        }
        buttonImage.src = ThingView.resourcePath + imgURL;
        buttonDiv.appendChild(buttonImage);
        return buttonDiv;
    }
    
    function _AddToolbarButtonMouseOver (button) {
        button.addEventListener("mouseenter", function(){
            button.style.backgroundColor = "#232B2D";
        });
        button.addEventListener("mouseleave", function(){
            button.style.backgroundColor = "#44474B";
        });
    }
    
    function _AddToolbarButtonLoad (buttonImage) {
        buttonImage.onload = function(){
            _toggleToolbarCover("none");
        }
    }
    
    // PDF ROTATE
    
    function _RotateDocumentPages (degrees) {
        if (degrees >= 360 || degrees <= -360) {
            degrees = degrees % 360;
        }
        _pageRotation = degrees;
        _refreshPDF(function(){
            if (_sidebarEnabled && _navbar.enabled) {
                _DisplayPdfNavigationBar (document.getElementById(_currentCanvasId).parentNode.parentNode, __CURRENT_PAGE);
            }
            _pdfCallback();
        });
    }
    
    function _checkPageRotation () {
        if ((_pageRotation >= 45 && _pageRotation <= 135)
            || (_pageRotation >= 225 && _pageRotation <= 315)
            || (_pageRotation >= -135 && _pageRotation <= -45)
            || (_pageRotation >= -315 && _pageRotation <= -225)) {
                return true;
            }
        return false;
    }
    
    // PDF PRINT
    
    function _PrintPdf (parent) {
        if (!_printEnabled || (_print && _print.running)) {
            return;
        }
        var canvasWrapper = document.getElementById(_currentCanvasId);
        var scrollWrapper = canvasWrapper.parentNode;
        _print = {running: true};
        _preparePrintStyling();
        var printDiv = document.createElement("div");
        printDiv.id = "PdfPrintDiv";
        printDiv.className = "PdfPrintElement";
        printDiv.setAttribute('style', "display: none");
        parent.appendChild(printDiv);
        window.addEventListener('afterprint', _removePdfPrintDiv);
        var docCursor = document.body.style.cursor != "" ? document.body.style.cursor : "auto";
        document.body.style.cursor = "wait";
        _populatePrintDiv(printDiv, function(){
            document.body.style.cursor = docCursor;
            window.print();
        });
    }
    
    function _populatePrintDiv (printDiv, callback) {
        var zoomScale = 150/72;
        _preparePrintWrapper(1, printDiv, zoomScale, function(){
            _preparePrintPage (1, zoomScale, function(){
                callback();
            });
        });
    }
    
    function  _preparePrintWrapper (pageNo, printDiv, zoomScale, callback){
        __PDF_DOC.getPage(pageNo).then(function(page){
            var viewport = page.getViewport(zoomScale);
            var printWrapper = document.createElement("div");
            printWrapper.id = "PdfPrintWrapper" + pageNo;
            printWrapper.className = "PdfPrintElement";
            printWrapper.height = viewport.height;
            printWrapper.width = viewport.width;
            printDiv.appendChild(printWrapper);
            if (pageNo >= __TOTAL_PAGES) {
                if (callback) {
                    callback();
                }
            } else {
                _preparePrintWrapper(pageNo+1, printDiv, zoomScale, callback);
            }
        });
    }
    
    function _preparePrintPage (pageNo, zoomScale, callback){
        __PDF_DOC.getPage(pageNo).then(function(page){
            var printWrapper = document.getElementById("PdfPrintWrapper" + pageNo);
            var viewport = page.getViewport(zoomScale);
            var canvas = document.createElement("canvas");
            canvas.className = "PdfPrintElement";
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            var context = canvas.getContext('2d', {alpha: false});
            page.render({canvasContext: canvas.getContext('2d'), viewport: viewport, intent: 'print'}).then(function(){
                printWrapper.appendChild(canvas);
                if (pageNo < __TOTAL_PAGES){
                    _preparePrintPage(pageNo+1, zoomScale, callback);
                } else {
                    if (callback) {
                        callback();
                    }
                }
            });
        });
    }
    
    function _preparePrintStyling () {
        //We don't need to remove a users @media print styling because the rules of precedence say the last in wins
        var newStyle = "@media print{ body :not(.PdfPrintElement){ display: none} .PdfPrintElement{ border: none !important; margin: 0px !important; padding: 0px !important; width: 100% !important; height: 100% !important; overflow: visible !important; box-shadow: none !important; display: block !important} @page{ margin: 0px} *{ float: none !important}}";
        if (!document.querySelector('style')) {
            var style = document.createElement('style');
            style.textContent = newStyle;
            document.getElementsByTagName('head')[0].appendChild(style);
        } else {
            document.querySelector('style').textContent += newStyle;
        }
    }
    
    function _removePrintStyling () {
        document.querySelector('style').textContent.replace("@media print{ body :not(.PdfPrintElement){ display: none} .PdfPrintElement{ border: none !important; margin: 0px !important; padding: 0px !important; width: 100% !important; height: 100% !important; overflow: visible !important; box-shadow: none !important; display: block !important} @page{ margin: 0px} *{ float: none !important}}", "");
    }
    
    function _addPdfPrintClass (element) {
        if (element.className != "") {
            element.className += " ";
        }
        element.className += "PdfPrintElement";
        if (element.parentNode && element.parentNode != document.body) {
            _addPdfPrintClass(element.parentNode);
        }
    }
    
    function _removePdfPrintDiv () {
        window.removeEventListener("afterprint", _removePdfPrintDiv);
        if (!_printEnabled || !_print || !_print.running) {
            return;
        }
        _print = null;
        _removePrintStyling();
        var printDiv = document.getElementById("PdfPrintDiv");
        printDiv.parentNode.removeChild(printDiv);
    }
    
    // MISC
    
    function _handleBrowserResize () {
        if(_toolbarEnabled){
            _resizeDocumentToolbar(document.getElementById(_parentCanvasId), _toolbarGroups);
        }
    }
    
     // PDF MARKUPS
    
    function _LoadPdfAnnotationSet(documentViewable, parentCanvasId, docScene, structure, annoSet, documentCallback) {
        _ignoreScrollEvent = true;
        _pdfAnnotationId = -1;
        _pdfParsedAnnotationSet = [];
        docScene.LoadPdf(documentViewable.idPath, documentViewable.index, structure, function(success) {
            if (!success) {
                return;
            }
            docScene.GetPdfBuffer(function(buffer){
                _LoadPdfFromBuffer(parentCanvasId, buffer, function(){
                    _pdfRawAnnotationSet = annoSet;
                    _processPdfAnnotationSet(annoSet, documentCallback);
                });
            });
        });
    }
    
    function _ApplyPdfAnnotationSet(annoSet, documentCallback) {
        _pdfRawAnnotationSet = annoSet;
        _processPdfAnnotationSet(annoSet, documentCallback);
    }
    
    function _processPdfAnnotationSet(annoSet, callback) {
        if (!annoSet) {
            return;
        }
        var stamps = [];
        for (var k = 0; k < annoSet.length; k++){
            var stamp = _displayPdfAnnotation(annoSet[k]);
            if (stamp){
                stamps.push(stamp);
            }
        }
        var canvases = document.getElementsByClassName("PdfAnnotationCanvas");
        var defs = "<defs><marker id='ClosedArrow' markerWidth='11' markerHeight='11' refX='3' refY='6'orient='auto'><path d='M2,6 L9,1 L9,10 Z' style='fill:rgb(255,0,0);' /></marker><marker id='ClosedArrowNote' markerWidth='11' markerHeight='11' refX='3' refY='6'orient='auto'><path d='M2,6 L9,1 L9,10 Z' style='fill:rgb(255,255,255);stroke:rgb(255,0,0)' /></marker><marker id='Circle' markerWidth='9' markerHeight='9' refX='5' refY='5' orient='auto'><circle cx='5' cy='5' r='3' style='fill:rgb(255,0,0);' /></marker></defs>";
        var svgFooter = "</svg>";
        for (var i = 0; i < canvases.length; i++) {
            var svgHeader = "<svg height = " + canvases[i].clientHeight + " width = " + canvases[i].clientWidth + ">";
            var tempInnerHtml = canvases[i].innerHTML;
            canvases[i].innerHTML = svgHeader + defs + tempInnerHtml + svgFooter;
        }
        for (var j = 0; j < stamps.length; j++){
            var pushStamp = stamps[j];
            var canvas = document.getElementById("PdfAnnotationCanvas" + pushStamp.pageNo);
            canvas.appendChild(pushStamp.stampImage);
        }
        var movableMarkups = document.getElementsByClassName("PdfAnnotationElement");
        for(var l = 0; l < movableMarkups.length; l++) {
            var drag = {
                x: 0,
                y: 0,
                index: -1,
                state: false
            };
            movableMarkups[l].addEventListener("mousedown", function(e){_handleMovePdfAnnoEvent(e, drag)});
            movableMarkups[l].addEventListener("mouseup", function(e){_handleMovePdfAnnoEvent(e, drag)});
            movableMarkups[l].addEventListener("mouseleave", function(e){_handleMovePdfAnnoEvent(e, drag)});
            movableMarkups[l].addEventListener("mouseenter", function(e){_handleMovePdfAnnoEvent(e, drag)});
            movableMarkups[l].addEventListener("mousemove", function(e){
                if(drag.state){
                    _handleMovePdfAnnoEvent(e, drag);
                }
            });
        }
        _ignoreScrollEvent = false;
        if (callback) {
            callback();
        }
    }
    
    function _displayPdfAnnotation(rawAnno){
        var annotation = _parsePdfRawAnnotation(rawAnno);        
        _pdfParsedAnnotationSet.push(annotation);
        if (!annotation) {
            console.log("Annotation type not supported");
            return;
        }
        if (annotation.pageNo < (_firstLoadedPage-1) || annotation.pageNo > (_lastLoadedPage-1)){
            return null;
        }
        var canvasId = "PdfAnnotationCanvas" + annotation.pageNo;
        var canvasWrapper = document.getElementById(_currentCanvasId);
        var canvas = document.getElementById(canvasId);
        if(!canvas || canvas.parentNode.parentNode != canvasWrapper){
            var pdfCanvas = document.getElementById("PdfPageDisplayWrapper" + (annotation.pageNo+1));
            canvas = document.createElement("div");
            canvas.setAttribute('id', canvasId);
            canvas.setAttribute('class', "PdfAnnotationCanvas");
            canvas.setAttribute('width', pdfCanvas.width + "px");
            canvas.setAttribute('height', pdfCanvas.height + "px");
            var positionTop = pdfCanvas.getBoundingClientRect().top - canvasWrapper.getBoundingClientRect().top;
            var positionLeft = pdfCanvas.getBoundingClientRect().left - canvasWrapper.getBoundingClientRect().left;
            canvas.setAttribute('style',"position: absolute; top: 0px; left: 0px; height: " + pdfCanvas.height + "px; width: " + pdfCanvas.width + "px; z-index: 3");
            pdfCanvas.insertBefore(canvas, pdfCanvas.firstChild);
            //pdfCanvas.childNodes[pdfCanvas.childNodes.length - 1].parentNode.insertBefore(canvas, pdfCanvas.childNodes[pdfCanvas.childNodes.length - 1].nextSibling);
        }
        switch (annotation.type) {
            case "LeaderLine":
                _displayPdfLeaderLine(annotation, canvas);
                return;
            case "PolyLine":
                _displayPdfPolyLine(annotation, canvas);
                return;
            case "Rectangle":
                _displayPdfRectangle(annotation, canvas);
                return null;
            case "Circle":
                _displayPdfCircle(annotation, canvas);
                return null;
            case "Polygon":
                _displayPdfPolygon(annotation, canvas);
                return null;
            case "Freehand":
                _displayPdfFreehand(annotation,canvas);
                return null;
            case "StrikeThrough":
                _displayPdfStrikeThrough(annotation, canvas);
                return null;
            case "Underline":
                _displayPdfUnderline(annotation, canvas);
                return null;
            case "Highlight":
                _displayPdfHighlight(annotation, canvas);
                return null;
            case "Note":
                _displayPdfNote(annotation, canvas);
                return null;
            case "Stamp":
                return {
                    stampImage: _displayPdfStamp(annotation, canvas),
                    pageNo: annotation.pageNo
                };
            default:
                console.log("Annotation type not supported");
        }
    }
    
    function _parsePdfRawAnnotation(rawAnno){
        switch (rawAnno.type){
            case "LeaderLine":
                return _parseLeaderLinePdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "PolyLine":
                return _parsePolyLinePdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Rectangle":
                return _parseRectanglePdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Circle":
                return _parseCirclePdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Polygon":
                return _parsePolygonPdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Freehand":
                return _parseFreehandPdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "StrikeThrough":
                return _parseStrikeThroughPdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Underline":
                return _parseUnderlinePdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Highlight":
                return _parseHighlightPdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Note":
                return _parseNotePdfRawAnno(rawAnno.data, rawAnno.pageNo);
            case "Stamp":
                return _parseStampPdfRawAnno(rawAnno.data, rawAnno.pageNo);
            default:
                return;
        }
    }
    
    function _getElementFromString(string, prefix, suffix) {
        if (suffix) {
            return string.substring(string.indexOf(prefix) + prefix.length, string.lastIndexOf(suffix));
        } else {
            return string.substring(string.indexOf(prefix) + prefix.length);
        }
    }
    
    function _getCorrectedBoundingBox(vertices, canvas){
        var box = {
            x1: vertices[0] < vertices[2] ? (vertices[0] * __ZOOMSCALE) : (vertices[2] * __ZOOMSCALE),
            x2: vertices[0] < vertices[2] ? (vertices[2] * __ZOOMSCALE) : (vertices[0] * __ZOOMSCALE),
            y2: vertices[1] > vertices[3] ? (canvas.clientHeight - (vertices[3] * __ZOOMSCALE)) : (canvas.clientHeight - (vertices[1] * __ZOOMSCALE)),
            y1: vertices[1] > vertices[3] ? (canvas.clientHeight - (vertices[1] * __ZOOMSCALE)) : (canvas.clientHeight - (vertices[3] * __ZOOMSCALE))
        }
        return box;
    }
    
    function _parseLeaderLinePdfRawAnno(data, pageNumber) {
        var annotation = {
            type: "LeaderLine",
            id: _getNextPdfAnnotationId(),
            vertices: _stringToFloatArray(_getElementFromString(data, "Vertices: ", ", Bounding")),
            boundingBox: _stringToFloatArray(_getElementFromString(data, "Bounding box: ", ", Head")),
            pageNo: pageNumber,
            head: _getElementFromString(data, "Head: ", ", Tail"),
            tail: _getElementFromString(data, "Tail: ")
        }
        return annotation;
    }
    
    function _parsePolyLinePdfRawAnno(data, pageNumber) {
        var annotation = _parseLeaderLinePdfRawAnno(data, pageNumber);
        annotation.type = "PolyLine";
        return annotation;
    }
    
    function _parseRectanglePdfRawAnno(data, pageNumber) {
        var annotation = {
            type: "Rectangle",
            id: _getNextPdfAnnotationId(),
            vertices: _stringToFloatArray(_getElementFromString(data, "Vertices: ", ", Filled")),
            pageNo: pageNumber,
            filled: _getElementFromString(data, "Filled: ") == "true" ? true : false
        }
        return annotation;
    }
    
    function _parseCirclePdfRawAnno(data, pageNumber) {
        var annotation = _parseRectanglePdfRawAnno(data, pageNumber);
        annotation.type = "Circle";
        return annotation;
    }
    
    function _parsePolygonPdfRawAnno(data, pageNumber) {
        var annotation = {
            type: "Polygon",
            id: _getNextPdfAnnotationId(),
            vertices: _stringToFloatArray(_getElementFromString(data, "Vertices: ", ", Bounding")),
            boundingBox: _stringToFloatArray(_getElementFromString(data, "Bounding box: ", ", Filled")),
            pageNo: pageNumber,
            filled: _getElementFromString(data, "Filled: ") == "true" ? true : false
        }
        return annotation;
    }
    
    function _parseFreehandPdfRawAnno(data, pageNumber) {
        var annotation = {
            type: "Freehand",
            id: _getNextPdfAnnotationId(),
            vertices: _stringToFloatArray(_getElementFromString(data, "Vertices: ", ", Bounding")),
            boundingBox: _stringToFloatArray(_getElementFromString(data, "Bounding box: ")),
            pageNo: pageNumber
        }
        return annotation;
    }
    
    function _parseStrikeThroughPdfRawAnno(data, pageNumber) {
        var annotation = {
            type: "StrikeThrough",
            id: _getNextPdfAnnotationId(),
            vertices: _stringToFloatArray(_getElementFromString(data, "Vertices: ", ", Bounding")),
            boundingBox: _stringToFloatArray(_getElementFromString(data, "Bounding box: ")),
            pageNo: pageNumber
        }
        return annotation;
    }
    
    function _parseUnderlinePdfRawAnno(data, pageNumber) {
        var annotation = _parseStrikeThroughPdfRawAnno(data, pageNumber);
        annotation.type = "Underline";
        return annotation;
    }
    
    function _parseHighlightPdfRawAnno(data, pageNumber) {
        var annotation = _parseStrikeThroughPdfRawAnno(data, pageNumber);
        annotation.type = "Highlight";
        return annotation;
    }
    
    function _parseNotePdfRawAnno(data, pageNumber) {
        var extractedContent = _getElementFromString(data, "Content: ", ", Font Family: ");
        data = data.replace(extractedContent, "");
        var lastIndex = 0;
        while(extractedContent.indexOf("\\r", lastIndex) != -1){
            var checkIndex = extractedContent.indexOf("\\r", lastIndex) - 1;
            if (!(checkIndex >= 0 && extractedContent.indexOf("\\\\r", lastIndex) == checkIndex)){
                var extractedSubstr = extractedContent.substr(extractedContent.indexOf("\\r", lastIndex));
                lastIndex = extractedContent.indexOf("\\r", lastIndex);
                var replaceSubstr = extractedSubstr.replace("\\r", " \n");
                extractedContent = extractedContent.replace(extractedSubstr, replaceSubstr);
            } else {
                lastIndex = extractedContent.indexOf("\\r", lastIndex) + 1;
                var extractIndex = checkIndex;
                while(extractIndex >= 1 && extractedContent[extractIndex-1] == "\\"){
                    extractIndex--;
                }
                var extractedSubstr = extractedContent.substr(extractIndex, checkIndex - extractIndex + 3);
                var replaceSubstr = Array((extractedSubstr.length-1)/2).join("\\");
                extractedContent = extractedContent.replace(extractedSubstr.substr(0,extractedSubstr.length-2), replaceSubstr);
            }
        }
        extractedContent = _sanitizeSvgText(extractedContent);
        var annotation = {
            type: "Note",
            id: _getNextPdfAnnotationId(),
            boundingBox: _stringToFloatArray(_getElementFromString(data, "Bounding box: ", ", Content")),
            pageNo: pageNumber,
            content: extractedContent,
            fontFamily: _getElementFromString(data, "Font Family: ", ", Text Alignment: "),
            textAlignment: _getElementFromString(data, "Text Alignment: ", ", Font Color:"),
            fontColor: _getElementFromString(data, "Font Color: ", ", Font Size:"),
            fontSize: parseFloat(_getElementFromString(data, "Font Size: ", ", Head:")),
            head: "",
            leaderLineVertices: []
        }
        if(data.indexOf("Leader Line Vertices: ") != -1){
            annotation.head = _getElementFromString(data, "Head: ", ", Leader Line Vertices");
            annotation.leaderLineVertices = _stringToFloatArray(_getElementFromString(data, "Leader Line Vertices: "));
        } else {
            annotation.head = _getElementFromString(data, "Head: ");
        }
        return annotation;
    }
    
    function _parseStampPdfRawAnno(data, pageNumber) {
        var annotation = {
            type: "Stamp",
            id: _getNextPdfAnnotationId(),
            vertices: _stringToFloatArray(_getElementFromString(data, "Vertices: ", ", Filter")),
            pageNo: pageNumber,
            filter: _getElementFromString(data, "Filter: ", ", Stream Length"),
            streamLength: parseInt(_getElementFromString(data, "Stream Length: ", ", Inflated Length")),
            inflatedLength: parseInt(_getElementFromString(data, "Inflated Length: ", ", Height")),
            height: parseInt(_getElementFromString(data, "Height: ", ", Width")),
            width: parseInt(_getElementFromString(data, "Width: ", ", Color Space")),
            colorSpace: _getElementFromString(data, "Color Space: ", ", Bits Per Component"),
            bitsPerComponent: parseInt(_getElementFromString(data, "Bits Per Component: ", ", Inflated Stream")),
            stream: _getElementFromString(data, "Inflated Stream: ")
        }
        return annotation;
    }
    
    // Displays
    function _displayPdfLeaderLine(annotation, canvas) {
        var svgElement =  "<line x1 = '" + (annotation.vertices[0] * __ZOOMSCALE) + "' y1 = '" + (canvas.clientHeight - (annotation.vertices[1] * __ZOOMSCALE)) + "' x2 = '" + (annotation.vertices[2] * __ZOOMSCALE) + "' y2 = '" + (canvas.clientHeight - (annotation.vertices[3] * __ZOOMSCALE)) + "' style = 'stroke:rgb(255,0,0);stroke-width:" + (1.5*__ZOOMSCALE) +"'";        
        var head = "";
        if(annotation.head != "None"){
            head = "marker-start='url(#" + annotation.head + ")' ";
        }  
        var tail = "";
        if(annotation.tail != "None"){
            tail = "marker-end='url(#" + annotation.tail + ")'";
        }
        var selectorBox = _buildLeaderLineSelectorBox(annotation.vertices, canvas, annotation.id);
        var svgCombined = "<g>" + svgElement + head + tail + " /></line>" + selectorBox + "</g>";
        canvas.innerHTML += svgCombined;
    }
    
    function _displayPdfPolyLine(annotation, canvas) {
        var svgElement = "<polyline points='" + _createPolyPointPath(annotation, canvas) + "' style='fill:none;stroke:rgb(255,0,0);stroke-width:" + 1.5*__ZOOMSCALE + "' ";
        var head = "";
        if (annotation.head != "None"){
            head = "marker-start='url(#" + annotation.head + ")' ";
        }        
        var tail = "";
        if (annotation.tail != "None"){
            tail = "marker-end='url(#" + annotation.tail + ")'";
        }
        var selectorBox = _buildPolyLineSelectorBox(annotation.vertices, canvas, annotation.id);
        var svgCombined = "<g>" + svgElement + head + tail + " /></polyline>" + selectorBox + "</g>";
        canvas.innerHTML += svgCombined;
    }
    
    function _displayPdfRectangle(annotation, canvas) {
        var box = _getCorrectedBoundingBox(annotation.vertices, canvas);
        var fill = annotation.filled ? "rgb(255,0,0)" : "transparent";
        var svgElement = "<rect id = 'PdfAnnotationElement" + annotation.id + "' class = 'PdfAnnotationElement' x='" + box.x1 + "' y='" + box.y1 + "' width='" + (box.x2 - box.x1) + "' height='" + (box.y2 - box.y1) + "' style='fill:" + fill + ";stroke:rgb(255,0,0);stroke-width:" + (1.5*__ZOOMSCALE) + ";opacity:0.5' /></rect>";
        canvas.innerHTML += svgElement;
    }
    
    function _displayPdfCircle(annotation, canvas) {
        var box = _getCorrectedBoundingBox(annotation.vertices, canvas);
        var cx = (box.x2 + box.x1)/2;
        var cy = (box.y2 + box.y1)/2;
        var rx = (box.x2 - box.x1)/2;
        var ry = (box.y2 - box.y1)/2;
        var fill = annotation.filled ? "rgb(255,0,0)" : "transparent";
        var svgElement = "<ellipse id = 'PdfAnnotationElement" + annotation.id + "' class = 'PdfAnnotationElement' cx='" + cx + "' cy='" + cy + "' rx='" + rx + "' ry='" + ry + "' style='stroke:rgb(255,0,0);stroke-width:" + (1.5*__ZOOMSCALE) + ";fill:" + fill + ";opacity:0.5'/></ellipse>";
        canvas.innerHTML +=svgElement;
    }
    
    function _displayPdfPolygon(annotation, canvas) {
        var fill = annotation.filled ? "rgb(255,0,0)" : "transparent";
        var svgElement = "<polygon id = 'PdfAnnotationElement" + annotation.id + "' class = 'PdfAnnotationElement' points='" + _createPolyPointPath(annotation, canvas) + "' style='stroke:rgb(255,0,0);stroke-width:" + (1.5*__ZOOMSCALE) + ";fill:" + fill + ";opacity:0.5'/></polygon>";
        canvas.innerHTML += svgElement;
    }
    
    function _displayPdfFreehand(annotation, canvas) {
        var path = "M" + (annotation.vertices[0] * __ZOOMSCALE) + " " + (canvas.clientHeight - (annotation.vertices[1] * __ZOOMSCALE));
        for (var i = 2; i < annotation.vertices.length-4; i+=4) {
            path += " Q" + (annotation.vertices[i] * __ZOOMSCALE) + " " + (canvas.clientHeight - (annotation.vertices[i+1] * __ZOOMSCALE)) + " " + (annotation.vertices[i+2] * __ZOOMSCALE) + " " + (canvas.clientHeight - (annotation.vertices[i+3] * __ZOOMSCALE));
        }
        var svgElement = "<path d='" + path + "' style='fill:none;stroke:rgb(255,0,0);stroke-width:" + (1.5*__ZOOMSCALE) + ";stroke-linejoin:round' /></path>";
        var selectorBox = _buildFreehandSelectorBox(annotation.vertices, canvas, annotation.id);
        canvas.innerHTML += "<g>" + svgElement + selectorBox + "</g>";
    }
    
    function _displayPdfStrikeThrough(annotation, canvas) {
        var path = "";
        for (var i = 0; i < annotation.vertices.length; i+=8){
            var x1 = annotation.vertices[i] * __ZOOMSCALE;
            var y1 = (canvas.clientHeight - (((annotation.vertices[i+1] * __ZOOMSCALE) + ((annotation.vertices[i+5] - 3) * __ZOOMSCALE))/2));
            var x2 = annotation.vertices[i+2] * __ZOOMSCALE;
            var y2 = (canvas.clientHeight - (((annotation.vertices[i+3] * __ZOOMSCALE) + ((annotation.vertices[i+7] - 3) * __ZOOMSCALE))/2));
            path += " M" + x1 + " " + y1 + " L" + x2 + " " + y2;
        }
        var svgElement = "<path id = 'PdfAnnotationElement" + annotation.id + "' d='" + path + "' style='stroke:rgb(255,0,0);stroke-width:" + (1.5*__ZOOMSCALE) + "' /></path>";
        canvas.innerHTML += svgElement;
    }
    
    function _displayPdfUnderline(annotation, canvas){
        var path = "";
        for (var i = 0; i < annotation.vertices.length; i+=8){
            var x1 = annotation.vertices[i] * __ZOOMSCALE;
            var y1 = (canvas.clientHeight - ((annotation.vertices[i+5] + 2) * __ZOOMSCALE));
            var x2 = annotation.vertices[i+2] * __ZOOMSCALE;
            var y2 = (canvas.clientHeight - ((annotation.vertices[i+7] + 2) * __ZOOMSCALE));
            path += " M" + x1 + " " + y1 + " L" + x2 + " " + y2;
        }
        var svgElement = "<path id = 'PdfAnnotationElement" + annotation.id + "' d='" + path + "' style='stroke:rgb(106,217,38);stroke-width:" + (1.5*__ZOOMSCALE) + "' /></path>";
        canvas.innerHTML += svgElement;
    }
    
    function _displayPdfHighlight(annotation, canvas){
        var path = "";
        for (var i = 0; i < annotation.vertices.length; i+=8){
            var x1 = annotation.vertices[i] * __ZOOMSCALE;
            var y1 = (canvas.clientHeight - ((annotation.vertices[i+1]) * __ZOOMSCALE));
            var x2 = annotation.vertices[i+2] * __ZOOMSCALE;
            var y2 = (canvas.clientHeight - ((annotation.vertices[i+5]) * __ZOOMSCALE));
            var xCurve1 = annotation.vertices[i] < annotation.vertices[i+2] ? (annotation.vertices[i] - 5)*__ZOOMSCALE : (annotation.vertices[i] + 5)*__ZOOMSCALE;
            var xCurve2 = annotation.vertices[i] > annotation.vertices[i+2] ? (annotation.vertices[i+2] - 5)*__ZOOMSCALE : (annotation.vertices[i+2] + 5)*__ZOOMSCALE;
            var yCurve = (y1 + y2) / 2;
            path += " M" + x1 + " " + y1 + " L" + x2 + " " + y1 + " S" + xCurve2 + " " + yCurve + " " + x2 + " " + y2 + " L" + x1 + " " + y2 + " S" + xCurve1 + " " + yCurve + " " + x1 + " " + y1;
        }
        var svgElement = "<path id = 'PdfAnnotationElement" + annotation.id + "' d='" + path + "' style='stroke:rgb(255,171,0);stroke-width:1;fill:rgb(255,171,0);opacity:0.5' /></path>";
        canvas.innerHTML += svgElement;
    }
    
    function _displayPdfNote(annotation, canvas){
        var box = _getCorrectedBoundingBox(annotation.boundingBox, canvas);
        var svgElement = "<g>";
        var textX = 0;
        var textY = 0;
        if (annotation.head == "None"){
            textX = box.x1 + (2 * __ZOOMSCALE);
            textY = box.y1 + (annotation.fontSize * __ZOOMSCALE); 
        } else {
            box = _getCorrectedLeaderLineBoundingBox (annotation, box, canvas);
            var path = "M" + annotation.leaderLineVertices[0]*__ZOOMSCALE + " " + (canvas.clientHeight - (annotation.leaderLineVertices[1] * __ZOOMSCALE));
            for (var i = 2; i < annotation.leaderLineVertices.length; i+=2){
                path += " L" + (annotation.leaderLineVertices[i] * __ZOOMSCALE) + " " + (canvas.clientHeight - (annotation.leaderLineVertices[i+1] * __ZOOMSCALE));
            }
            svgElement += "<path d='" + path + "' style='stroke:" + annotation.fontColor + ";stroke-width:" + (1.5*__ZOOMSCALE) + ";fill:none'" + "marker-start='url(#" + annotation.head + "Note)' " + " /></path>";
            textX = box.x1 + (2 * __ZOOMSCALE);
            textY = box.y1 + (annotation.fontSize * __ZOOMSCALE);
        }
        var styleName = "";
        var j = 0;
        var found = false;
        while (!found){
            if (canvas.innerHTML.indexOf(".TextStyle" + j + " { ") == -1) {
                styleName = "TextStyle" + j;
                found = true;
            } else {
                j++;
            }
        }
        var style = "<style> ." + styleName + " { font: normal " + (annotation.fontSize * __ZOOMSCALE) + "px " + "arial, sans-serif" + "; fill: " + annotation.fontColor + "; }</style>";
        var formattedObject = _buildAdjustedNoteContent(annotation, box, canvas);
        var formattedContent = formattedObject.content;
        var rectHeight = annotation.head == "None" ? box.y2 - box.y1 : ((formattedObject.lineCount * annotation.fontSize + 5)) * __ZOOMSCALE;
        svgElement += "<rect id = 'PdfAnnotationElement" + annotation.id + "' x='" + box.x1 + "' y='" + box.y1 + "' width='" + (box.x2 - box.x1) + "' class = 'PdfAnnotationElement' height='" + rectHeight + "' style='fill:#f5f4ea;stroke:" + annotation.fontColor + ";stroke-width:" + (1.5*__ZOOMSCALE) + "' /></rect>";
        svgElement += "<text pointer-events='none' x='" + textX + "' y='" + textY + "' class='" + styleName + "'>" + formattedContent + "</text>";
        svgElement += "</g>";
        var tempHtml = canvas.innerHTML;
        canvas.innerHTML = style + tempHtml + svgElement;
    }
    
    function _displayPdfStamp(annotation, canvas){
        var stampImage = document.createElement("img");
        stampImage.id = "PdfAnnotationElement" + annotation.id;
        stampImage.className = "PdfAnnotationElement";
        stampImage.draggable = false;
        stampImage.src = "data:image/bmp;base64," + annotation.stream;
        var box = _getCorrectedBoundingBox(annotation.vertices, canvas);
        stampImage.setAttribute('style',"position: absolute; left: " + box.x1 + "px; top: " + box.y1 + "px; width: " + (box.x2 - box.x1) + "px; height: " + (box.y2 - box.y1) + "px");
        return stampImage;
    }
    
    function _createPolyPointPath(annotation, canvas){
        var path = "";
        for (var i = 0; i < annotation.vertices.length; i++) {
            if (i%2==0) {
                path += annotation.vertices[i] * __ZOOMSCALE;
                if (i<annotation.vertices.length - 1) {
                    path += ",";
                }
            } else {
                path += (canvas.clientHeight - (annotation.vertices[i] * __ZOOMSCALE));
                if (i<annotation.vertices.length - 1) {
                    path += " ";
                }
            }
        }
        return path;
    }
    
    function _getCorrectedLeaderLineBoundingBox (annotation, box, canvas){
        var xLeader = annotation.leaderLineVertices[annotation.leaderLineVertices.length - 2] * __ZOOMSCALE;
        var yLeader = canvas.clientHeight - (annotation.leaderLineVertices[annotation.leaderLineVertices.length - 1] * __ZOOMSCALE);
        if ((box.x1 - xLeader) == (box.x2 - xLeader)) {
            if ((box.y1 - yLeader) < (box.y2 - yLeader)) {
                box.y1 = yLeader;
            } else {
                box.y2 = yLeader;
            }
        } else if ((box.x1 - xLeader) < (box.x2 - xLeader)) {
            box.x1 = xLeader;
        } else {
            box.x2 = xLeader;
        }
        return box;
    }
    
    function _buildAdjustedNoteContent(annotation, boundingBox, canvas){
        var contentArray = annotation.content.split(" ");
        var hiddenDiv = document.createElement("div");
        hiddenDiv.setAttribute('style', "position: absolute; visibility: hidden; height: auto; width: auto; white-space: nowrap;");
        hiddenDiv.style.fontSize = annotation.fontSize * __ZOOMSCALE;
        canvas.appendChild(hiddenDiv);
        var expectedWidth = boundingBox.x2 - boundingBox.x1 - (4 * __ZOOMSCALE);
        var seperator = " ";
        var contentLine = "";
        var adjustedContent = "";
        var lineCount = 1;
        for (var i = 0; i < contentArray.length; i++) {
            if (i == contentArray.length - 1) {
                seperator = "";
            }
            hiddenDiv.innerHTML += contentArray[i] + seperator;
            if (((hiddenDiv.clientWidth > expectedWidth) && (contentLine.length != 0)) || contentArray[i].indexOf("\n") == 0) {
                adjustedContent += "<tspan x='" + (boundingBox.x1 + (2 * __ZOOMSCALE)) + "' y='" + (boundingBox.y1 + ((annotation.fontSize * __ZOOMSCALE) * lineCount)) + "'>" + contentLine + "</tspan>";
                contentLine = contentArray[i] + seperator;
                hiddenDiv.innerHTML = contentArray[i] + seperator;
                lineCount++;
            } else {
                contentLine += contentArray[i] + seperator;
            }
            if (hiddenDiv.clientWidth > expectedWidth){
                hiddenDiv.innerHTML = "";
                contentLine = "";
                for (var j = 0; j < contentArray[i].length; j++){
                    hiddenDiv.innerHTML += contentArray[i].charAt(j);
                    if (hiddenDiv.clientWidth > expectedWidth){
                        adjustedContent += "<tspan x='" + (boundingBox.x1 + (2 * __ZOOMSCALE)) + "' y='" + (boundingBox.y1 + ((annotation.fontSize * __ZOOMSCALE) * lineCount)) + "'>" + contentLine + "</tspan>";
                        contentLine = "" + contentArray[i].charAt(j);
                        hiddenDiv.innerHTML = "" + contentArray[i].charAt(j);
                        lineCount++;
                    } else {
                        contentLine += contentArray[i].charAt(j);
                    }
                }
                hiddenDiv.innerHTML += seperator;
                contentLine += seperator;
            }
        }
        adjustedContent += "<tspan x='" + (boundingBox.x1 + (2 * __ZOOMSCALE)) + "' y='" + (boundingBox.y1 + ((annotation.fontSize * __ZOOMSCALE) * lineCount)) + "'>" + contentLine + "</tspan>";
        canvas.removeChild(hiddenDiv);
        var returnObject = {
            content: adjustedContent,
            lineCount: lineCount
        }
        return returnObject;
    }
    
    function _sanitizeSvgText(content){
        content = content.replace(/</g,'&lt');
        content = content.replace(/>/g,'&gt');
        content = content.replace("\u0096", '&OElig;');
        content = content.replace("\u009c", '&oelig;');
        content = content.replace(/\\\(/g, '(');
        content = content.replace(/\\\)/g, ')');
        return content;
    }
    
    function _getNextPdfAnnotationId() {
        _pdfAnnotationId += 1;
        return _pdfAnnotationId;
    }
    
    function _buildLeaderLineSelectorBox (vertices, canvas, idNo) {
        var x1 = vertices[0] < vertices[2] ? (vertices[0]*__ZOOMSCALE) - 5 : (vertices[2]*__ZOOMSCALE) - 5;
        var y1 = vertices[1] > vertices[3] ? (canvas.clientHeight - (vertices[1]*__ZOOMSCALE)) - 5 : (canvas.clientHeight - (vertices[3]*__ZOOMSCALE)) - 5;
        var x2 = vertices[0] < vertices[2] ? (vertices[2]*__ZOOMSCALE) + 5 : (vertices[0]*__ZOOMSCALE) + 5;
        var y2 = vertices[1] > vertices[3] ? (canvas.clientHeight - (vertices[3]*__ZOOMSCALE)) + 5 : (canvas.clientHeight - (vertices[1]*__ZOOMSCALE)) + 5;
        var selectorBox = '<polygon id = "PdfAnnotationElement' + idNo +  '" class="PdfAnnotationElement" points="' + x1 + ',' + y1 + ' ' + x2 + ',' + y1 + ' ' + x2 + ',' + y2 + ' ' + x1 + ',' + y2 + '" style="fill:transparent"></polygon>';
        return selectorBox;
    }
    
    function _buildPolyLineSelectorBox (vertices, canvas, idNo) {
        var selectorBox = "<polygon id = 'PdfAnnotationElement" + idNo + "' class = 'PdfAnnotationElement' points = '";
        for (var i = 0; i < vertices.length; i+=2) {
            selectorBox += ((vertices[i] * __ZOOMSCALE) - 5) + "," + ((canvas.clientHeight - (vertices[i+1] * __ZOOMSCALE)) - 5) + " ";
        }
        for (var j = vertices.length-1; j > 0; j-=2) {
            selectorBox += ((vertices[j-1] * __ZOOMSCALE) + 5) + "," + ((canvas.clientHeight - (vertices[j] * __ZOOMSCALE)) + 5) + " ";
        }
        selectorBox = selectorBox.substring(0, selectorBox.length-1);
        selectorBox += "' style='fill:transparent' ></polygon>";
        return selectorBox;
    }
    
    function _buildFreehandSelectorBox (vertices, canvas, idNo) {
        var selectorSize = 5 * __ZOOMSCALE
        var selectorGroup = "<g id = 'PdfAnnotationElement" + idNo + "' class = 'PdfAnnotationElement'>"
        var previousSelectorBox = [];
        for (var i = 0; i < vertices.length - 2; i+=2) {
            var selectorBox = "<polygon points = '";
            var selectorSizeX =  vertices[i] < vertices[i+2] ? selectorSize : 0 - selectorSize;
            var selectorSizeY =  vertices[i+1] < vertices[i+3] ? selectorSize : 0 - selectorSize;
            var deltaX = Math.abs(vertices[i] - vertices[i+2]);
            var deltaY = Math.abs(vertices[i+1] - vertices[i+3]);
            if (deltaX > deltaY) {
                //if line is on the horizontal
                var newSelectorBox = [((vertices[i] * __ZOOMSCALE) - selectorSizeX), ((canvas.clientHeight - (vertices[i+1] * __ZOOMSCALE)) - selectorSizeY), ((vertices[i+2] * __ZOOMSCALE) + selectorSizeX), (((vertices[i+1] * __ZOOMSCALE)) + selectorSizeY)];
                selectorBox += ((vertices[i] * __ZOOMSCALE) - selectorSizeX) + "," + ((canvas.clientHeight - (vertices[i+1] * __ZOOMSCALE)) - selectorSizeY) + " ";
                selectorBox += ((vertices[i+2] * __ZOOMSCALE) + selectorSizeX) + "," + ((canvas.clientHeight - (vertices[i+3] * __ZOOMSCALE)) - selectorSizeY) + " ";
                selectorBox += ((vertices[i+2] * __ZOOMSCALE) + selectorSizeX) + "," + ((canvas.clientHeight - (vertices[i+3] * __ZOOMSCALE)) + selectorSizeY) + " ";
                selectorBox += ((vertices[i] * __ZOOMSCALE) - selectorSizeX) + "," + ((canvas.clientHeight - (vertices[i+1] * __ZOOMSCALE)) + selectorSizeY) + " ";
                previousSelectorBox = newSelectorBox;
            } else {
                //if line is on the vertical
                var newSelectorBox = [((vertices[i] * __ZOOMSCALE) - selectorSizeX), ((canvas.clientHeight - (vertices[i+1] * __ZOOMSCALE)) - selectorSizeY), ((vertices[i+2] * __ZOOMSCALE) - selectorSizeX), ((canvas.clientHeight - (vertices[i+3] * __ZOOMSCALE)) + selectorSizeY)];
                if(previousSelectorBox.length > 0 && newSelectorBox[1] != previousSelectorBox[1] && newSelectorBox[3] != previousSelectorBox[3]) {
                    if(Math.abs(newSelectorBox[1] - previousSelectorBox[1]) < Math.abs(newSelectorBox[3] - previousSelectorBox[3])) {
                        newSelectorBox[1] = previousSelectorBox[1];
                    } else {
                        newSelectorBox[3] = previousSelectorBox[3];
                    }
                }
                selectorBox += ((vertices[i] * __ZOOMSCALE) - selectorSizeX) + "," + newSelectorBox[1] + " ";
                selectorBox += ((vertices[i] * __ZOOMSCALE) + selectorSizeX) + "," + newSelectorBox[1] + " ";
                selectorBox += ((vertices[i+2] * __ZOOMSCALE) + selectorSizeX) + "," + newSelectorBox[3] + " ";
                selectorBox += ((vertices[i+2] * __ZOOMSCALE) - selectorSizeX) + "," + newSelectorBox[3] + " ";
                previousSelectorBox = newSelectorBox;
            }
            selectorBox += "' style='fill:transparent' ></polygon>";
            selectorGroup += selectorBox;
        }
        selectorGroup += "</g>";
        return selectorGroup;
    }

//PDF MOVE MARKUPS
    
    function _handleMovePdfAnnoEvent(e, drag) {
        e.stopPropagation();
        e.preventDefault();
        switch(e.type) {
            case "mouseenter":
                document.getElementById(_currentCanvasId).style.cursor = "move";
                break;
            case "mousedown":
                drag.x = e.pageX;
                drag.y = e.pageY;
                drag.state = true;
                _reorderSVGElement(e.target, drag, true);
                break;
            case "mousemove":
                _movePdfAnno(e, drag);
                break;
            case "mouseleave":
                _reorderSVGElement(e.target, drag, false);
                drag.state = false;
                document.getElementById(_currentCanvasId).style.cursor = "auto";
            case "mouseup":
                _reorderSVGElement(e.target, drag, false);
                drag.state = false;
                break;
            default:
                return;
        }
    }
    
    function _reorderSVGElement(target, drag, bringToFront) {
        var parent = target.parentNode;
        var redrawNode = target;
        while (parent.tagName != "svg" && parent.parentNode) {
            redrawNode = parent;
            parent = parent.parentNode;
        }
        if (bringToFront) {
            drag.index = -1;
            for (var i = 0; i < parent.childNodes.length; i++) {
                if (parent.childNodes[i] == redrawNode) {
                    drag.index = i;
                    break;
                }
            }
            if (drag.index < 0) {
                return;
            }
            parent.appendChild(redrawNode);
        } else {
            if(drag.index < 0) {
                return;
            }
            parent.insertBefore(redrawNode, parent.childNodes[drag.index]);
            drag.index = -1;
        }
    }
    
    function _movePdfAnno(e, drag) {
        e.preventDefault()
        var annoId = -1;
        if (e.target.id.length == 0) {
            annoId = parseInt(e.target.parentNode.id.substring(20));
        } else {
            annoId = parseInt(e.target.id.substring(20));
        }
        if(annoId < 0) {
            return;
        }
        var parsedAnno = _pdfParsedAnnotationSet[annoId];
        var deltaX = e.pageX - drag.x;
        var deltaY = e.pageY - drag.y;
        switch (parsedAnno.type) {
            case "LeaderLine" :
                _moveLeaderLineAnno(deltaX, deltaY, parsedAnno, e.target);
                break;
            case "PolyLine" :
                _movePolyLineAnno(deltaX, deltaY, parsedAnno, e.target);
                break;
            case "Rectangle" :
                _moveRectangleAnno(deltaX, deltaY, parsedAnno, e.target);
                break;
            case "Circle" :
                _moveCircleAnno(deltaX, deltaY, parsedAnno, e.target);
                break;
            case "Polygon" :
                _movePolygonAnno(deltaX, deltaY, parsedAnno, e.target);
                break;
            case "Freehand" :
                _moveFreehandAnno(deltaX, deltaY, parsedAnno, e.target);
                break
            case "Note" :
                _moveNoteAnno(deltaX, deltaY, parsedAnno, e.target);
                break;
            case "Stamp" :
                _moveStampAnno(deltaX, deltaY, parsedAnno, e.target);
            default:
                break;
        }
        drag.x = e.pageX;
        drag.y = e.pageY;
    }
    
    function _moveRectangleAnno(deltaX, deltaY, parsedAnno, target) {
        target.setAttribute("x", parseInt(target.attributes.x.nodeValue) + deltaX);
        target.setAttribute("y", parseInt(target.attributes.y.nodeValue) + deltaY);
        parsedAnno.vertices[0] += deltaX;
        parsedAnno.vertices[1] += deltaY;
        parsedAnno.vertices[2] += deltaX;
        parsedAnno.vertices[3] += deltaY;
    }
    
    function _moveCircleAnno(deltaX, deltaY, parsedAnno, target) {
        target.setAttribute("cx", parseInt(target.attributes.cx.nodeValue) + deltaX);
        target.setAttribute("cy", parseInt(target.attributes.cy.nodeValue) + deltaY);
        parsedAnno.vertices[0] += deltaX;
        parsedAnno.vertices[1] += deltaY;
        parsedAnno.vertices[2] += deltaX;
        parsedAnno.vertices[3] += deltaY;
    }
    
    function _movePolygonAnno(deltaX, deltaY, parsedAnno, target) {
        var points = target.attributes.points.nodeValue.split(" ");
        var newPoints = "";
        for (var i = 0; i < points.length; i++) {
            points[i] = points[i].split(",");
            points[i][0] = parseInt(points[i][0]) + deltaX;
            points[i][1] = parseInt(points[i][1]) + deltaY;
            newPoints += points[i][0] + "," + points[i][1] + " ";
        }
        newPoints = newPoints.substring(0, newPoints.length);
        target.setAttribute("points", newPoints);
        for (var j = 0; j < parsedAnno.vertices.length-2; j+=2) {
            parsedAnno.vertices[j] += deltaX;
            parsedAnno.vertices[j+1] += deltaY;
        }
    }
    
    function _moveNoteAnno(deltaX, deltaY, parsedAnno, target) {
        var parentGroup = target.parentNode;
        for (var i = 0; i < parentGroup.childNodes.length; i++) {
            var node = parentGroup.childNodes[i];
            switch (node.tagName) {
                case "rect":
                    node.setAttribute("x", parseInt(node.attributes.x.nodeValue) + deltaX);
                    node.setAttribute("y", parseInt(node.attributes.y.nodeValue) + deltaY);
                    break;
                case "text" :
                    node.setAttribute("x", parseInt(node.attributes.x.nodeValue) + deltaX);
                    node.setAttribute("y", parseInt(node.attributes.y.nodeValue) + deltaY);
                    for (var j = 0; j < node.childNodes.length; j++) {
                        if (node.childNodes[j].tagName == "tspan") {
                            node.childNodes[j].setAttribute("x", parseInt(node.childNodes[j].attributes.x.nodeValue) + deltaX);
                            node.childNodes[j].setAttribute("y", parseInt(node.childNodes[j].attributes.y.nodeValue) + deltaY);
                        }
                    }
                    break;
                case "path" :
                    var newPath = "";
                    var pathArray = node.attributes.d.nodeValue.split(" L");
                    for (var k = 0; k < pathArray.length; k++) {
                        pathArray[k] = pathArray[k].split(" ");
                        if(pathArray[k][0].indexOf("M") != -1) {
                            pathArray[k][0] = pathArray[k][0].replace("M", "");
                        }
                        pathArray[k][0] = parseInt(pathArray[k][0]) + deltaX;
                        pathArray[k][1] = parseInt(pathArray[k][1]) + deltaY;
                        newPath += "L" + pathArray[k][0] + " " + pathArray[k][1] + " ";
                    }
                    newPath = "M" + newPath.substring(1, newPath.length-1);
                    node.setAttribute("d", newPath);
                    break;
                default:
                    break;
            }
        }
        for (var l = 0; l < parsedAnno.boundingBox.length-2; l+=2) {
            parsedAnno.boundingBox[l] += deltaX;
            parsedAnno.boundingBox[l+1] += deltaY;
        }
        for (var m = 0; m < parsedAnno.leaderLineVertices.length-2; m+=2) {
            parsedAnno.leaderLineVertices[m] += deltaX;
            parsedAnno.leaderLineVertices[m+1] += deltaY;
        }
    }
    
    function _moveStampAnno (deltaX, deltaY, parsedAnno, target) {
        target.style.left =  parseInt(target.style.left) + deltaX + "px";
        target.style.top = parseInt(target.style.top) + deltaY + "px";
        parsedAnno.vertices[0] += deltaX;
        parsedAnno.vertices[1] += deltaY;
        parsedAnno.vertices[2] += deltaX;
        parsedAnno.vertices[3] += deltaY;
    }
    
    function _moveLeaderLineAnno(deltaX, deltaY, parsedAnno, target) {
        for (var i = 0; i < target.parentNode.childNodes.length; i++) {
            var node = target.parentNode.childNodes[i];
            switch (node.tagName) {
                case "line" :
                    node.setAttribute('x1', parseInt(node.attributes.x1.nodeValue) + deltaX);
                    node.setAttribute('x2', parseInt(node.attributes.x2.nodeValue) + deltaX);
                    node.setAttribute('y1', parseInt(node.attributes.y1.nodeValue) + deltaY);
                    node.setAttribute('y2', parseInt(node.attributes.y2.nodeValue) + deltaY);
                    break;
                case "polygon" :
                    _updateNodePointsArray(node, deltaX, deltaY);
                    break;
                default :
                    break;
            }
        }
        for (var l = 0; l < parsedAnno.boundingBox.length-2; l+=2) {
            parsedAnno.boundingBox[l] += deltaX;
            parsedAnno.boundingBox[l+1] += deltaY;
        }
        for (var m = 0; m < parsedAnno.vertices.length-2; m+=2) {
            parsedAnno.vertices[m] += deltaX;
            parsedAnno.vertices[m+1] += deltaY;
        }
    }
    
    function _movePolyLineAnno (deltaX, deltaY, parsedAnno, target) {
        for (var i = 0; i < target.parentNode.childNodes.length; i++) {
            var node = target.parentNode.childNodes[i];
            switch (node.tagName) {
                case "polyline" :
                case "polygon" :
                    _updateNodePointsArray(node, deltaX, deltaY);
                    break;
                default :
                    break;
            }
        }
        for (var l = 0; l < parsedAnno.boundingBox.length-2; l+=2) {
            parsedAnno.boundingBox[l] += deltaX;
            parsedAnno.boundingBox[l+1] += deltaY;
        }
        for (var m = 0; m < parsedAnno.vertices.length-2; m+=2) {
            parsedAnno.vertices[m] += deltaX;
            parsedAnno.vertices[m+1] += deltaY;
        }
    }
    
    function _moveFreehandAnno(deltaX, deltaY, parsedAnno, target) {
        for (var i = 0; i < target.parentNode.parentNode.childNodes.length; i++) {
            var node = target.parentNode.parentNode.childNodes[i];
            switch (node.tagName) {
                case "path" :
                    var newPath = "";
                    var pathArray = node.attributes.d.nodeValue.split(" Q");
                    pathArray[0] = pathArray[0].split(" ");
                    pathArray[0][0] = pathArray[0][0].replace("M", "");
                    newPath += "M" + (parseInt(pathArray[0][0]) + deltaX) + " " + (parseInt(pathArray[0][1]) + deltaY) + " ";
                    for (var k = 1; k < pathArray.length; k++) {
                        pathArray[k] = pathArray[k].split(" ");
                        pathArray[k][0] = parseInt(pathArray[k][0]) + deltaX;
                        pathArray[k][1] = parseInt(pathArray[k][1]) + deltaY;
                        pathArray[k][2] = parseInt(pathArray[k][2]) + deltaX;
                        pathArray[k][3] = parseInt(pathArray[k][3]) + deltaY;
                        newPath += "Q" + pathArray[k][0] + " " + pathArray[k][1] + " " + pathArray[k][2] + " " + pathArray[k][3] + " ";
                    }
                    newPath = newPath.substring(0, newPath.length-1);
                    node.setAttribute("d", newPath);
                    break;
                case "g" :
                    for (var j = 0; j < node.childNodes.length; j++) {
                        _updateNodePointsArray(node.childNodes[j], deltaX, deltaY);
                    }
                    break;
                default :
                    break;
            }
        }
        for (var l = 0; l < parsedAnno.boundingBox.length-2; l+=2) {
            parsedAnno.boundingBox[l] += deltaX;
            parsedAnno.boundingBox[l+1] += deltaY;
        }
        for (var m = 0; m < parsedAnno.vertices.length-2; m+=2) {
            parsedAnno.vertices[m] += deltaX;
            parsedAnno.vertices[m+1] += deltaY;
        }
    }
    
    function _updateNodePointsArray (node, deltaX, deltaY) {
        var newPoints = "";
        var pointsArray = node.attributes.points.nodeValue.split(" ");
        for (var j = 0; j < pointsArray.length; j++) {
            pointsArray[j] = pointsArray[j].split(",");
            pointsArray[j][0] = parseInt(pointsArray[j][0]) + deltaX;
            pointsArray[j][1] = parseInt(pointsArray[j][1]) + deltaY;
            newPoints += pointsArray[j][0] + "," + pointsArray[j][1] + " ";
        }
        node.setAttribute("points", newPoints.substring(0,newPoints.length-1));
    }
    
})();