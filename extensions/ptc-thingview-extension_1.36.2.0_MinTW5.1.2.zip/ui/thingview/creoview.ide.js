/* bcwti
 *
 * Copyright (c) 2016-2019 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 * ecwti
 */

/* var s_idePluginVersion = "0.36.2+LC3HRt"; */

TW.IDE.Widgets.thingview = function() {
    var thisWidget = this;
    this.widgetIconUrl = function() {
        return "../Common/extensions/ptc-thingview-extension/ui/thingview/pview.png";
    };

    this.widgetProperties = function() {
        return {
            'name': 'ThingView',
            'description': 'The  Creo View WebGL Widget allows 3-D models to be displayed.',
            'category': ['Common', 'Components'],
            'isResizable': true,
            'supportsAutoResize': true,
            'properties': {
                'Width': {
                    'defaultValue': 300
                },
                'Height': {
                    'defaultValue': 200
                },
                'ProductToView': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'The url of the file to load.'
                },
                'baseUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': 'The base url of the strucutre.'
                },
                'oid': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': 'The oid of the strucutre.'
                },
                'mapUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': 'The map file url.'
                },
                'markupUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': 'The url to markup content.'
                },
                'Orientations': {
                    'isBindingTarget': true,
                    'description': '',
                    'baseType': 'STRING',
                    'defaultValue': 'ISO1',
                    'selectOptions': [
                        { value: 'ISO1', text: 'ISO1' },
                        { value: 'ISO2', text: 'ISO2' },
                        { value: 'Top', text: 'Top' },
                        { value: 'Bottom', text: 'Bottom' },
                        { value: 'Left', text: 'Left' },
                        { value: 'Right', text: 'Right' },
                        { value: 'Front', text: 'Front' },
                        { value: 'Back', text: 'Back' }
                    ]
                },
                'MouseNavigation': {
                    'isBindingTarget': true,
                    'description': 'The mouse navigation mode to use in the 3D view',
                    'baseType': 'STRING',
                    'defaultValue': 'CREOVIEW',
                    'selectOptions': [
                        { value: 'CREOVIEW', text: 'CreoView' },
                        { value: 'CREO', text: 'Creo' },
                        { value: 'CATIAV5COMPATIBLE', text: 'CATIA_V5_Compatible' },
                        { value: 'EXPLORE', text: 'Explore'}
                    ]
                },
                'Orientation': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'Euler angles for camera orientation in X,Y,Z format (unit: degree). (For 90 degrees model rotation around Y-axis, specify 0,90,0)'
                },
                'Position': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': 'Camera position in X,Y,Z format (unit: meter). (For 0.5 meters distance along Y-axis from origin, specifiy 0,0.5,0)'
                },
                'BackgroundStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultShapeUnfilledBackgroundStyle',
                    'description': 'The background color used for the widget. All other fields ignored.'
                },
                'Data': {
                    'description': 'Part selection',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'OccurrenceField': {
                    'description': 'Field in the Data that contains the Occurrence path id.  Used to find rows for selection and coloring.',
                    'baseType': 'FIELDNAME',
                    'baseTypeRestriction': "STRING",
                    'sourcePropertyName': 'Data',
                    'defaultValue': 'treeId'
                },
                'DataFormatter': {
                    'description': 'Rules for color in the widget. Only the Text Color will be used, both its color value and ' +
                        ' transparency setting.  Set the transparency very low to hide parts for example. All other fields ignored.',
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'Data'
                },
                'SelectedOccurrencePath': {
                    'description': 'The Occurrence path that is last selected.',
                    'baseType': 'STRING',
                    'isEditable': false,
                    'isBindingSource': true,
                    'isBindingTarget': false
                },
                'PreSelectedOccurrencePath': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': 'The occurrence path of preselected part.',
                    'warnIfNotBoundAsTarget': false
                },
                'Views': {
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isEditable': true,
                    'baseType': 'INFOTABLE',
                    'isVisible': true,
                    'description': 'A list of Views (Name, Type, Id).'
                },
                'Gnomon': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Display the Gnomon'
                },
                'EnablePartSelection': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': 'Allow part selection'
                },
                'EnablePartDragger': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Allow the user to drag parts'
                },
                'SpinCenter': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Display the Spin Center during rotation of model in the 3D view'
                },
                'AllowCORSCredentials': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'For CORS requests specify whether cookies will be added to the requests'
                },
                'AllowClientRedirect': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': 'Make the media proxy not handle redirects and pass them to ThingView to handle'
                },
                'AcknowledgeStepText': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': 'The message to display when a sequence step requires an acknowledgement.'
                },
                'SequenceStepNumber': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': 'The current sequence step number.'
                },
                'SequenceStepName': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': 'The current sequence step name.'
                },
                'WindchillSourceData': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': 'Set to true if ProductToView data is coming from Windchill otherwise set it to false'
                },
                'EnableWindchillFileCache': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Set to true to enable part file cache from Windchill data source.'
                },
                'WindchillCacheSize': {
                    'baseType': 'NUMBER',
                    'isVisible': true,
                    'defaultValue': 1000,
                    'description': 'Cache size in megabytes when using Windchill data source.'
                },
                'SelectedParts': {
                    'description': 'Part selection',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'ThingViewControls': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': 'Display the UI controls in ThingView'
                },
                'DisplayViewState': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': 'Display viewstates in ThingViewControls'
                },
                'DisplayAlternateRep': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Display alternate representations in ThingViewControls'
                },
                'DisplayExplodeState': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Display explode states in ThingViewControls'
                },
                'DisplaySectionCut': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': 'Display section cuts in ThingViewControls'
                },
                'DisplayFilter': {
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '{ \"ModelAnnotation\": { \"HiddenByDefault\": true, \"PlanarAnnotation\": true, \"FloatingAnnotation\": false, \"MiscAnnotation\": false } }',
                    'description': 'JSON string to specify display filters. i.e. { \"ModelAnnotation\": { \"HiddenByDefault\": true, \"PlanarAnnotation\": true, \"FloatingAnnotation\": false, \"MiscAnnotation\": false } }'
                },
                'ProjectionMode': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'description': 'The projection mode to use in the 3D view',
                    'baseType': 'STRING',
                    'defaultValue': 'ORTHOGRAPHIC',
                    'selectOptions': [
                        { value: 'PERSPECTIVE', text: 'Perspective' },
                        { value: 'ORTHOGRAPHIC', text: 'Orthographic' }
                    ]
                },
                'PerspectiveHFOV': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'NUMBER',
                    'isVisible': true,
                    'defaultValue': 60,
                    'description': 'Horizontal field of view in perspective view.'
                }
            }
        };
    };

    this.customWidgetEvents = {
        'Loaded': {
            'description': 'Triggered when loading a model is completed.'
        },
        'SelectionChanged': {
            'description': 'Triggered when selection is changed in 3D view or Data grid.'
        },
        'PreSelectionChanged': {
            'description': 'Triggered when preselection is changed in 3D view.'
        },
        'HasAnimation': {
            'description': 'Triggered when loaded illustration has an animation.'
        },
        'HasSequence': {
            'description': 'Triggered when loaded illustration has a sequence.'
        },
        'SequenceStepAcknowledge': {
            'description': 'Triggered when a sequence step has an acknowledge'
        }
    };

    this.widgetServices = function() {
        return {
            'GetViewLocation': {
                'warnIfNotBound': false,
                'description': 'Get the location (orientation and position) of the main camera in the 3D view.'
            },
            'SetViewLocation': {
                'warnIfNotBound': false,
                'description': 'Move the main camera to be at the location given in the 3D view.'
            },
            'ZoomAll': {
                'warnIfNotBound': false,
                'description': 'Zoom so all visible parts and markups fill the view window.'
            },
            'ZoomSelected': {
                'warnIfNotBound': false,
                'description': 'Zoom so all selected parts and markups fill the view window.'
            },
            'PlaySequenceStep': {
                'warnIfNotBound': false,
                'description': 'Play the current sequence step playback.'
            },
            'PauseSequence': {
                'warnIfNotBound': false,
                'description': 'Pause the current sequence step playback.'
            },
            'StopSequence': {
                'warnIfNotBound': false,
                'description': 'Stop the current sequence step playback.'
            },
            'RewindSequence': {
                'warnIfNotBound': false,
                'description': 'Rewind the current sequence back to the start.'
            },
            'NextSequenceStep': {
                'warnIfNotBound': false,
                'description': 'Jump to the next step in the sequence.'
            },
            'PrevSequenceStep': {
                'warnIfNotBound': false,
                'description': 'Jump to the previous step in the sequence.'
            },
            'PlayAnimation': {
                'warnIfNotBound': false,
                'description': 'Play the animation.'
            },
            'PauseAnimation': {
                'warnIfNotBound': false,
                'description': 'Pause the animation.'
            },
            'StopAnimation': {
                'warnIfNotBound': false,
                'description': 'Stop the animation.'
            }
        };
    };

    this.widgetEvents = function() {
        return this.customWidgetEvents;
    };

    this.renderHtml = function() {
        var html = '';
        html += '<div class="widget-content widget-thingview"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span style="color: #5bb73b">ThingView</span></td></tr></table></div>';
        return html;
    };

    this.afterLoad = function () {
        TW.IDE.GetDataShapeInfo("Selection", function (info) {
            if (info) {
                var infoTable = {
                    'dataShape': info,
                    'rows': []
                };
                thisWidget.setProperty('SelectedParts', infoTable);
            }
        });

        TW.IDE.GetDataShapeInfo("Views", function (info) {
            if (info) {
                var infoTable = {
                    'dataShape': info,
                    'rows': []
                };
                thisWidget.setProperty('Views', infoTable);
            }
        });
    }

    this.afterSetProperty = function(name, value) {
        if (name === 'Width') {
            this.width = value;
            var canvasElem = document.getElementById('pvCanvas');
            canvasElem.width = value;
        }
        else if (name === 'Height') {
            this.height = value;
            var canvasElem = document.getElementById('pvCanvas');
            canvasElem.height = value;
        }
    };

    this.getSourceDatashapeName = function (propertyName) {
        if (propertyName === 'SelectedParts') {
            return 'Selection';
        } else if (propertyName == 'Views') {
            return 'Views';
        }

        return undefined;
    }
};