/* bcwti
 *
 * Copyright (c) 2015-2019 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 * ecwti
 */

/* var s_runtimePluginVersion = "0.36.2+LC3HRt"; */

TW.Runtime.Widgets.thingview = function() {
    var thisWidget = this;
    thisWidget.formatter = thisWidget.getProperty('DataFormatter');
    thisWidget.backgroundStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BackgroundStyle', ''));
    thisWidget.occurrenceIdField = thisWidget.getProperty('OccurrenceField');
    if (!thisWidget.occurrenceIdField)
        thisWidget.occurrenceIdField = 'treeId';
    thisWidget.localData = null;
    thisWidget.selectedInstances = [];
    thisWidget.templateUrl = "";
    thisWidget.loadingModel = false;
    thisWidget.figureNums = 0;
    thisWidget.figureName = "";

    thisWidget.setFormatter = function(f) {
        thisWidget.formatter = f;
    };

    thisWidget.applyFormatter = function() {
        if (thisWidget.localData && thisWidget.localData.length > 0 && thisWidget.formatter && thisWidget.model) {
            for (var i = 0; i < thisWidget.localData.length; i++) {
                var formatResult = TW.getStyleFromStateFormatting({DataRow: thisWidget.localData[i], StateFormatting: thisWidget.formatter});
                if (formatResult.foregroundColor) {
                    var color = thisWidget.parseRGBA(formatResult.foregroundColor);
                    thisWidget.model.SetPartColor(
                        thisWidget.localData[i][thisWidget.occurrenceIdField],
                        parseFloat(color[0]), parseFloat(color[1]), parseFloat(color[2]), parseFloat(color[3]),
                        Module.ChildBehaviour.IGNORED,
                        Module.InheritBehaviour.USE_DEFAULT
                    );
                }
            }
        }
    };

    this.runtimeProperties = function() {
        return {
            'needsDataLoadingAndError': false
        };
    };


    this.renderHtml = function() {
        TW.log.info('Thing View Widget .renderHtml');
        var color = thisWidget.backgroundStyle.backgroundColor;
        var html = '';
        html = '<div class="widget-content widget-thingview"\
                style="display:block;'
        if (color) {
            html += 'background-color: ' + color;
        }
        html += '">\
                <div class="thing-view-plugin-wrapper"></div>\
                </div>';
        return html;
    };

    function setTemplateUrl() {
        if (thisWidget.productToView.indexOf("/servlet") > 0) {
            //Set the template param to allow fetching the child files
            var baseUrl = '';
            if (!thisWidget.urlbase) {
                baseUrl = thisWidget.productToView.substring(0, thisWidget.productToView.indexOf("/servlet"));
            }
            if (!thisWidget.templateUrl) {
                baseUrl += '/servlet/WindchillAuthGW/com.ptc.wvs.server.util.WVSContentHelper/redirectDownload/FILENAME_KEY?HttpOperationItem=OID1_KEY&ContentHolder=OID2_KEY&u8=1';
                var clientRedirect = thisWidget.getProperty('AllowClientRedirect');
                if (clientRedirect == undefined) clientRedirect = true;
                if (clientRedirect) {
                    baseUrl += '&twxME_ClientFollowRedirect=true';
                }
                thisWidget.templateUrl = baseUrl;
            }
        }
    }

    this.afterRender = function() {
        if (window.MyThingView === undefined) {
            TW.log.info('Thing View Widget window.MyThingView: is undefined');
            window.MyThingView = new Object();
            window.MyThingView.thingViewEngineInitialised = false;
            window.MyThingView.thingViewEngineStarting = false;
        }
        TW.log.info('Thing View Widget window.MyThingView: ' + window.MyThingView);
        TW.log.info('Thing View Widget window.MyThingView.thingViewEngineInitialised: ' + window.MyThingView.thingViewEngineInitialised);
        TW.log.info('Thing View Widget window.MyThingView.thingViewEngineStarting: ' + window.MyThingView.thingViewEngineStarting);

        thisWidget.productToView = thisWidget.getProperty('ProductToView');
        thisWidget.baseUrl = thisWidget.getProperty('baseUrl');
        thisWidget.windchillSourceData = thisWidget.getProperty('WindchillSourceData');
        if (thisWidget.windchillSourceData == undefined) thisWidget.windchillSourceData = true;
        if (thisWidget.windchillSourceData == true) {
            setTemplateUrl();
        }

        thisWidget.oid = thisWidget.getProperty('oid');
        thisWidget.mapUrl = thisWidget.getProperty('mapUrl');
        thisWidget.markupUrl = thisWidget.getProperty('markupUrl');

        var infoTableValueViews = thisWidget.getProperty('Views');
        if (infoTableValueViews === undefined) {
            var dataShapeInfoViews = undefined;
            TW.Runtime.GetDataShapeInfo("Views", function (info) {
                dataShapeInfoViews = info;

                // create empty infotable
                var infoTable = {
                    'dataShape': dataShapeInfoViews,
                    'name': 'views',
                    'description': 'all the views from this session',
                    'rows': []
                };
                thisWidget.setProperty('Views', infoTable);
            });
        }

        var infoTableValueParts = thisWidget.getProperty('SelectedParts');
        if (infoTableValueParts === undefined) {
            var dataShapeInfoParts = undefined;
            TW.Runtime.GetDataShapeInfo("Selection", function (info) {
                dataShapeInfoParts = info;

                // create empty infotable
                var infoTable = {
                    'dataShape': dataShapeInfoParts,
                    'name': 'SelectedParts',
                    'description': 'all the selected parts in the session',
                    'rows': []
                };
                thisWidget.setProperty('SelectedParts', infoTable);
            });
        }
        thisWidget.updatePVHtml();
    };

    this.updatePVHtml = function() {
        var pluginId = thisWidget.getProperty('Id') + "-plugin";

        thisWidget.thingViewId = "ThingViewContainer-" + pluginId;
        var htmlToWrite = '<div id="';
        htmlToWrite += thisWidget.thingViewId;
        htmlToWrite += '" style="width: 100%; height: 100%; margin-left: auto; margin-right: auto;"></div>';

        thisWidget.thingViewControls = thisWidget.getProperty('ThingViewControls');
        if (thisWidget.thingViewControls == undefined) thisWidget.thingViewControls = true;
        if (thisWidget.thingViewControls) {
            htmlToWrite += ' \
            <div class="radialButton rightPaneButtons rightPaneOpener noselect" id="rightPaneOpener" title="Zooming & Selection tools" disabled> \
                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_right_pane_icon.svg"/> \
            </div> \
            <div id="rightPaneContainerBG" class="rightPaneContainerBG noselect"> \
                <div id="rightPaneContainer" class="rightPaneContainer"> \
                    <div id="rightPaneCloser" class="rightPaneTrapezoidContainer"> \
                        <div class="rightPaneTrapezoid" title="Close"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/> \
                        </div> \
                    </div> \
                    <div id="rightPaneContent" class="rightPaneContent scrollable-container"> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton3" title="Show All"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_show_all.svg"/> \
                        </div> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton1" title="Hide Selected"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_hide.svg"/> \
                        </div> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton2" title="Isolate Selected"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_isolate.svg"/> \
                        </div> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton4" title="Zoom All"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_zoom_to_fit.svg"/> \
                        </div> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton5" title="Zoom Selected"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_zoom_to_selected.svg"/> \
                        </div> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton6" title="Zoom Window"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_zoom_to_window.svg"/> \
                        </div> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton7" title="Part Dragger"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_part_dragger.svg"/> \
                        </div> \
                        <div class="radialButton rightPaneButtons" id="rightPaneButton8" title="Restore Part Location"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_restore_location.svg"/> \
                        </div> \
                    </div> \
                </div> \
            </div> \
            <div class="radialButton radialButtonOrient leftPaneOpener noselect" id="leftPaneOpener" title="Orientation & View States" disabled> \
                <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_left_pane_icon.svg"/> \
            </div> \
            <div id="leftPaneContainerBG" class="leftPaneContainerBG noselect"> \
                <div id="leftPaneContainer" class="leftPaneContainer"> \
                    <div id="leftPaneCloser" class="leftPaneTrapezoidContainer"> \
                        <div class="leftPaneTrapezoid" title="Close"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/> \
                        </div> \
                    </div> \
                    <div id="leftPaneOrientsTitle" class="leftPaneTitle" title="Toggle orientations"> \
                        <img id="leftPaneOrientsTitleMark" class="leftPaneTitleMark" \
                            src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/> \
                        <span id="leftPaneOrientsTitleText" class="leftPaneTitleText">Orientation</span> \
                    </div> \
                    <div id="leftPaneOrientsContent"> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientISO1" title="ISO 1"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_iso1.svg"/> \
                        </div> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientISO2" title="ISO 2"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_iso2.svg"/> \
                        </div> \
                        <br/> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientTop" title="Top"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_top.svg"/> \
                        </div> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientBottom" title="Bottom"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_bottom.svg"/> \
                        </div> \
                        <br/> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientLeft" title="Left"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_left.svg"/> \
                        </div> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientRight" title="Right"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_right.svg"/> \
                        </div> \
                        <br/> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientFront" title="Front"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_front.svg"/> \
                        </div> \
                        <div class="radialButton radialButtonOrient" id="widgetOrientBack" title="Back"> \
                            <img src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_orientation_back.svg"/> \
                        </div> \
                    </div> \
                    <div id="leftPaneViewablesTitle" class="leftPaneTitle" title="Toggle view states"> \
                        <img id="leftPaneViewablesTitleMark" class="leftPaneTitleMark" \
                            src="../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg"/> \
                        <span id="leftPaneViewablesTitleText" class="leftPaneTitleText">View States</span> \
                    </div> \
                    <div id="leftPaneViewablesContent" class="widgetViewableContainer scrollable-container"></div> \
                    <div id="bottomBorder" style="height: 4px; width: 140px;"></div> \
                </div> \
            </div>';
        }
        thisWidget.jqElement.find('.thing-view-plugin-wrapper').html(htmlToWrite);

        if (window.MyThingView.thingViewEngineInitialised === true) {
            TW.log.info('Thing View Widget already initialised create session');
            thisWidget.CreateSession();
            thisWidget.LoadModel();
        } else if (window.MyThingView.thingViewEngineStarting !== true) {
            TW.log.info('Thing View Widget is not initialised or starting now initialise it');
            TW.log.info("window.MyThingView.thingViewEngineInitialised: " + window.MyThingView.thingViewEngineInitialised);
            window.MyThingView.thingViewEngineStarting = true;

            ThingView.init("../Common/extensions/ptc-thingview-extension/ui/thingview/js/ptc/thingview/", function () {
                window.MyThingView.thingViewEngineInitialised = true;

                var defaultPrefs = '{'+
                    '"ParseNode" : {'+
                        '"Type" : "root",'+
                        '"Name" : "",'+
                        '"Value" : "",'+
                        '"Locked" : false,'+
                        '"Children" : ['+
                            '{'+
                                '"Type" : "category",'+
                                '"Name" : "Startup",'+
                                '"Value" : "",'+
                                '"Locked" : false,'+
                                '"Children" : ['+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Enable item lists",'+
                                        '"Value" : "true",'+
                                        '"Locked" : false'+
                                    '},'+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Enable measurements",'+
                                        '"Value" : "true",'+
                                        '"Locked" : false'+
                                    '},'+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Enable construction geometry",'+
                                        '"Value" : "true",'+
                                        '"Locked" : false'+
                                    '},'+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Enable section cuts",'+
                                        '"Value" : "false",'+
                                        '"Locked" : false'+
                                    '},'+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Pvk system properties",'+
                                        '"Value" : "CalcEachTime",'+
                                        '"Locked" : false'+
                                    '},'+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Enable feature manager",'+
                                        '"Value" : "true",'+
                                        '"Locked" : false'+
                                    '},'+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Enable screen space dragger",'+
                                        '"Value" : "false",'+
                                        '"Locked" : false'+
                                    '}'+
                                ']'+
                            '},'+
                            '{'+
                                '"Type" : "category",'+
                                '"Name" : "Loader",'+
                                '"Value" : "",'+
                                '"Locked" : false,'+
                                '"Children" : ['+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Illustration unload parts",'+
                                        '"Value" : "true",'+
                                        '"Locked" : false'+
                                    '}'+
                                ']'+
                            '},'+
                            '{'+
                                '"Type" : "category",'+
                                '"Name" : "Shape Scene",'+
                                '"Value" : "",'+
                                '"Locked" : false,'+
                                '"Children" : ['+
                                    '{'+
                                        '"Type" : "preference",'+
                                        '"Name" : "Transition override inherit behaviour",'+
                                        '"Value" : "false",'+
                                        '"Locked" : false'+
                                    '},' +
                                    '{' +
                                        '"Type" : "preference",'+
                                        '"Name" : "Zoom on load",'+
                                        '"Value" : "true",'+
                                        '"Locked" : false'+
                                    '},' +
                                    '{' +
                                        '"Type" : "preference",' +
                                        '"Name" : "Hidden items are unpickable",' +
                                        '"Value" : "true",' +
                                        '"Locked" : false' +
                                    '},' +
                                    '{' +
                                        '"Type" : "preference",' +
                                        '"Name" : "Disable sbom selection",' +
                                        '"Value" : "false",' +
                                        '"Locked" : false' +
                                    '},' +
                                    '{' +
                                        '"Type" : "preference",' +
                                        '"Name" : "Merge appearances in animations",' +
                                        '"Value" : "false",' +
                                        '"Locked" : false' +
                                    '}' +
                                ']'+
                            '}'+
                        ']'+
                    '}'+
                '}';

                try {
                    ThingView.SetSystemPreferencesFromJson(defaultPrefs);
                } catch (e) {
                    TW.log.info('Failed to apply system preferences from json, widget probably shutdown before thingview initialization completed');
                }
                if (thisWidget) {
                    thisWidget.CreateSession();
                    thisWidget.LoadModel();
                }
            });
        } else {
            var initInterval = setInterval(function(){
                if (window.MyThingView.thingViewEngineInitialised) {
                    TW.log.info('ThingView init complete');
                    window.clearInterval(initInterval);

                    thisWidget.CreateSession();
                    thisWidget.LoadModel();
                } else {
                    TW.log.info('Waiting for ThingView init to complete');
                }
            }, 3000);
        }
    }

    function getCachedOccurrencePath(row) {
        if (!row._cachedOccurrencePath) {
            return thisWidget.constructIdPath(row);
        }
        return row._cachedOccurrencePath;
    }

    this.getIndex = function(value) {
        if (!value || !thisWidget.localData) {
            return undefined;
        }
        var i = thisWidget.localData.length;
        while (i--) {
            if (getCachedOccurrencePath(thisWidget.localData[i]) === value ||
                thisWidget.localData[i][thisWidget.occurrenceIdField] === value) {
                return i;
            }
        }
        return undefined;
    };

    this.getParentRow = function(id) {
        if (!thisWidget.localData) {
            return;
        }

        var i = thisWidget.localData.length;
        while (i--) {
            if (thisWidget.localData[i].objectId === id) {
                return thisWidget.localData[i];
            }
        }

        return null;
    };

    this.constructIdPath = function(row) {
        var id = row[thisWidget.occurrenceIdField] + '';
        if (id.charAt(0) === '/') {
            return id;
        }
        var parent = row;
        var count = 0;
        while (parent && id.charAt(0) !== '/' && count++ < 100) {
            id = '/' + id;
            parent = this.getParentRow(parent.parentId);
            if (parent) {
                var pid = parent[thisWidget.occurrenceIdField];
                if (pid !== '/' && pid) {
                    id = pid + id;
                }
            }
        }
        row._cachedOccurrencePath = id;
        return id;
    };

    this.CreateSession = function() {
        MySelectionClass = Module.SelectionEvents.extend("SelectionEvents", {
            OnSelectionBegin: function () {
                thisWidget.tmpIndexes = [];
            },
            OnSelectionChanged: function (clear, removed, added) {
                var infoTableValue = thisWidget.getProperty('SelectedParts');
                if (infoTableValue.rows == undefined)
                    infoTableValue.rows = [];

                if (clear) {
                    infoTableValue.rows = [];
                    thisWidget.setProperty('SelectedOccurrencePath', "");
                    thisWidget.selectedInstances = [];
                }
                var lastIdPath = "";
                for (var i=0;i<added.size();++i) {
                    var idPath = added.get(i);
                    lastIdPath = idPath;
                    infoTableValue.rows.push({ 'idPath': idPath });
                }
                thisWidget.setProperty('SelectedOccurrencePath', lastIdPath);

                for (var i=0;i<removed.size();++i) {
                    var idPath = removed.get(i);
                    for (var ii=0;ii<infoTableValue.rows.length;++ii) {
                        if (infoTableValue.rows[ii].idPath == idPath) {
                            infoTableValue.rows.splice(ii, 1);
                        }
                    }
                }

                if (thisWidget.localData !== undefined) { // Data property section
                    for (var i=0;i<removed.size();++i) {
                        var idPath = removed.get(i);
                        var idx = thisWidget.selectedInstances.indexOf(idPath);
                        if (idx !== -1)
                            thisWidget.selectedInstances.splice(idx, 1);
                    }
                    for (var i=0;i<added.size();++i) {
                        var idPath = added.get(i);
                        var index = thisWidget.getIndex(idPath);
                        thisWidget.selectedInstances.push(idPath);
                    }
                }

                for (var si=0;si<thisWidget.selectedInstances.length;++si) {
                    var index = thisWidget.getIndex(thisWidget.selectedInstances[si]);
                    if (index !== undefined)
                        thisWidget.tmpIndexes.push(index);
                }

                thisWidget.updateSelection('Data', thisWidget.tmpIndexes);
                thisWidget.setProperty('SelectedParts', infoTableValue);
                thisWidget.jqElement.triggerHandler('SelectionChanged');
            },
            OnSelectionEnd: function () {
                thisWidget.tmpIndexes = [];
                if (thisWidget.thingViewControls) {
                    thisWidget.updateRightPaneButtonsAvailability();
                }
            }
        });

        // Initialisation
        thisWidget.app = ThingView.CreateCVApplication(thisWidget.thingViewId);
        thisWidget.session = thisWidget.app.GetSession();
        thisWidget.shapeScene = thisWidget.session.MakeShapeScene(true);
        thisWidget.shapeView = thisWidget.shapeScene.MakeShapeView(document.getElementById(thisWidget.thingViewId).firstChild.id, true);

        // shapeView settings
        thisWidget.ApplyProjection();
        thisWidget.ApplyNavigation();

        thisWidget.ApplyBackgroundColor();
        thisWidget.ApplyPartDragger();
        thisWidget.shapeView.ShowSpinCenter(thisWidget.getProperty('SpinCenter') == true);
        thisWidget.shapeView.ShowGnomon(thisWidget.getProperty('Gnomon') == true);
        thisWidget.shapeView.SetAntialiasingMode(Module.AntialiasingMode.SS4X);

        // shapeScene settings
        thisWidget.ApplySelectionFilter();
        thisWidget.selectionObserver = new MySelectionClass();
        thisWidget.shapeScene.RegisterSelectionObserver(thisWidget.selectionObserver);
        thisWidget.ApplyShapeFilters(true);

        // session settings
        thisWidget.session.EnableCrossSiteAccess(thisWidget.getProperty('AllowCORSCredentials') == true);
        if (thisWidget.getProperty('EnableWindchillFileCache') == true) {
            var cacheSize = thisWidget.getProperty('WindchillCacheSize');
            if (cacheSize != undefined) {
                thisWidget.session.EnableFileCache(cacheSize);
            }
        }
    }

    this.UnloadModel = function() {
        if (thisWidget.session) {
            thisWidget.session.RemoveAllLoadSources();
        }
        if (thisWidget.structure) {
            thisWidget.structure = null;
        }
        if (thisWidget.model) {
            thisWidget.model = null;
        }
        if (thisWidget.thingViewControls) {
            thisWidget.leftWidgetPane = undefined;
            thisWidget.rightWidgetPane = undefined;
            thisWidget.leftScroll = undefined;
            thisWidget.figureNums = 0;
            thisWidget.figureName = "";
        }

        var infoTableValueViews = thisWidget.getProperty('Views');
        if (infoTableValueViews != undefined) {
            infoTableValueViews.rows = [];
            thisWidget.setProperty('Views', infoTableValueViews);
        }
        var infoTableValueParts = thisWidget.getProperty('SelectedParts');
        if (infoTableValueParts != undefined) {
            infoTableValueParts.rows = [];
            thisWidget.setProperty('SelectedParts', infoTableValueParts);
        }
    }

    this.LoadDefaultView = function(callback) {
        var idPathArr = new Module.VectorString();
        idPathArr.push_back('/');
        thisWidget.model.LoadParts(idPathArr, true, function (result) {
            if (result == true) {
                if (callback) callback();
            }
        });
    }

    this.ApplyOrientation = function (animate) {
        if (!thisWidget.shapeView) return;

        var preset = Module.OrientPreset.ORIENT_ISO1;
        var orientation = thisWidget.getProperty('Orientations');
        if (orientation == 'ISO1')
            preset = Module.OrientPreset.ORIENT_ISO1;
        else if (orientation == 'ISO2')
            preset = Module.OrientPreset.ORIENT_ISO2;
        else if (orientation == 'Top')
            preset = Module.OrientPreset.ORIENT_TOP;
        else if (orientation == 'Bottom')
            preset = Module.OrientPreset.ORIENT_BOTTOM;
        else if (orientation == 'Left')
            preset = Module.OrientPreset.ORIENT_LEFT;
        else if (orientation == 'Right')
            preset = Module.OrientPreset.ORIENT_RIGHT;
        else if (orientation == 'Front')
            preset = Module.OrientPreset.ORIENT_FRONT;
        else if (orientation == 'Back')
            preset = Module.OrientPreset.ORIENT_BACK;

        thisWidget.shapeView.ApplyOrientPreset(preset, animate ? 1000 : 0);
    }

    this.ApplyNavigation = function() {
        if (!thisWidget.shapeView) return;

        var mode = Module.NavMode.CREO_VIEW;
        var navigationMode = thisWidget.getProperty('MouseNavigation');
        if (navigationMode == 'CREOVIEW')
            mode = Module.NavMode.CREO_VIEW;
        else if (navigationMode == 'CREO')
            mode = Module.NavMode.CREO;
        else if (navigationMode == 'CATIAV5COMPATIBLE')
            mode = Module.NavMode.CATIA;
        else if (navigationMode == 'EXPLORE')
            mode = Module.NavMode.EXPLORE;

        if (mode == Module.NavMode.EXPLORE)
            thisWidget.shapeView.SetDoNotRoll(true);
        else
            thisWidget.shapeView.SetDoNotRoll(false);

        thisWidget.shapeView.SetNavigationMode(mode);
    }

    this.ApplyProjection = function() {
        if (!thisWidget.shapeView) return;

        var mode = 'Orthographic';
        var projectionMode = thisWidget.getProperty('ProjectionMode');
        if (projectionMode == 'PERSPECTIVE') mode = 'Perspective';
        else if (projectionMode == 'ORTHOGRAPHIC') mode = 'Orthographic';
        else {
            TW.log.error(projectionMode + ' is an invalid projection mode.');
            return;
        }

        if (mode == 'Perspective') {
            var hfov = thisWidget.getProperty('PerspectiveHFOV');
            if (hfov == undefined) hfov = 60;
            if (hfov > 0 && hfov < 180)
                thisWidget.shapeView.SetPerspectiveProjection(hfov);
            else
                TW.log.error('HFOV must be larger than 0 and less than 180.');
        } else if (mode == 'Orthographic') {
            thisWidget.shapeView.SetOrthographicProjection(1.0);
        }
    }

    this.ApplySelectionFilter = function() {
        if (thisWidget.shapeScene) {
            var enablePartSelection = thisWidget.getProperty('EnablePartSelection');
            if (enablePartSelection == undefined) enablePartSelection = true;

            if (enablePartSelection == true) {
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.PART, Module.SelectionList.PRIMARYSELECTION);
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.PART, Module.SelectionList.PRESELECTION);
            } else if (enablePartSelection == false) {
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.DISABLED, Module.SelectionList.PRIMARYSELECTION);
                thisWidget.shapeScene.SetSelectionFilter(Module.SelectionFilter.DISABLED, Module.SelectionList.PRESELECTION);
            }
        }
    }

    this.ApplyShapeFilters = function(defaultView) {
        if (thisWidget.shapeFilters == undefined) {
            var defaultDisplayFilter =
            '{' +
                '\"ModelAnnotation\": {' +
                    '\"HiddenByDefault\": true,' +
                    '\"PlanarAnnotation\": true,' +
                    '\"FloatingAnnotation\": false,' +
                    '\"MiscAnnotation\": false' +
                '}' +
            '}';
            var displayFilter = thisWidget.getProperty('DisplayFilter');
            if (displayFilter == undefined) {
                displayFilter = defaultDisplayFilter;
            } else {
                displayFilter = displayFilter.replace(/\s/g, "");
                if (displayFilter == "") displayFilter = defaultDisplayFilter;
            }

            var shapeFilterJson = {};
            try {                
                shapeFilterJson = JSON.parse(displayFilter);
            } catch (error) {
                TW.log.error('JSON parsing error: ' + error);
            }

            if (shapeFilterJson == undefined) shapeFilterJson = {};
            if (shapeFilterJson.ModelAnnotation == undefined) shapeFilterJson.ModelAnnotation = {};
            if (shapeFilterJson.ModelAnnotation.HiddenByDefault    == undefined) shapeFilterJson.ModelAnnotation.HiddenByDefault = true;
            if (shapeFilterJson.ModelAnnotation.PlanarAnnotation   == undefined) shapeFilterJson.ModelAnnotation.PlanarAnnotation = true;
            if (shapeFilterJson.ModelAnnotation.FloatingAnnotation == undefined) shapeFilterJson.ModelAnnotation.FloatingAnnotation = false;
            if (shapeFilterJson.ModelAnnotation.MiscAnnotation     == undefined) shapeFilterJson.ModelAnnotation.MiscAnnotation = false;

            thisWidget.shapeFilters = shapeFilterJson;
        }

        if (thisWidget.shapeScene) {
            var shapeFilters = 0x7; // Solids (0x1), Surfaces (0x2) and Cosmetics (0x4) of Model Geometry
            if (defaultView) {
                if (thisWidget.shapeFilters.ModelAnnotation.HiddenByDefault == false) {
                    if (thisWidget.shapeFilters.ModelAnnotation.PlanarAnnotation   == true) shapeFilters |= 0x100000;
                    if (thisWidget.shapeFilters.ModelAnnotation.FloatingAnnotation == true) shapeFilters |= 0x200000;
                    if (thisWidget.shapeFilters.ModelAnnotation.MiscAnnotation     == true) shapeFilters |= 0x400000;
                }
            } else {
                if (thisWidget.shapeFilters.ModelAnnotation.PlanarAnnotation   == true) shapeFilters |= 0x100000;
                if (thisWidget.shapeFilters.ModelAnnotation.FloatingAnnotation == true) shapeFilters |= 0x200000;
                if (thisWidget.shapeFilters.ModelAnnotation.MiscAnnotation     == true) shapeFilters |= 0x400000;
            }

            thisWidget.shapeScene.SetShapeFilters(shapeFilters);
        }
    }

    this.ApplyPartDragger = function() {
        if (thisWidget.shapeView) {
            var enablePartDragger = thisWidget.getProperty('EnablePartDragger');
            if (enablePartDragger == undefined) enablePartDragger = false;
            
            if (enablePartDragger == true) {
                thisWidget.shapeView.SetDragMode(Module.DragMode.DRAG);
            } else if (enablePartDragger == false) {
                thisWidget.shapeView.SetDragMode(Module.DragMode.NONE);
            }
        }
    }

    this.ApplyBackgroundColor = function () {
        var color = thisWidget.backgroundStyle.backgroundColor;
        if (color && color.charAt(0) === '#') {
            color = color.substring(1);
            color = '0x' + color + '00';
            thisWidget.shapeView.SetBackgroundColor(parseInt(color));
        }
    }

    this.LoadModel = function() {
        if (thisWidget.session && thisWidget.productToView) {
            function HandleSequenceStepResult(playstate, stepInfo, playpos) {
                TW.log.info("OnSequenceEvent");
                thisWidget.setProperty('SequenceStepNumber', stepInfo.number.toString());
                if (playstate == Module.SequencePlayState.PLAYING)
                    thisWidget.playState = "playing";
                else if (playstate == Module.SequencePlayState.STOPPED)
                    thisWidget.playState = "stopped";

                thisWidget.playPosition = 'START';
                if (playpos == Module.SequencePlayPosition.MIDDLE)
                    thisWidget.playPosition = 'MIDDLE';
                else if (playpos == Module.SequencePlayPosition.END)
                    thisWidget.playPosition = 'END';

                if (stepInfo.acknowledge)
                    thisWidget.jqElement.triggerHandler('SequenceStepAcknowledge');
            }

            function GetViewableImage(viewable) {
                if (viewable.type == undefined) { // figure
                    thisWidget.figureNums++;
                    thisWidget.figureName = viewable.name;
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_figures.svg';
                } else { // viewstate
                    return GetViewstateImage(viewable.type);
                }
            }

            function GetViewstateImage(type) {
                if (type == 'AlternateRep') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_simp_rep.svg';
                } else if (type == 'ViewState') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_all_state.svg';
                } else if (type == 'ExplodeState') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_preset_explode.svg';
                } else if (type == 'SectionCut') {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_sec_preset.svg';
                } else {
                    return '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_default_3d_view.svg';
                }
            }

            function GetViewableName(name) {
                var lengthLimit = 60; // px
                var c = document.createElement('canvas');
                var ctx = c.getContext('2d');
                ctx.font = "normal 500 12px 'Open Sans', Arial, sans-serif";

                var newName = name;
                for (var i=0;i<name.length;i++) {
                    var tempName = name.substring(0,i+1);
                    var length = ctx.measureText(tempName).width;
                    if (length > lengthLimit && (i+1) < name.length) {
                        newName = $.trim(name.substring(0, i)) + '&hellip;';
                        break;
                    }
                }

                return newName;
            }

            function GetAvailableViewStateTypes() {
                var availableTypes = {};
                availableTypes.ViewState    = thisWidget.getProperty('DisplayViewState');
                if (availableTypes.ViewState == undefined) availableTypes.ViewState = true;

                availableTypes.AlternateRep = thisWidget.getProperty('DisplayAlternateRep');
                if (availableTypes.AlternateRep == undefined) availableTypes.AlternateRep = false;
                availableTypes.ExplodeState = thisWidget.getProperty('DisplayExplodeState');
                if (availableTypes.ExplodeState == undefined) availableTypes.ExplodeState = false;
                availableTypes.SectionCut   = thisWidget.getProperty('DisplaySectionCut');
                if (availableTypes.SectionCut == undefined) availableTypes.SectionCut = false;

                return availableTypes;
            }

            function AssignLoadViewstateFunc(id, viewstate) {
                var viewableId = '#ThingViewWidgetVB-' + id.toString();
                thisWidget.jqElement.find(viewableId).unbind('click').click({
                    name: viewstate.name,
                    path: viewstate.path
                }, function (e) {
                    var views = thisWidget.getProperty('Views');
                    if (views != undefined) {
                        for (var i = 0; i < views.rows.length; i++) {
                            if (views.rows[i].name == e.data.name &&
                                views.rows[i].value == e.data.path &&
                                views.rows[i].type == "viewstate") {
                                thisWidget.updateSelection('Views', [i]);
                                break;
                            }
                        }
                    }

                    thisWidget.ApplyShapeFilters(false);
                    thisWidget.LoadViewState(e.data.name, e.data.path);
                });
            }

            function AssignLoadIllustrationFunc(id, illustration) {
                var viewableId = '#ThingViewWidgetVB-' + id.toString();
                thisWidget.jqElement.find(viewableId).unbind('click').click({
                    name: illustration.name
                }, function(e) {
                    var views = thisWidget.getProperty('Views');
                    if (views != undefined) {
                        for (var i=0;i<views.rows.length;i++) {
                            if (views.rows[i].name == e.data.name &&
                                views.rows[i].value == e.data.name &&
                                views.rows[i].type == "viewable") {
                                thisWidget.updateSelection('Views', [i]);
                                break;
                            }
                        }
                    }
                    thisWidget.LoadIllustration(e.data.name);
                });
            }

            function UpdateWidgetViewables(widgetIllustrations, widgetViewStates) {
                var widgetViewables = [];
                var availableViewstateTypes = GetAvailableViewStateTypes();
                if (widgetIllustrations.length) {
                    thisWidget.displayFigure = true;
                    widgetViewables = widgetIllustrations;
                    thisWidget.jqElement.find('#leftPaneViewablesTitleText').text('Figures');
                    thisWidget.jqElement.find('#leftPaneViewablesTitle').attr('title', 'Toggle figures')
                } else {
                    thisWidget.displayFigure = false;
                    widgetViewables = widgetViewStates;
                    thisWidget.jqElement.find('#leftPaneViewablesTitleText').text('View States');
                    thisWidget.jqElement.find('#leftPaneViewablesTitle').attr('title', 'Toggle view states')
                }

                var htmlElem = '';
                for (var i = 0; i < widgetViewables.length; i++) {
                    if (widgetViewables[i].type != undefined && !availableViewstateTypes[widgetViewables[i].type])
                        continue;

                    htmlElem += '<div id=\"ThingViewWidgetVB-';
                    htmlElem += i.toString();
                    htmlElem += '\" class=\"leftPaneViewableItem\" title=\"';
                    htmlElem += widgetViewables[i].name.replace(/"/g, '&#34;');
                    htmlElem += '\"><img src=\"';
                    htmlElem += GetViewableImage(widgetViewables[i]);
                    htmlElem += '\" class=\"leftPaneViewableItemImg\"/><span>';
                    htmlElem += GetViewableName(widgetViewables[i].name);
                    htmlElem += '</span></div>';
                }

                if (!thisWidget.displayFigure) {
                    var homeElem = '';
                    homeElem += '<div id=\"ThingViewWidgetVB-Home\" class=\"leftPaneViewableItem\" title=\"Default View\">';
                    homeElem += '<img src=\"../Common/extensions/ptc-thingview-extension/ui/thingview/widget_default_3d_view.svg\"';
                    homeElem += ' class=\"leftPaneViewableItemImg\"/>';
                    homeElem += '<span>Default View</span></div>';
                    htmlElem = homeElem + htmlElem;
                }
                thisWidget.jqElement.find('#leftPaneViewablesContent').html(htmlElem);
                thisWidget.leftScroll = $("#leftPaneViewablesContent").scrollable({pos: 'left', jqe: thisWidget.jqElement});

                if (!thisWidget.displayFigure) {
                    thisWidget.jqElement.find('#ThingViewWidgetVB-Home').unbind('click').click(function() {
                        if (thisWidget.shapeScene && thisWidget.model) {
                            thisWidget.shapeScene.RemoveAllCVMarkups(Module.CV_MARKUP_TYPES.CVMARKUPTYPE_ALL);
                            thisWidget.shapeScene.RemoveSectionCut();
                            thisWidget.model.ResetToPvkDefault();
                            thisWidget.ApplyShapeFilters(true);
                            thisWidget.LoadIllustration("", function() {
                                thisWidget.LoadDefaultView(function() {
                                    thisWidget.ApplyBackgroundColor();
                                    thisWidget.applyFormatter();
                                    thisWidget.ApplyOrientation(false);
                                    thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_ALL, 0);
                                    thisWidget.UpdateLocation();
                                });
                            });
                        }
                    });
                }

                for (var i = 0; i < widgetViewables.length; i++) {
                    if (widgetViewables[i].type != undefined) {
                        if (availableViewstateTypes[widgetViewables[i].type]) {
                            AssignLoadViewstateFunc(i, widgetViewables[i]);
                        }
                    } else {
                        AssignLoadIllustrationFunc(i, widgetViewables[i]);
                    }
                }
            }

            function AssignWidgetButtonFunctions() {
                function setVisibility(vis, allNode) {
                    if (!thisWidget.model) return;
                    
                    if (allNode) {
                        thisWidget.model.SetPartVisibility('/', vis,
                                                           Module.ChildBehaviour.INCLUDE,
                                                           Module.InheritBehaviour.USE_DEFAULT);
                    } else {
                        var selectedParts = thisWidget.getProperty('SelectedParts');
                        if (selectedParts != undefined) {
                            for (var i = 0; i < selectedParts.rows.length; i++) {
                                thisWidget.model.SetPartVisibility(
                                    selectedParts.rows[i].idPath, vis,
                                    Module.ChildBehaviour.INCLUDE,
                                    Module.InheritBehaviour.USE_DEFAULT
                                );
                            }
                        }
                    }
                }

                // Right pane opener
                thisWidget.jqElement.find('#rightPaneOpener').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    $(this)
                    .css({
                        cursor: 'default',
                        opacity: 0.2
                    }).prop({
                        disabled: true
                    });

                    if (thisWidget.rightWidgetPane != undefined) {
                        thisWidget.rightWidgetPane.open();
                    }
                });

                // Hide selected
                thisWidget.jqElement.find('#rightPaneButton1').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    setVisibility(false, false);
                });

                // Isolate selected
                thisWidget.jqElement.find('#rightPaneButton2').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    setVisibility(false, true);
                    setVisibility(true, false);
                });

                // Show all
                thisWidget.jqElement.find('#rightPaneButton3').unbind('click').click(function() {
                    setVisibility(true, true);
                });

                // Zoom all
                thisWidget.jqElement.find('#rightPaneButton4').unbind('click').click(function() {
                    thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                });

                // Zoom selected
                thisWidget.jqElement.find('#rightPaneButton5').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_SELECTED, 1000.0);
                });

                // Zoom window
                thisWidget.jqElement.find('#rightPaneButton6').unbind('click').click(function() {
                    thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_WINDOW, 1000.0);
                });

                // Part dragger
                thisWidget.jqElement.find('#rightPaneButton7').unbind('click').click(function() {
                    thisWidget.setProperty('EnablePartDragger', !thisWidget.getProperty('EnablePartDragger'));
                    thisWidget.rightWidgetPane.setPartDraggerButtonStatus();
                    thisWidget.ApplyPartDragger();
                });

                // Restore part location
                thisWidget.jqElement.find('#rightPaneButton8').unbind('click').click(function () {
                    if (thisWidget.model) {
                        thisWidget.model.UnsetLocation(true/*includeChildren*/);
                    }
                });

                thisWidget.updateRightPaneButtonsAvailability = function () {
                    function disableButton(id) {
                        thisWidget.jqElement.find('#rightPaneButton' + id)
                        .css({
                            cursor: 'default',
                            opacity: 0.2
                        }).prop({
                            disabled: true
                        });
                    }
                    function enableButton(id) {
                        thisWidget.jqElement.find('#rightPaneButton' + id)
                        .css({
                            cursor: 'pointer',
                            opacity: 1.0
                        }).prop({
                            disabled: false
                        });
                    }

                    var selectedPart = thisWidget.getProperty('SelectedOccurrencePath');
                    if (selectedPart != undefined && selectedPart.length > 0) {
                        enableButton('1');
                        enableButton('2');
                        enableButton('5');
                    } else {
                        disableButton('1');
                        disableButton('2');
                        disableButton('5');
                    }
                }

                function disableButton(id, title) {
                    thisWidget.jqElement.find(id)
                    .css({
                        cursor: 'default',
                        opacity: 0.2
                    }).prop({
                        disabled: true
                    }).attr({
                        title: title + ' (Disabled)'
                    });
                }
                function enableButton(id, title) {
                    thisWidget.jqElement.find(id)
                    .css({
                        cursor: 'pointer',
                        opacity: 1.0
                    }).prop({
                        disabled: false
                    }).attr({
                        title: title
                    });
                }

                // Right pane
                if (thisWidget.rightWidgetPane == undefined) {
                    thisWidget.rightWidgetPane = {};
                    thisWidget.rightWidgetPane.visibility = false;
                    thisWidget.rightWidgetPane.forceClosed = false;
                    thisWidget.rightWidgetPane.animating = false;
                    thisWidget.rightWidgetPane.hidingMargin = 30;
                    thisWidget.rightWidgetPane.closedRight = '0px';

                    // Initialize pane
                    thisWidget.rightWidgetPane.initialisePane = function() {
                        let rightPaneContainerWidth  = thisWidget.jqElement.find('#rightPaneContainer').outerWidth();
                        thisWidget.jqElement.find('#rightPaneContainer').css({
                            right: '-' + (rightPaneContainerWidth + thisWidget.rightWidgetPane.hidingMargin).toString() + 'px',
                            visibility: 'visible'
                        });
                        thisWidget.jqElement.find("#rightPaneCloser").css({
                            right: rightPaneContainerWidth.toString() + 'px'
                        });

                        thisWidget.updateRightPaneButtonsAvailability();
                        thisWidget.rightWidgetPane.setPartDraggerButtonStatus();
                    }

                    // Resize event
                    thisWidget.rightWidgetPane.resize = function() {

                        let rightPaneContainerBGHeight = thisWidget.jqElement.find('#rightPaneContainerBG').outerHeight();
                        let rightPaneContainerHeight  =
                            10 /* Top offset */
                            + 6 /* Top border */
                            + thisWidget.jqElement.find('#rightPaneCloser').outerHeight()
                            + 6 /* Bottom border */
                            + 10 /* Bottom offset */;

                        let rightPaneContentMaxHeight =
                            rightPaneContainerBGHeight
                            - 20 /* Top/Bottom margin */
                            - 12 /* Top/Bottom padding */;

                        let buttons = $("#rightPaneContent").find('.rightPaneButtons');

                        let rightPaneContentHeight =
                            + (6 /* Top margin */ + 40 /* Button height */ + 6 /* Bottom margin */) * buttons.length /* No. of buttons */;

                        thisWidget.jqElement.find("#rightPaneContent").css({
                            height: Math.min(rightPaneContentMaxHeight, rightPaneContentHeight).toString() + 'px'
                        });

                        // Width
                        let rightPaneContainerWidth = thisWidget.jqElement.find('#rightPaneContainer').outerWidth();

                        // Hide Zooming & Selection tools if there is not enough space (height)
                        if (rightPaneContainerBGHeight < rightPaneContainerHeight) { // Hide
                            if (thisWidget.jqElement.find('#rightPaneContainer').css('right') == thisWidget.rightWidgetPane.closedRight) {
                                // It's open so close it
                                thisWidget.rightWidgetPane.forceClosed = true;
                                thisWidget.jqElement.find('#rightPaneContainer').stop().animate({
                                    right: '-' + (rightPaneContainerWidth + thisWidget.rightWidgetPane.hidingMargin).toString() + 'px'
                                }, 500, 'swing', function () {
                                    disableButton("#rightPaneOpener", 'Zooming & Selection tools');
                                });
                            } else {
                                // Already closed
                                disableButton("#rightPaneOpener", 'Zooming & Selection tools');
                            }

                            thisWidget.rightWidgetPane.visibility = false;
                        } else { // Show
                            if (thisWidget.rightWidgetPane.forceClosed) {
                                thisWidget.rightWidgetPane.forceClosed = false;

                                disableButton("#rightPaneOpener", 'Zooming & Selection tools');

                                thisWidget.rightWidgetPane.open();
                            } else {
                                if (!thisWidget.rightWidgetPane.visibility) {
                                    if (thisWidget.rightWidgetPane.animating) return;
                                    // Closed
                                    thisWidget.jqElement.find('#rightPaneContainer').stop().css({
                                        right: '-' + (rightPaneContainerWidth + thisWidget.rightWidgetPane.hidingMargin).toString() + 'px'
                                    });

                                    enableButton("#rightPaneOpener", 'Zooming & Selection tools');
                                } else {
                                    // Open
                                    thisWidget.jqElement.find('#rightPaneContainer').stop().css({
                                        right: thisWidget.rightWidgetPane.closedRight
                                    });
                                }
                            }
                        }
                    }

                    // Set DragSelect button status
                    thisWidget.rightWidgetPane.setPartDraggerButtonStatus = function() {
                        if (thisWidget.getProperty('EnablePartDragger') == true) {
                            thisWidget.jqElement.find('#rightPaneButton7').addClass('buttonPressed');
                        } else if (thisWidget.getProperty('EnablePartDragger') == false) {
                            thisWidget.jqElement.find('#rightPaneButton7').removeClass('buttonPressed');
                        }
                    }

                    if (thisWidget.rightScroll == undefined)
                        thisWidget.rightScroll = $("#rightPaneContent").scrollable();
                }

                // Right pane opener
                thisWidget.rightWidgetPane.open = function() {
                    thisWidget.rightWidgetPane.animating = true;
                    if (thisWidget.rightScroll)
                        thisWidget.rightScroll.onResize();
                    thisWidget.jqElement.find('#rightPaneContainer').css({
                        backgroundColor: 'rgba(240,240,240,0.9)'
                    }).stop().animate({
                        right: thisWidget.rightWidgetPane.closedRight
                    }, 500, 'swing', function () {
                        thisWidget.rightWidgetPane.animating = false;
                    });
        
                    thisWidget.rightWidgetPane.visibility = true;
                }
                thisWidget.rightWidgetPane.close = function (callback) {
                    thisWidget.rightWidgetPane.animating = true;
                    let rightPaneContainerWidth  = thisWidget.jqElement.find('#rightPaneContainer').outerWidth();
                    thisWidget.jqElement.find('#rightPaneContainer').stop().animate({
                        right: '-' + (rightPaneContainerWidth + thisWidget.rightWidgetPane.hidingMargin).toString() + 'px'
                    }, 500, 'swing', function () {
                        thisWidget.rightWidgetPane.animating = false;
                        if (callback) callback();
                    });
        
                    thisWidget.rightWidgetPane.visibility = false;
                }
                thisWidget.jqElement.find('#rightPaneCloser').unbind('click').click(function() {
                    if (thisWidget.rightWidgetPane.visibility) {
                        thisWidget.rightWidgetPane.close(function() {
                            thisWidget.jqElement.find('#rightPaneOpener')
                            .css({
                                cursor: 'pointer',
                                opacity: 1.0
                            }).prop({
                                disabled: false
                            });
                        });
                    }
                });

                // Left pane

                // Left pane opener
                thisWidget.jqElement.find('#leftPaneOpener').unbind('click').click(function() {
                    if ($(this).prop('disabled')) return;

                    $(this)
                    .css({
                        cursor: 'default',
                        opacity: 0.2
                    }).prop({
                        disabled: true
                    });

                    if (thisWidget.leftWidgetPane != undefined) {
                        thisWidget.leftWidgetPane.open();
                    }
                });

                // Left pane
                if (thisWidget.leftWidgetPane == undefined) {
                    thisWidget.leftWidgetPane = {};
                    thisWidget.leftWidgetPane.visibility = false;
                    thisWidget.leftWidgetPane.forceClosed = false;
                    thisWidget.leftWidgetPane.animating = false;
                    thisWidget.leftWidgetPane.orientsContentVis = thisWidget.jqElement.find('#leftPaneOrientsContent').css('display') == 'table';
                    thisWidget.leftWidgetPane.viewstatesContentVis = thisWidget.jqElement.find('#leftPaneViewablesContent').css('display') == 'block';
                    thisWidget.leftWidgetPane.hidingMargin = 30;

                    if (thisWidget.displayFigure) {
                        thisWidget.leftWidgetPane.openerTitle = "Orientation & Figures";
                    } else {
                        thisWidget.leftWidgetPane.openerTitle = "Orientation & View States";
                    }
                    thisWidget.jqElement.find("#leftPaneOpener").attr({title: thisWidget.leftWidgetPane.openerTitle});

                    // Initialize pane
                    thisWidget.leftWidgetPane.initialisePane = function() {
                        let leftPaneContainerWidth  = thisWidget.jqElement.find('#leftPaneContainer').outerWidth();
                        thisWidget.jqElement.find('#leftPaneContainer').css({
                            left: '-' + (leftPaneContainerWidth + thisWidget.leftWidgetPane.hidingMargin).toString() + 'px',
                            visibility: 'visible'
                        });
                        thisWidget.jqElement.find("#leftPaneCloser").css({
                            right: leftPaneContainerWidth.toString() + 'px'
                        });
                    }

                    // Resize pane
                    thisWidget.leftWidgetPane.resizePane = function () {
                        // Locate left pane opener
                        let leftPaneContainerRect = document.getElementById('leftPaneContainer').getBoundingClientRect();
                        let leftPaneContainerWidth = leftPaneContainerRect.width;

                        thisWidget.jqElement.find("#leftPaneCloser").css({
                            left: leftPaneContainerWidth.toString() + 'px'
                        });

                        // Set max height of view states
                        let leftPaneContainerBGHeight = thisWidget.jqElement.find('#leftPaneContainerBG').outerHeight();

                        let leftPaneTopOffset = 10;
                        let leftPaneOrientsTitleHeight = thisWidget.jqElement.find("#leftPaneOrientsTitle").outerHeight(true);
                        let leftPaneOrientsContentHeight = document.getElementById('leftPaneOrientsContent').getBoundingClientRect().height;
                        if (thisWidget.leftWidgetPane.orientsHeight == undefined)
                            thisWidget.leftWidgetPane.orientsHeight = leftPaneOrientsContentHeight;
                        let leftPaneViewablesTitleHeight = thisWidget.jqElement.find("#leftPaneViewablesTitle").outerHeight(true);
                        let leftPaneBottomBorderHeight = thisWidget.jqElement.find('#bottomBorder').outerHeight();
                        let leftPaneBottomOffset = 10;
                        let height =
                            leftPaneTopOffset
                            + leftPaneOrientsTitleHeight
                            + leftPaneOrientsContentHeight
                            + leftPaneViewablesTitleHeight
                            + leftPaneBottomBorderHeight
                            + leftPaneBottomOffset;
                        let viewstateMaxHeight = leftPaneContainerBGHeight - height;

                        let leftPaneHeight = 0;

                        if (thisWidget.leftWidgetPane.viewstatesContentVis) {
                            var vsItems = thisWidget.jqElement.find(".leftPaneViewableItem");
                            if (vsItems.length) {
                                var vsItemHeight = vsItems.outerHeight(true);// - 2;
                                var vsItemsHeight = vsItemHeight * vsItems.length;// + 4;

                                var vsMinHeight = Math.min(viewstateMaxHeight, vsItemsHeight);

                                thisWidget.jqElement.find("#leftPaneViewablesContent").css({
                                    height: vsMinHeight.toString() + 'px'
                                });

                                leftPaneHeight = height + vsItemHeight;
                            } else {
                                var noVS = thisWidget.jqElement.find('#noViewables');
                                if (noVS.length) {
                                    var noVSHeight = noVS.outerHeight(true);
                                    leftPaneHeight = height + noVSHeight;
                                }    
                            }
                        } else {
                            leftPaneHeight = leftPaneContainerRect.height + leftPaneTopOffset + leftPaneBottomOffset;
                        }

                        if (thisWidget.leftWidgetPane.orientsContentVis == false) {
                            if ((leftPaneHeight + thisWidget.leftWidgetPane.orientsHeight) < leftPaneContainerBGHeight)
                                enableButton('#leftPaneOrientsTitle', "Toggle orientations");
                            else
                                disableButton('#leftPaneOrientsTitle', "Toggle orientations");
                        }

                        // Width

                        // Hide pane if there is not enough space (height)
                        if (leftPaneHeight > leftPaneContainerBGHeight) { // Hide
                            if (thisWidget.leftWidgetPane.orientsContentVis == true &&
                                thisWidget.leftWidgetPane.viewstatesContentVis == true) {
                                // Disable orientation button
                                disableButton('#leftPaneOrientsTitle', "Toggle orientations");

                                // Close orientation content
                                thisWidget.leftWidgetPane.closeOrientsContent();
                                thisWidget.leftWidgetPane.resizePane();
                            } else {
                                if (thisWidget.jqElement.find('#leftPaneContainer').css('left') == '0px') {
                                    // It's open so close it
                                    thisWidget.leftWidgetPane.forceClosed = true;
                                    thisWidget.jqElement.find('#leftPaneContainer').stop().animate({
                                        left: '-' + (leftPaneContainerWidth + thisWidget.leftWidgetPane.hidingMargin).toString() + 'px'
                                    }, 500, 'swing', function () {
                                        disableButton("#leftPaneOpener", thisWidget.leftWidgetPane.openerTitle);
                                    });
                                } else {
                                    // Already closed
                                    disableButton("#leftPaneOpener", thisWidget.leftWidgetPane.openerTitle);
                                }

                                thisWidget.leftWidgetPane.visibility = false;
                            }
                        } else { // Show
                            if (thisWidget.leftWidgetPane.forceClosed) {
                                thisWidget.leftWidgetPane.forceClosed = false;

                                disableButton("#leftPaneOpener", thisWidget.leftWidgetPane.openerTitle);

                                thisWidget.leftWidgetPane.open();
                            } else {
                                if (!thisWidget.leftWidgetPane.visibility) {
                                    if (thisWidget.leftWidgetPane.animating) return;
                                    // Closed
                                    thisWidget.jqElement.find('#leftPaneContainer').stop().css({
                                        left: '-' + (leftPaneContainerWidth + thisWidget.leftWidgetPane.hidingMargin).toString() + 'px'
                                    });

                                    enableButton("#leftPaneOpener", thisWidget.leftWidgetPane.openerTitle);
                                } else {
                                    // Open
                                    thisWidget.jqElement.find('#leftPaneContainer').stop().css({
                                        left: '0px'
                                    });
                                }
                            }
                        }
                    }

                    $(window).bind('resize', function() {
                        if (thisWidget.leftWidgetPane != undefined)
                            thisWidget.leftWidgetPane.resizePane();
                        if (thisWidget.rightWidgetPane != undefined)
                            thisWidget.rightWidgetPane.resize();
                        if (thisWidget.leftScroll)
                            thisWidget.leftScroll.onResize();
                        if (thisWidget.rightScroll)
                            thisWidget.rightScroll.onResize();
                    });

                    thisWidget.leftWidgetPane.initialisePane();
                    thisWidget.rightWidgetPane.initialisePane();
                }

                // Left pane opener
                thisWidget.leftWidgetPane.open = function() {
                    thisWidget.leftWidgetPane.animating = true;
                    if (thisWidget.leftScroll)
                        thisWidget.leftScroll.onResize();
                    thisWidget.jqElement.find('#leftPaneContainer').css({
                        backgroundColor: 'rgba(240,240,240,0.9)'
                    }).stop().animate({
                        left: '0px'
                    }, 500, 'swing', function() {
                        thisWidget.leftWidgetPane.animating = false;
                    });
        
                    thisWidget.leftWidgetPane.visibility = true;
                }
                thisWidget.leftWidgetPane.close = function (callback) {
                    thisWidget.leftWidgetPane.animating = true;
                    let leftPaneContainerWidth  = thisWidget.jqElement.find('#leftPaneContainer').outerWidth();
                    thisWidget.jqElement.find('#leftPaneContainer').stop().animate({
                        left: '-' + (leftPaneContainerWidth + thisWidget.leftWidgetPane.hidingMargin).toString() + 'px'
                    }, 500, 'swing', function() {
                        thisWidget.leftWidgetPane.animating = false;
                        if (callback) callback();
                    });
        
                    thisWidget.leftWidgetPane.visibility = false;
                }
                thisWidget.jqElement.find('#leftPaneCloser').unbind('click').click(function() {
                    if (thisWidget.leftWidgetPane.visibility) {
                        thisWidget.leftWidgetPane.close(function() {
                            thisWidget.jqElement.find('#leftPaneOpener')
                            .css({
                                cursor: 'pointer',
                                opacity: 1.0
                            }).prop({
                                disabled: false
                            });
                        });
                    }
                });

                // Toggle orientation contents
                thisWidget.leftWidgetPane.closeOrientsContent = function() {
                    thisWidget.jqElement.find('#leftPaneOrientsContent').css({ display: 'none' });
                    thisWidget.jqElement.find('#leftPaneOrientsTitleMark')
                        .attr({
                            src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_expand.svg'
                        });
                    thisWidget.leftWidgetPane.orientsContentVis = false;
                }
                thisWidget.leftWidgetPane.openOrientsContent = function() {
                    thisWidget.jqElement.find('#leftPaneOrientsContent').css({ display: 'table' });
                    thisWidget.jqElement.find('#leftPaneOrientsTitleMark')
                    .attr({
                        src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg'
                    });
                    thisWidget.leftWidgetPane.orientsContentVis = true;
                }
                thisWidget.jqElement.find('#leftPaneOrientsTitle').unbind('click').click(function () {
                    if ($(this).prop('disabled')) return;

                    if (thisWidget.leftWidgetPane.orientsContentVis) {
                        thisWidget.leftWidgetPane.closeOrientsContent();
                    } else {
                        thisWidget.leftWidgetPane.openOrientsContent();
                    }
                    thisWidget.leftWidgetPane.resizePane();
                    if (thisWidget.leftScroll)
                        thisWidget.leftScroll.onResize();
                });

                // Orientations
                thisWidget.jqElement.find('#widgetOrientFront').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_FRONT, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientBack').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_BACK, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientLeft').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_LEFT, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientRight').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_RIGHT, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientBottom').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_BOTTOM, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientTop').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_TOP, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientISO1').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_ISO1, 1000.0);
                });
                thisWidget.jqElement.find('#widgetOrientISO2').unbind('click').click(function() {
                    thisWidget.shapeView.ApplyOrientPreset(Module.OrientPreset.ORIENT_ISO2, 1000.0);
                });

                // Toggle viewables contents
                thisWidget.leftWidgetPane.closeViewablesContent = function() {
                    thisWidget.jqElement.find('#leftPaneViewablesContent').css({ display: 'none' });
                    thisWidget.jqElement.find('#leftPaneViewablesTitleMark')
                        .attr({
                            src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_expand.svg'
                        });
                    thisWidget.leftWidgetPane.viewstatesContentVis = false;
                }
                thisWidget.leftWidgetPane.openViewablesContent = function() {
                    thisWidget.jqElement.find('#leftPaneViewablesContent').css({ display: 'block' });
                    thisWidget.jqElement.find('#leftPaneViewablesTitleMark')
                        .attr({
                            src: '../Common/extensions/ptc-thingview-extension/ui/thingview/widget_collapse.svg'
                        });
                    thisWidget.leftWidgetPane.viewstatesContentVis = true;
                }
                thisWidget.jqElement.find('#leftPaneViewablesTitle').unbind('click').click(function () {
                    if (thisWidget.leftWidgetPane.viewstatesContentVis) {
                        thisWidget.leftWidgetPane.closeViewablesContent();
                    } else {
                        thisWidget.leftWidgetPane.openViewablesContent();
                    }
                    thisWidget.leftWidgetPane.resizePane();
                    if (thisWidget.leftScroll)
                        thisWidget.leftScroll.onResize();
                });

                // initialize pane
                thisWidget.leftWidgetPane.resizePane();
                thisWidget.rightWidgetPane.resize();
            }

            function StructureLoadComplete() {
                TW.log.info('Structure Loaded');

                var infoTableValue = thisWidget.getProperty('Views');
                if (infoTableValue.rows == undefined)
                    infoTableValue.rows = [];

                var spinfoTableValue = thisWidget.getProperty('SelectedParts');
                if (spinfoTableValue.rows == undefined)
                    spinfoTableValue.rows = [];

                var annoSets = thisWidget.structure.GetAnnotationSets();
                if (annoSets) {
                    for (var i = 0; i < annoSets.size() ; i++) {
                        var annoSetTemp = annoSets.get(i);
                        if (annoSetTemp.propertyName == 'model') {
                            var setName = decodeURIComponent(escape(annoSetTemp.name));
                            infoTableValue.rows.push({ 'name': setName, 'type': 'annotation', 'value': setName});
                        }
                    }
                }

                var widgetIllustrations = [];
                var widgetViewStates = [];
                var illustrations = thisWidget.structure.GetIllustrations()
                if (illustrations.size() > 0) {
                    for (var i = 0; i < illustrations.size() ; i++) {
                        var illustrationName = decodeURIComponent(escape(illustrations.get(i).name));
                        infoTableValue.rows.push({ 'name': illustrationName, 'type': 'viewable', 'value': illustrationName });

                        if (thisWidget.thingViewControls) {
                            widgetIllustrations.push({name: illustrationName});
                        }
                    }
                } else {
                    var viewStates = thisWidget.structure.GetViewStates();
                    if (viewStates) {
                        for (var i = 0; i < viewStates.size(); i++) {
                            var viewState = viewStates.get(i);
                            var viewStateName = decodeURIComponent(escape(viewState.name));
                            var viewStatePath = viewState.path;
                            infoTableValue.rows.push({ 'name': viewStateName, 'type': 'viewstate', 'value': viewStatePath});
    
                            if (thisWidget.thingViewControls) {
                                if (viewStatePath == '/') {
                                    widgetViewStates.push({name: viewStateName, path: viewStatePath, type: viewState.type});
                                }
                            }
                        }
                    }
                }

                if (thisWidget.thingViewControls) {
                    UpdateWidgetViewables(widgetIllustrations, widgetViewStates);
                    AssignWidgetButtonFunctions();
                }

                thisWidget.setProperty('Views', infoTableValue);
                thisWidget.setProperty('SelectedParts', spinfoTableValue);
            }

            function ModelLoadComplete() {
                thisWidget.ApplyBackgroundColor();
                thisWidget.ApplyOrientation(false);
                thisWidget.UpdateLocation();

                // Set callbacks
                thisWidget.model.SetSequenceEventCallback(function(playstate, stepNum, playpos) {
                    HandleSequenceStepResult(playstate, stepNum, playpos);
                });

                thisWidget.model.SetSelectionCallback(function(type, si, idPath, selected, selType) {
                    if (selType == Module.SelectionList.PRESELECTION) {
                        if (selected) {
                            thisWidget.setProperty("PreSelectedOccurrencePath", idPath);
                        } else {
                            thisWidget.setProperty("PreSelectedOccurrencePath", "");
                        }
                        thisWidget.jqElement.triggerHandler('PreSelectionChanged');
                    }
                });

                function modelLoaded() {
                    TW.log.info('Model loaded');
                    thisWidget.shapeScene.ShowProgress(false);

                    setTimeout(thisWidget.applyFormatter, 100);
                    thisWidget.jqElement.triggerHandler('Loaded');
                    thisWidget.loadingModel = false;
                }

                if (thisWidget.figureNums == 0) {
                    // No figures so load default view
                    thisWidget.LoadDefaultView(function() {
                        thisWidget.ApplyOrientation(false);
                        thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000);
                        thisWidget.UpdateLocation();
                        modelLoaded();
                    });
                } else {
                    if (thisWidget.figureNums == 1) {
                        // If we have only one figure, load it
                        thisWidget.LoadIllustration(thisWidget.figureName, function() {
                            modelLoaded();
                        });
                    } else {
                        // no need to load anything
                        modelLoaded();

                        // but show the figures menu
                        thisWidget.jqElement.find('#leftPaneOpener')
                        .css({
                            cursor: 'default',
                            opacity: 0.2
                        }).prop({
                            disabled: true
                        });
                        if (thisWidget.leftWidgetPane != undefined) {
                            thisWidget.leftWidgetPane.open();
                            thisWidget.leftWidgetPane.closeOrientsContent();
                            thisWidget.leftWidgetPane.resizePane();
                            if (thisWidget.leftScroll)
                                thisWidget.leftScroll.onResize();
                        }
                    }
                }
            }

            function logErrorStack(errorStack) {
                for (var i=0;i<errorStack.size();i++) {
                    var error = errorStack.get(i);
                    TW.log.error('Load Model error [' + error.number + '] ' + error.name + ' - ' + error.message);
                }
            }

            thisWidget.loadingModel = true;
            thisWidget.model = thisWidget.shapeScene.MakeModel();

            if (thisWidget.windchillSourceData == true) {
                var widgetParams = new Module.NameValueVec();
                widgetParams.push_back({name:"sourceUrl",value:thisWidget.productToView});
                widgetParams.push_back({name:"templateUrl",value:thisWidget.templateUrl});
                widgetParams.push_back({name:"mapUrl",value:thisWidget.mapUrl});
                widgetParams.push_back({name:"oid",value:thisWidget.oid});
                widgetParams.push_back({name:"markupUrl",value:thisWidget.markupUrl});

                thisWidget.structure = thisWidget.session.LoadStructureWithWCURL(
                    widgetParams, true,
                    function(success, errorStack) {
                        if (success) {
                            thisWidget.model.LoadStructure(
                                thisWidget.structure, false, false,
                                function (_success, _isStructure, _errorStack) {
                                    if (_success === true) {
                                        if (_isStructure === true) {
                                            // The structure has finished loading
                                            StructureLoadComplete();
                                        } else {
                                            // The entire model has finished loading
                                            ModelLoadComplete();
                                        }
                                    } else {
                                        thisWidget.loadingModel = false;
                                        TW.log.error('Failed to load model');
                                        logErrorStack(_errorStack);
                                        thisWidget.UnloadModel();
                                    }
                                }
                            );
                        } else {
                            thisWidget.loadingModel = false;
                            TW.log.error('Failed to load structure with Windchill URL');
                            logErrorStack(errorStack);
                        }
                    }
                );
            } else {
                thisWidget.structure = thisWidget.session.LoadStructureWithURL(
                    thisWidget.productToView, true,
                    function(success, errorStack) {
                        if (success) {
                            thisWidget.model.LoadStructure(
                                thisWidget.structure, false, false,
                                function (_success, _isStructure, _errorStack) {
                                    if (_success === true) {
                                        if (_isStructure === true) {
                                            // The structure has finished loading
                                            StructureLoadComplete();
                                        } else {
                                            // The entire model has finished loading
                                            ModelLoadComplete();
                                        }
                                    } else {
                                        thisWidget.loadingModel = false;
                                        TW.log.error('Failed to load model');
                                        logErrorStack(_errorStack);
                                        thisWidget.UnloadModel();
                                    }
                                }
                            );
                        } else {
                            thisWidget.loadingModel = false;
                            TW.log.error('Failed to load structure with URL');
                            logErrorStack(errorStack);
                        }
                    }
                );
            }

            setTimeout(function() {
                thisWidget.shapeScene.ShowProgress(true);
            }, 500);
        }
    }

    this.UpdateLocation  = function() {
        thisWidget.GetViewLocation();
    }

    this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
        switch (propertyName) {
            case 'Data': {
                if (thisWidget.shapeScene)
                    thisWidget.shapeScene.DeselectAllInstances();
                else {
                    TW.log.info("DeselectAll cannot be called as model is not loaded");
                }
                var i = selectedRowIndices.length;
                var idPathArr = new Module.VectorString();

                var infoTableValue = thisWidget.getProperty('SelectedParts');
                infoTableValue.rows = [];

                var lastIdPath = undefined;
                while (i--) {
                    var id = getCachedOccurrencePath(thisWidget.localData[selectedRowIndices[i]]);
                    idPathArr.push_back(id);
                    infoTableValue.rows.push({ 'idPath': id });
                    lastIdPath = id;
                }
                thisWidget.shapeScene.SelectInstances(idPathArr, true);
                if (lastIdPath !== undefined)
                    thisWidget.setProperty('SelectedOccurrencePath', lastIdPath);
                else
                    thisWidget.setProperty('SelectedOccurrencePath', '');
                thisWidget.setProperty('SelectedParts', infoTableValue);
                if (thisWidget.thingViewControls) {
                    thisWidget.updateRightPaneButtonsAvailability();
                }
            }
            break;
            case 'Views': {
                if (selectedRows.length == 1) {
                    if (selectedRows[0].type == "annotation") {
                        if(ThingView.IsPDFSession() || ThingView.IsSVGSession()){
                            ThingView.Destroy2DCanvas();
                            ThingView.Show3DCanvas(thisWidget.session);
                        }
                        if (thisWidget.model) {
                            thisWidget.model.ResetToPvkDefault();
                            thisWidget.model.LoadAnnotationSetWithCallback(selectedRows[0].value, function(success, name) {
                                if (success === true) {
                                    TW.log.info("OnLoadAnnotationSetComplete");
                                    if (thisWidget.model.HasAnimation())
                                        thisWidget.jqElement.triggerHandler('HasAnimation');
                                } else {
                                    TW.log.error("OnLoadAnnotationSetError");
                                }
                            });
                        } else {
                            TW.log.error("OnLoadAnnotationSetError - Model does not exist.");
                        }
                    } else if (selectedRows[0].type == "viewable") {
                        if(ThingView.IsPDFSession() || ThingView.IsSVGSession()){
                            ThingView.Destroy2DCanvas();
                            ThingView.Show3DCanvas(thisWidget.session);
                        }
                        thisWidget.LoadIllustration(selectedRows[0].value);
                    } else if (selectedRows[0].type == "viewstate") {
                        if(ThingView.IsPDFSession() || ThingView.IsSVGSession()){
                            ThingView.Destroy2DCanvas();
                            ThingView.Show3DCanvas(thisWidget.session);
                        }
                        thisWidget.ApplyShapeFilters(false);
                        thisWidget.LoadViewState(selectedRows[0].name, selectedRows[0].value);
                    }
                } else {
                    TW.log.info("must have only one selected row");
                }
            }
            break;
        }
    }

    this.updateProperty = function(updatePropertyInfo) {
        switch (updatePropertyInfo.TargetProperty) {
            case 'ProductToView': {
                if (!thisWidget.loadingModel) {
                    this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                    thisWidget.productToView = thisWidget.getProperty('ProductToView');

                    if (thisWidget.windchillSourceData == true) {
                        setTemplateUrl();
                    }
                
                    TW.log.info('ProductToView property updated unload existing model and load new one: ' + thisWidget.productToView);
                    thisWidget.UnloadModel();
                    thisWidget.LoadModel();
                }
                break;
            }
            case 'Orientation': {
                TW.log.info('Orientation updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                break;
            }
            case 'Position': {
                TW.log.info('Position updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                break;
            }
            case 'Orientations': {
                TW.log.info('Orientations updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyOrientation(true);
                break;
            }
            case 'MouseNavigation': {
                TW.log.info('MouseNavigation updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyNavigation();
                break;
            }
            case 'BackgroundStyle': {
                TW.log.info('BackgroundStyle updated');
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.backgroundStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('BackgroundStyle', ''));
                thisWidget.ApplyBackgroundColor();
                break;
            }
            case 'SelectedParts': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                var localSelectedParts = updatePropertyInfo.ActualDataRows;

                if (localSelectedParts.length == 0) { // Nothing selected, clear selection
                    thisWidget.selectedInstances = [];
                    thisWidget.shapeScene.DeselectAllInstances();
                    return;
                }

                var idPathArr = new Module.VectorString();
                var deselectidPathArr = new Module.VectorString();

                var selInstances = [];

                for (var i=0;i<thisWidget.selectedInstances.length;++i) {
                    var idx = -1;
                    for (var ii=0;ii<localSelectedParts.length;++ii) {
                        if (localSelectedParts[ii]['idPath'] == thisWidget.selectedInstances[i])
                            idx = 0;
                    }

                    if (idx == -1) { // Deselect currently selected parts not in new selection list
                        deselectidPathArr.push_back(thisWidget.selectedInstances[i]);
                    } else {
                        selInstances.push(thisWidget.selectedInstances[i]);
                    }
                }

                var infoTableValue = thisWidget.getProperty('SelectedParts');
                infoTableValue.rows = [];

                for (var i=0;i<localSelectedParts.length;++i) {
                    var idx = thisWidget.selectedInstances.indexOf(localSelectedParts[i]['idPath']);
                    if (idx == -1) { // If new selection list is not in current selection list select the parts
                        idPathArr.push_back(localSelectedParts[i]['idPath']);
                        selInstances.push(localSelectedParts[i]['idPath']);
                    }
                    infoTableValue.rows.push({ 'idPath': localSelectedParts[i]['idPath'] });
                }

                thisWidget.selectedInstances = selInstances.slice(0);
                thisWidget.shapeScene.SelectInstances(deselectidPathArr, false);
                thisWidget.shapeScene.SelectInstances(idPathArr, true);
                thisWidget.setProperty('SelectedParts', infoTableValue);
                break;
            }
            case 'Data': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.localData = updatePropertyInfo.ActualDataRows;
                if (thisWidget.localData && thisWidget.localData.length > 0) {
                    var i = thisWidget.localData.length;
                    while (i--) {
                        thisWidget.localData[i]._cachedOccurrencePath = null;
                    }
                }

                for (i in thisWidget.localData) {
                    var formatResult = TW.getStyleFromStateFormatting({DataRow: thisWidget.localData[i], StateFormatting: thisWidget.formatter});
                    if (formatResult.foregroundColor) {
                        if (thisWidget.model) {
                            var color = this.parseRGBA(formatResult.foregroundColor);
                            thisWidget.model.SetPartColor(
                                thisWidget.localData[i][thisWidget.occurrenceIdField],
                                parseFloat(color[0]), parseFloat(color[1]), parseFloat(color[2]), parseFloat(color[3]),
                                Module.ChildBehaviour.IGNORED,
                                Module.InheritBehaviour.USE_DEFAULT
                            );
                        }
                    }
                }
                break;
            }
            case 'Gnomon': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.shapeView) {
                    var showGnomon = thisWidget.getProperty('Gnomon');
                    if (showGnomon == undefined) showGnomon = false;
                    if (showGnomon == true) {
                        thisWidget.shapeView.ShowGnomon(true);
                    } else if (showGnomon == false) {
                        thisWidget.shapeView.ShowGnomon(false);
                    }
                }
                break;
            }
            case 'EnablePartSelection': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplySelectionFilter();
                break;
            }
            case 'EnablePartDragger': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyPartDragger();
                if (thisWidget.thingViewControls) {
                    thisWidget.rightWidgetPane.setPartDraggerButtonStatus();
                }
                break;
            }
            case 'SpinCenter': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                if (thisWidget.shapeView) {
                    var showSpinCenter = thisWidget.getProperty('SpinCenter');
                    if (showSpinCenter == undefined) showSpinCenter = false;

                    if (showSpinCenter == true) {
                        thisWidget.shapeView.ShowSpinCenter(true);
                    } else if (showSpinCenter == false) {
                        thisWidget.shapeView.ShowSpinCenter(false);
                    }
                }
                break;
            }
            case 'WindchillSourceData': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                break;
            }
            case 'ProjectionMode': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyProjection();
                break;
            }
            case 'PerspectiveHFOV': {
                this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                thisWidget.ApplyProjection();
                break;
            }
        }
    }

    this.GetViewLocation = function() {
        if (thisWidget.shapeView) {
            var loc = thisWidget.shapeView.GetViewLocation();

            loc.position.x = Number(loc.position.x.toFixed(6));
            loc.position.y = Number(loc.position.y.toFixed(6));
            loc.position.z = Number(loc.position.z.toFixed(6));

            loc.orientation.x = Number(loc.orientation.x.toFixed(3));
            loc.orientation.y = Number(loc.orientation.y.toFixed(3));
            loc.orientation.z = Number(loc.orientation.z.toFixed(3));

            thisWidget.setProperty('Position', loc.position.x + ',' + loc.position.y + ',' + loc.position.z);
            thisWidget.setProperty('Orientation', loc.orientation.x + ',' + loc.orientation.y + ',' + loc.orientation.z);
        }
    }

    this.SetViewLocation = function() {
        if (thisWidget.shapeView) {
            var orientation = thisWidget.getProperty('Orientation');
            var orientArray = orientation.split(',');
            var position = thisWidget.getProperty('Position');
            var posArray = position.split(',');

            if (orientArray.length == 3 && posArray.length == 3) {
                var loc = new Object();
                loc.position = {
                    x: Number(posArray[0]),
                    y: Number(posArray[1]),
                    z: Number(posArray[2])
                };
                loc.orientation = {
                    x: Number(orientArray[0]),
                    y: Number(orientArray[1]),
                    z: Number(orientArray[2]) 
                };
                loc.scale = { x: 1.0, y: 1.0, z: 1.0 };
                loc.size  = { x: 1.0, y: 1.0, z: 1.0 };
                loc.valid = true;
                
                thisWidget.shapeView.SetViewLocation(loc);
            }
        }
    }

    this.LoadIllustration = function(name, callback) {
        if (thisWidget.model) {
            thisWidget.model.LoadIllustrationWithCallback(
                unescape(encodeURIComponent(name)),
                function(success, pviFile, stepInfoVec) {
                    if (success === true) {
                        TW.log.info("OnLoadIllustrationComplete");
                        if (thisWidget.model.HasAnimation())
                            thisWidget.jqElement.triggerHandler('HasAnimation');
                        if (thisWidget.model.HasSequence()) {
                            thisWidget.jqElement.triggerHandler('HasSequence');
                            thisWidget.setProperty('SequenceStepNumber', '0');
                        }
                        if (callback) callback();
                    } else {
                        TW.log.error("OnLoadIllustrationError");
                    }
                }
            );
        } else {
            TW.log.error("OnLoadViewStateError - Model does not exist.");
        }
    }

    this.LoadViewState = function(name, path) {
        if (thisWidget.model) {
            thisWidget.model.LoadViewStateWithCallback(
                unescape(encodeURIComponent(name)), path,
                function (success, _name) {
                    if (success === true) {
                        TW.log.info("OnLoadViewStateComplete");
                    } else {
                        TW.log.error("OnLoadViewStateError");
                    }
                }
            );
        } else {
            TW.log.error("OnLoadViewStateError - Model does not exist.");
        }
    }

    this.parseRGBA = function (color) {
        var colorParts;
        var parsedColor = color.replace(/\s\s*/g, ''); // Remove all spaces

	     // Checks for 6 digit hex and converts string to integer
	     if (colorParts = /^#([\da-fA-F]{2})([\da-fA-F]{2})([\da-fA-F]{2})/.exec(parsedColor))
	         colorParts = [parseInt(colorParts[1], 16), parseInt(colorParts[2], 16), parseInt(colorParts[3], 16)];

	     // Checks for 3 digit hex and converts string to integer
	     else if (colorParts = /^#([\da-fA-F])([\da-fA-F])([\da-fA-F])/.exec(parsedColor))
	         colorParts = [parseInt(colorParts[1], 16) * 17, parseInt(colorParts[2], 16) * 17, parseInt(colorParts[3], 16) * 17];

	     // Checks for rgba and converts string to
	     // integer/float using unary + operator to save bytes
	     else if (colorParts = /^rgba\(([\d]+),([\d]+),([\d]+),([\d]+|[\d]*.[\d]+)\)/.exec(parsedColor))
	         colorParts = [+colorParts[1], +colorParts[2], +colorParts[3], +colorParts[4]];

	     // Checks for rgb and converts string to
	     // integer/float using unary + operator to save bytes
	     else if (colorParts = /^rgb\(([\d]+),([\d]+),([\d]+)\)/.exec(parsedColor))
	         colorParts = [+colorParts[1], +colorParts[2], +colorParts[3]];

	     // Otherwise throw an exception to make debugging easier
	     else
	    	 colorParts = [0,0,0,1];

	     // Performs RGBA conversion by default
	     isNaN(colorParts[3]) && (colorParts[3] = 1);

         if (colorParts[0] != 0)
             colorParts[0] = colorParts[0] / 255;
         if (colorParts[1] != 0)
             colorParts[1] = colorParts[1] / 255;
         if (colorParts[2] != 0)
             colorParts[2] = colorParts[2] / 255;
	     // Adds or removes 4th value based on rgba support
	     // Support is flipped twice to prevent erros if
	     // it's not defined
	     return colorParts;
	};

    this.serviceInvoked = function (serviceName) {
        if (serviceName === 'GetViewLocation') {
            thisWidget.GetViewLocation();
        } else if (serviceName === 'SetViewLocation') {
            thisWidget.SetViewLocation();
        } else if (serviceName === 'ZoomAll') {
            thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
        } else if (serviceName === 'ZoomSelected') {
            thisWidget.shapeView.ZoomView(Module.ZoomMode.ZOOM_SELECTED, 1000.0);
        } else if (serviceName === 'PlaySequenceStep') {
            if (thisWidget.playPosition === 'END') {
                var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
            } else {
                thisWidget.model.PlaySequenceStep();
            }
        } else if (serviceName === 'PauseSequence') {
            thisWidget.model.PauseSequence();
        } else if (serviceName === 'StopSequence') {
            thisWidget.model.StopSequence();
        } else if (serviceName === 'RewindSequence') {
            thisWidget.model.GoToSequenceStep(0, Module.SequencePlayPosition.START, false);
        } else if (serviceName === 'NextSequenceStep') {
            var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
            if (thisWidget.playState === "playing")
                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, true);
            else
                thisWidget.model.GoToSequenceStep(currentStep + 1, Module.SequencePlayPosition.START, false);
        } else if (serviceName === 'PrevSequenceStep') {
            var currentStep = Number(thisWidget.getProperty('SequenceStepNumber'));
            if (thisWidget.playState === "stopped") {
                thisWidget.model.GoToSequenceStep(currentStep - 1, Module.SequencePlayPosition.START, false);
            } else if (thisWidget.playState === "playing") {
                thisWidget.model.GoToSequenceStep(currentStep, Module.SequencePlayPosition.START, true);
            }
        } else if (serviceName === 'PlayAnimation') {
            thisWidget.model.PlayAnimation();
        } else if (serviceName === 'PauseAnimation') {
            thisWidget.model.PauseAnimation();
        } else if (serviceName === 'StopAnimation') {
            thisWidget.model.StopAnimation();
        } else {
            TW.log.error('thingview widget, unexpected serviceName invoked "' + serviceName + '"');
        }
    }

    this.beforeDestroy = function() {
        if (thisWidget.shapeScene !== undefined)
            thisWidget.shapeScene.UnRegisterSelectionObserver();
        thisWidget.UnloadModel();
        if (thisWidget.session !== undefined) {
            ThingView.DeleteSession(thisWidget.thingViewId);
        }
        thisWidget.session = undefined;
        TW.log.info('Thing View Widget .beforeDestroy');
        if (thisWidget.jqElement) {
            thisWidget.jqElement.find('img').unbind('click');
        }
        thisWidget.reverseidMap = null;
        thisWidget.formatter = null;
        thisWidget.localData = null;
        thisWidget = null;
    }
}

!(function (jQuery, document) {
    "use strict";

    var pluginName = "scrollable",
        defaults = {
            containerClass: "scrollable-container",
            containerNoScrollLeftClass: "scrollable-container-noscroll-left",
            containerNoScrollRightClass: "scrollable-container-noscroll-right",
            contentLeftClass: "scrollable-content-left",
            contentRightClass: "scrollable-content-right",
            scrollbarContainerLeftClass: "scrollable-scrollbar-container-left",
            scrollbarContainerRightClass: "scrollable-scrollbar-container-right",
            scrollBarLeftClass: "scrollable-scrollbar-left",
            scrollBarRightClass: "scrollable-scrollbar-right",
            scrollBarBGClass: "scrollable-scrollbar-background"
        };

    function Plugin(element, options) {
        this.element = element;
        this.settings = jQuery.extend({}, defaults, options);
        this.init();
    }

    jQuery.extend(Plugin.prototype, {
        init: function () {
            this.addScrollbar();
            this.addEvents();
            this.onResize();
        },
        addScrollbar: function () {
            jQuery(this.element).addClass(this.settings.containerClass);
            if (this.settings.pos == 'left') {
                this.wrapper = jQuery("<div class='" + this.settings.contentLeftClass + "' />");
            } else {
                this.wrapper = jQuery("<div class='" + this.settings.contentRightClass + "' />");
            }
            
            this.wrapper.append(jQuery(this.element).contents());
            jQuery(this.element).append(this.wrapper);

            if (this.settings.pos == 'left') {
                this.scrollbarContainer = jQuery("<div class='" + this.settings.scrollbarContainerLeftClass + "' />");
                this.scrollBar = jQuery("<div class='" + this.settings.scrollBarLeftClass + "' />");
            } else {
                this.scrollbarContainer = jQuery("<div class='" + this.settings.scrollbarContainerRightClass + "' />");
                this.scrollBar = jQuery("<div class='" + this.settings.scrollBarRightClass + "' />");
            }
            
            this.scrollBarBG = jQuery("<div class='" + this.settings.scrollBarBGClass + "' />");
            this.scrollbarContainer.append(this.scrollBar);
            this.scrollbarContainer.append(this.scrollBarBG);
            jQuery(this.element).prepend(this.scrollbarContainer);
        },
        addEvents: function () {
            this.wrapper.on("scroll." + pluginName, jQuery.proxy(this.onScroll, this));
            this.scrollBar.on('mousedown.' + pluginName, jQuery.proxy(this.onMousedown, this));
            this.scrollBar.on('touchstart.' + pluginName, jQuery.proxy(this.onTouchstart, this));

            this.scrollbarContainer.on('wheel.' + pluginName, jQuery.proxy(this.onWheel, this));
        },

        onTouchstart: function (ev) {
            var me = this;

            ev.preventDefault();
            var y = me.scrollBar[0].offsetTop;

            var onMove = function (end) {
                var delta = end.touches[0].pageY - ev.touches[0].pageY;
                me.scrollBar[0].style.top = Math.min(me.scrollbarContainer[0].clientHeight - me.scrollBar[0].clientHeight, Math.max(0, y + delta)) + 'px';
                me.wrapper[0].scrollTop = (me.wrapper[0].scrollHeight * me.scrollBar[0].offsetTop / me.scrollbarContainer[0].clientHeight);
            };

            jQuery(document).on("touchmove." + pluginName, onMove);
            jQuery(document).on("touchend." + pluginName, function () {
                jQuery(document).off("touchmove." + pluginName);
                jQuery(document).off("touchend." + pluginName);
            });
        },

        onMousedown: function (ev) {
            var me = this;

            ev.preventDefault();
            var y = me.scrollBar[0].offsetTop;

            var onMove = function (end) {
                var delta = end.pageY - ev.pageY;
                me.scrollBar[0].style.top = Math.min(me.scrollbarContainer[0].clientHeight - me.scrollBar[0].clientHeight, Math.max(0, y + delta)) + 'px';
                me.wrapper[0].scrollTop = (me.wrapper[0].scrollHeight * me.scrollBar[0].offsetTop / me.scrollbarContainer[0].clientHeight);
            };

            jQuery(document).on("mousemove." + pluginName, onMove);
            jQuery(document).on("mouseup." + pluginName, function () {
                jQuery(document).off("mousemove." + pluginName);
                jQuery(document).off("mouseup." + pluginName);
            });
        },

        onResize: function () {
            this.wrapper.css("max-height", jQuery(this.element).height());
            var wrapper_client_height = this.wrapper[0].clientHeight;
            this.scrollBar.css("height", this.scrollbarContainer[0].clientHeight * wrapper_client_height / this.wrapper[0].scrollHeight + "px");
            if (this.scrollbarContainer[0].clientHeight <= this.scrollBar[0].clientHeight) {
                if (this.settings.pos == 'left') {
                    if (this.settings.jqe) {
                        this.settings.jqe.find('.leftPaneViewableItem').removeClass('leftPaneViewableItemShort');
                    }
                    jQuery(this.element).addClass(this.settings.containerNoScrollLeftClass);
                } else {
                    jQuery(this.element).find('.radialButton').removeClass('rightPaneButtonsMoved');
                    jQuery(this.element).addClass(this.settings.containerNoScrollRightClass);
                }
            } else {
                if (this.settings.pos == 'left') {
                    if (this.settings.jqe) {
                        this.settings.jqe.find('.leftPaneViewableItem').addClass('leftPaneViewableItemShort');
                    }
                    jQuery(this.element).removeClass(this.settings.containerNoScrollLeftClass);
                } else {
                    jQuery(this.element).find('.radialButton').addClass('rightPaneButtonsMoved');
                    jQuery(this.element).removeClass(this.settings.containerNoScrollRightClass);
                }
            }

            this.onScroll();
        },

        onScroll: function () {
            this.scrollBar.css("top",
                               Math.min(this.scrollbarContainer[0].clientHeight - this.scrollBar[0].clientHeight,
                                        this.scrollbarContainer[0].clientHeight * this.wrapper[0].scrollTop / this.wrapper[0].scrollHeight) + "px");
        },

        onWheel: function (ev) {
            var me = this;

            ev.preventDefault();
            var y = me.scrollBar[0].offsetTop;
            var delta = ev.originalEvent.deltaY > 0 ? 10 : -10;

            me.scrollBar[0].style.top = Math.min(me.scrollbarContainer[0].clientHeight - me.scrollBar[0].clientHeight, Math.max(0, y + delta)) + 'px';
            me.wrapper[0].scrollTop = (me.wrapper[0].scrollHeight * me.scrollBar[0].offsetTop / me.scrollbarContainer[0].clientHeight);
        }
    });

    jQuery.fn[pluginName] = function (options) {
        var plugin = new Plugin(this, options);
        jQuery.data(this, "plugin_" + pluginName, plugin);
        return plugin;
    };
})(jQuery, document);