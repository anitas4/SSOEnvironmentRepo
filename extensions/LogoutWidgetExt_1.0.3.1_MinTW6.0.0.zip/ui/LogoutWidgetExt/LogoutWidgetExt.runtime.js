﻿/*global Encoder,TW */

(function () {
    var addedDefaultButtonStyles = false;

    TW.Runtime.Widgets.LogoutWidgetExt = function () {
        var thisWidget = this;

		this.runtimeProperties = function () {
		    return {
		        'needsDataLoadingAndError': false,
		        'propertyAttributes': {
		            'selector': {
		                'isLocalizable': false
		            }
		        }
		    };
		};

        this.renderHtml = function () {
            var html =
                '<div class="widget-content GreyoutContent">'
                + '</div>';
            return html;
        };

        this.renderStyles = function () {
        };

        this.afterRender = function () {
        };

        this.beforeDestroy = function () {
            try {
                $("#tiptip_holder").remove();
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.button.beforeDestroy', err);
            }
        };

        this.serviceInvoked = function (serviceName) {
            var widgetElement = this.jqElement;
            var widgetReference = this;
            var destination = widgetReference.getProperty("redirectURL");
            
            if (serviceName === 'Navigate') {
                var logoutInvoker = new ThingworxInvoker({
                    entityType: "Server",
                    entityName: "*",
                    apiMethod: "POST",
                    characteristic: "Services",
                    target: "Logout"
                  });
                  logoutInvoker.invokeService(function () {
                    window.location.href = destination;
                  }, function () {
                    alert('Failed to log out');
                  });
            } else {
              TW.log.error('Link widget, unexpected serviceName invoked "' + serviceName + '"');
            }
          };

		this.updateProperty = function (updatePropertyInfo) {
			if (updatePropertyInfo.TargetProperty === '') {
				
			}
		};
    };
}());