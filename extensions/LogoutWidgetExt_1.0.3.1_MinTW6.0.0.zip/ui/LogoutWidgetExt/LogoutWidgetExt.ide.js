﻿/*global Encoder,TW */

TW.IDE.Widgets.LogoutWidgetExt = function () {
    var roundedCorners = true;
    this.widgetProperties = function () {
        return {
            'name': 'LogoutWidgetExt',
            'description': 'Log out a user by by a click or upon an event',
            'category': ['Common'],
            'iconImage': 'LogoutWidgetExt.ide.png',
            'properties': {
                'Width': {
                    'description': 'Width of widget',
                    'baseType': 'NUMBER',
                    'defaultValue': 75
                },
                'Height': {
                    'description': 'Height of widget',
                    'baseType': 'NUMBER',
                    'defaultValue': 30
                },
                'BGColor': {
                    'description': 'Back ground color',
                    'baseType': 'STRING',
                    'defaultValue': 'grey'
                },
                'redirectURL': {
                    'description': 'URL of the location where the page should navigate upon logout',
                    'baseType': 'STRING',
                    'defaultValue': ''
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
            'Clicked': { 'warnIfNotBound': true }
        };
    };

    this.widgetIconUrl = function () {
        return  "../Common/extensions/LogoutWidgetExt/ui/LogoutWidgetExt/images/LogoutWidgetExt.ide.png";
    };
    
    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Label' :
            case 'Style':
            case 'Width':
            case 'Height':
            case 'RoundedCorners':
            case 'HoverStyle':
            case 'IconAlignment':
                result = true;
                break;
            default:
                break;
        }
        return result;
    };


    this.renderHtml = function () {
        html = '<div class="widget-content LogoutWidgetExt">' + '</div>';
        return html;
    };
    
    this.afterRender = function () {
        var thisWidget = this;
        thisWidget.jqElementId.css({'background-color' : thisWidget.getProperty("BGColor")});
    };

    this.widgetServices = function () {
        return {
            'Navigate': { 'warnIfNotBound': false }
        };
    };

    this.widgetEvents = function () {
        return {
        	'Clicked' : { 'warnIfNotBound': false }
        };
    };
};